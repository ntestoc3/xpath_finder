// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex_sample.background.storage');
goog.require('cljs.core');
goog.require('cljs.core.async');
goog.require('chromex.logging');
goog.require('chromex.protocols.chrome_storage_area');
goog.require('chromex.ext.storage');
chromex_sample.background.storage.test_storage_BANG_ = (function chromex_sample$background$storage$test_storage_BANG_(){
var local_storage = chromex.ext.storage.local_STAR_.call(null,chromex.config.get_active_config.call(null));
chromex.protocols.chrome_storage_area.set.call(null,local_storage,({"key1": "string", "key2": [(1),(2),(3)], "key3": true, "key4": null}));

var c__27715__auto___50209 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_50135){
var state_val_50136 = (state_50135[(1)]);
if((state_val_50136 === (1))){
var inst_50122 = chromex.protocols.chrome_storage_area.get.call(null,local_storage);
var state_50135__$1 = state_50135;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_50135__$1,(2),inst_50122);
} else {
if((state_val_50136 === (2))){
var inst_50127 = (state_50135[(7)]);
var inst_50124 = (state_50135[(2)]);
var inst_50125 = cljs.core.nth.call(null,inst_50124,(0),null);
var inst_50126 = cljs.core.nth.call(null,inst_50125,(0),null);
var inst_50127__$1 = cljs.core.nth.call(null,inst_50124,(1),null);
var state_50135__$1 = (function (){var statearr_50137 = state_50135;
(statearr_50137[(8)] = inst_50126);

(statearr_50137[(7)] = inst_50127__$1);

return statearr_50137;
})();
if(cljs.core.truth_(inst_50127__$1)){
var statearr_50138_50210 = state_50135__$1;
(statearr_50138_50210[(1)] = (3));

} else {
var statearr_50139_50211 = state_50135__$1;
(statearr_50139_50211[(1)] = (4));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_50136 === (3))){
var inst_50127 = (state_50135[(7)]);
var inst_50129 = inst_50127.call(null,"fetch all error:",inst_50127);
var state_50135__$1 = state_50135;
var statearr_50140_50212 = state_50135__$1;
(statearr_50140_50212[(2)] = inst_50129);

(statearr_50140_50212[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_50136 === (4))){
var inst_50126 = (state_50135[(8)]);
var inst_50131 = console.log("fetch all:",inst_50126);
var state_50135__$1 = (function (){var statearr_50141 = state_50135;
(statearr_50141[(9)] = inst_50131);

return statearr_50141;
})();
var statearr_50142_50213 = state_50135__$1;
(statearr_50142_50213[(2)] = null);

(statearr_50142_50213[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_50136 === (5))){
var inst_50133 = (state_50135[(2)]);
var state_50135__$1 = state_50135;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_50135__$1,inst_50133);
} else {
return null;
}
}
}
}
}
});
return (function() {
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__ = null;
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____0 = (function (){
var statearr_50143 = [null,null,null,null,null,null,null,null,null,null];
(statearr_50143[(0)] = chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__);

(statearr_50143[(1)] = (1));

return statearr_50143;
});
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____1 = (function (state_50135){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_50135);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e50144){if((e50144 instanceof Object)){
var ex__27528__auto__ = e50144;
var statearr_50145_50214 = state_50135;
(statearr_50145_50214[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_50135);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e50144;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__50215 = state_50135;
state_50135 = G__50215;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__ = function(state_50135){
switch(arguments.length){
case 0:
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____0.call(this);
case 1:
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____1.call(this,state_50135);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____0;
chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____1;
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_50146 = f__27716__auto__.call(null);
(statearr_50146[(6)] = c__27715__auto___50209);

return statearr_50146;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


var c__27715__auto___50216 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_50166){
var state_val_50167 = (state_50166[(1)]);
if((state_val_50167 === (1))){
var inst_50153 = chromex.protocols.chrome_storage_area.get.call(null,local_storage,"key1");
var state_50166__$1 = state_50166;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_50166__$1,(2),inst_50153);
} else {
if((state_val_50167 === (2))){
var inst_50158 = (state_50166[(7)]);
var inst_50155 = (state_50166[(2)]);
var inst_50156 = cljs.core.nth.call(null,inst_50155,(0),null);
var inst_50157 = cljs.core.nth.call(null,inst_50156,(0),null);
var inst_50158__$1 = cljs.core.nth.call(null,inst_50155,(1),null);
var state_50166__$1 = (function (){var statearr_50168 = state_50166;
(statearr_50168[(8)] = inst_50157);

(statearr_50168[(7)] = inst_50158__$1);

return statearr_50168;
})();
if(cljs.core.truth_(inst_50158__$1)){
var statearr_50169_50217 = state_50166__$1;
(statearr_50169_50217[(1)] = (3));

} else {
var statearr_50170_50218 = state_50166__$1;
(statearr_50170_50218[(1)] = (4));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_50167 === (3))){
var inst_50158 = (state_50166[(7)]);
var inst_50160 = inst_50158.call(null,"fetch key1 error:",inst_50158);
var state_50166__$1 = state_50166;
var statearr_50171_50219 = state_50166__$1;
(statearr_50171_50219[(2)] = inst_50160);

(statearr_50171_50219[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_50167 === (4))){
var inst_50157 = (state_50166[(8)]);
var inst_50162 = console.log("fetch key1:",inst_50157);
var state_50166__$1 = (function (){var statearr_50172 = state_50166;
(statearr_50172[(9)] = inst_50162);

return statearr_50172;
})();
var statearr_50173_50220 = state_50166__$1;
(statearr_50173_50220[(2)] = null);

(statearr_50173_50220[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_50167 === (5))){
var inst_50164 = (state_50166[(2)]);
var state_50166__$1 = state_50166;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_50166__$1,inst_50164);
} else {
return null;
}
}
}
}
}
});
return (function() {
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__ = null;
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____0 = (function (){
var statearr_50174 = [null,null,null,null,null,null,null,null,null,null];
(statearr_50174[(0)] = chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__);

(statearr_50174[(1)] = (1));

return statearr_50174;
});
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____1 = (function (state_50166){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_50166);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e50175){if((e50175 instanceof Object)){
var ex__27528__auto__ = e50175;
var statearr_50176_50221 = state_50166;
(statearr_50176_50221[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_50166);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e50175;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__50222 = state_50166;
state_50166 = G__50222;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__ = function(state_50166){
switch(arguments.length){
case 0:
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____0.call(this);
case 1:
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____1.call(this,state_50166);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____0;
chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____1;
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_50177 = f__27716__auto__.call(null);
(statearr_50177[(6)] = c__27715__auto___50216);

return statearr_50177;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


var c__27715__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_50197){
var state_val_50198 = (state_50197[(1)]);
if((state_val_50198 === (1))){
var inst_50184 = chromex.protocols.chrome_storage_area.get.call(null,local_storage,["key2","key3"]);
var state_50197__$1 = state_50197;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_50197__$1,(2),inst_50184);
} else {
if((state_val_50198 === (2))){
var inst_50189 = (state_50197[(7)]);
var inst_50186 = (state_50197[(2)]);
var inst_50187 = cljs.core.nth.call(null,inst_50186,(0),null);
var inst_50188 = cljs.core.nth.call(null,inst_50187,(0),null);
var inst_50189__$1 = cljs.core.nth.call(null,inst_50186,(1),null);
var state_50197__$1 = (function (){var statearr_50199 = state_50197;
(statearr_50199[(8)] = inst_50188);

(statearr_50199[(7)] = inst_50189__$1);

return statearr_50199;
})();
if(cljs.core.truth_(inst_50189__$1)){
var statearr_50200_50223 = state_50197__$1;
(statearr_50200_50223[(1)] = (3));

} else {
var statearr_50201_50224 = state_50197__$1;
(statearr_50201_50224[(1)] = (4));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_50198 === (3))){
var inst_50189 = (state_50197[(7)]);
var inst_50191 = inst_50189.call(null,"fetch key2 and key3 error:",inst_50189);
var state_50197__$1 = state_50197;
var statearr_50202_50225 = state_50197__$1;
(statearr_50202_50225[(2)] = inst_50191);

(statearr_50202_50225[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_50198 === (4))){
var inst_50188 = (state_50197[(8)]);
var inst_50193 = console.log("fetch key2 and key3:",inst_50188);
var state_50197__$1 = (function (){var statearr_50203 = state_50197;
(statearr_50203[(9)] = inst_50193);

return statearr_50203;
})();
var statearr_50204_50226 = state_50197__$1;
(statearr_50204_50226[(2)] = null);

(statearr_50204_50226[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_50198 === (5))){
var inst_50195 = (state_50197[(2)]);
var state_50197__$1 = state_50197;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_50197__$1,inst_50195);
} else {
return null;
}
}
}
}
}
});
return (function() {
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__ = null;
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____0 = (function (){
var statearr_50205 = [null,null,null,null,null,null,null,null,null,null];
(statearr_50205[(0)] = chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__);

(statearr_50205[(1)] = (1));

return statearr_50205;
});
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____1 = (function (state_50197){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_50197);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e50206){if((e50206 instanceof Object)){
var ex__27528__auto__ = e50206;
var statearr_50207_50227 = state_50197;
(statearr_50207_50227[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_50197);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e50206;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__50228 = state_50197;
state_50197 = G__50228;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__ = function(state_50197){
switch(arguments.length){
case 0:
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____0.call(this);
case 1:
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____1.call(this,state_50197);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____0;
chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto____1;
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_50208 = f__27716__auto__.call(null);
(statearr_50208[(6)] = c__27715__auto__);

return statearr_50208;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));

return c__27715__auto__;
});

//# sourceMappingURL=storage.js.map
