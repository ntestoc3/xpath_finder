// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex_sample.background.core');
goog.require('cljs.core');
goog.require('goog.string');
goog.require('goog.string.format');
goog.require('cljs.core.async');
goog.require('chromex.logging');
goog.require('chromex.chrome_event_channel');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.ext.tabs');
goog.require('chromex.ext.runtime');
goog.require('chromex_sample.background.storage');
chromex_sample.background.core.clients = cljs.core.atom.call(null,cljs.core.PersistentVector.EMPTY);
chromex_sample.background.core.add_client_BANG_ = (function chromex_sample$background$core$add_client_BANG_(client){
console.log("BACKGROUND: client connected",chromex.protocols.chrome_port.get_sender.call(null,client));


return cljs.core.swap_BANG_.call(null,chromex_sample.background.core.clients,cljs.core.conj,client);
});
chromex_sample.background.core.remove_client_BANG_ = (function chromex_sample$background$core$remove_client_BANG_(client){
console.log("BACKGROUND: client disconnected",chromex.protocols.chrome_port.get_sender.call(null,client));


var remove_item = (function (coll,item){
return cljs.core.remove.call(null,(function (p1__52567_SHARP_){
return (item === p1__52567_SHARP_);
}),coll);
});
return cljs.core.swap_BANG_.call(null,chromex_sample.background.core.clients,remove_item,client);
});
chromex_sample.background.core.run_client_message_loop_BANG_ = (function chromex_sample$background$core$run_client_message_loop_BANG_(client){
console.log("BACKGROUND: starting event loop for client:",chromex.protocols.chrome_port.get_sender.call(null,client));


var c__27715__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_52585){
var state_val_52586 = (state_52585[(1)]);
if((state_val_52586 === (1))){
var state_52585__$1 = state_52585;
var statearr_52587_52600 = state_52585__$1;
(statearr_52587_52600[(2)] = null);

(statearr_52587_52600[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52586 === (2))){
var state_52585__$1 = state_52585;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_52585__$1,(4),client);
} else {
if((state_val_52586 === (3))){
var inst_52583 = (state_52585[(2)]);
var state_52585__$1 = state_52585;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_52585__$1,inst_52583);
} else {
if((state_val_52586 === (4))){
var inst_52570 = (state_52585[(7)]);
var inst_52570__$1 = (state_52585[(2)]);
var inst_52571 = (inst_52570__$1 == null);
var state_52585__$1 = (function (){var statearr_52588 = state_52585;
(statearr_52588[(7)] = inst_52570__$1);

return statearr_52588;
})();
if(cljs.core.truth_(inst_52571)){
var statearr_52589_52601 = state_52585__$1;
(statearr_52589_52601[(1)] = (5));

} else {
var statearr_52590_52602 = state_52585__$1;
(statearr_52590_52602[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52586 === (5))){
var state_52585__$1 = state_52585;
var statearr_52591_52603 = state_52585__$1;
(statearr_52591_52603[(2)] = null);

(statearr_52591_52603[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52586 === (6))){
var inst_52570 = (state_52585[(7)]);
var inst_52574 = chromex.protocols.chrome_port.get_sender.call(null,client);
var inst_52575 = console.log("BACKGROUND: got client message:",inst_52570,"from",inst_52574);
var state_52585__$1 = (function (){var statearr_52592 = state_52585;
(statearr_52592[(8)] = inst_52575);

return statearr_52592;
})();
var statearr_52593_52604 = state_52585__$1;
(statearr_52593_52604[(2)] = null);

(statearr_52593_52604[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52586 === (7))){
var inst_52578 = (state_52585[(2)]);
var inst_52579 = chromex.protocols.chrome_port.get_sender.call(null,client);
var inst_52580 = console.log("BACKGROUND: leaving event loop for client:",inst_52579);
var inst_52581 = chromex_sample.background.core.remove_client_BANG_.call(null,client);
var state_52585__$1 = (function (){var statearr_52594 = state_52585;
(statearr_52594[(9)] = inst_52578);

(statearr_52594[(10)] = inst_52580);

return statearr_52594;
})();
var statearr_52595_52605 = state_52585__$1;
(statearr_52595_52605[(2)] = inst_52581);

(statearr_52595_52605[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
});
return (function() {
var chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__27525__auto__ = null;
var chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__27525__auto____0 = (function (){
var statearr_52596 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_52596[(0)] = chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__27525__auto__);

(statearr_52596[(1)] = (1));

return statearr_52596;
});
var chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__27525__auto____1 = (function (state_52585){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_52585);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e52597){if((e52597 instanceof Object)){
var ex__27528__auto__ = e52597;
var statearr_52598_52606 = state_52585;
(statearr_52598_52606[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_52585);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e52597;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__52607 = state_52585;
state_52585 = G__52607;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__27525__auto__ = function(state_52585){
switch(arguments.length){
case 0:
return chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__27525__auto____0.call(this);
case 1:
return chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__27525__auto____1.call(this,state_52585);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__27525__auto____0;
chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__27525__auto____1;
return chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_52599 = f__27716__auto__.call(null);
(statearr_52599[(6)] = c__27715__auto__);

return statearr_52599;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));

return c__27715__auto__;
});
chromex_sample.background.core.handle_client_connection_BANG_ = (function chromex_sample$background$core$handle_client_connection_BANG_(client){
chromex_sample.background.core.add_client_BANG_.call(null,client);

chromex.protocols.chrome_port.post_message_BANG_.call(null,client,"hello from BACKGROUND PAGE!");

return chromex_sample.background.core.run_client_message_loop_BANG_.call(null,client);
});
chromex_sample.background.core.tell_clients_about_new_tab_BANG_ = (function chromex_sample$background$core$tell_clients_about_new_tab_BANG_(){
var seq__52608 = cljs.core.seq.call(null,cljs.core.deref.call(null,chromex_sample.background.core.clients));
var chunk__52609 = null;
var count__52610 = (0);
var i__52611 = (0);
while(true){
if((i__52611 < count__52610)){
var client = cljs.core._nth.call(null,chunk__52609,i__52611);
chromex.protocols.chrome_port.post_message_BANG_.call(null,client,"a new tab was created");


var G__52612 = seq__52608;
var G__52613 = chunk__52609;
var G__52614 = count__52610;
var G__52615 = (i__52611 + (1));
seq__52608 = G__52612;
chunk__52609 = G__52613;
count__52610 = G__52614;
i__52611 = G__52615;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq.call(null,seq__52608);
if(temp__5735__auto__){
var seq__52608__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__52608__$1)){
var c__4609__auto__ = cljs.core.chunk_first.call(null,seq__52608__$1);
var G__52616 = cljs.core.chunk_rest.call(null,seq__52608__$1);
var G__52617 = c__4609__auto__;
var G__52618 = cljs.core.count.call(null,c__4609__auto__);
var G__52619 = (0);
seq__52608 = G__52616;
chunk__52609 = G__52617;
count__52610 = G__52618;
i__52611 = G__52619;
continue;
} else {
var client = cljs.core.first.call(null,seq__52608__$1);
chromex.protocols.chrome_port.post_message_BANG_.call(null,client,"a new tab was created");


var G__52620 = cljs.core.next.call(null,seq__52608__$1);
var G__52621 = null;
var G__52622 = (0);
var G__52623 = (0);
seq__52608 = G__52620;
chunk__52609 = G__52621;
count__52610 = G__52622;
i__52611 = G__52623;
continue;
}
} else {
return null;
}
}
break;
}
});
chromex_sample.background.core.process_chrome_event = (function chromex_sample$background$core$process_chrome_event(event_num,event){
console.log(goog.string.format("BACKGROUND: got chrome event (%05d)",event_num),event);


var vec__52624 = event;
var event_id = cljs.core.nth.call(null,vec__52624,(0),null);
var event_args = cljs.core.nth.call(null,vec__52624,(1),null);
var G__52627 = event_id;
var G__52627__$1 = (((G__52627 instanceof cljs.core.Keyword))?G__52627.fqn:null);
switch (G__52627__$1) {
case "chromex.ext.runtime/on-connect":
return cljs.core.apply.call(null,chromex_sample.background.core.handle_client_connection_BANG_,event_args);

break;
case "chromex.ext.tabs/on-created":
return chromex_sample.background.core.tell_clients_about_new_tab_BANG_.call(null);

break;
default:
return null;

}
});
chromex_sample.background.core.run_chrome_event_loop_BANG_ = (function chromex_sample$background$core$run_chrome_event_loop_BANG_(chrome_event_channel){
console.log("BACKGROUND: starting main event loop...");


var c__27715__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_52645){
var state_val_52646 = (state_52645[(1)]);
if((state_val_52646 === (1))){
var inst_52629 = (1);
var state_52645__$1 = (function (){var statearr_52647 = state_52645;
(statearr_52647[(7)] = inst_52629);

return statearr_52647;
})();
var statearr_52648_52661 = state_52645__$1;
(statearr_52648_52661[(2)] = null);

(statearr_52648_52661[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52646 === (2))){
var state_52645__$1 = state_52645;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_52645__$1,(4),chrome_event_channel);
} else {
if((state_val_52646 === (3))){
var inst_52643 = (state_52645[(2)]);
var state_52645__$1 = state_52645;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_52645__$1,inst_52643);
} else {
if((state_val_52646 === (4))){
var inst_52632 = (state_52645[(8)]);
var inst_52632__$1 = (state_52645[(2)]);
var inst_52633 = (inst_52632__$1 == null);
var state_52645__$1 = (function (){var statearr_52649 = state_52645;
(statearr_52649[(8)] = inst_52632__$1);

return statearr_52649;
})();
if(cljs.core.truth_(inst_52633)){
var statearr_52650_52662 = state_52645__$1;
(statearr_52650_52662[(1)] = (5));

} else {
var statearr_52651_52663 = state_52645__$1;
(statearr_52651_52663[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52646 === (5))){
var state_52645__$1 = state_52645;
var statearr_52652_52664 = state_52645__$1;
(statearr_52652_52664[(2)] = null);

(statearr_52652_52664[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52646 === (6))){
var inst_52629 = (state_52645[(7)]);
var inst_52632 = (state_52645[(8)]);
var inst_52636 = chromex_sample.background.core.process_chrome_event.call(null,inst_52629,inst_52632);
var inst_52637 = (inst_52629 + (1));
var inst_52629__$1 = inst_52637;
var state_52645__$1 = (function (){var statearr_52653 = state_52645;
(statearr_52653[(7)] = inst_52629__$1);

(statearr_52653[(9)] = inst_52636);

return statearr_52653;
})();
var statearr_52654_52665 = state_52645__$1;
(statearr_52654_52665[(2)] = null);

(statearr_52654_52665[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52646 === (7))){
var inst_52640 = (state_52645[(2)]);
var inst_52641 = console.log("BACKGROUND: leaving main event loop");
var state_52645__$1 = (function (){var statearr_52655 = state_52645;
(statearr_52655[(10)] = inst_52641);

(statearr_52655[(11)] = inst_52640);

return statearr_52655;
})();
var statearr_52656_52666 = state_52645__$1;
(statearr_52656_52666[(2)] = null);

(statearr_52656_52666[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
});
return (function() {
var chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__27525__auto__ = null;
var chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__27525__auto____0 = (function (){
var statearr_52657 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_52657[(0)] = chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__27525__auto__);

(statearr_52657[(1)] = (1));

return statearr_52657;
});
var chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__27525__auto____1 = (function (state_52645){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_52645);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e52658){if((e52658 instanceof Object)){
var ex__27528__auto__ = e52658;
var statearr_52659_52667 = state_52645;
(statearr_52659_52667[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_52645);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e52658;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__52668 = state_52645;
state_52645 = G__52668;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__27525__auto__ = function(state_52645){
switch(arguments.length){
case 0:
return chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__27525__auto____0.call(this);
case 1:
return chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__27525__auto____1.call(this,state_52645);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__27525__auto____0;
chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__27525__auto____1;
return chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_52660 = f__27716__auto__.call(null);
(statearr_52660[(6)] = c__27715__auto__);

return statearr_52660;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));

return c__27715__auto__;
});
chromex_sample.background.core.boot_chrome_event_loop_BANG_ = (function chromex_sample$background$core$boot_chrome_event_loop_BANG_(){
var chrome_event_channel = chromex.chrome_event_channel.make_chrome_event_channel.call(null,cljs.core.async.chan.call(null));
var chan52669_52673 = chrome_event_channel;
var config52670_52674 = chromex.config.get_active_config.call(null);
chromex.ext.tabs.on_created_STAR_.call(null,config52670_52674,chan52669_52673);

chromex.ext.tabs.on_updated_STAR_.call(null,config52670_52674,chan52669_52673);

chromex.ext.tabs.on_moved_STAR_.call(null,config52670_52674,chan52669_52673);

chromex.ext.tabs.on_activated_STAR_.call(null,config52670_52674,chan52669_52673);

chromex.ext.tabs.on_highlighted_STAR_.call(null,config52670_52674,chan52669_52673);

chromex.ext.tabs.on_detached_STAR_.call(null,config52670_52674,chan52669_52673);

chromex.ext.tabs.on_attached_STAR_.call(null,config52670_52674,chan52669_52673);

chromex.ext.tabs.on_removed_STAR_.call(null,config52670_52674,chan52669_52673);

chromex.ext.tabs.on_replaced_STAR_.call(null,config52670_52674,chan52669_52673);

chromex.ext.tabs.on_zoom_change_STAR_.call(null,config52670_52674,chan52669_52673);

var chan52671_52675 = chrome_event_channel;
var config52672_52676 = chromex.config.get_active_config.call(null);
chromex.ext.runtime.on_startup_STAR_.call(null,config52672_52676,chan52671_52675);

chromex.ext.runtime.on_installed_STAR_.call(null,config52672_52676,chan52671_52675);

chromex.ext.runtime.on_suspend_STAR_.call(null,config52672_52676,chan52671_52675);

chromex.ext.runtime.on_suspend_canceled_STAR_.call(null,config52672_52676,chan52671_52675);

chromex.ext.runtime.on_update_available_STAR_.call(null,config52672_52676,chan52671_52675);

chromex.ext.runtime.on_connect_STAR_.call(null,config52672_52676,chan52671_52675);

chromex.ext.runtime.on_connect_external_STAR_.call(null,config52672_52676,chan52671_52675);

chromex.ext.runtime.on_connect_native_STAR_.call(null,config52672_52676,chan52671_52675);

chromex.ext.runtime.on_message_STAR_.call(null,config52672_52676,chan52671_52675);

chromex.ext.runtime.on_message_external_STAR_.call(null,config52672_52676,chan52671_52675);

chromex.ext.runtime.on_restart_required_STAR_.call(null,config52672_52676,chan52671_52675);

return chromex_sample.background.core.run_chrome_event_loop_BANG_.call(null,chrome_event_channel);
});
chromex_sample.background.core.init_BANG_ = (function chromex_sample$background$core$init_BANG_(){
console.log("BACKGROUND: start ");


chromex_sample.background.storage.test_storage_BANG_.call(null);

return chromex_sample.background.core.boot_chrome_event_loop_BANG_.call(null);
});

//# sourceMappingURL=core.js.map
