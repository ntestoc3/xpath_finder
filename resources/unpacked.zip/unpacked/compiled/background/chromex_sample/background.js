// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex_sample.background');
goog.require('cljs.core');
goog.require('chromex_sample.background.core');
if((typeof chromex_sample !== 'undefined') && (typeof chromex_sample.background !== 'undefined') && (typeof chromex_sample.background.runonce_1364499943 !== 'undefined')){
} else {
chromex_sample.background.runonce_1364499943 = new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"value","value",305978217),chromex_sample.background.core.init_BANG_.call(null),new cljs.core.Keyword(null,"code","code",1586293142),"(do (core/init!))"], null);
}

//# sourceMappingURL=background.js.map
