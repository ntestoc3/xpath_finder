// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex_sample.robula');
goog.require('cljs.core');
goog.require('oops.core');
goog.require('clojure.string');
goog.require('goog.string');
goog.require('goog.string.format');
goog.require('clojure.set');
goog.require('dommy.core');
chromex_sample.robula.xpath_length = cljs.core.count;
chromex_sample.robula.xpath_head = cljs.core.first;
chromex_sample.robula.xpath_head_has_predicates_QMARK_ = (function chromex_sample$robula$xpath_head_has_predicates_QMARK_(xpath){
return clojure.string.includes_QMARK_.call(null,chromex_sample.robula.xpath_head.call(null,xpath),"[");
});
chromex_sample.robula.xpath_head_has_position_QMARK_ = (function chromex_sample$robula$xpath_head_has_position_QMARK_(xpath){
var head = chromex_sample.robula.xpath_head.call(null,xpath);
var or__4185__auto__ = clojure.string.includes_QMARK_.call(null,head,"position()");
if(or__4185__auto__){
return or__4185__auto__;
} else {
var or__4185__auto____$1 = clojure.string.includes_QMARK_.call(null,head,"last");
if(or__4185__auto____$1){
return or__4185__auto____$1;
} else {
return cljs.core.re_find.call(null,/\[[0-9]+\]/,head);
}
}
});
chromex_sample.robula.xpath_head_has_text_QMARK_ = (function chromex_sample$robula$xpath_head_has_text_QMARK_(xpath){
return clojure.string.includes_QMARK_.call(null,chromex_sample.robula.xpath_head.call(null,xpath),"text()");
});
chromex_sample.robula.xpath_head_with_all_QMARK_ = (function chromex_sample$robula$xpath_head_with_all_QMARK_(xpath){
return clojure.string.starts_with_QMARK_.call(null,chromex_sample.robula.xpath_head.call(null,xpath),"*");
});
chromex_sample.robula.xpath_add_predicate_to_head = (function chromex_sample$robula$xpath_add_predicate_to_head(xpath,predicate){
var new_head = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.first.call(null,xpath)),cljs.core.str.cljs$core$IFn$_invoke$arity$1(predicate)].join('');
return cljs.core.assoc.call(null,cljs.core.into.call(null,cljs.core.PersistentVector.EMPTY,xpath),(0),new_head);
});
chromex_sample.robula.xpath_replace_head_all = (function chromex_sample$robula$xpath_replace_head_all(xpath,head_tag){
var new_head = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(head_tag),cljs.core.subs.call(null,cljs.core.first.call(null,xpath),(1))].join('');
return cljs.core.assoc.call(null,cljs.core.into.call(null,cljs.core.PersistentVector.EMPTY,xpath),(0),new_head);
});
chromex_sample.robula.xpath_add_head_all = (function chromex_sample$robula$xpath_add_head_all(xpath){
return cljs.core.cons.call(null,"*",xpath);
});
chromex_sample.robula.xpath_empty = cljs.core.PersistentVector.EMPTY;
chromex_sample.robula.xpath_all = new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, ["*"], null);
chromex_sample.robula.xpath__GT_str = (function chromex_sample$robula$xpath__GT_str(xpath){
return ["//",clojure.string.join.call(null,"/",xpath)].join('');
});
chromex_sample.robula.get_previous_element_siblings_base = (function chromex_sample$robula$get_previous_element_siblings_base(element){
return cljs.core.take_while.call(null,cljs.core.identity,cljs.core.iterate.call(null,(function (p1__38359_SHARP_){
var target_obj_38360 = p1__38359_SHARP_;
var _STAR_runtime_state_STAR__orig_val__38362 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38363 = oops.state.prepare_state.call(null,target_obj_38360,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38363);

try{var next_obj_38361 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_38360,(0),"previousElementSibling",true,true,false))?(target_obj_38360["previousElementSibling"]):null);
return next_obj_38361;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38362);
}}),element));
});
chromex_sample.robula.get_previous_element_siblings = cljs.core.memoize.call(null,chromex_sample.robula.get_previous_element_siblings_base);
/**
 * 获取所有父级元素，包括自身
 */
chromex_sample.robula.get_all_ancestor_base = (function chromex_sample$robula$get_all_ancestor_base(element){
return cljs.core.take_while.call(null,cljs.core.identity,cljs.core.iterate.call(null,(function (p1__38364_SHARP_){
var target_obj_38365 = p1__38364_SHARP_;
var _STAR_runtime_state_STAR__orig_val__38367 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38368 = oops.state.prepare_state.call(null,target_obj_38365,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38368);

try{var next_obj_38366 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_38365,(0),"parentElement",true,true,false))?(target_obj_38365["parentElement"]):null);
return next_obj_38366;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38367);
}}),element));
});
chromex_sample.robula.get_all_ancestor = cljs.core.memoize.call(null,chromex_sample.robula.get_all_ancestor_base);
chromex_sample.robula.get_ancestor_count = (function chromex_sample$robula$get_ancestor_count(element){
return cljs.core.count.call(null,chromex_sample.robula.get_all_ancestor.call(null,element));
});
chromex_sample.robula.get_ancestor_at = (function chromex_sample$robula$get_ancestor_at(element,index){
return cljs.core.nth.call(null,chromex_sample.robula.get_all_ancestor.call(null,element),index);
});
/**
 * 获取元素的所有属性
 */
chromex_sample.robula.get_attributes = (function chromex_sample$robula$get_attributes(element){
var get_attr_kv = (function (attr){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(function (){var target_obj_38370 = attr;
var _STAR_runtime_state_STAR__orig_val__38372 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38373 = oops.state.prepare_state.call(null,target_obj_38370,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38373);

try{var next_obj_38371 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_38370,(0),"name",true,true,false))?(target_obj_38370["name"]):null);
return next_obj_38371;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38372);
}})(),(function (){var target_obj_38374 = attr;
var _STAR_runtime_state_STAR__orig_val__38376 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38377 = oops.state.prepare_state.call(null,target_obj_38374,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38377);

try{var next_obj_38375 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_38374,(0),"value",true,true,false))?(target_obj_38374["value"]):null);
return next_obj_38375;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38376);
}})()], null);
});
var attrs = (function (){var target_obj_38378 = element;
var _STAR_runtime_state_STAR__orig_val__38380 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38381 = oops.state.prepare_state.call(null,target_obj_38378,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38381);

try{var next_obj_38379 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_38378,(0),"attributes",true,true,false))?(target_obj_38378["attributes"]):null);
return next_obj_38379;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38380);
}})();
return cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.call(null,(function (p1__38369_SHARP_){
return get_attr_kv.call(null,(function (){var target_obj_38382 = attrs;
var _STAR_runtime_state_STAR__orig_val__38383 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38384 = oops.state.prepare_state.call(null,target_obj_38382,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38384);

try{return oops.core.get_selector_dynamically.call(null,target_obj_38382,cljs.core.str.cljs$core$IFn$_invoke$arity$1(p1__38369_SHARP_));
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38383);
}})());
}),cljs.core.range.call(null,(function (){var target_obj_38385 = attrs;
var _STAR_runtime_state_STAR__orig_val__38387 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38388 = oops.state.prepare_state.call(null,target_obj_38385,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38388);

try{var next_obj_38386 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_38385,(0),"length",true,true,false))?(target_obj_38385["length"]):null);
return next_obj_38386;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38387);
}})())));
});
chromex_sample.robula.tag_name = (function chromex_sample$robula$tag_name(element){
return clojure.string.lower_case.call(null,(function (){var target_obj_38389 = element;
var _STAR_runtime_state_STAR__orig_val__38391 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38392 = oops.state.prepare_state.call(null,target_obj_38389,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38392);

try{var next_obj_38390 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_38389,(0),"tagName",true,true,false))?(target_obj_38389["tagName"]):null);
return next_obj_38390;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38391);
}})());
});
chromex_sample.robula.attribute_priorization_list = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 5, ["class",null,"name",null,"value",null,"alt",null,"title",null], null), null);
chromex_sample.robula.attribute_black_list = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 10, ["width",null,"height",null,"src",null,"href",null,"style",null,"onclick",null,"onload",null,"maxlength",null,"size",null,"tabindex",null], null), null);
/**
 * 获取xpath头部的祖先元素
 */
chromex_sample.robula.get_xpath_head_ancestor = (function chromex_sample$robula$get_xpath_head_ancestor(xpath,element){
return chromex_sample.robula.get_ancestor_at.call(null,element,(chromex_sample.robula.xpath_length.call(null,xpath) - (1)));
});
/**
 * 转换xpath的*表示
 */
chromex_sample.robula.transf_convert_star = (function chromex_sample$robula$transf_convert_star(xpath,element){
var ancestor = chromex_sample.robula.get_xpath_head_ancestor.call(null,xpath,element);
if(chromex_sample.robula.xpath_head_with_all_QMARK_.call(null,xpath)){
return (new cljs.core.PersistentVector(null,1,(5),cljs.core.PersistentVector.EMPTY_NODE,[chromex_sample.robula.xpath_replace_head_all.call(null,xpath,chromex_sample.robula.tag_name.call(null,ancestor))],null));
} else {
return null;
}
});
chromex_sample.robula.max_text_length = (30);
chromex_sample.robula.xpath_trans = (function chromex_sample$robula$xpath_trans(k,v){
if(clojure.string.includes_QMARK_.call(null,v,"'")){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [goog.string.format("translate(%s,\"'\",\" \")",k),clojure.string.replace.call(null,v,"'"," ")], null);
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [k,v], null);
}
});
chromex_sample.robula.xpath_contains_trans = (function chromex_sample$robula$xpath_contains_trans(k,v){
return cljs.core.apply.call(null,goog.string.format,"contains(%s,'%s')",chromex_sample.robula.xpath_trans.call(null,k,v));
});
/**
 * 构造text表达式
 */
chromex_sample.robula.make_xpath_text_exp = (function chromex_sample$robula$make_xpath_text_exp(s){
var text_fn_name = (((cljs.core.count.call(null,s) > chromex_sample.robula.max_text_length))?goog.string.format("substring(text(),1,%d)",chromex_sample.robula.max_text_length):"text()");
var target_s = cljs.core.subs.call(null,s,(0),chromex_sample.robula.max_text_length);
return goog.string.format("[%s]",chromex_sample.robula.xpath_contains_trans.call(null,text_fn_name,target_s));
});
chromex_sample.robula.make_xpath_attr_predicate = (function chromex_sample$robula$make_xpath_attr_predicate(attr_key,value){
var k = ["@",cljs.core.str.cljs$core$IFn$_invoke$arity$1(attr_key)].join('');
if((cljs.core.count.call(null,value) > chromex_sample.robula.max_text_length)){
return chromex_sample.robula.xpath_contains_trans.call(null,k,cljs.core.subs.call(null,value,(0),chromex_sample.robula.max_text_length));
} else {
return cljs.core.apply.call(null,goog.string.format,"%s='%s'",chromex_sample.robula.xpath_trans.call(null,k,value));
}
});
chromex_sample.robula.make_xpath_attr_exp = (function chromex_sample$robula$make_xpath_attr_exp(attr_key,value){
return goog.string.format("[%s]",chromex_sample.robula.make_xpath_attr_predicate.call(null,attr_key,value));
});
/**
 * 添加id属性
 */
chromex_sample.robula.transf_add_id = (function chromex_sample$robula$transf_add_id(xpath,element){
var ancestor = chromex_sample.robula.get_xpath_head_ancestor.call(null,xpath,element);
var ancestor_id = (function (){var target_obj_38393 = ancestor;
var _STAR_runtime_state_STAR__orig_val__38395 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38396 = oops.state.prepare_state.call(null,target_obj_38393,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38396);

try{var next_obj_38394 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_38393,(0),"id",true,true,false))?(target_obj_38393["id"]):null);
return next_obj_38394;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38395);
}})();
if(((cljs.core.seq.call(null,ancestor_id)) && ((!(chromex_sample.robula.xpath_head_has_predicates_QMARK_.call(null,xpath)))))){
return (new cljs.core.PersistentVector(null,1,(5),cljs.core.PersistentVector.EMPTY_NODE,[chromex_sample.robula.xpath_add_predicate_to_head.call(null,xpath,chromex_sample.robula.make_xpath_attr_exp.call(null,"id",ancestor_id))],null));
} else {
return null;
}
});
/**
 * 添加text属性
 */
chromex_sample.robula.transf_add_text = (function chromex_sample$robula$transf_add_text(xpath,element){
var ancestor = chromex_sample.robula.get_xpath_head_ancestor.call(null,xpath,element);
var ancestor_text = (function (){var target_obj_38397 = ancestor;
var _STAR_runtime_state_STAR__orig_val__38399 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38400 = oops.state.prepare_state.call(null,target_obj_38397,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38400);

try{var next_obj_38398 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_38397,(0),"textContent",true,true,false))?(target_obj_38397["textContent"]):null);
return next_obj_38398;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38399);
}})();
if(((cljs.core.seq.call(null,ancestor_text)) && (cljs.core.not.call(null,chromex_sample.robula.xpath_head_has_position_QMARK_.call(null,xpath))) && ((!(chromex_sample.robula.xpath_head_has_text_QMARK_.call(null,xpath)))))){
return (new cljs.core.PersistentVector(null,1,(5),cljs.core.PersistentVector.EMPTY_NODE,[chromex_sample.robula.xpath_add_predicate_to_head.call(null,xpath,chromex_sample.robula.make_xpath_text_exp.call(null,ancestor_text))],null));
} else {
return null;
}
});
/**
 * 添加其他属性
 */
chromex_sample.robula.transf_add_attribute = (function chromex_sample$robula$transf_add_attribute(xpath,element){
var ancestor = chromex_sample.robula.get_xpath_head_ancestor.call(null,xpath,element);
var ancestor_attrs = chromex_sample.robula.get_attributes.call(null,ancestor);
if((!(chromex_sample.robula.xpath_head_has_predicates_QMARK_.call(null,xpath)))){
var ancestor_priority_attrs = cljs.core.select_keys.call(null,ancestor_attrs,chromex_sample.robula.attribute_priorization_list);
var ancestor_other_attrs = cljs.core.select_keys.call(null,ancestor_attrs,clojure.set.difference.call(null,cljs.core.set.call(null,cljs.core.keys.call(null,ancestor_attrs)),chromex_sample.robula.attribute_priorization_list,chromex_sample.robula.attribute_black_list));
return cljs.core.map.call(null,(function (p__38401){
var vec__38402 = p__38401;
var k = cljs.core.nth.call(null,vec__38402,(0),null);
var v = cljs.core.nth.call(null,vec__38402,(1),null);
return chromex_sample.robula.xpath_add_predicate_to_head.call(null,xpath,chromex_sample.robula.make_xpath_attr_exp.call(null,k,v));
}),cljs.core.concat.call(null,ancestor_priority_attrs,ancestor_other_attrs));
} else {
return null;
}
});
chromex_sample.robula.powerset = (function chromex_sample$robula$powerset(coll){
return cljs.core.reduce.call(null,(function (a,x){
return cljs.core.into.call(null,a,cljs.core.map.call(null,(function (p1__38405_SHARP_){
return cljs.core.conj.call(null,p1__38405_SHARP_,x);
})),a);
}),cljs.core.PersistentHashSet.createAsIfByAssoc([cljs.core.PersistentHashSet.EMPTY]),coll);
});
/**
 * 优先属性比较
 */
chromex_sample.robula.priorization_attr_compare = (function chromex_sample$robula$priorization_attr_compare(priorization_set,attr1,attr2){
if(cljs.core.truth_(priorization_set.call(null,cljs.core.first.call(null,attr1)))){
return (-1);
} else {
if(cljs.core.truth_(priorization_set.call(null,cljs.core.first.call(null,attr2)))){
return (1);
} else {
return (0);

}
}
});
/**
 * 添加其他属性集合(幂集)
 */
chromex_sample.robula.transf_add_attribute_set = (function chromex_sample$robula$transf_add_attribute_set(xpath,element){
var ancestor_attrs = chromex_sample.robula.get_attributes.call(null,chromex_sample.robula.get_xpath_head_ancestor.call(null,xpath,element));
if((!(chromex_sample.robula.xpath_head_has_predicates_QMARK_.call(null,xpath)))){
var ancestor_useful_attrs = cljs.core.select_keys.call(null,ancestor_attrs,clojure.set.difference.call(null,cljs.core.set.call(null,cljs.core.keys.call(null,ancestor_attrs)),chromex_sample.robula.attribute_black_list));
var attr_power_set = cljs.core.filter.call(null,(function (p1__38406_SHARP_){
return (cljs.core.count.call(null,p1__38406_SHARP_) > (1));
}),chromex_sample.robula.powerset.call(null,ancestor_useful_attrs));
var priorization_set_val_cmp = cljs.core.partial.call(null,chromex_sample.robula.priorization_attr_compare,cljs.core.conj.call(null,chromex_sample.robula.attribute_priorization_list,"id"));
var sorted_attr_set = cljs.core.sort.call(null,(function (attr_set1,attr_set2){
var l1 = cljs.core.count.call(null,attr_set1);
var l2 = cljs.core.count.call(null,attr_set2);
if(cljs.core._EQ_.call(null,l1,l2)){
return cljs.core.apply.call(null,priorization_set_val_cmp,cljs.core.first.call(null,cljs.core.drop_while.call(null,(function (p1__38408_SHARP_){
return cljs.core._EQ_.call(null,cljs.core.first.call(null,p1__38408_SHARP_),cljs.core.second.call(null,p1__38408_SHARP_));
}),cljs.core.zipmap.call(null,attr_set1,attr_set2))));
} else {
return cljs.core.compare.call(null,l1,l2);
}
}),cljs.core.map.call(null,(function (p1__38407_SHARP_){
return cljs.core.sort.call(null,priorization_set_val_cmp,p1__38407_SHARP_);
}),attr_power_set));
var gen_attr_set_xpath = (function (attrs){
return chromex_sample.robula.xpath_add_predicate_to_head.call(null,xpath,goog.string.format("[%s]",clojure.string.join.call(null," and ",cljs.core.map.call(null,(function (p__38409){
var vec__38410 = p__38409;
var k = cljs.core.nth.call(null,vec__38410,(0),null);
var v = cljs.core.nth.call(null,vec__38410,(1),null);
return chromex_sample.robula.make_xpath_attr_predicate.call(null,k,v);
}),attrs))));
});
return cljs.core.map.call(null,gen_attr_set_xpath,sorted_attr_set);
} else {
return null;
}
});
/**
 * 添加位置索引
 */
chromex_sample.robula.transf_add_position = (function chromex_sample$robula$transf_add_position(xpath,element){
var ancestor = chromex_sample.robula.get_xpath_head_ancestor.call(null,xpath,element);
var prev_siblings = chromex_sample.robula.get_previous_element_siblings.call(null,ancestor);
if(cljs.core.not.call(null,chromex_sample.robula.xpath_head_has_position_QMARK_.call(null,xpath))){
var idx = ((chromex_sample.robula.xpath_head_with_all_QMARK_.call(null,xpath))?cljs.core.count.call(null,prev_siblings):cljs.core.count.call(null,cljs.core.filter.call(null,(function (p1__38413_SHARP_){
return cljs.core._EQ_.call(null,chromex_sample.robula.tag_name.call(null,ancestor),p1__38413_SHARP_);
}),cljs.core.map.call(null,chromex_sample.robula.tag_name,prev_siblings))));
if((idx > (0))){
return (new cljs.core.PersistentVector(null,1,(5),cljs.core.PersistentVector.EMPTY_NODE,[chromex_sample.robula.xpath_add_predicate_to_head.call(null,xpath,["[",cljs.core.str.cljs$core$IFn$_invoke$arity$1(idx),"]"].join(''))],null));
} else {
return null;
}
} else {
return null;
}
});
/**
 * 添加深度
 */
chromex_sample.robula.transf_add_level = (function chromex_sample$robula$transf_add_level(xpath,element){
if((chromex_sample.robula.xpath_length.call(null,xpath) < (chromex_sample.robula.get_ancestor_count.call(null,element) - (1)))){
return (new cljs.core.PersistentVector(null,1,(5),cljs.core.PersistentVector.EMPTY_NODE,[chromex_sample.robula.xpath_add_head_all.call(null,xpath)],null));
} else {
return null;
}
});
chromex_sample.robula.locate_count = (function chromex_sample$robula$locate_count(document,xpath){
var target_obj_38414 = document.evaluate(xpath,document,null,(function (){var target_obj_38416 = XPathResult;
var _STAR_runtime_state_STAR__orig_val__38418 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38419 = oops.state.prepare_state.call(null,target_obj_38416,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38419);

try{var next_obj_38417 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_38416,(0),"ORDERED_NODE_SNAPSHOT_TYPE",true,true,false))?(target_obj_38416["ORDERED_NODE_SNAPSHOT_TYPE"]):null);
return next_obj_38417;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38418);
}})(),null);
var _STAR_runtime_state_STAR__orig_val__38420 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38421 = oops.state.prepare_state.call(null,target_obj_38414,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38421);

try{var next_obj_38415 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_38414,(0),"snapshotLength",true,true,false))?(target_obj_38414["snapshotLength"]):null);
return next_obj_38415;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38420);
}});
/**
 * 唯一定位？
 */
chromex_sample.robula.unique_locate_QMARK_ = (function chromex_sample$robula$unique_locate_QMARK_(xpath,element,document){
var node_snap = document.evaluate(xpath,document,null,(function (){var target_obj_38422 = XPathResult;
var _STAR_runtime_state_STAR__orig_val__38424 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38425 = oops.state.prepare_state.call(null,target_obj_38422,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38425);

try{var next_obj_38423 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_38422,(0),"ORDERED_NODE_SNAPSHOT_TYPE",true,true,false))?(target_obj_38422["ORDERED_NODE_SNAPSHOT_TYPE"]):null);
return next_obj_38423;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38424);
}})(),null);
return ((cljs.core._EQ_.call(null,(1),(function (){var target_obj_38430 = node_snap;
var _STAR_runtime_state_STAR__orig_val__38432 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38433 = oops.state.prepare_state.call(null,target_obj_38430,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38433);

try{var next_obj_38431 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_38430,(0),"snapshotLength",true,true,false))?(target_obj_38430["snapshotLength"]):null);
return next_obj_38431;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38432);
}})())) && ((element === node_snap.snapshotItem((0)))));
});
chromex_sample.robula.get_element_by_xpath = (function chromex_sample$robula$get_element_by_xpath(document,xpath){
var target_obj_38434 = document.evaluate(xpath,document,null,(function (){var target_obj_38436 = XPathResult;
var _STAR_runtime_state_STAR__orig_val__38438 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38439 = oops.state.prepare_state.call(null,target_obj_38436,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38439);

try{var next_obj_38437 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_38436,(0),"FIRST_ORDERED_NODE_TYPE",true,true,false))?(target_obj_38436["FIRST_ORDERED_NODE_TYPE"]):null);
return next_obj_38437;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38438);
}})(),null);
var _STAR_runtime_state_STAR__orig_val__38440 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__38441 = oops.state.prepare_state.call(null,target_obj_38434,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__38441);

try{var next_obj_38435 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_38434,(0),"singleNodeValue",true,true,false))?(target_obj_38434["singleNodeValue"]):null);
return next_obj_38435;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__38440);
}});
chromex_sample.robula.$x = cljs.core.partial.call(null,chromex_sample.robula.get_element_by_xpath,document);
chromex_sample.robula.unique_xpath_QMARK_ = (function chromex_sample$robula$unique_xpath_QMARK_(path,doc,element){
return chromex_sample.robula.unique_locate_QMARK_.call(null,chromex_sample.robula.xpath__GT_str.call(null,path),element,doc);
});
chromex_sample.robula.get_xpath_in_list = (function chromex_sample$robula$get_xpath_in_list(xpath_list,doc,element){
while(true){
if(cljs.core.seq.call(null,xpath_list)){
var xpath = cljs.core.first.call(null,xpath_list);
var new_xpath_list = cljs.core.concat.call(null,chromex_sample.robula.transf_convert_star.call(null,xpath,element),chromex_sample.robula.transf_add_id.call(null,xpath,element),chromex_sample.robula.transf_add_text.call(null,xpath,element),chromex_sample.robula.transf_add_attribute.call(null,xpath,element),chromex_sample.robula.transf_add_position.call(null,xpath,element),chromex_sample.robula.transf_add_level.call(null,xpath,element));
var paths = cljs.core.vec.call(null,cljs.core.distinct.call(null,new_xpath_list));
var temp__5733__auto__ = cljs.core.some.call(null,((function (xpath_list,doc,element,xpath,new_xpath_list,paths){
return (function (p1__38442_SHARP_){
if(chromex_sample.robula.unique_xpath_QMARK_.call(null,p1__38442_SHARP_,doc,element)){
return p1__38442_SHARP_;
} else {
return null;
}
});})(xpath_list,doc,element,xpath,new_xpath_list,paths))
,paths);
if(cljs.core.truth_(temp__5733__auto__)){
var result = temp__5733__auto__;
return chromex_sample.robula.xpath__GT_str.call(null,result);
} else {
var G__38443 = cljs.core.vec.call(null,cljs.core.concat.call(null,cljs.core.rest.call(null,xpath_list),paths));
var G__38444 = doc;
var G__38445 = element;
xpath_list = G__38443;
doc = G__38444;
element = G__38445;
continue;
}
} else {
return null;
}
break;
}
});
chromex_sample.robula.get_robust_xpath_base = (function chromex_sample$robula$get_robust_xpath_base(document,element){
return chromex_sample.robula.get_xpath_in_list.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [chromex_sample.robula.xpath_all], null),document,element);
});
chromex_sample.robula.get_robust_xpath = cljs.core.memoize.call(null,chromex_sample.robula.get_robust_xpath_base);

//# sourceMappingURL=robula.js.map
