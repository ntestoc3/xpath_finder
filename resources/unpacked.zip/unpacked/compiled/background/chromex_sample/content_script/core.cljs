(ns chromex-sample.content-script.core
  (:require-macros [cljs.core.async.macros :refer [go-loop]]
                   [chromex-sample.macros :refer [load-js]])
  (:require [cljs.core.async :refer [<!]]
            [goog.string :as gstring]
            [chromex-sample.robula :refer [get-robust-xpath]]
            [clojure.string :as string]
            [cljs.pprint :refer [char-code]]
            [dommy.core :as dommy :refer-macros [sel sel1]]
            [oops.core :refer [oget oset! ocall oapply ocall! oapply!
                               oget+ oset!+ ocall+ oapply+ ocall!+ oapply!+]]
            [chromex.logging :refer-macros [log info warn error group group-end]]
            [chromex.protocols.chrome-port :refer [post-message!]]
            [chromex.ext.runtime :as runtime :refer-macros [connect]]))

; -- a message loop ---------------------------------------------------------------------------------------------------------
(def server (atom nil))

(defn process-message! [message]
  (log "CONTENT SCRIPT: got message:" message))

(defn run-message-loop! [message-channel]
  (log "CONTENT SCRIPT: starting message loop...")
  (go-loop []
    (when-some [message (<! message-channel)]
      (process-message! message)
      (recur))
    (log "CONTENT SCRIPT: leaving message loop")))

; -- a simple page analysis  ------------------------------------------------------------------------------------------------

(defn do-page-analysis! [background-port]
  (let [script-elements (.getElementsByTagName js/document "a")
        script-count (.-length script-elements)
        title (.-title js/document)
        msg (str "CONTENT SCRIPT: document '" title "' contains " script-count " a tags.")]
    (log msg)
    (post-message! background-port msg)))

(defn connect-to-background-page! []
  (let [background-port (runtime/connect)]
    (post-message! background-port "hello from CONTENT SCRIPT!")
    (reset! server background-port)
    (run-message-loop! background-port)
    (do-page-analysis! background-port)))

; -- main entry point -------------------------------------------------------------------------------------------------------


(defn hook-event
  ([target event-name event-listener] (hook-event target event-name event-listener true))
  ([target event-name event-listener use-capture]
   (.addEventListener target (name event-name) event-listener use-capture)))

(defn send-command
  "发送命令消息"
  [data]
  (post-message! @server (clj->js {:type "command"
                                   :cmd-data data})))

(defn trim-http-protocol
  [url]
  (string/replace url #"^https?:" ""))


(def in-iframe (not= js/window js/top))

(defn get-parent-frames
  []
  (let [frames (oget js/parent "frames")
        length (oget frames "length")]
    (map #(oget+ frames (str %)) (range length))))

(defn get-frame-info
  []
  (when in-iframe
    (if-let [frame (oget js/window "frameElement")]
      ;; 同源iframe
      ;;注意使用父窗口的document
      {:type "same-orgin"
       :path (get-robust-xpath (oget js/window "parent.document") frame)}
      ;; 跨域iframe
      (if-let [window-idx (-> (get-parent-frames)
                              (.indexOf js/window))]
        ;; 找到当前window,则返回索引
        {:type "cross-domain"
         :window-index window-idx}
        {:type "cross-domain"
         :location (trim-http-protocol (oget js/location "href"))}))))

(defn get-cross-domain-frame-xpath-by-index
  [index]
  (let [frame-window (oget+ js/window "frames" (str index))
        frame-dom  (some->> (sel "iframe")
                            (filter #(= frame-window (oget % "contentWindow")))
                            first)]
    (log "frame-xpath-by-index dom:" frame-dom)
    (if frame-dom
      (get-robust-xpath js/document frame-dom)
      (error "get-cross-domain-frame-xpath-by-index can't find frame index:" index))))

(defn get-cross-domain-frame-xpath-by-location
  [frame-location]
  ;; src指向
  (let [frame-dom (some->> (sel "* /deep/ iframe")
                           (filter (fn [dom]
                                     (-> (oget dom "src")
                                         (trim-http-protocol)
                                         (= frame-location))))
                           first)]
    (if frame-dom
      (get-robust-xpath js/document frame-dom)
      (error "get-cross-domain-frame-xpath can't find frame location:" frame-location))))

(defn save-command
  [cmd data]
  (let [frame-info (get-frame-info)]
    (if (identical? "cross-domain" (:type frame-info))
      (do (log "save-command post parent!")
          (.postMessage js/parent
                        #js {:type "ntr-frame-command"
                             :data  (clj->js {:frame frame-info
                                              :cmd cmd
                                              :data data})}
                        "*"))
      (send-command {:frame-path (:path frame-info)
                     :cmd cmd
                     :data data}))))

(defn message-proc
  "消息处理函数"
  [e]
  (log "message proc!!")
  (let [data (-> (oget e "data")
                 (js->clj :keywordize-keys true))]
    (log "message-proc data:" data)
    (case (:type data)
      "ntr-alert-command"
      (let [cmd-info (:cmd-info data)]
        (save-command (:cmd cmd-info) (:data cmd-info)))

      "ntr-frame-command"
      (let [data (:data data)
            frame (:frame data)
            frame-path (cond
                         (:window-index frame)
                         (get-cross-domain-frame-xpath-by-index (:window-index frame))

                         (:location frame)
                         (get-cross-domain-frame-xpath-by-location (:location frame)))]
        (log "ntr-frame-command proc path:" frame-path)
        (send-command {:frame-path frame-path
                       :cmd (:cmd data)
                       :data (:data data)}))

      (error "message-proc unknown message:" data))))


(defn uniq-id?
  [id]
  (= (count (sel (str "#" id)))
     1))

(defn ele-name
  [ele]
  (string/lower-case (oget ele "localName")))

(defn xpath-ele-id
  [ele]
  (str (ele-name ele)
       "[@id=\"" (oget ele "id") "\"]"))

(defn xpath-ele-class
  [ele]
  (str (ele-name ele)
       "[@class=\"" (dommy/class ele) "\"]"))

(defn previous-siblings
  [ele]
  (let [prev (oget ele "previousSibling")]
    (if prev
      (cons prev (lazy-seq (previous-siblings prev)))
      [])))

(defn previous-sibling-elements
  [ele]
  (->> (previous-siblings ele)
       (filter #(= (oget %1 "nodeType") 1))))

(defn make-xpath
  "构造元素的xpath, 比较简单，适应性较差"
  [element]
  (loop [ele element
         segs []]
    (if (and ele
             (= (oget ele "nodeType")
                1))
      (let [next-ele (oget ele "parentNode")]
        (cond
          ;; 有id属性辅助定位
          (.hasAttribute ele "id")
          (let [id (oget ele "id")]
            (if (uniq-id? id)
              (->> (cons (str "id(\"" id "\")") segs)
                   (string/join "/"))
              (recur next-ele
                     (cons (xpath-ele-id ele) segs))))

          ;; 有class属性辅助定位
          (.hasAttribute ele "class")
          (recur next-ele
                 (cons (xpath-ele-class ele) segs))

          ;; 使用兄弟元素同标签索引定位
          :else
          (let [index (->> (previous-sibling-elements ele)
                           (filter #(= (oget %1 "localName")
                                       (oget ele "localName")))
                           count
                           inc
                           )]
            (recur next-ele
                   (cons (str (ele-name ele) "[" index "]")
                         segs)))))
      ;; 相对位置定位
      (when-not (empty? segs)
        (str "/" (string/join "/" segs))))))

(defn lookup-element-by-xpath
  [xpath]
  (let [evaluator (new js/XPathEvaluator)]
    (-> (.evaluate evaluator xpath (oget js/document "documentElement") nil (oget js/XPathResult "FIRST_ORDERED_NODE_TYPE") nil)
        (oget "singleNodeValue"))))

(defn my-eval
  [code]
  (let [head (sel1 :head)
        script (dommy/create-element "script")]
    (dommy/set-html! script (str "(" code ")()"))
    (dommy/append! head script)
    #_(dommy/remove! head script)))

(def last-ele (atom nil))

(defn remove-mark
  [ele]
  (when ele
    (dommy/remove-style! ele :box-shadow)
    (reset! last-ele nil)))

(defn mark-element
  [ele]
  (when ele
    (dommy/set-style! ele :box-shadow "0px 0px 2px 2px blue")
    (reset! last-ele ele)))

(defn handle-mouse-move
  [e]
  (let [x (.-clientX e)
        y (.-clientY e)]
    (log "x:" x " y:" y)
    (if-let [ele (.elementFromPoint js/document x y)]
      (do
        (when-let [prev-ele @last-ele]
          (when-not (= ele prev-ele)
            (remove-mark prev-ele)))
        (mark-element ele)
        (save-command "mouse-move" {:x x :y y} )
        (log "elements xpath:" (get-robust-xpath js/document ele)))
      (remove-mark @last-ele))))

(defn bytes-len
  [text]
  (->> (map #(if (> (char-code %) 255)
               2
               1) text)
       (reduce +)))

(defn- format-text
  [text]
  (let [trimed-text (-> (string/replace text #"\s*\r?\n\s*" " ")
                        (string/trim))]
    (condp < (bytes-len trimed-text)
      60 ""
      20 (str (subs trimed-text 0 20) "...")
      trimed-text)))

(defn get-target-text
  [element]
  (-> (case (oget element "nodeName")
        "INPUT"
        (if (#{"button" "reset" "submit"} (dommy/attr element :type))
          (dommy/attr element :value)
          (let [parent-node (dommy/parent element)
                id (dommy/attr element :id)]
            (cond
              (= "LABEL" (oget parent-node "nodeName"))
              (dommy/text parent-node)

              id
              (if-let [label-ele (sel1 (gstring/format "label[for='%s']" id))]
                (dommy/text label-ele)
                (dommy/attr element :name))

              :else
              (dommy/attr element :name))))

        "SELECT"
        (dommy/attr element :name)

        (dommy/text element))
      format-text))

(defn event-target
  "获取事件的目标"
  [event]
  (let [target (.-target event)]
    (if (.-shadowRoot target)
      (first (.-path event))
      target)))

(defn get-label-target
  "获取label指向的目标,不含label指向则返回nil"
  [target]
  (when-not (identical? (oget target "nodeName") "INPUT")
    (when-let [label (cond
                     (identical? (oget target "nodeName") "LABEL")
                     target

                     (identical? (oget target "parentNode.nodeName") "LABEL")
                     (oget target "parentNode"))]
      (if-let [for-value (dommy/attr label "for")]
        (sel1 (str "#" for-value))
        (sel1 label :input)))))

(defn mouse-not-in-scroll?
  [event]
  (let [target (.-target event)]
    (and (not (and (> (.-clientWidth target) 0)
                   (>= (.-offsetX event) (.-clientWidth target))))
         (not (and (> (.-clientHeight target) 0)
                   (>= (.-offsetY event) (.-clientHeight target)))))))

(defn mouse-opable-target?
  "是否为鼠标可操作的目标"
  [target]
  (-> (re-matches #"(?i)html|select|optgroup|option" (oget target "tagName"))
      not))

(defn file-input?
  "是否为文件输入"
  [target]
  (and (identical? (oget target "tagName") "INPUT")
       (identical? (dommy/attr target :type) "file")))

(defn upload-role?
  "是否为上传角色"
  [target]
  (when target
    (let [role (or (dommy/attr target :role)
                   (dommy/attr target :data-role))]
      (if (re-matches #"(?i)upload|file" role)
        true
        (upload-role? (oget target "parentNode"))))))

(defn upload-element?
  "是否为上传元素"
  [target]
  (or (file-input? target)
      (upload-role? target)))

(defn handle-mouse-down
  [e]
  )

(when in-iframe
  (log "CONTENT SCRIPT: in iframe")
  )
;; test
(defn init! []
  (log "CONTENT SCRIPT: init")
  (dommy/listen! js/document :DOMContentLoaded (fn []
                                                 (log "dom content loaded!")
                                                 (hook-event js/window "message" message-proc)
                                                 (hook-event js/document :mousemove handle-mouse-move)
                                                 (connect-to-background-page!)
                                                 (my-eval (load-js "hook.js"))
                                                 )))

(comment
  (hook-event :mousemove handle-mouse-move)


  )
