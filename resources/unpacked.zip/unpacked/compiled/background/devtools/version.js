// Compiled by ClojureScript 1.10.597 {}
goog.provide('devtools.version');
goog.require('cljs.core');
devtools.version.current_version = "0.9.11";
devtools.version.get_current_version = (function devtools$version$get_current_version(){
return devtools.version.current_version;
});

//# sourceMappingURL=version.js.map
