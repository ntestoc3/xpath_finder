// Compiled by ClojureScript 1.10.520 {}
goog.provide('tailrecursion.priority_map');
goog.require('cljs.core');
goog.require('cljs.core');
goog.require('cljs.reader');

/**
* @constructor
 * @implements {cljs.core.IReversible}
 * @implements {cljs.core.IEquiv}
 * @implements {cljs.core.IHash}
 * @implements {cljs.core.IFn}
 * @implements {cljs.core.ICollection}
 * @implements {cljs.core.IEmptyableCollection}
 * @implements {cljs.core.ICounted}
 * @implements {cljs.core.ISorted}
 * @implements {cljs.core.ISeqable}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IStack}
 * @implements {cljs.core.IPrintWithWriter}
 * @implements {cljs.core.IWithMeta}
 * @implements {cljs.core.IAssociative}
 * @implements {cljs.core.IMap}
 * @implements {cljs.core.ILookup}
*/
tailrecursion.priority_map.PersistentPriorityMap = (function (priority__GT_set_of_items,item__GT_priority,meta,keyfn,__hash){
this.priority__GT_set_of_items = priority__GT_set_of_items;
this.item__GT_priority = item__GT_priority;
this.meta = meta;
this.keyfn = keyfn;
this.__hash = __hash;
this.cljs$lang$protocol_mask$partition0$ = 2565220111;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$ILookup$_lookup$arity$2 = (function (this$,item){
var self__ = this;
var this$__$1 = this;
return cljs.core.get.call(null,self__.item__GT_priority,item);
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$ILookup$_lookup$arity$3 = (function (coll,item,not_found){
var self__ = this;
var coll__$1 = this;
return cljs.core.get.call(null,self__.item__GT_priority,item,not_found);
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$IPrintWithWriter$_pr_writer$arity$3 = (function (coll,writer,opts){
var self__ = this;
var coll__$1 = this;
var pr_pair = ((function (coll__$1){
return (function (keyval){
return cljs.core.pr_sequential_writer.call(null,writer,cljs.core.pr_writer,""," ","",opts,keyval);
});})(coll__$1))
;
return cljs.core.pr_sequential_writer.call(null,writer,pr_pair,"#tailrecursion.priority-map {",", ","}",opts,coll__$1);
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$IMeta$_meta$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return self__.meta;
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$ICounted$_count$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return cljs.core.count.call(null,self__.item__GT_priority);
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$IStack$_peek$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
if((cljs.core.count.call(null,self__.item__GT_priority) === (0))){
return null;
} else {
var f = cljs.core.first.call(null,self__.priority__GT_set_of_items);
var item = cljs.core.first.call(null,cljs.core.val.call(null,f));
if(cljs.core.truth_(self__.keyfn)){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [item,self__.item__GT_priority.call(null,item)], null);
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [item,cljs.core.key.call(null,f)], null);
}
}
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$IStack$_pop$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
if((cljs.core.count.call(null,self__.item__GT_priority) === (0))){
throw (new Error("Can't pop empty priority map"));
} else {
var f = cljs.core.first.call(null,self__.priority__GT_set_of_items);
var item_set = cljs.core.val.call(null,f);
var item = cljs.core.first.call(null,item_set);
var priority_key = cljs.core.key.call(null,f);
if(cljs.core._EQ_.call(null,cljs.core.count.call(null,item_set),(1))){
return (new tailrecursion.priority_map.PersistentPriorityMap(cljs.core.dissoc.call(null,self__.priority__GT_set_of_items,priority_key),cljs.core.dissoc.call(null,self__.item__GT_priority,item),self__.meta,self__.keyfn,null));
} else {
return (new tailrecursion.priority_map.PersistentPriorityMap(cljs.core.assoc.call(null,self__.priority__GT_set_of_items,priority_key,cljs.core.disj.call(null,item_set,item)),cljs.core.dissoc.call(null,self__.item__GT_priority,item),self__.meta,self__.keyfn,null));
}
}
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$IReversible$_rseq$arity$1 = (function (coll){
var self__ = this;
var coll__$1 = this;
if(cljs.core.truth_(self__.keyfn)){
return cljs.core.seq.call(null,(function (){var iter__4523__auto__ = ((function (coll__$1){
return (function tailrecursion$priority_map$iter__32127(s__32128){
return (new cljs.core.LazySeq(null,((function (coll__$1){
return (function (){
var s__32128__$1 = s__32128;
while(true){
var temp__5735__auto__ = cljs.core.seq.call(null,s__32128__$1);
if(temp__5735__auto__){
var xs__6292__auto__ = temp__5735__auto__;
var vec__32133 = cljs.core.first.call(null,xs__6292__auto__);
var priority = cljs.core.nth.call(null,vec__32133,(0),null);
var item_set = cljs.core.nth.call(null,vec__32133,(1),null);
var iterys__4519__auto__ = ((function (s__32128__$1,vec__32133,priority,item_set,xs__6292__auto__,temp__5735__auto__,coll__$1){
return (function tailrecursion$priority_map$iter__32127_$_iter__32129(s__32130){
return (new cljs.core.LazySeq(null,((function (s__32128__$1,vec__32133,priority,item_set,xs__6292__auto__,temp__5735__auto__,coll__$1){
return (function (){
var s__32130__$1 = s__32130;
while(true){
var temp__5735__auto____$1 = cljs.core.seq.call(null,s__32130__$1);
if(temp__5735__auto____$1){
var s__32130__$2 = temp__5735__auto____$1;
if(cljs.core.chunked_seq_QMARK_.call(null,s__32130__$2)){
var c__4521__auto__ = cljs.core.chunk_first.call(null,s__32130__$2);
var size__4522__auto__ = cljs.core.count.call(null,c__4521__auto__);
var b__32132 = cljs.core.chunk_buffer.call(null,size__4522__auto__);
if((function (){var i__32131 = (0);
while(true){
if((i__32131 < size__4522__auto__)){
var item = cljs.core._nth.call(null,c__4521__auto__,i__32131);
cljs.core.chunk_append.call(null,b__32132,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [item,self__.item__GT_priority.call(null,item)], null));

var G__32181 = (i__32131 + (1));
i__32131 = G__32181;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons.call(null,cljs.core.chunk.call(null,b__32132),tailrecursion$priority_map$iter__32127_$_iter__32129.call(null,cljs.core.chunk_rest.call(null,s__32130__$2)));
} else {
return cljs.core.chunk_cons.call(null,cljs.core.chunk.call(null,b__32132),null);
}
} else {
var item = cljs.core.first.call(null,s__32130__$2);
return cljs.core.cons.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [item,self__.item__GT_priority.call(null,item)], null),tailrecursion$priority_map$iter__32127_$_iter__32129.call(null,cljs.core.rest.call(null,s__32130__$2)));
}
} else {
return null;
}
break;
}
});})(s__32128__$1,vec__32133,priority,item_set,xs__6292__auto__,temp__5735__auto__,coll__$1))
,null,null));
});})(s__32128__$1,vec__32133,priority,item_set,xs__6292__auto__,temp__5735__auto__,coll__$1))
;
var fs__4520__auto__ = cljs.core.seq.call(null,iterys__4519__auto__.call(null,item_set));
if(fs__4520__auto__){
return cljs.core.concat.call(null,fs__4520__auto__,tailrecursion$priority_map$iter__32127.call(null,cljs.core.rest.call(null,s__32128__$1)));
} else {
var G__32182 = cljs.core.rest.call(null,s__32128__$1);
s__32128__$1 = G__32182;
continue;
}
} else {
return null;
}
break;
}
});})(coll__$1))
,null,null));
});})(coll__$1))
;
return iter__4523__auto__.call(null,cljs.core.rseq.call(null,self__.priority__GT_set_of_items));
})());
} else {
return cljs.core.seq.call(null,(function (){var iter__4523__auto__ = ((function (coll__$1){
return (function tailrecursion$priority_map$iter__32136(s__32137){
return (new cljs.core.LazySeq(null,((function (coll__$1){
return (function (){
var s__32137__$1 = s__32137;
while(true){
var temp__5735__auto__ = cljs.core.seq.call(null,s__32137__$1);
if(temp__5735__auto__){
var xs__6292__auto__ = temp__5735__auto__;
var vec__32142 = cljs.core.first.call(null,xs__6292__auto__);
var priority = cljs.core.nth.call(null,vec__32142,(0),null);
var item_set = cljs.core.nth.call(null,vec__32142,(1),null);
var iterys__4519__auto__ = ((function (s__32137__$1,vec__32142,priority,item_set,xs__6292__auto__,temp__5735__auto__,coll__$1){
return (function tailrecursion$priority_map$iter__32136_$_iter__32138(s__32139){
return (new cljs.core.LazySeq(null,((function (s__32137__$1,vec__32142,priority,item_set,xs__6292__auto__,temp__5735__auto__,coll__$1){
return (function (){
var s__32139__$1 = s__32139;
while(true){
var temp__5735__auto____$1 = cljs.core.seq.call(null,s__32139__$1);
if(temp__5735__auto____$1){
var s__32139__$2 = temp__5735__auto____$1;
if(cljs.core.chunked_seq_QMARK_.call(null,s__32139__$2)){
var c__4521__auto__ = cljs.core.chunk_first.call(null,s__32139__$2);
var size__4522__auto__ = cljs.core.count.call(null,c__4521__auto__);
var b__32141 = cljs.core.chunk_buffer.call(null,size__4522__auto__);
if((function (){var i__32140 = (0);
while(true){
if((i__32140 < size__4522__auto__)){
var item = cljs.core._nth.call(null,c__4521__auto__,i__32140);
cljs.core.chunk_append.call(null,b__32141,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [item,priority], null));

var G__32183 = (i__32140 + (1));
i__32140 = G__32183;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons.call(null,cljs.core.chunk.call(null,b__32141),tailrecursion$priority_map$iter__32136_$_iter__32138.call(null,cljs.core.chunk_rest.call(null,s__32139__$2)));
} else {
return cljs.core.chunk_cons.call(null,cljs.core.chunk.call(null,b__32141),null);
}
} else {
var item = cljs.core.first.call(null,s__32139__$2);
return cljs.core.cons.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [item,priority], null),tailrecursion$priority_map$iter__32136_$_iter__32138.call(null,cljs.core.rest.call(null,s__32139__$2)));
}
} else {
return null;
}
break;
}
});})(s__32137__$1,vec__32142,priority,item_set,xs__6292__auto__,temp__5735__auto__,coll__$1))
,null,null));
});})(s__32137__$1,vec__32142,priority,item_set,xs__6292__auto__,temp__5735__auto__,coll__$1))
;
var fs__4520__auto__ = cljs.core.seq.call(null,iterys__4519__auto__.call(null,item_set));
if(fs__4520__auto__){
return cljs.core.concat.call(null,fs__4520__auto__,tailrecursion$priority_map$iter__32136.call(null,cljs.core.rest.call(null,s__32137__$1)));
} else {
var G__32184 = cljs.core.rest.call(null,s__32137__$1);
s__32137__$1 = G__32184;
continue;
}
} else {
return null;
}
break;
}
});})(coll__$1))
,null,null));
});})(coll__$1))
;
return iter__4523__auto__.call(null,cljs.core.rseq.call(null,self__.priority__GT_set_of_items));
})());
}
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$IHash$_hash$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
var h__4243__auto__ = self__.__hash;
if((!((h__4243__auto__ == null)))){
return h__4243__auto__;
} else {
var h__4243__auto____$1 = cljs.core.hash_unordered_coll.call(null,this$__$1);
self__.__hash = h__4243__auto____$1;

return h__4243__auto____$1;
}
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$IEquiv$_equiv$arity$2 = (function (this$,other){
var self__ = this;
var this$__$1 = this;
return cljs.core._equiv.call(null,self__.item__GT_priority,other);
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$IEmptyableCollection$_empty$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return cljs.core.with_meta.call(null,tailrecursion.priority_map.PersistentPriorityMap.EMPTY,self__.meta);
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$IMap$_dissoc$arity$2 = (function (this$,item){
var self__ = this;
var this$__$1 = this;
var priority = self__.item__GT_priority.call(null,item,new cljs.core.Keyword("tailrecursion.priority-map","not-found","tailrecursion.priority-map/not-found",-436727517));
if(cljs.core._EQ_.call(null,priority,new cljs.core.Keyword("tailrecursion.priority-map","not-found","tailrecursion.priority-map/not-found",-436727517))){
return this$__$1;
} else {
var priority_key = self__.keyfn.call(null,priority);
var item_set = self__.priority__GT_set_of_items.call(null,priority_key);
if(cljs.core._EQ_.call(null,cljs.core.count.call(null,item_set),(1))){
return (new tailrecursion.priority_map.PersistentPriorityMap(cljs.core.dissoc.call(null,self__.priority__GT_set_of_items,priority_key),cljs.core.dissoc.call(null,self__.item__GT_priority,item),self__.meta,self__.keyfn,null));
} else {
return (new tailrecursion.priority_map.PersistentPriorityMap(cljs.core.assoc.call(null,self__.priority__GT_set_of_items,priority_key,cljs.core.disj.call(null,item_set,item)),cljs.core.dissoc.call(null,self__.item__GT_priority,item),self__.meta,self__.keyfn,null));
}
}
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$IAssociative$_assoc$arity$3 = (function (this$,item,priority){
var self__ = this;
var this$__$1 = this;
var temp__5733__auto__ = cljs.core.get.call(null,self__.item__GT_priority,item,null);
if(cljs.core.truth_(temp__5733__auto__)){
var current_priority = temp__5733__auto__;
if(cljs.core._EQ_.call(null,current_priority,priority)){
return this$__$1;
} else {
var priority_key = self__.keyfn.call(null,priority);
var current_priority_key = self__.keyfn.call(null,current_priority);
var item_set = cljs.core.get.call(null,self__.priority__GT_set_of_items,current_priority_key);
if(cljs.core._EQ_.call(null,cljs.core.count.call(null,item_set),(1))){
return (new tailrecursion.priority_map.PersistentPriorityMap(cljs.core.assoc.call(null,cljs.core.dissoc.call(null,self__.priority__GT_set_of_items,current_priority_key),priority_key,cljs.core.conj.call(null,cljs.core.get.call(null,self__.priority__GT_set_of_items,priority_key,cljs.core.PersistentHashSet.EMPTY),item)),cljs.core.assoc.call(null,self__.item__GT_priority,item,priority),self__.meta,self__.keyfn,null));
} else {
return (new tailrecursion.priority_map.PersistentPriorityMap(cljs.core.assoc.call(null,self__.priority__GT_set_of_items,current_priority_key,cljs.core.disj.call(null,cljs.core.get.call(null,self__.priority__GT_set_of_items,current_priority_key),item),priority_key,cljs.core.conj.call(null,cljs.core.get.call(null,self__.priority__GT_set_of_items,priority_key,cljs.core.PersistentHashSet.EMPTY),item)),cljs.core.assoc.call(null,self__.item__GT_priority,item,priority),self__.meta,self__.keyfn,null));
}
}
} else {
var priority_key = self__.keyfn.call(null,priority);
return (new tailrecursion.priority_map.PersistentPriorityMap(cljs.core.assoc.call(null,self__.priority__GT_set_of_items,priority_key,cljs.core.conj.call(null,cljs.core.get.call(null,self__.priority__GT_set_of_items,priority_key,cljs.core.PersistentHashSet.EMPTY),item)),cljs.core.assoc.call(null,self__.item__GT_priority,item,priority),self__.meta,self__.keyfn,null));
}
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$IAssociative$_contains_key_QMARK_$arity$2 = (function (this$,item){
var self__ = this;
var this$__$1 = this;
return cljs.core.contains_QMARK_.call(null,self__.item__GT_priority,item);
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$ISeqable$_seq$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.keyfn)){
return cljs.core.seq.call(null,(function (){var iter__4523__auto__ = ((function (this$__$1){
return (function tailrecursion$priority_map$iter__32145(s__32146){
return (new cljs.core.LazySeq(null,((function (this$__$1){
return (function (){
var s__32146__$1 = s__32146;
while(true){
var temp__5735__auto__ = cljs.core.seq.call(null,s__32146__$1);
if(temp__5735__auto__){
var xs__6292__auto__ = temp__5735__auto__;
var vec__32151 = cljs.core.first.call(null,xs__6292__auto__);
var priority = cljs.core.nth.call(null,vec__32151,(0),null);
var item_set = cljs.core.nth.call(null,vec__32151,(1),null);
var iterys__4519__auto__ = ((function (s__32146__$1,vec__32151,priority,item_set,xs__6292__auto__,temp__5735__auto__,this$__$1){
return (function tailrecursion$priority_map$iter__32145_$_iter__32147(s__32148){
return (new cljs.core.LazySeq(null,((function (s__32146__$1,vec__32151,priority,item_set,xs__6292__auto__,temp__5735__auto__,this$__$1){
return (function (){
var s__32148__$1 = s__32148;
while(true){
var temp__5735__auto____$1 = cljs.core.seq.call(null,s__32148__$1);
if(temp__5735__auto____$1){
var s__32148__$2 = temp__5735__auto____$1;
if(cljs.core.chunked_seq_QMARK_.call(null,s__32148__$2)){
var c__4521__auto__ = cljs.core.chunk_first.call(null,s__32148__$2);
var size__4522__auto__ = cljs.core.count.call(null,c__4521__auto__);
var b__32150 = cljs.core.chunk_buffer.call(null,size__4522__auto__);
if((function (){var i__32149 = (0);
while(true){
if((i__32149 < size__4522__auto__)){
var item = cljs.core._nth.call(null,c__4521__auto__,i__32149);
cljs.core.chunk_append.call(null,b__32150,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [item,self__.item__GT_priority.call(null,item)], null));

var G__32185 = (i__32149 + (1));
i__32149 = G__32185;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons.call(null,cljs.core.chunk.call(null,b__32150),tailrecursion$priority_map$iter__32145_$_iter__32147.call(null,cljs.core.chunk_rest.call(null,s__32148__$2)));
} else {
return cljs.core.chunk_cons.call(null,cljs.core.chunk.call(null,b__32150),null);
}
} else {
var item = cljs.core.first.call(null,s__32148__$2);
return cljs.core.cons.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [item,self__.item__GT_priority.call(null,item)], null),tailrecursion$priority_map$iter__32145_$_iter__32147.call(null,cljs.core.rest.call(null,s__32148__$2)));
}
} else {
return null;
}
break;
}
});})(s__32146__$1,vec__32151,priority,item_set,xs__6292__auto__,temp__5735__auto__,this$__$1))
,null,null));
});})(s__32146__$1,vec__32151,priority,item_set,xs__6292__auto__,temp__5735__auto__,this$__$1))
;
var fs__4520__auto__ = cljs.core.seq.call(null,iterys__4519__auto__.call(null,item_set));
if(fs__4520__auto__){
return cljs.core.concat.call(null,fs__4520__auto__,tailrecursion$priority_map$iter__32145.call(null,cljs.core.rest.call(null,s__32146__$1)));
} else {
var G__32186 = cljs.core.rest.call(null,s__32146__$1);
s__32146__$1 = G__32186;
continue;
}
} else {
return null;
}
break;
}
});})(this$__$1))
,null,null));
});})(this$__$1))
;
return iter__4523__auto__.call(null,self__.priority__GT_set_of_items);
})());
} else {
return cljs.core.seq.call(null,(function (){var iter__4523__auto__ = ((function (this$__$1){
return (function tailrecursion$priority_map$iter__32154(s__32155){
return (new cljs.core.LazySeq(null,((function (this$__$1){
return (function (){
var s__32155__$1 = s__32155;
while(true){
var temp__5735__auto__ = cljs.core.seq.call(null,s__32155__$1);
if(temp__5735__auto__){
var xs__6292__auto__ = temp__5735__auto__;
var vec__32160 = cljs.core.first.call(null,xs__6292__auto__);
var priority = cljs.core.nth.call(null,vec__32160,(0),null);
var item_set = cljs.core.nth.call(null,vec__32160,(1),null);
var iterys__4519__auto__ = ((function (s__32155__$1,vec__32160,priority,item_set,xs__6292__auto__,temp__5735__auto__,this$__$1){
return (function tailrecursion$priority_map$iter__32154_$_iter__32156(s__32157){
return (new cljs.core.LazySeq(null,((function (s__32155__$1,vec__32160,priority,item_set,xs__6292__auto__,temp__5735__auto__,this$__$1){
return (function (){
var s__32157__$1 = s__32157;
while(true){
var temp__5735__auto____$1 = cljs.core.seq.call(null,s__32157__$1);
if(temp__5735__auto____$1){
var s__32157__$2 = temp__5735__auto____$1;
if(cljs.core.chunked_seq_QMARK_.call(null,s__32157__$2)){
var c__4521__auto__ = cljs.core.chunk_first.call(null,s__32157__$2);
var size__4522__auto__ = cljs.core.count.call(null,c__4521__auto__);
var b__32159 = cljs.core.chunk_buffer.call(null,size__4522__auto__);
if((function (){var i__32158 = (0);
while(true){
if((i__32158 < size__4522__auto__)){
var item = cljs.core._nth.call(null,c__4521__auto__,i__32158);
cljs.core.chunk_append.call(null,b__32159,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [item,priority], null));

var G__32187 = (i__32158 + (1));
i__32158 = G__32187;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons.call(null,cljs.core.chunk.call(null,b__32159),tailrecursion$priority_map$iter__32154_$_iter__32156.call(null,cljs.core.chunk_rest.call(null,s__32157__$2)));
} else {
return cljs.core.chunk_cons.call(null,cljs.core.chunk.call(null,b__32159),null);
}
} else {
var item = cljs.core.first.call(null,s__32157__$2);
return cljs.core.cons.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [item,priority], null),tailrecursion$priority_map$iter__32154_$_iter__32156.call(null,cljs.core.rest.call(null,s__32157__$2)));
}
} else {
return null;
}
break;
}
});})(s__32155__$1,vec__32160,priority,item_set,xs__6292__auto__,temp__5735__auto__,this$__$1))
,null,null));
});})(s__32155__$1,vec__32160,priority,item_set,xs__6292__auto__,temp__5735__auto__,this$__$1))
;
var fs__4520__auto__ = cljs.core.seq.call(null,iterys__4519__auto__.call(null,item_set));
if(fs__4520__auto__){
return cljs.core.concat.call(null,fs__4520__auto__,tailrecursion$priority_map$iter__32154.call(null,cljs.core.rest.call(null,s__32155__$1)));
} else {
var G__32188 = cljs.core.rest.call(null,s__32155__$1);
s__32155__$1 = G__32188;
continue;
}
} else {
return null;
}
break;
}
});})(this$__$1))
,null,null));
});})(this$__$1))
;
return iter__4523__auto__.call(null,self__.priority__GT_set_of_items);
})());
}
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (this$,meta__$1){
var self__ = this;
var this$__$1 = this;
return (new tailrecursion.priority_map.PersistentPriorityMap(self__.priority__GT_set_of_items,self__.item__GT_priority,meta__$1,self__.keyfn,self__.__hash));
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$ICollection$_conj$arity$2 = (function (this$,entry){
var self__ = this;
var this$__$1 = this;
if(cljs.core.vector_QMARK_.call(null,entry)){
return cljs.core._assoc.call(null,this$__$1,cljs.core._nth.call(null,entry,(0)),cljs.core._nth.call(null,entry,(1)));
} else {
return cljs.core.reduce.call(null,cljs.core._conj,this$__$1,entry);
}
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.call = (function() {
var G__32189 = null;
var G__32189__2 = (function (self__,item){
var self__ = this;
var self____$1 = this;
var this$ = self____$1;
return cljs.core._lookup.call(null,this$,item);
});
var G__32189__3 = (function (self__,item,not_found){
var self__ = this;
var self____$1 = this;
var this$ = self____$1;
return cljs.core._lookup.call(null,this$,item,not_found);
});
G__32189 = function(self__,item,not_found){
switch(arguments.length){
case 2:
return G__32189__2.call(this,self__,item);
case 3:
return G__32189__3.call(this,self__,item,not_found);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
G__32189.cljs$core$IFn$_invoke$arity$2 = G__32189__2;
G__32189.cljs$core$IFn$_invoke$arity$3 = G__32189__3;
return G__32189;
})()
;

tailrecursion.priority_map.PersistentPriorityMap.prototype.apply = (function (self__,args32126){
var self__ = this;
var self____$1 = this;
return self____$1.call.apply(self____$1,[self____$1].concat(cljs.core.aclone.call(null,args32126)));
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$IFn$_invoke$arity$1 = (function (item){
var self__ = this;
var this$ = this;
return cljs.core._lookup.call(null,this$,item);
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$IFn$_invoke$arity$2 = (function (item,not_found){
var self__ = this;
var this$ = this;
return cljs.core._lookup.call(null,this$,item,not_found);
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$ISorted$_sorted_seq$arity$2 = (function (this$,ascending_QMARK_){
var self__ = this;
var this$__$1 = this;
return (cljs.core.truth_(ascending_QMARK_)?cljs.core.seq:cljs.core.rseq).call(null,this$__$1);
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$ISorted$_sorted_seq_from$arity$3 = (function (this$,k,ascending_QMARK_){
var self__ = this;
var this$__$1 = this;
var sets = (cljs.core.truth_(ascending_QMARK_)?cljs.core.subseq.call(null,self__.priority__GT_set_of_items,cljs.core._GT__EQ_,k):cljs.core.rsubseq.call(null,self__.priority__GT_set_of_items,cljs.core._LT__EQ_,k));
if(cljs.core.truth_(self__.keyfn)){
return cljs.core.seq.call(null,(function (){var iter__4523__auto__ = ((function (sets,this$__$1){
return (function tailrecursion$priority_map$iter__32163(s__32164){
return (new cljs.core.LazySeq(null,((function (sets,this$__$1){
return (function (){
var s__32164__$1 = s__32164;
while(true){
var temp__5735__auto__ = cljs.core.seq.call(null,s__32164__$1);
if(temp__5735__auto__){
var xs__6292__auto__ = temp__5735__auto__;
var vec__32169 = cljs.core.first.call(null,xs__6292__auto__);
var priority = cljs.core.nth.call(null,vec__32169,(0),null);
var item_set = cljs.core.nth.call(null,vec__32169,(1),null);
var iterys__4519__auto__ = ((function (s__32164__$1,vec__32169,priority,item_set,xs__6292__auto__,temp__5735__auto__,sets,this$__$1){
return (function tailrecursion$priority_map$iter__32163_$_iter__32165(s__32166){
return (new cljs.core.LazySeq(null,((function (s__32164__$1,vec__32169,priority,item_set,xs__6292__auto__,temp__5735__auto__,sets,this$__$1){
return (function (){
var s__32166__$1 = s__32166;
while(true){
var temp__5735__auto____$1 = cljs.core.seq.call(null,s__32166__$1);
if(temp__5735__auto____$1){
var s__32166__$2 = temp__5735__auto____$1;
if(cljs.core.chunked_seq_QMARK_.call(null,s__32166__$2)){
var c__4521__auto__ = cljs.core.chunk_first.call(null,s__32166__$2);
var size__4522__auto__ = cljs.core.count.call(null,c__4521__auto__);
var b__32168 = cljs.core.chunk_buffer.call(null,size__4522__auto__);
if((function (){var i__32167 = (0);
while(true){
if((i__32167 < size__4522__auto__)){
var item = cljs.core._nth.call(null,c__4521__auto__,i__32167);
cljs.core.chunk_append.call(null,b__32168,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [item,self__.item__GT_priority.call(null,item)], null));

var G__32190 = (i__32167 + (1));
i__32167 = G__32190;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons.call(null,cljs.core.chunk.call(null,b__32168),tailrecursion$priority_map$iter__32163_$_iter__32165.call(null,cljs.core.chunk_rest.call(null,s__32166__$2)));
} else {
return cljs.core.chunk_cons.call(null,cljs.core.chunk.call(null,b__32168),null);
}
} else {
var item = cljs.core.first.call(null,s__32166__$2);
return cljs.core.cons.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [item,self__.item__GT_priority.call(null,item)], null),tailrecursion$priority_map$iter__32163_$_iter__32165.call(null,cljs.core.rest.call(null,s__32166__$2)));
}
} else {
return null;
}
break;
}
});})(s__32164__$1,vec__32169,priority,item_set,xs__6292__auto__,temp__5735__auto__,sets,this$__$1))
,null,null));
});})(s__32164__$1,vec__32169,priority,item_set,xs__6292__auto__,temp__5735__auto__,sets,this$__$1))
;
var fs__4520__auto__ = cljs.core.seq.call(null,iterys__4519__auto__.call(null,item_set));
if(fs__4520__auto__){
return cljs.core.concat.call(null,fs__4520__auto__,tailrecursion$priority_map$iter__32163.call(null,cljs.core.rest.call(null,s__32164__$1)));
} else {
var G__32191 = cljs.core.rest.call(null,s__32164__$1);
s__32164__$1 = G__32191;
continue;
}
} else {
return null;
}
break;
}
});})(sets,this$__$1))
,null,null));
});})(sets,this$__$1))
;
return iter__4523__auto__.call(null,sets);
})());
} else {
return cljs.core.seq.call(null,(function (){var iter__4523__auto__ = ((function (sets,this$__$1){
return (function tailrecursion$priority_map$iter__32172(s__32173){
return (new cljs.core.LazySeq(null,((function (sets,this$__$1){
return (function (){
var s__32173__$1 = s__32173;
while(true){
var temp__5735__auto__ = cljs.core.seq.call(null,s__32173__$1);
if(temp__5735__auto__){
var xs__6292__auto__ = temp__5735__auto__;
var vec__32178 = cljs.core.first.call(null,xs__6292__auto__);
var priority = cljs.core.nth.call(null,vec__32178,(0),null);
var item_set = cljs.core.nth.call(null,vec__32178,(1),null);
var iterys__4519__auto__ = ((function (s__32173__$1,vec__32178,priority,item_set,xs__6292__auto__,temp__5735__auto__,sets,this$__$1){
return (function tailrecursion$priority_map$iter__32172_$_iter__32174(s__32175){
return (new cljs.core.LazySeq(null,((function (s__32173__$1,vec__32178,priority,item_set,xs__6292__auto__,temp__5735__auto__,sets,this$__$1){
return (function (){
var s__32175__$1 = s__32175;
while(true){
var temp__5735__auto____$1 = cljs.core.seq.call(null,s__32175__$1);
if(temp__5735__auto____$1){
var s__32175__$2 = temp__5735__auto____$1;
if(cljs.core.chunked_seq_QMARK_.call(null,s__32175__$2)){
var c__4521__auto__ = cljs.core.chunk_first.call(null,s__32175__$2);
var size__4522__auto__ = cljs.core.count.call(null,c__4521__auto__);
var b__32177 = cljs.core.chunk_buffer.call(null,size__4522__auto__);
if((function (){var i__32176 = (0);
while(true){
if((i__32176 < size__4522__auto__)){
var item = cljs.core._nth.call(null,c__4521__auto__,i__32176);
cljs.core.chunk_append.call(null,b__32177,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [item,priority], null));

var G__32192 = (i__32176 + (1));
i__32176 = G__32192;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons.call(null,cljs.core.chunk.call(null,b__32177),tailrecursion$priority_map$iter__32172_$_iter__32174.call(null,cljs.core.chunk_rest.call(null,s__32175__$2)));
} else {
return cljs.core.chunk_cons.call(null,cljs.core.chunk.call(null,b__32177),null);
}
} else {
var item = cljs.core.first.call(null,s__32175__$2);
return cljs.core.cons.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [item,priority], null),tailrecursion$priority_map$iter__32172_$_iter__32174.call(null,cljs.core.rest.call(null,s__32175__$2)));
}
} else {
return null;
}
break;
}
});})(s__32173__$1,vec__32178,priority,item_set,xs__6292__auto__,temp__5735__auto__,sets,this$__$1))
,null,null));
});})(s__32173__$1,vec__32178,priority,item_set,xs__6292__auto__,temp__5735__auto__,sets,this$__$1))
;
var fs__4520__auto__ = cljs.core.seq.call(null,iterys__4519__auto__.call(null,item_set));
if(fs__4520__auto__){
return cljs.core.concat.call(null,fs__4520__auto__,tailrecursion$priority_map$iter__32172.call(null,cljs.core.rest.call(null,s__32173__$1)));
} else {
var G__32193 = cljs.core.rest.call(null,s__32173__$1);
s__32173__$1 = G__32193;
continue;
}
} else {
return null;
}
break;
}
});})(sets,this$__$1))
,null,null));
});})(sets,this$__$1))
;
return iter__4523__auto__.call(null,sets);
})());
}
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$ISorted$_entry_key$arity$2 = (function (this$,entry){
var self__ = this;
var this$__$1 = this;
return self__.keyfn.call(null,cljs.core.val.call(null,entry));
});

tailrecursion.priority_map.PersistentPriorityMap.prototype.cljs$core$ISorted$_comparator$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return cljs.core.compare;
});

tailrecursion.priority_map.PersistentPriorityMap.getBasis = (function (){
return new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"priority->set-of-items","priority->set-of-items",-1256537211,null),new cljs.core.Symbol(null,"item->priority","item->priority",-899999435,null),new cljs.core.Symbol(null,"meta","meta",-1154898805,null),new cljs.core.Symbol(null,"keyfn","keyfn",-1874375437,null),cljs.core.with_meta(new cljs.core.Symbol(null,"__hash","__hash",-1328796629,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"mutable","mutable",875778266),true], null))], null);
});

tailrecursion.priority_map.PersistentPriorityMap.cljs$lang$type = true;

tailrecursion.priority_map.PersistentPriorityMap.cljs$lang$ctorStr = "tailrecursion.priority-map/PersistentPriorityMap";

tailrecursion.priority_map.PersistentPriorityMap.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write.call(null,writer__4375__auto__,"tailrecursion.priority-map/PersistentPriorityMap");
});

/**
 * Positional factory function for tailrecursion.priority-map/PersistentPriorityMap.
 */
tailrecursion.priority_map.__GT_PersistentPriorityMap = (function tailrecursion$priority_map$__GT_PersistentPriorityMap(priority__GT_set_of_items,item__GT_priority,meta,keyfn,__hash){
return (new tailrecursion.priority_map.PersistentPriorityMap(priority__GT_set_of_items,item__GT_priority,meta,keyfn,__hash));
});

tailrecursion.priority_map.PersistentPriorityMap.EMPTY = (new tailrecursion.priority_map.PersistentPriorityMap(cljs.core.sorted_map.call(null),cljs.core.PersistentArrayMap.EMPTY,cljs.core.PersistentArrayMap.EMPTY,cljs.core.identity,null));
tailrecursion.priority_map.pm_empty_by = (function tailrecursion$priority_map$pm_empty_by(comparator){
return (new tailrecursion.priority_map.PersistentPriorityMap(cljs.core.sorted_map_by.call(null,comparator),cljs.core.PersistentArrayMap.EMPTY,cljs.core.PersistentArrayMap.EMPTY,cljs.core.identity,null));
});
tailrecursion.priority_map.pm_empty_keyfn = (function tailrecursion$priority_map$pm_empty_keyfn(var_args){
var G__32195 = arguments.length;
switch (G__32195) {
case 1:
return tailrecursion.priority_map.pm_empty_keyfn.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return tailrecursion.priority_map.pm_empty_keyfn.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

tailrecursion.priority_map.pm_empty_keyfn.cljs$core$IFn$_invoke$arity$1 = (function (keyfn){
return (new tailrecursion.priority_map.PersistentPriorityMap(cljs.core.sorted_map.call(null),cljs.core.PersistentArrayMap.EMPTY,cljs.core.PersistentArrayMap.EMPTY,keyfn,null));
});

tailrecursion.priority_map.pm_empty_keyfn.cljs$core$IFn$_invoke$arity$2 = (function (keyfn,comparator){
return (new tailrecursion.priority_map.PersistentPriorityMap(cljs.core.sorted_map_by.call(null,comparator),cljs.core.PersistentArrayMap.EMPTY,cljs.core.PersistentArrayMap.EMPTY,keyfn,null));
});

tailrecursion.priority_map.pm_empty_keyfn.cljs$lang$maxFixedArity = 2;

tailrecursion.priority_map.read_priority_map = (function tailrecursion$priority_map$read_priority_map(elems){
if(cljs.core.map_QMARK_.call(null,elems)){
return cljs.core.into.call(null,tailrecursion.priority_map.PersistentPriorityMap.EMPTY,elems);
} else {
throw Error("Priority map literal expects a map for its elements.");
}
});
cljs.reader.register_tag_parser_BANG_.call(null,"tailrecursion.priority-map",tailrecursion.priority_map.read_priority_map);
/**
 * keyval => key val
 *   Returns a new priority map with supplied mappings.
 */
tailrecursion.priority_map.priority_map = (function tailrecursion$priority_map$priority_map(var_args){
var args__4736__auto__ = [];
var len__4730__auto___32198 = arguments.length;
var i__4731__auto___32199 = (0);
while(true){
if((i__4731__auto___32199 < len__4730__auto___32198)){
args__4736__auto__.push((arguments[i__4731__auto___32199]));

var G__32200 = (i__4731__auto___32199 + (1));
i__4731__auto___32199 = G__32200;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((0) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((0)),(0),null)):null);
return tailrecursion.priority_map.priority_map.cljs$core$IFn$_invoke$arity$variadic(argseq__4737__auto__);
});

tailrecursion.priority_map.priority_map.cljs$core$IFn$_invoke$arity$variadic = (function (keyvals){
var in$ = cljs.core.seq.call(null,keyvals);
var out = tailrecursion.priority_map.PersistentPriorityMap.EMPTY;
while(true){
if(in$){
var G__32201 = cljs.core.nnext.call(null,in$);
var G__32202 = cljs.core.assoc.call(null,out,cljs.core.first.call(null,in$),cljs.core.second.call(null,in$));
in$ = G__32201;
out = G__32202;
continue;
} else {
return out;
}
break;
}
});

tailrecursion.priority_map.priority_map.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
tailrecursion.priority_map.priority_map.cljs$lang$applyTo = (function (seq32197){
var self__4718__auto__ = this;
return self__4718__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq32197));
});

/**
 * keyval => key val
 *   Returns a new priority map with supplied
 *   mappings, using the supplied comparator.
 */
tailrecursion.priority_map.priority_map_by = (function tailrecursion$priority_map$priority_map_by(var_args){
var args__4736__auto__ = [];
var len__4730__auto___32205 = arguments.length;
var i__4731__auto___32206 = (0);
while(true){
if((i__4731__auto___32206 < len__4730__auto___32205)){
args__4736__auto__.push((arguments[i__4731__auto___32206]));

var G__32207 = (i__4731__auto___32206 + (1));
i__4731__auto___32206 = G__32207;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return tailrecursion.priority_map.priority_map_by.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

tailrecursion.priority_map.priority_map_by.cljs$core$IFn$_invoke$arity$variadic = (function (comparator,keyvals){
var in$ = cljs.core.seq.call(null,keyvals);
var out = tailrecursion.priority_map.pm_empty_by.call(null,comparator);
while(true){
if(in$){
var G__32208 = cljs.core.nnext.call(null,in$);
var G__32209 = cljs.core.assoc.call(null,out,cljs.core.first.call(null,in$),cljs.core.second.call(null,in$));
in$ = G__32208;
out = G__32209;
continue;
} else {
return out;
}
break;
}
});

tailrecursion.priority_map.priority_map_by.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
tailrecursion.priority_map.priority_map_by.cljs$lang$applyTo = (function (seq32203){
var G__32204 = cljs.core.first.call(null,seq32203);
var seq32203__$1 = cljs.core.next.call(null,seq32203);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__32204,seq32203__$1);
});

/**
 * keyval => key val
 *   Returns a new priority map with supplied
 *   mappings, using the supplied keyfn.
 */
tailrecursion.priority_map.priority_map_keyfn = (function tailrecursion$priority_map$priority_map_keyfn(var_args){
var args__4736__auto__ = [];
var len__4730__auto___32212 = arguments.length;
var i__4731__auto___32213 = (0);
while(true){
if((i__4731__auto___32213 < len__4730__auto___32212)){
args__4736__auto__.push((arguments[i__4731__auto___32213]));

var G__32214 = (i__4731__auto___32213 + (1));
i__4731__auto___32213 = G__32214;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return tailrecursion.priority_map.priority_map_keyfn.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

tailrecursion.priority_map.priority_map_keyfn.cljs$core$IFn$_invoke$arity$variadic = (function (keyfn,keyvals){
var in$ = cljs.core.seq.call(null,keyvals);
var out = tailrecursion.priority_map.pm_empty_keyfn.call(null,keyfn);
while(true){
if(in$){
var G__32215 = cljs.core.nnext.call(null,in$);
var G__32216 = cljs.core.assoc.call(null,out,cljs.core.first.call(null,in$),cljs.core.second.call(null,in$));
in$ = G__32215;
out = G__32216;
continue;
} else {
return out;
}
break;
}
});

tailrecursion.priority_map.priority_map_keyfn.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
tailrecursion.priority_map.priority_map_keyfn.cljs$lang$applyTo = (function (seq32210){
var G__32211 = cljs.core.first.call(null,seq32210);
var seq32210__$1 = cljs.core.next.call(null,seq32210);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__32211,seq32210__$1);
});

/**
 * keyval => key val
 *   Returns a new priority map with supplied
 *   mappings, using the supplied keyfn and comparator.
 */
tailrecursion.priority_map.priority_map_keyfn_by = (function tailrecursion$priority_map$priority_map_keyfn_by(var_args){
var args__4736__auto__ = [];
var len__4730__auto___32220 = arguments.length;
var i__4731__auto___32221 = (0);
while(true){
if((i__4731__auto___32221 < len__4730__auto___32220)){
args__4736__auto__.push((arguments[i__4731__auto___32221]));

var G__32222 = (i__4731__auto___32221 + (1));
i__4731__auto___32221 = G__32222;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return tailrecursion.priority_map.priority_map_keyfn_by.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

tailrecursion.priority_map.priority_map_keyfn_by.cljs$core$IFn$_invoke$arity$variadic = (function (keyfn,comparator,keyvals){
var in$ = cljs.core.seq.call(null,keyvals);
var out = tailrecursion.priority_map.pm_empty_keyfn.call(null,keyfn,comparator);
while(true){
if(in$){
var G__32223 = cljs.core.nnext.call(null,in$);
var G__32224 = cljs.core.assoc.call(null,out,cljs.core.first.call(null,in$),cljs.core.second.call(null,in$));
in$ = G__32223;
out = G__32224;
continue;
} else {
return out;
}
break;
}
});

tailrecursion.priority_map.priority_map_keyfn_by.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
tailrecursion.priority_map.priority_map_keyfn_by.cljs$lang$applyTo = (function (seq32217){
var G__32218 = cljs.core.first.call(null,seq32217);
var seq32217__$1 = cljs.core.next.call(null,seq32217);
var G__32219 = cljs.core.first.call(null,seq32217__$1);
var seq32217__$2 = cljs.core.next.call(null,seq32217__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__32218,G__32219,seq32217__$2);
});


//# sourceMappingURL=priority_map.js.map
