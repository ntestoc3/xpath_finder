// Compiled by ClojureScript 1.10.597 {}
goog.provide('cljs.core.async');
goog.require('cljs.core');
goog.require('cljs.core.async.impl.protocols');
goog.require('cljs.core.async.impl.channels');
goog.require('cljs.core.async.impl.buffers');
goog.require('cljs.core.async.impl.timers');
goog.require('cljs.core.async.impl.dispatch');
goog.require('cljs.core.async.impl.ioc_helpers');
goog.require('goog.array');
cljs.core.async.fn_handler = (function cljs$core$async$fn_handler(var_args){
var G__44272 = arguments.length;
switch (G__44272) {
case 1:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1 = (function (f){
return cljs.core.async.fn_handler.call(null,f,true);
}));

(cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2 = (function (f,blockable){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async44273 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async44273 = (function (f,blockable,meta44274){
this.f = f;
this.blockable = blockable;
this.meta44274 = meta44274;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async44273.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_44275,meta44274__$1){
var self__ = this;
var _44275__$1 = this;
return (new cljs.core.async.t_cljs$core$async44273(self__.f,self__.blockable,meta44274__$1));
}));

(cljs.core.async.t_cljs$core$async44273.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_44275){
var self__ = this;
var _44275__$1 = this;
return self__.meta44274;
}));

(cljs.core.async.t_cljs$core$async44273.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async44273.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
}));

(cljs.core.async.t_cljs$core$async44273.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.blockable;
}));

(cljs.core.async.t_cljs$core$async44273.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.f;
}));

(cljs.core.async.t_cljs$core$async44273.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"blockable","blockable",-28395259,null),new cljs.core.Symbol(null,"meta44274","meta44274",1005102200,null)], null);
}));

(cljs.core.async.t_cljs$core$async44273.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async44273.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async44273");

(cljs.core.async.t_cljs$core$async44273.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write.call(null,writer__4429__auto__,"cljs.core.async/t_cljs$core$async44273");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async44273.
 */
cljs.core.async.__GT_t_cljs$core$async44273 = (function cljs$core$async$__GT_t_cljs$core$async44273(f__$1,blockable__$1,meta44274){
return (new cljs.core.async.t_cljs$core$async44273(f__$1,blockable__$1,meta44274));
});

}

return (new cljs.core.async.t_cljs$core$async44273(f,blockable,cljs.core.PersistentArrayMap.EMPTY));
}));

(cljs.core.async.fn_handler.cljs$lang$maxFixedArity = 2);

/**
 * Returns a fixed buffer of size n. When full, puts will block/park.
 */
cljs.core.async.buffer = (function cljs$core$async$buffer(n){
return cljs.core.async.impl.buffers.fixed_buffer.call(null,n);
});
/**
 * Returns a buffer of size n. When full, puts will complete but
 *   val will be dropped (no transfer).
 */
cljs.core.async.dropping_buffer = (function cljs$core$async$dropping_buffer(n){
return cljs.core.async.impl.buffers.dropping_buffer.call(null,n);
});
/**
 * Returns a buffer of size n. When full, puts will complete, and be
 *   buffered, but oldest elements in buffer will be dropped (not
 *   transferred).
 */
cljs.core.async.sliding_buffer = (function cljs$core$async$sliding_buffer(n){
return cljs.core.async.impl.buffers.sliding_buffer.call(null,n);
});
/**
 * Returns true if a channel created with buff will never block. That is to say,
 * puts into this buffer will never cause the buffer to be full. 
 */
cljs.core.async.unblocking_buffer_QMARK_ = (function cljs$core$async$unblocking_buffer_QMARK_(buff){
if((!((buff == null)))){
if(((false) || ((cljs.core.PROTOCOL_SENTINEL === buff.cljs$core$async$impl$protocols$UnblockingBuffer$)))){
return true;
} else {
if((!buff.cljs$lang$protocol_mask$partition$)){
return cljs.core.native_satisfies_QMARK_.call(null,cljs.core.async.impl.protocols.UnblockingBuffer,buff);
} else {
return false;
}
}
} else {
return cljs.core.native_satisfies_QMARK_.call(null,cljs.core.async.impl.protocols.UnblockingBuffer,buff);
}
});
/**
 * Creates a channel with an optional buffer, an optional transducer (like (map f),
 *   (filter p) etc or a composition thereof), and an optional exception handler.
 *   If buf-or-n is a number, will create and use a fixed buffer of that size. If a
 *   transducer is supplied a buffer must be specified. ex-handler must be a
 *   fn of one argument - if an exception occurs during transformation it will be called
 *   with the thrown value as an argument, and any non-nil return value will be placed
 *   in the channel.
 */
cljs.core.async.chan = (function cljs$core$async$chan(var_args){
var G__44279 = arguments.length;
switch (G__44279) {
case 0:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.chan.call(null,null);
}));

(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1 = (function (buf_or_n){
return cljs.core.async.chan.call(null,buf_or_n,null,null);
}));

(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2 = (function (buf_or_n,xform){
return cljs.core.async.chan.call(null,buf_or_n,xform,null);
}));

(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3 = (function (buf_or_n,xform,ex_handler){
var buf_or_n__$1 = ((cljs.core._EQ_.call(null,buf_or_n,(0)))?null:buf_or_n);
if(cljs.core.truth_(xform)){
if(cljs.core.truth_(buf_or_n__$1)){
} else {
throw (new Error(["Assert failed: ","buffer must be supplied when transducer is","\n","buf-or-n"].join('')));
}
} else {
}

return cljs.core.async.impl.channels.chan.call(null,((typeof buf_or_n__$1 === 'number')?cljs.core.async.buffer.call(null,buf_or_n__$1):buf_or_n__$1),xform,ex_handler);
}));

(cljs.core.async.chan.cljs$lang$maxFixedArity = 3);

/**
 * Creates a promise channel with an optional transducer, and an optional
 *   exception-handler. A promise channel can take exactly one value that consumers
 *   will receive. Once full, puts complete but val is dropped (no transfer).
 *   Consumers will block until either a value is placed in the channel or the
 *   channel is closed. See chan for the semantics of xform and ex-handler.
 */
cljs.core.async.promise_chan = (function cljs$core$async$promise_chan(var_args){
var G__44282 = arguments.length;
switch (G__44282) {
case 0:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.promise_chan.call(null,null);
}));

(cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1 = (function (xform){
return cljs.core.async.promise_chan.call(null,xform,null);
}));

(cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2 = (function (xform,ex_handler){
return cljs.core.async.chan.call(null,cljs.core.async.impl.buffers.promise_buffer.call(null),xform,ex_handler);
}));

(cljs.core.async.promise_chan.cljs$lang$maxFixedArity = 2);

/**
 * Returns a channel that will close after msecs
 */
cljs.core.async.timeout = (function cljs$core$async$timeout(msecs){
return cljs.core.async.impl.timers.timeout.call(null,msecs);
});
/**
 * takes a val from port. Must be called inside a (go ...) block. Will
 *   return nil if closed. Will park if nothing is available.
 *   Returns true unless port is already closed
 */
cljs.core.async._LT__BANG_ = (function cljs$core$async$_LT__BANG_(port){
throw (new Error("<! used not in (go ...) block"));
});
/**
 * Asynchronously takes a val from port, passing to fn1. Will pass nil
 * if closed. If on-caller? (default true) is true, and value is
 * immediately available, will call fn1 on calling thread.
 * Returns nil.
 */
cljs.core.async.take_BANG_ = (function cljs$core$async$take_BANG_(var_args){
var G__44285 = arguments.length;
switch (G__44285) {
case 2:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,fn1){
return cljs.core.async.take_BANG_.call(null,port,fn1,true);
}));

(cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,fn1,on_caller_QMARK_){
var ret = cljs.core.async.impl.protocols.take_BANG_.call(null,port,cljs.core.async.fn_handler.call(null,fn1));
if(cljs.core.truth_(ret)){
var val_44287 = cljs.core.deref.call(null,ret);
if(cljs.core.truth_(on_caller_QMARK_)){
fn1.call(null,val_44287);
} else {
cljs.core.async.impl.dispatch.run.call(null,(function (){
return fn1.call(null,val_44287);
}));
}
} else {
}

return null;
}));

(cljs.core.async.take_BANG_.cljs$lang$maxFixedArity = 3);

cljs.core.async.nop = (function cljs$core$async$nop(_){
return null;
});
cljs.core.async.fhnop = cljs.core.async.fn_handler.call(null,cljs.core.async.nop);
/**
 * puts a val into port. nil values are not allowed. Must be called
 *   inside a (go ...) block. Will park if no buffer space is available.
 *   Returns true unless port is already closed.
 */
cljs.core.async._GT__BANG_ = (function cljs$core$async$_GT__BANG_(port,val){
throw (new Error(">! used not in (go ...) block"));
});
/**
 * Asynchronously puts a val into port, calling fn1 (if supplied) when
 * complete. nil values are not allowed. Will throw if closed. If
 * on-caller? (default true) is true, and the put is immediately
 * accepted, will call fn1 on calling thread.  Returns nil.
 */
cljs.core.async.put_BANG_ = (function cljs$core$async$put_BANG_(var_args){
var G__44289 = arguments.length;
switch (G__44289) {
case 2:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,val){
var temp__5733__auto__ = cljs.core.async.impl.protocols.put_BANG_.call(null,port,val,cljs.core.async.fhnop);
if(cljs.core.truth_(temp__5733__auto__)){
var ret = temp__5733__auto__;
return cljs.core.deref.call(null,ret);
} else {
return true;
}
}));

(cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,val,fn1){
return cljs.core.async.put_BANG_.call(null,port,val,fn1,true);
}));

(cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4 = (function (port,val,fn1,on_caller_QMARK_){
var temp__5733__auto__ = cljs.core.async.impl.protocols.put_BANG_.call(null,port,val,cljs.core.async.fn_handler.call(null,fn1));
if(cljs.core.truth_(temp__5733__auto__)){
var retb = temp__5733__auto__;
var ret = cljs.core.deref.call(null,retb);
if(cljs.core.truth_(on_caller_QMARK_)){
fn1.call(null,ret);
} else {
cljs.core.async.impl.dispatch.run.call(null,(function (){
return fn1.call(null,ret);
}));
}

return ret;
} else {
return true;
}
}));

(cljs.core.async.put_BANG_.cljs$lang$maxFixedArity = 4);

cljs.core.async.close_BANG_ = (function cljs$core$async$close_BANG_(port){
return cljs.core.async.impl.protocols.close_BANG_.call(null,port);
});
cljs.core.async.random_array = (function cljs$core$async$random_array(n){
var a = (new Array(n));
var n__4666__auto___44291 = n;
var x_44292 = (0);
while(true){
if((x_44292 < n__4666__auto___44291)){
(a[x_44292] = x_44292);

var G__44293 = (x_44292 + (1));
x_44292 = G__44293;
continue;
} else {
}
break;
}

goog.array.shuffle(a);

return a;
});
cljs.core.async.alt_flag = (function cljs$core$async$alt_flag(){
var flag = cljs.core.atom.call(null,true);
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async44294 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async44294 = (function (flag,meta44295){
this.flag = flag;
this.meta44295 = meta44295;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async44294.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_44296,meta44295__$1){
var self__ = this;
var _44296__$1 = this;
return (new cljs.core.async.t_cljs$core$async44294(self__.flag,meta44295__$1));
}));

(cljs.core.async.t_cljs$core$async44294.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_44296){
var self__ = this;
var _44296__$1 = this;
return self__.meta44295;
}));

(cljs.core.async.t_cljs$core$async44294.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async44294.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.deref.call(null,self__.flag);
}));

(cljs.core.async.t_cljs$core$async44294.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
}));

(cljs.core.async.t_cljs$core$async44294.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_.call(null,self__.flag,null);

return true;
}));

(cljs.core.async.t_cljs$core$async44294.getBasis = (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"flag","flag",-1565787888,null),new cljs.core.Symbol(null,"meta44295","meta44295",750723317,null)], null);
}));

(cljs.core.async.t_cljs$core$async44294.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async44294.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async44294");

(cljs.core.async.t_cljs$core$async44294.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write.call(null,writer__4429__auto__,"cljs.core.async/t_cljs$core$async44294");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async44294.
 */
cljs.core.async.__GT_t_cljs$core$async44294 = (function cljs$core$async$alt_flag_$___GT_t_cljs$core$async44294(flag__$1,meta44295){
return (new cljs.core.async.t_cljs$core$async44294(flag__$1,meta44295));
});

}

return (new cljs.core.async.t_cljs$core$async44294(flag,cljs.core.PersistentArrayMap.EMPTY));
});
cljs.core.async.alt_handler = (function cljs$core$async$alt_handler(flag,cb){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async44297 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async44297 = (function (flag,cb,meta44298){
this.flag = flag;
this.cb = cb;
this.meta44298 = meta44298;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async44297.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_44299,meta44298__$1){
var self__ = this;
var _44299__$1 = this;
return (new cljs.core.async.t_cljs$core$async44297(self__.flag,self__.cb,meta44298__$1));
}));

(cljs.core.async.t_cljs$core$async44297.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_44299){
var self__ = this;
var _44299__$1 = this;
return self__.meta44298;
}));

(cljs.core.async.t_cljs$core$async44297.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async44297.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.active_QMARK_.call(null,self__.flag);
}));

(cljs.core.async.t_cljs$core$async44297.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
}));

(cljs.core.async.t_cljs$core$async44297.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.async.impl.protocols.commit.call(null,self__.flag);

return self__.cb;
}));

(cljs.core.async.t_cljs$core$async44297.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"flag","flag",-1565787888,null),new cljs.core.Symbol(null,"cb","cb",-2064487928,null),new cljs.core.Symbol(null,"meta44298","meta44298",-1506700824,null)], null);
}));

(cljs.core.async.t_cljs$core$async44297.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async44297.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async44297");

(cljs.core.async.t_cljs$core$async44297.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write.call(null,writer__4429__auto__,"cljs.core.async/t_cljs$core$async44297");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async44297.
 */
cljs.core.async.__GT_t_cljs$core$async44297 = (function cljs$core$async$alt_handler_$___GT_t_cljs$core$async44297(flag__$1,cb__$1,meta44298){
return (new cljs.core.async.t_cljs$core$async44297(flag__$1,cb__$1,meta44298));
});

}

return (new cljs.core.async.t_cljs$core$async44297(flag,cb,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * returns derefable [val port] if immediate, nil if enqueued
 */
cljs.core.async.do_alts = (function cljs$core$async$do_alts(fret,ports,opts){
if((cljs.core.count.call(null,ports) > (0))){
} else {
throw (new Error(["Assert failed: ","alts must have at least one channel operation","\n","(pos? (count ports))"].join('')));
}

var flag = cljs.core.async.alt_flag.call(null);
var n = cljs.core.count.call(null,ports);
var idxs = cljs.core.async.random_array.call(null,n);
var priority = new cljs.core.Keyword(null,"priority","priority",1431093715).cljs$core$IFn$_invoke$arity$1(opts);
var ret = (function (){var i = (0);
while(true){
if((i < n)){
var idx = (cljs.core.truth_(priority)?i:(idxs[i]));
var port = cljs.core.nth.call(null,ports,idx);
var wport = ((cljs.core.vector_QMARK_.call(null,port))?port.call(null,(0)):null);
var vbox = (cljs.core.truth_(wport)?(function (){var val = port.call(null,(1));
return cljs.core.async.impl.protocols.put_BANG_.call(null,wport,val,cljs.core.async.alt_handler.call(null,flag,((function (i,val,idx,port,wport,flag,n,idxs,priority){
return (function (p1__44300_SHARP_){
return fret.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__44300_SHARP_,wport], null));
});})(i,val,idx,port,wport,flag,n,idxs,priority))
));
})():cljs.core.async.impl.protocols.take_BANG_.call(null,port,cljs.core.async.alt_handler.call(null,flag,((function (i,idx,port,wport,flag,n,idxs,priority){
return (function (p1__44301_SHARP_){
return fret.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__44301_SHARP_,port], null));
});})(i,idx,port,wport,flag,n,idxs,priority))
)));
if(cljs.core.truth_(vbox)){
return cljs.core.async.impl.channels.box.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.deref.call(null,vbox),(function (){var or__4185__auto__ = wport;
if(cljs.core.truth_(or__4185__auto__)){
return or__4185__auto__;
} else {
return port;
}
})()], null));
} else {
var G__44302 = (i + (1));
i = G__44302;
continue;
}
} else {
return null;
}
break;
}
})();
var or__4185__auto__ = ret;
if(cljs.core.truth_(or__4185__auto__)){
return or__4185__auto__;
} else {
if(cljs.core.contains_QMARK_.call(null,opts,new cljs.core.Keyword(null,"default","default",-1987822328))){
var temp__5735__auto__ = (function (){var and__4174__auto__ = cljs.core.async.impl.protocols.active_QMARK_.call(null,flag);
if(cljs.core.truth_(and__4174__auto__)){
return cljs.core.async.impl.protocols.commit.call(null,flag);
} else {
return and__4174__auto__;
}
})();
if(cljs.core.truth_(temp__5735__auto__)){
var got = temp__5735__auto__;
return cljs.core.async.impl.channels.box.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"default","default",-1987822328).cljs$core$IFn$_invoke$arity$1(opts),new cljs.core.Keyword(null,"default","default",-1987822328)], null));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Completes at most one of several channel operations. Must be called
 * inside a (go ...) block. ports is a vector of channel endpoints,
 * which can be either a channel to take from or a vector of
 *   [channel-to-put-to val-to-put], in any combination. Takes will be
 *   made as if by <!, and puts will be made as if by >!. Unless
 *   the :priority option is true, if more than one port operation is
 *   ready a non-deterministic choice will be made. If no operation is
 *   ready and a :default value is supplied, [default-val :default] will
 *   be returned, otherwise alts! will park until the first operation to
 *   become ready completes. Returns [val port] of the completed
 *   operation, where val is the value taken for takes, and a
 *   boolean (true unless already closed, as per put!) for puts.
 * 
 *   opts are passed as :key val ... Supported options:
 * 
 *   :default val - the value to use if none of the operations are immediately ready
 *   :priority true - (default nil) when true, the operations will be tried in order.
 * 
 *   Note: there is no guarantee that the port exps or val exprs will be
 *   used, nor in what order should they be, so they should not be
 *   depended upon for side effects.
 */
cljs.core.async.alts_BANG_ = (function cljs$core$async$alts_BANG_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___44308 = arguments.length;
var i__4790__auto___44309 = (0);
while(true){
if((i__4790__auto___44309 < len__4789__auto___44308)){
args__4795__auto__.push((arguments[i__4790__auto___44309]));

var G__44310 = (i__4790__auto___44309 + (1));
i__4790__auto___44309 = G__44310;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((1) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((1)),(0),null)):null);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4796__auto__);
});

(cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (ports,p__44305){
var map__44306 = p__44305;
var map__44306__$1 = (((((!((map__44306 == null))))?(((((map__44306.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__44306.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__44306):map__44306);
var opts = map__44306__$1;
throw (new Error("alts! used not in (go ...) block"));
}));

(cljs.core.async.alts_BANG_.cljs$lang$maxFixedArity = (1));

/** @this {Function} */
(cljs.core.async.alts_BANG_.cljs$lang$applyTo = (function (seq44303){
var G__44304 = cljs.core.first.call(null,seq44303);
var seq44303__$1 = cljs.core.next.call(null,seq44303);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__44304,seq44303__$1);
}));

/**
 * Puts a val into port if it's possible to do so immediately.
 *   nil values are not allowed. Never blocks. Returns true if offer succeeds.
 */
cljs.core.async.offer_BANG_ = (function cljs$core$async$offer_BANG_(port,val){
var ret = cljs.core.async.impl.protocols.put_BANG_.call(null,port,val,cljs.core.async.fn_handler.call(null,cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref.call(null,ret);
} else {
return null;
}
});
/**
 * Takes a val from port if it's possible to do so immediately.
 *   Never blocks. Returns value if successful, nil otherwise.
 */
cljs.core.async.poll_BANG_ = (function cljs$core$async$poll_BANG_(port){
var ret = cljs.core.async.impl.protocols.take_BANG_.call(null,port,cljs.core.async.fn_handler.call(null,cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref.call(null,ret);
} else {
return null;
}
});
/**
 * Takes elements from the from channel and supplies them to the to
 * channel. By default, the to channel will be closed when the from
 * channel closes, but can be determined by the close?  parameter. Will
 * stop consuming the from channel if the to channel closes
 */
cljs.core.async.pipe = (function cljs$core$async$pipe(var_args){
var G__44312 = arguments.length;
switch (G__44312) {
case 2:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2 = (function (from,to){
return cljs.core.async.pipe.call(null,from,to,true);
}));

(cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3 = (function (from,to,close_QMARK_){
var c__27715__auto___44358 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_44336){
var state_val_44337 = (state_44336[(1)]);
if((state_val_44337 === (7))){
var inst_44332 = (state_44336[(2)]);
var state_44336__$1 = state_44336;
var statearr_44338_44359 = state_44336__$1;
(statearr_44338_44359[(2)] = inst_44332);

(statearr_44338_44359[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44337 === (1))){
var state_44336__$1 = state_44336;
var statearr_44339_44360 = state_44336__$1;
(statearr_44339_44360[(2)] = null);

(statearr_44339_44360[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44337 === (4))){
var inst_44315 = (state_44336[(7)]);
var inst_44315__$1 = (state_44336[(2)]);
var inst_44316 = (inst_44315__$1 == null);
var state_44336__$1 = (function (){var statearr_44340 = state_44336;
(statearr_44340[(7)] = inst_44315__$1);

return statearr_44340;
})();
if(cljs.core.truth_(inst_44316)){
var statearr_44341_44361 = state_44336__$1;
(statearr_44341_44361[(1)] = (5));

} else {
var statearr_44342_44362 = state_44336__$1;
(statearr_44342_44362[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44337 === (13))){
var state_44336__$1 = state_44336;
var statearr_44343_44363 = state_44336__$1;
(statearr_44343_44363[(2)] = null);

(statearr_44343_44363[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44337 === (6))){
var inst_44315 = (state_44336[(7)]);
var state_44336__$1 = state_44336;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_44336__$1,(11),to,inst_44315);
} else {
if((state_val_44337 === (3))){
var inst_44334 = (state_44336[(2)]);
var state_44336__$1 = state_44336;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_44336__$1,inst_44334);
} else {
if((state_val_44337 === (12))){
var state_44336__$1 = state_44336;
var statearr_44344_44364 = state_44336__$1;
(statearr_44344_44364[(2)] = null);

(statearr_44344_44364[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44337 === (2))){
var state_44336__$1 = state_44336;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_44336__$1,(4),from);
} else {
if((state_val_44337 === (11))){
var inst_44325 = (state_44336[(2)]);
var state_44336__$1 = state_44336;
if(cljs.core.truth_(inst_44325)){
var statearr_44345_44365 = state_44336__$1;
(statearr_44345_44365[(1)] = (12));

} else {
var statearr_44346_44366 = state_44336__$1;
(statearr_44346_44366[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44337 === (9))){
var state_44336__$1 = state_44336;
var statearr_44347_44367 = state_44336__$1;
(statearr_44347_44367[(2)] = null);

(statearr_44347_44367[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44337 === (5))){
var state_44336__$1 = state_44336;
if(cljs.core.truth_(close_QMARK_)){
var statearr_44348_44368 = state_44336__$1;
(statearr_44348_44368[(1)] = (8));

} else {
var statearr_44349_44369 = state_44336__$1;
(statearr_44349_44369[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44337 === (14))){
var inst_44330 = (state_44336[(2)]);
var state_44336__$1 = state_44336;
var statearr_44350_44370 = state_44336__$1;
(statearr_44350_44370[(2)] = inst_44330);

(statearr_44350_44370[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44337 === (10))){
var inst_44322 = (state_44336[(2)]);
var state_44336__$1 = state_44336;
var statearr_44351_44371 = state_44336__$1;
(statearr_44351_44371[(2)] = inst_44322);

(statearr_44351_44371[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44337 === (8))){
var inst_44319 = cljs.core.async.close_BANG_.call(null,to);
var state_44336__$1 = state_44336;
var statearr_44352_44372 = state_44336__$1;
(statearr_44352_44372[(2)] = inst_44319);

(statearr_44352_44372[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_44353 = [null,null,null,null,null,null,null,null];
(statearr_44353[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_44353[(1)] = (1));

return statearr_44353;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_44336){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_44336);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e44354){if((e44354 instanceof Object)){
var ex__27528__auto__ = e44354;
var statearr_44355_44373 = state_44336;
(statearr_44355_44373[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_44336);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e44354;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__44374 = state_44336;
state_44336 = G__44374;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_44336){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_44336);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_44356 = f__27716__auto__.call(null);
(statearr_44356[(6)] = c__27715__auto___44358);

return statearr_44356;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


return to;
}));

(cljs.core.async.pipe.cljs$lang$maxFixedArity = 3);

cljs.core.async.pipeline_STAR_ = (function cljs$core$async$pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,type){
if((n > (0))){
} else {
throw (new Error("Assert failed: (pos? n)"));
}

var jobs = cljs.core.async.chan.call(null,n);
var results = cljs.core.async.chan.call(null,n);
var process = (function (p__44375){
var vec__44376 = p__44375;
var v = cljs.core.nth.call(null,vec__44376,(0),null);
var p = cljs.core.nth.call(null,vec__44376,(1),null);
var job = vec__44376;
if((job == null)){
cljs.core.async.close_BANG_.call(null,results);

return null;
} else {
var res = cljs.core.async.chan.call(null,(1),xf,ex_handler);
var c__27715__auto___44547 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_44383){
var state_val_44384 = (state_44383[(1)]);
if((state_val_44384 === (1))){
var state_44383__$1 = state_44383;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_44383__$1,(2),res,v);
} else {
if((state_val_44384 === (2))){
var inst_44380 = (state_44383[(2)]);
var inst_44381 = cljs.core.async.close_BANG_.call(null,res);
var state_44383__$1 = (function (){var statearr_44385 = state_44383;
(statearr_44385[(7)] = inst_44380);

return statearr_44385;
})();
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_44383__$1,inst_44381);
} else {
return null;
}
}
});
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0 = (function (){
var statearr_44386 = [null,null,null,null,null,null,null,null];
(statearr_44386[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__);

(statearr_44386[(1)] = (1));

return statearr_44386;
});
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1 = (function (state_44383){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_44383);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e44387){if((e44387 instanceof Object)){
var ex__27528__auto__ = e44387;
var statearr_44388_44548 = state_44383;
(statearr_44388_44548[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_44383);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e44387;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__44549 = state_44383;
state_44383 = G__44549;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = function(state_44383){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1.call(this,state_44383);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_44389 = f__27716__auto__.call(null);
(statearr_44389[(6)] = c__27715__auto___44547);

return statearr_44389;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


cljs.core.async.put_BANG_.call(null,p,res);

return true;
}
});
var async = (function (p__44390){
var vec__44391 = p__44390;
var v = cljs.core.nth.call(null,vec__44391,(0),null);
var p = cljs.core.nth.call(null,vec__44391,(1),null);
var job = vec__44391;
if((job == null)){
cljs.core.async.close_BANG_.call(null,results);

return null;
} else {
var res = cljs.core.async.chan.call(null,(1));
xf.call(null,v,res);

cljs.core.async.put_BANG_.call(null,p,res);

return true;
}
});
var n__4666__auto___44550 = n;
var __44551 = (0);
while(true){
if((__44551 < n__4666__auto___44550)){
var G__44394_44552 = type;
var G__44394_44553__$1 = (((G__44394_44552 instanceof cljs.core.Keyword))?G__44394_44552.fqn:null);
switch (G__44394_44553__$1) {
case "compute":
var c__27715__auto___44555 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (__44551,c__27715__auto___44555,G__44394_44552,G__44394_44553__$1,n__4666__auto___44550,jobs,results,process,async){
return (function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = ((function (__44551,c__27715__auto___44555,G__44394_44552,G__44394_44553__$1,n__4666__auto___44550,jobs,results,process,async){
return (function (state_44407){
var state_val_44408 = (state_44407[(1)]);
if((state_val_44408 === (1))){
var state_44407__$1 = state_44407;
var statearr_44409_44556 = state_44407__$1;
(statearr_44409_44556[(2)] = null);

(statearr_44409_44556[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44408 === (2))){
var state_44407__$1 = state_44407;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_44407__$1,(4),jobs);
} else {
if((state_val_44408 === (3))){
var inst_44405 = (state_44407[(2)]);
var state_44407__$1 = state_44407;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_44407__$1,inst_44405);
} else {
if((state_val_44408 === (4))){
var inst_44397 = (state_44407[(2)]);
var inst_44398 = process.call(null,inst_44397);
var state_44407__$1 = state_44407;
if(cljs.core.truth_(inst_44398)){
var statearr_44410_44557 = state_44407__$1;
(statearr_44410_44557[(1)] = (5));

} else {
var statearr_44411_44558 = state_44407__$1;
(statearr_44411_44558[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44408 === (5))){
var state_44407__$1 = state_44407;
var statearr_44412_44559 = state_44407__$1;
(statearr_44412_44559[(2)] = null);

(statearr_44412_44559[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44408 === (6))){
var state_44407__$1 = state_44407;
var statearr_44413_44560 = state_44407__$1;
(statearr_44413_44560[(2)] = null);

(statearr_44413_44560[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44408 === (7))){
var inst_44403 = (state_44407[(2)]);
var state_44407__$1 = state_44407;
var statearr_44414_44561 = state_44407__$1;
(statearr_44414_44561[(2)] = inst_44403);

(statearr_44414_44561[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
});})(__44551,c__27715__auto___44555,G__44394_44552,G__44394_44553__$1,n__4666__auto___44550,jobs,results,process,async))
;
return ((function (__44551,switch__27524__auto__,c__27715__auto___44555,G__44394_44552,G__44394_44553__$1,n__4666__auto___44550,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0 = (function (){
var statearr_44415 = [null,null,null,null,null,null,null];
(statearr_44415[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__);

(statearr_44415[(1)] = (1));

return statearr_44415;
});
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1 = (function (state_44407){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_44407);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e44416){if((e44416 instanceof Object)){
var ex__27528__auto__ = e44416;
var statearr_44417_44562 = state_44407;
(statearr_44417_44562[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_44407);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e44416;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__44563 = state_44407;
state_44407 = G__44563;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = function(state_44407){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1.call(this,state_44407);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__;
})()
;})(__44551,switch__27524__auto__,c__27715__auto___44555,G__44394_44552,G__44394_44553__$1,n__4666__auto___44550,jobs,results,process,async))
})();
var state__27717__auto__ = (function (){var statearr_44418 = f__27716__auto__.call(null);
(statearr_44418[(6)] = c__27715__auto___44555);

return statearr_44418;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
});})(__44551,c__27715__auto___44555,G__44394_44552,G__44394_44553__$1,n__4666__auto___44550,jobs,results,process,async))
);


break;
case "async":
var c__27715__auto___44564 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (__44551,c__27715__auto___44564,G__44394_44552,G__44394_44553__$1,n__4666__auto___44550,jobs,results,process,async){
return (function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = ((function (__44551,c__27715__auto___44564,G__44394_44552,G__44394_44553__$1,n__4666__auto___44550,jobs,results,process,async){
return (function (state_44431){
var state_val_44432 = (state_44431[(1)]);
if((state_val_44432 === (1))){
var state_44431__$1 = state_44431;
var statearr_44433_44565 = state_44431__$1;
(statearr_44433_44565[(2)] = null);

(statearr_44433_44565[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44432 === (2))){
var state_44431__$1 = state_44431;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_44431__$1,(4),jobs);
} else {
if((state_val_44432 === (3))){
var inst_44429 = (state_44431[(2)]);
var state_44431__$1 = state_44431;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_44431__$1,inst_44429);
} else {
if((state_val_44432 === (4))){
var inst_44421 = (state_44431[(2)]);
var inst_44422 = async.call(null,inst_44421);
var state_44431__$1 = state_44431;
if(cljs.core.truth_(inst_44422)){
var statearr_44434_44566 = state_44431__$1;
(statearr_44434_44566[(1)] = (5));

} else {
var statearr_44435_44567 = state_44431__$1;
(statearr_44435_44567[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44432 === (5))){
var state_44431__$1 = state_44431;
var statearr_44436_44568 = state_44431__$1;
(statearr_44436_44568[(2)] = null);

(statearr_44436_44568[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44432 === (6))){
var state_44431__$1 = state_44431;
var statearr_44437_44569 = state_44431__$1;
(statearr_44437_44569[(2)] = null);

(statearr_44437_44569[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44432 === (7))){
var inst_44427 = (state_44431[(2)]);
var state_44431__$1 = state_44431;
var statearr_44438_44570 = state_44431__$1;
(statearr_44438_44570[(2)] = inst_44427);

(statearr_44438_44570[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
});})(__44551,c__27715__auto___44564,G__44394_44552,G__44394_44553__$1,n__4666__auto___44550,jobs,results,process,async))
;
return ((function (__44551,switch__27524__auto__,c__27715__auto___44564,G__44394_44552,G__44394_44553__$1,n__4666__auto___44550,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0 = (function (){
var statearr_44439 = [null,null,null,null,null,null,null];
(statearr_44439[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__);

(statearr_44439[(1)] = (1));

return statearr_44439;
});
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1 = (function (state_44431){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_44431);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e44440){if((e44440 instanceof Object)){
var ex__27528__auto__ = e44440;
var statearr_44441_44571 = state_44431;
(statearr_44441_44571[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_44431);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e44440;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__44572 = state_44431;
state_44431 = G__44572;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = function(state_44431){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1.call(this,state_44431);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__;
})()
;})(__44551,switch__27524__auto__,c__27715__auto___44564,G__44394_44552,G__44394_44553__$1,n__4666__auto___44550,jobs,results,process,async))
})();
var state__27717__auto__ = (function (){var statearr_44442 = f__27716__auto__.call(null);
(statearr_44442[(6)] = c__27715__auto___44564);

return statearr_44442;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
});})(__44551,c__27715__auto___44564,G__44394_44552,G__44394_44553__$1,n__4666__auto___44550,jobs,results,process,async))
);


break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__44394_44553__$1)].join('')));

}

var G__44573 = (__44551 + (1));
__44551 = G__44573;
continue;
} else {
}
break;
}

var c__27715__auto___44574 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_44464){
var state_val_44465 = (state_44464[(1)]);
if((state_val_44465 === (7))){
var inst_44460 = (state_44464[(2)]);
var state_44464__$1 = state_44464;
var statearr_44466_44575 = state_44464__$1;
(statearr_44466_44575[(2)] = inst_44460);

(statearr_44466_44575[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44465 === (1))){
var state_44464__$1 = state_44464;
var statearr_44467_44576 = state_44464__$1;
(statearr_44467_44576[(2)] = null);

(statearr_44467_44576[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44465 === (4))){
var inst_44445 = (state_44464[(7)]);
var inst_44445__$1 = (state_44464[(2)]);
var inst_44446 = (inst_44445__$1 == null);
var state_44464__$1 = (function (){var statearr_44468 = state_44464;
(statearr_44468[(7)] = inst_44445__$1);

return statearr_44468;
})();
if(cljs.core.truth_(inst_44446)){
var statearr_44469_44577 = state_44464__$1;
(statearr_44469_44577[(1)] = (5));

} else {
var statearr_44470_44578 = state_44464__$1;
(statearr_44470_44578[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44465 === (6))){
var inst_44445 = (state_44464[(7)]);
var inst_44450 = (state_44464[(8)]);
var inst_44450__$1 = cljs.core.async.chan.call(null,(1));
var inst_44451 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_44452 = [inst_44445,inst_44450__$1];
var inst_44453 = (new cljs.core.PersistentVector(null,2,(5),inst_44451,inst_44452,null));
var state_44464__$1 = (function (){var statearr_44471 = state_44464;
(statearr_44471[(8)] = inst_44450__$1);

return statearr_44471;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_44464__$1,(8),jobs,inst_44453);
} else {
if((state_val_44465 === (3))){
var inst_44462 = (state_44464[(2)]);
var state_44464__$1 = state_44464;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_44464__$1,inst_44462);
} else {
if((state_val_44465 === (2))){
var state_44464__$1 = state_44464;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_44464__$1,(4),from);
} else {
if((state_val_44465 === (9))){
var inst_44457 = (state_44464[(2)]);
var state_44464__$1 = (function (){var statearr_44472 = state_44464;
(statearr_44472[(9)] = inst_44457);

return statearr_44472;
})();
var statearr_44473_44579 = state_44464__$1;
(statearr_44473_44579[(2)] = null);

(statearr_44473_44579[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44465 === (5))){
var inst_44448 = cljs.core.async.close_BANG_.call(null,jobs);
var state_44464__$1 = state_44464;
var statearr_44474_44580 = state_44464__$1;
(statearr_44474_44580[(2)] = inst_44448);

(statearr_44474_44580[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44465 === (8))){
var inst_44450 = (state_44464[(8)]);
var inst_44455 = (state_44464[(2)]);
var state_44464__$1 = (function (){var statearr_44475 = state_44464;
(statearr_44475[(10)] = inst_44455);

return statearr_44475;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_44464__$1,(9),results,inst_44450);
} else {
return null;
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0 = (function (){
var statearr_44476 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_44476[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__);

(statearr_44476[(1)] = (1));

return statearr_44476;
});
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1 = (function (state_44464){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_44464);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e44477){if((e44477 instanceof Object)){
var ex__27528__auto__ = e44477;
var statearr_44478_44581 = state_44464;
(statearr_44478_44581[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_44464);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e44477;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__44582 = state_44464;
state_44464 = G__44582;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = function(state_44464){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1.call(this,state_44464);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_44479 = f__27716__auto__.call(null);
(statearr_44479[(6)] = c__27715__auto___44574);

return statearr_44479;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


var c__27715__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_44517){
var state_val_44518 = (state_44517[(1)]);
if((state_val_44518 === (7))){
var inst_44513 = (state_44517[(2)]);
var state_44517__$1 = state_44517;
var statearr_44519_44583 = state_44517__$1;
(statearr_44519_44583[(2)] = inst_44513);

(statearr_44519_44583[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44518 === (20))){
var state_44517__$1 = state_44517;
var statearr_44520_44584 = state_44517__$1;
(statearr_44520_44584[(2)] = null);

(statearr_44520_44584[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44518 === (1))){
var state_44517__$1 = state_44517;
var statearr_44521_44585 = state_44517__$1;
(statearr_44521_44585[(2)] = null);

(statearr_44521_44585[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44518 === (4))){
var inst_44482 = (state_44517[(7)]);
var inst_44482__$1 = (state_44517[(2)]);
var inst_44483 = (inst_44482__$1 == null);
var state_44517__$1 = (function (){var statearr_44522 = state_44517;
(statearr_44522[(7)] = inst_44482__$1);

return statearr_44522;
})();
if(cljs.core.truth_(inst_44483)){
var statearr_44523_44586 = state_44517__$1;
(statearr_44523_44586[(1)] = (5));

} else {
var statearr_44524_44587 = state_44517__$1;
(statearr_44524_44587[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44518 === (15))){
var inst_44495 = (state_44517[(8)]);
var state_44517__$1 = state_44517;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_44517__$1,(18),to,inst_44495);
} else {
if((state_val_44518 === (21))){
var inst_44508 = (state_44517[(2)]);
var state_44517__$1 = state_44517;
var statearr_44525_44588 = state_44517__$1;
(statearr_44525_44588[(2)] = inst_44508);

(statearr_44525_44588[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44518 === (13))){
var inst_44510 = (state_44517[(2)]);
var state_44517__$1 = (function (){var statearr_44526 = state_44517;
(statearr_44526[(9)] = inst_44510);

return statearr_44526;
})();
var statearr_44527_44589 = state_44517__$1;
(statearr_44527_44589[(2)] = null);

(statearr_44527_44589[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44518 === (6))){
var inst_44482 = (state_44517[(7)]);
var state_44517__$1 = state_44517;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_44517__$1,(11),inst_44482);
} else {
if((state_val_44518 === (17))){
var inst_44503 = (state_44517[(2)]);
var state_44517__$1 = state_44517;
if(cljs.core.truth_(inst_44503)){
var statearr_44528_44590 = state_44517__$1;
(statearr_44528_44590[(1)] = (19));

} else {
var statearr_44529_44591 = state_44517__$1;
(statearr_44529_44591[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44518 === (3))){
var inst_44515 = (state_44517[(2)]);
var state_44517__$1 = state_44517;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_44517__$1,inst_44515);
} else {
if((state_val_44518 === (12))){
var inst_44492 = (state_44517[(10)]);
var state_44517__$1 = state_44517;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_44517__$1,(14),inst_44492);
} else {
if((state_val_44518 === (2))){
var state_44517__$1 = state_44517;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_44517__$1,(4),results);
} else {
if((state_val_44518 === (19))){
var state_44517__$1 = state_44517;
var statearr_44530_44592 = state_44517__$1;
(statearr_44530_44592[(2)] = null);

(statearr_44530_44592[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44518 === (11))){
var inst_44492 = (state_44517[(2)]);
var state_44517__$1 = (function (){var statearr_44531 = state_44517;
(statearr_44531[(10)] = inst_44492);

return statearr_44531;
})();
var statearr_44532_44593 = state_44517__$1;
(statearr_44532_44593[(2)] = null);

(statearr_44532_44593[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44518 === (9))){
var state_44517__$1 = state_44517;
var statearr_44533_44594 = state_44517__$1;
(statearr_44533_44594[(2)] = null);

(statearr_44533_44594[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44518 === (5))){
var state_44517__$1 = state_44517;
if(cljs.core.truth_(close_QMARK_)){
var statearr_44534_44595 = state_44517__$1;
(statearr_44534_44595[(1)] = (8));

} else {
var statearr_44535_44596 = state_44517__$1;
(statearr_44535_44596[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44518 === (14))){
var inst_44495 = (state_44517[(8)]);
var inst_44495__$1 = (state_44517[(2)]);
var inst_44496 = (inst_44495__$1 == null);
var inst_44497 = cljs.core.not.call(null,inst_44496);
var state_44517__$1 = (function (){var statearr_44536 = state_44517;
(statearr_44536[(8)] = inst_44495__$1);

return statearr_44536;
})();
if(inst_44497){
var statearr_44537_44597 = state_44517__$1;
(statearr_44537_44597[(1)] = (15));

} else {
var statearr_44538_44598 = state_44517__$1;
(statearr_44538_44598[(1)] = (16));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44518 === (16))){
var state_44517__$1 = state_44517;
var statearr_44539_44599 = state_44517__$1;
(statearr_44539_44599[(2)] = false);

(statearr_44539_44599[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44518 === (10))){
var inst_44489 = (state_44517[(2)]);
var state_44517__$1 = state_44517;
var statearr_44540_44600 = state_44517__$1;
(statearr_44540_44600[(2)] = inst_44489);

(statearr_44540_44600[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44518 === (18))){
var inst_44500 = (state_44517[(2)]);
var state_44517__$1 = state_44517;
var statearr_44541_44601 = state_44517__$1;
(statearr_44541_44601[(2)] = inst_44500);

(statearr_44541_44601[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44518 === (8))){
var inst_44486 = cljs.core.async.close_BANG_.call(null,to);
var state_44517__$1 = state_44517;
var statearr_44542_44602 = state_44517__$1;
(statearr_44542_44602[(2)] = inst_44486);

(statearr_44542_44602[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0 = (function (){
var statearr_44543 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_44543[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__);

(statearr_44543[(1)] = (1));

return statearr_44543;
});
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1 = (function (state_44517){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_44517);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e44544){if((e44544 instanceof Object)){
var ex__27528__auto__ = e44544;
var statearr_44545_44603 = state_44517;
(statearr_44545_44603[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_44517);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e44544;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__44604 = state_44517;
state_44517 = G__44604;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = function(state_44517){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1.call(this,state_44517);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_44546 = f__27716__auto__.call(null);
(statearr_44546[(6)] = c__27715__auto__);

return statearr_44546;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));

return c__27715__auto__;
});
/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the async function af, with parallelism n. af
 *   must be a function of two arguments, the first an input value and
 *   the second a channel on which to place the result(s). af must close!
 *   the channel before returning.  The presumption is that af will
 *   return immediately, having launched some asynchronous operation
 *   whose completion/callback will manipulate the result channel. Outputs
 *   will be returned in order relative to  the inputs. By default, the to
 *   channel will be closed when the from channel closes, but can be
 *   determined by the close?  parameter. Will stop consuming the from
 *   channel if the to channel closes.
 */
cljs.core.async.pipeline_async = (function cljs$core$async$pipeline_async(var_args){
var G__44606 = arguments.length;
switch (G__44606) {
case 4:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4 = (function (n,to,af,from){
return cljs.core.async.pipeline_async.call(null,n,to,af,from,true);
}));

(cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5 = (function (n,to,af,from,close_QMARK_){
return cljs.core.async.pipeline_STAR_.call(null,n,to,af,from,close_QMARK_,null,new cljs.core.Keyword(null,"async","async",1050769601));
}));

(cljs.core.async.pipeline_async.cljs$lang$maxFixedArity = 5);

/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the transducer xf, with parallelism n. Because
 *   it is parallel, the transducer will be applied independently to each
 *   element, not across elements, and may produce zero or more outputs
 *   per input.  Outputs will be returned in order relative to the
 *   inputs. By default, the to channel will be closed when the from
 *   channel closes, but can be determined by the close?  parameter. Will
 *   stop consuming the from channel if the to channel closes.
 * 
 *   Note this is supplied for API compatibility with the Clojure version.
 *   Values of N > 1 will not result in actual concurrency in a
 *   single-threaded runtime.
 */
cljs.core.async.pipeline = (function cljs$core$async$pipeline(var_args){
var G__44609 = arguments.length;
switch (G__44609) {
case 4:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
case 6:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),(arguments[(5)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4 = (function (n,to,xf,from){
return cljs.core.async.pipeline.call(null,n,to,xf,from,true);
}));

(cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5 = (function (n,to,xf,from,close_QMARK_){
return cljs.core.async.pipeline.call(null,n,to,xf,from,close_QMARK_,null);
}));

(cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6 = (function (n,to,xf,from,close_QMARK_,ex_handler){
return cljs.core.async.pipeline_STAR_.call(null,n,to,xf,from,close_QMARK_,ex_handler,new cljs.core.Keyword(null,"compute","compute",1555393130));
}));

(cljs.core.async.pipeline.cljs$lang$maxFixedArity = 6);

/**
 * Takes a predicate and a source channel and returns a vector of two
 *   channels, the first of which will contain the values for which the
 *   predicate returned true, the second those for which it returned
 *   false.
 * 
 *   The out channels will be unbuffered by default, or two buf-or-ns can
 *   be supplied. The channels will close after the source channel has
 *   closed.
 */
cljs.core.async.split = (function cljs$core$async$split(var_args){
var G__44612 = arguments.length;
switch (G__44612) {
case 2:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 4:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.split.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.split.call(null,p,ch,null,null);
}));

(cljs.core.async.split.cljs$core$IFn$_invoke$arity$4 = (function (p,ch,t_buf_or_n,f_buf_or_n){
var tc = cljs.core.async.chan.call(null,t_buf_or_n);
var fc = cljs.core.async.chan.call(null,f_buf_or_n);
var c__27715__auto___44661 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_44638){
var state_val_44639 = (state_44638[(1)]);
if((state_val_44639 === (7))){
var inst_44634 = (state_44638[(2)]);
var state_44638__$1 = state_44638;
var statearr_44640_44662 = state_44638__$1;
(statearr_44640_44662[(2)] = inst_44634);

(statearr_44640_44662[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44639 === (1))){
var state_44638__$1 = state_44638;
var statearr_44641_44663 = state_44638__$1;
(statearr_44641_44663[(2)] = null);

(statearr_44641_44663[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44639 === (4))){
var inst_44615 = (state_44638[(7)]);
var inst_44615__$1 = (state_44638[(2)]);
var inst_44616 = (inst_44615__$1 == null);
var state_44638__$1 = (function (){var statearr_44642 = state_44638;
(statearr_44642[(7)] = inst_44615__$1);

return statearr_44642;
})();
if(cljs.core.truth_(inst_44616)){
var statearr_44643_44664 = state_44638__$1;
(statearr_44643_44664[(1)] = (5));

} else {
var statearr_44644_44665 = state_44638__$1;
(statearr_44644_44665[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44639 === (13))){
var state_44638__$1 = state_44638;
var statearr_44645_44666 = state_44638__$1;
(statearr_44645_44666[(2)] = null);

(statearr_44645_44666[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44639 === (6))){
var inst_44615 = (state_44638[(7)]);
var inst_44621 = p.call(null,inst_44615);
var state_44638__$1 = state_44638;
if(cljs.core.truth_(inst_44621)){
var statearr_44646_44667 = state_44638__$1;
(statearr_44646_44667[(1)] = (9));

} else {
var statearr_44647_44668 = state_44638__$1;
(statearr_44647_44668[(1)] = (10));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44639 === (3))){
var inst_44636 = (state_44638[(2)]);
var state_44638__$1 = state_44638;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_44638__$1,inst_44636);
} else {
if((state_val_44639 === (12))){
var state_44638__$1 = state_44638;
var statearr_44648_44669 = state_44638__$1;
(statearr_44648_44669[(2)] = null);

(statearr_44648_44669[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44639 === (2))){
var state_44638__$1 = state_44638;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_44638__$1,(4),ch);
} else {
if((state_val_44639 === (11))){
var inst_44615 = (state_44638[(7)]);
var inst_44625 = (state_44638[(2)]);
var state_44638__$1 = state_44638;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_44638__$1,(8),inst_44625,inst_44615);
} else {
if((state_val_44639 === (9))){
var state_44638__$1 = state_44638;
var statearr_44649_44670 = state_44638__$1;
(statearr_44649_44670[(2)] = tc);

(statearr_44649_44670[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44639 === (5))){
var inst_44618 = cljs.core.async.close_BANG_.call(null,tc);
var inst_44619 = cljs.core.async.close_BANG_.call(null,fc);
var state_44638__$1 = (function (){var statearr_44650 = state_44638;
(statearr_44650[(8)] = inst_44618);

return statearr_44650;
})();
var statearr_44651_44671 = state_44638__$1;
(statearr_44651_44671[(2)] = inst_44619);

(statearr_44651_44671[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44639 === (14))){
var inst_44632 = (state_44638[(2)]);
var state_44638__$1 = state_44638;
var statearr_44652_44672 = state_44638__$1;
(statearr_44652_44672[(2)] = inst_44632);

(statearr_44652_44672[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44639 === (10))){
var state_44638__$1 = state_44638;
var statearr_44653_44673 = state_44638__$1;
(statearr_44653_44673[(2)] = fc);

(statearr_44653_44673[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44639 === (8))){
var inst_44627 = (state_44638[(2)]);
var state_44638__$1 = state_44638;
if(cljs.core.truth_(inst_44627)){
var statearr_44654_44674 = state_44638__$1;
(statearr_44654_44674[(1)] = (12));

} else {
var statearr_44655_44675 = state_44638__$1;
(statearr_44655_44675[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_44656 = [null,null,null,null,null,null,null,null,null];
(statearr_44656[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_44656[(1)] = (1));

return statearr_44656;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_44638){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_44638);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e44657){if((e44657 instanceof Object)){
var ex__27528__auto__ = e44657;
var statearr_44658_44676 = state_44638;
(statearr_44658_44676[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_44638);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e44657;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__44677 = state_44638;
state_44638 = G__44677;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_44638){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_44638);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_44659 = f__27716__auto__.call(null);
(statearr_44659[(6)] = c__27715__auto___44661);

return statearr_44659;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [tc,fc], null);
}));

(cljs.core.async.split.cljs$lang$maxFixedArity = 4);

/**
 * f should be a function of 2 arguments. Returns a channel containing
 *   the single result of applying f to init and the first item from the
 *   channel, then applying f to that result and the 2nd item, etc. If
 *   the channel closes without yielding items, returns init and f is not
 *   called. ch must close before reduce produces a result.
 */
cljs.core.async.reduce = (function cljs$core$async$reduce(f,init,ch){
var c__27715__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_44698){
var state_val_44699 = (state_44698[(1)]);
if((state_val_44699 === (7))){
var inst_44694 = (state_44698[(2)]);
var state_44698__$1 = state_44698;
var statearr_44700_44718 = state_44698__$1;
(statearr_44700_44718[(2)] = inst_44694);

(statearr_44700_44718[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44699 === (1))){
var inst_44678 = init;
var state_44698__$1 = (function (){var statearr_44701 = state_44698;
(statearr_44701[(7)] = inst_44678);

return statearr_44701;
})();
var statearr_44702_44719 = state_44698__$1;
(statearr_44702_44719[(2)] = null);

(statearr_44702_44719[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44699 === (4))){
var inst_44681 = (state_44698[(8)]);
var inst_44681__$1 = (state_44698[(2)]);
var inst_44682 = (inst_44681__$1 == null);
var state_44698__$1 = (function (){var statearr_44703 = state_44698;
(statearr_44703[(8)] = inst_44681__$1);

return statearr_44703;
})();
if(cljs.core.truth_(inst_44682)){
var statearr_44704_44720 = state_44698__$1;
(statearr_44704_44720[(1)] = (5));

} else {
var statearr_44705_44721 = state_44698__$1;
(statearr_44705_44721[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44699 === (6))){
var inst_44681 = (state_44698[(8)]);
var inst_44685 = (state_44698[(9)]);
var inst_44678 = (state_44698[(7)]);
var inst_44685__$1 = f.call(null,inst_44678,inst_44681);
var inst_44686 = cljs.core.reduced_QMARK_.call(null,inst_44685__$1);
var state_44698__$1 = (function (){var statearr_44706 = state_44698;
(statearr_44706[(9)] = inst_44685__$1);

return statearr_44706;
})();
if(inst_44686){
var statearr_44707_44722 = state_44698__$1;
(statearr_44707_44722[(1)] = (8));

} else {
var statearr_44708_44723 = state_44698__$1;
(statearr_44708_44723[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44699 === (3))){
var inst_44696 = (state_44698[(2)]);
var state_44698__$1 = state_44698;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_44698__$1,inst_44696);
} else {
if((state_val_44699 === (2))){
var state_44698__$1 = state_44698;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_44698__$1,(4),ch);
} else {
if((state_val_44699 === (9))){
var inst_44685 = (state_44698[(9)]);
var inst_44678 = inst_44685;
var state_44698__$1 = (function (){var statearr_44709 = state_44698;
(statearr_44709[(7)] = inst_44678);

return statearr_44709;
})();
var statearr_44710_44724 = state_44698__$1;
(statearr_44710_44724[(2)] = null);

(statearr_44710_44724[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44699 === (5))){
var inst_44678 = (state_44698[(7)]);
var state_44698__$1 = state_44698;
var statearr_44711_44725 = state_44698__$1;
(statearr_44711_44725[(2)] = inst_44678);

(statearr_44711_44725[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44699 === (10))){
var inst_44692 = (state_44698[(2)]);
var state_44698__$1 = state_44698;
var statearr_44712_44726 = state_44698__$1;
(statearr_44712_44726[(2)] = inst_44692);

(statearr_44712_44726[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44699 === (8))){
var inst_44685 = (state_44698[(9)]);
var inst_44688 = cljs.core.deref.call(null,inst_44685);
var state_44698__$1 = state_44698;
var statearr_44713_44727 = state_44698__$1;
(statearr_44713_44727[(2)] = inst_44688);

(statearr_44713_44727[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$reduce_$_state_machine__27525__auto__ = null;
var cljs$core$async$reduce_$_state_machine__27525__auto____0 = (function (){
var statearr_44714 = [null,null,null,null,null,null,null,null,null,null];
(statearr_44714[(0)] = cljs$core$async$reduce_$_state_machine__27525__auto__);

(statearr_44714[(1)] = (1));

return statearr_44714;
});
var cljs$core$async$reduce_$_state_machine__27525__auto____1 = (function (state_44698){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_44698);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e44715){if((e44715 instanceof Object)){
var ex__27528__auto__ = e44715;
var statearr_44716_44728 = state_44698;
(statearr_44716_44728[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_44698);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e44715;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__44729 = state_44698;
state_44698 = G__44729;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$reduce_$_state_machine__27525__auto__ = function(state_44698){
switch(arguments.length){
case 0:
return cljs$core$async$reduce_$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$reduce_$_state_machine__27525__auto____1.call(this,state_44698);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$reduce_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$reduce_$_state_machine__27525__auto____0;
cljs$core$async$reduce_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$reduce_$_state_machine__27525__auto____1;
return cljs$core$async$reduce_$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_44717 = f__27716__auto__.call(null);
(statearr_44717[(6)] = c__27715__auto__);

return statearr_44717;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));

return c__27715__auto__;
});
/**
 * async/reduces a channel with a transformation (xform f).
 *   Returns a channel containing the result.  ch must close before
 *   transduce produces a result.
 */
cljs.core.async.transduce = (function cljs$core$async$transduce(xform,f,init,ch){
var f__$1 = xform.call(null,f);
var c__27715__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_44735){
var state_val_44736 = (state_44735[(1)]);
if((state_val_44736 === (1))){
var inst_44730 = cljs.core.async.reduce.call(null,f__$1,init,ch);
var state_44735__$1 = state_44735;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_44735__$1,(2),inst_44730);
} else {
if((state_val_44736 === (2))){
var inst_44732 = (state_44735[(2)]);
var inst_44733 = f__$1.call(null,inst_44732);
var state_44735__$1 = state_44735;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_44735__$1,inst_44733);
} else {
return null;
}
}
});
return (function() {
var cljs$core$async$transduce_$_state_machine__27525__auto__ = null;
var cljs$core$async$transduce_$_state_machine__27525__auto____0 = (function (){
var statearr_44737 = [null,null,null,null,null,null,null];
(statearr_44737[(0)] = cljs$core$async$transduce_$_state_machine__27525__auto__);

(statearr_44737[(1)] = (1));

return statearr_44737;
});
var cljs$core$async$transduce_$_state_machine__27525__auto____1 = (function (state_44735){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_44735);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e44738){if((e44738 instanceof Object)){
var ex__27528__auto__ = e44738;
var statearr_44739_44741 = state_44735;
(statearr_44739_44741[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_44735);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e44738;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__44742 = state_44735;
state_44735 = G__44742;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$transduce_$_state_machine__27525__auto__ = function(state_44735){
switch(arguments.length){
case 0:
return cljs$core$async$transduce_$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$transduce_$_state_machine__27525__auto____1.call(this,state_44735);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$transduce_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$transduce_$_state_machine__27525__auto____0;
cljs$core$async$transduce_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$transduce_$_state_machine__27525__auto____1;
return cljs$core$async$transduce_$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_44740 = f__27716__auto__.call(null);
(statearr_44740[(6)] = c__27715__auto__);

return statearr_44740;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));

return c__27715__auto__;
});
/**
 * Puts the contents of coll into the supplied channel.
 * 
 *   By default the channel will be closed after the items are copied,
 *   but can be determined by the close? parameter.
 * 
 *   Returns a channel which will close after the items are copied.
 */
cljs.core.async.onto_chan = (function cljs$core$async$onto_chan(var_args){
var G__44744 = arguments.length;
switch (G__44744) {
case 2:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2 = (function (ch,coll){
return cljs.core.async.onto_chan.call(null,ch,coll,true);
}));

(cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3 = (function (ch,coll,close_QMARK_){
var c__27715__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_44769){
var state_val_44770 = (state_44769[(1)]);
if((state_val_44770 === (7))){
var inst_44751 = (state_44769[(2)]);
var state_44769__$1 = state_44769;
var statearr_44771_44792 = state_44769__$1;
(statearr_44771_44792[(2)] = inst_44751);

(statearr_44771_44792[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44770 === (1))){
var inst_44745 = cljs.core.seq.call(null,coll);
var inst_44746 = inst_44745;
var state_44769__$1 = (function (){var statearr_44772 = state_44769;
(statearr_44772[(7)] = inst_44746);

return statearr_44772;
})();
var statearr_44773_44793 = state_44769__$1;
(statearr_44773_44793[(2)] = null);

(statearr_44773_44793[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44770 === (4))){
var inst_44746 = (state_44769[(7)]);
var inst_44749 = cljs.core.first.call(null,inst_44746);
var state_44769__$1 = state_44769;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_44769__$1,(7),ch,inst_44749);
} else {
if((state_val_44770 === (13))){
var inst_44763 = (state_44769[(2)]);
var state_44769__$1 = state_44769;
var statearr_44774_44794 = state_44769__$1;
(statearr_44774_44794[(2)] = inst_44763);

(statearr_44774_44794[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44770 === (6))){
var inst_44754 = (state_44769[(2)]);
var state_44769__$1 = state_44769;
if(cljs.core.truth_(inst_44754)){
var statearr_44775_44795 = state_44769__$1;
(statearr_44775_44795[(1)] = (8));

} else {
var statearr_44776_44796 = state_44769__$1;
(statearr_44776_44796[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44770 === (3))){
var inst_44767 = (state_44769[(2)]);
var state_44769__$1 = state_44769;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_44769__$1,inst_44767);
} else {
if((state_val_44770 === (12))){
var state_44769__$1 = state_44769;
var statearr_44777_44797 = state_44769__$1;
(statearr_44777_44797[(2)] = null);

(statearr_44777_44797[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44770 === (2))){
var inst_44746 = (state_44769[(7)]);
var state_44769__$1 = state_44769;
if(cljs.core.truth_(inst_44746)){
var statearr_44778_44798 = state_44769__$1;
(statearr_44778_44798[(1)] = (4));

} else {
var statearr_44779_44799 = state_44769__$1;
(statearr_44779_44799[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44770 === (11))){
var inst_44760 = cljs.core.async.close_BANG_.call(null,ch);
var state_44769__$1 = state_44769;
var statearr_44780_44800 = state_44769__$1;
(statearr_44780_44800[(2)] = inst_44760);

(statearr_44780_44800[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44770 === (9))){
var state_44769__$1 = state_44769;
if(cljs.core.truth_(close_QMARK_)){
var statearr_44781_44801 = state_44769__$1;
(statearr_44781_44801[(1)] = (11));

} else {
var statearr_44782_44802 = state_44769__$1;
(statearr_44782_44802[(1)] = (12));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44770 === (5))){
var inst_44746 = (state_44769[(7)]);
var state_44769__$1 = state_44769;
var statearr_44783_44803 = state_44769__$1;
(statearr_44783_44803[(2)] = inst_44746);

(statearr_44783_44803[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44770 === (10))){
var inst_44765 = (state_44769[(2)]);
var state_44769__$1 = state_44769;
var statearr_44784_44804 = state_44769__$1;
(statearr_44784_44804[(2)] = inst_44765);

(statearr_44784_44804[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44770 === (8))){
var inst_44746 = (state_44769[(7)]);
var inst_44756 = cljs.core.next.call(null,inst_44746);
var inst_44746__$1 = inst_44756;
var state_44769__$1 = (function (){var statearr_44785 = state_44769;
(statearr_44785[(7)] = inst_44746__$1);

return statearr_44785;
})();
var statearr_44786_44805 = state_44769__$1;
(statearr_44786_44805[(2)] = null);

(statearr_44786_44805[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_44787 = [null,null,null,null,null,null,null,null];
(statearr_44787[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_44787[(1)] = (1));

return statearr_44787;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_44769){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_44769);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e44788){if((e44788 instanceof Object)){
var ex__27528__auto__ = e44788;
var statearr_44789_44806 = state_44769;
(statearr_44789_44806[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_44769);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e44788;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__44807 = state_44769;
state_44769 = G__44807;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_44769){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_44769);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_44790 = f__27716__auto__.call(null);
(statearr_44790[(6)] = c__27715__auto__);

return statearr_44790;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));

return c__27715__auto__;
}));

(cljs.core.async.onto_chan.cljs$lang$maxFixedArity = 3);

/**
 * Creates and returns a channel which contains the contents of coll,
 *   closing when exhausted.
 */
cljs.core.async.to_chan = (function cljs$core$async$to_chan(coll){
var ch = cljs.core.async.chan.call(null,cljs.core.bounded_count.call(null,(100),coll));
cljs.core.async.onto_chan.call(null,ch,coll);

return ch;
});

/**
 * @interface
 */
cljs.core.async.Mux = function(){};

cljs.core.async.muxch_STAR_ = (function cljs$core$async$muxch_STAR_(_){
if((((!((_ == null)))) && ((!((_.cljs$core$async$Mux$muxch_STAR_$arity$1 == null)))))){
return _.cljs$core$async$Mux$muxch_STAR_$arity$1(_);
} else {
var x__4487__auto__ = (((_ == null))?null:_);
var m__4488__auto__ = (cljs.core.async.muxch_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,_);
} else {
var m__4485__auto__ = (cljs.core.async.muxch_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,_);
} else {
throw cljs.core.missing_protocol.call(null,"Mux.muxch*",_);
}
}
}
});


/**
 * @interface
 */
cljs.core.async.Mult = function(){};

cljs.core.async.tap_STAR_ = (function cljs$core$async$tap_STAR_(m,ch,close_QMARK_){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$tap_STAR_$arity$3 == null)))))){
return m.cljs$core$async$Mult$tap_STAR_$arity$3(m,ch,close_QMARK_);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.tap_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,m,ch,close_QMARK_);
} else {
var m__4485__auto__ = (cljs.core.async.tap_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,m,ch,close_QMARK_);
} else {
throw cljs.core.missing_protocol.call(null,"Mult.tap*",m);
}
}
}
});

cljs.core.async.untap_STAR_ = (function cljs$core$async$untap_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mult$untap_STAR_$arity$2(m,ch);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.untap_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,m,ch);
} else {
var m__4485__auto__ = (cljs.core.async.untap_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,m,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Mult.untap*",m);
}
}
}
});

cljs.core.async.untap_all_STAR_ = (function cljs$core$async$untap_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mult$untap_all_STAR_$arity$1(m);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.untap_all_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,m);
} else {
var m__4485__auto__ = (cljs.core.async.untap_all_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,m);
} else {
throw cljs.core.missing_protocol.call(null,"Mult.untap-all*",m);
}
}
}
});

/**
 * Creates and returns a mult(iple) of the supplied channel. Channels
 *   containing copies of the channel can be created with 'tap', and
 *   detached with 'untap'.
 * 
 *   Each item is distributed to all taps in parallel and synchronously,
 *   i.e. each tap must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow taps from holding up the mult.
 * 
 *   Items received when there are no taps get dropped.
 * 
 *   If a tap puts to a closed channel, it will be removed from the mult.
 */
cljs.core.async.mult = (function cljs$core$async$mult(ch){
var cs = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async44808 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Mult}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async44808 = (function (ch,cs,meta44809){
this.ch = ch;
this.cs = cs;
this.meta44809 = meta44809;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async44808.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_44810,meta44809__$1){
var self__ = this;
var _44810__$1 = this;
return (new cljs.core.async.t_cljs$core$async44808(self__.ch,self__.cs,meta44809__$1));
}));

(cljs.core.async.t_cljs$core$async44808.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_44810){
var self__ = this;
var _44810__$1 = this;
return self__.meta44809;
}));

(cljs.core.async.t_cljs$core$async44808.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async44808.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
}));

(cljs.core.async.t_cljs$core$async44808.prototype.cljs$core$async$Mult$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async44808.prototype.cljs$core$async$Mult$tap_STAR_$arity$3 = (function (_,ch__$1,close_QMARK_){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.assoc,ch__$1,close_QMARK_);

return null;
}));

(cljs.core.async.t_cljs$core$async44808.prototype.cljs$core$async$Mult$untap_STAR_$arity$2 = (function (_,ch__$1){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.dissoc,ch__$1);

return null;
}));

(cljs.core.async.t_cljs$core$async44808.prototype.cljs$core$async$Mult$untap_all_STAR_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_.call(null,self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return null;
}));

(cljs.core.async.t_cljs$core$async44808.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"cs","cs",-117024463,null),new cljs.core.Symbol(null,"meta44809","meta44809",-726906793,null)], null);
}));

(cljs.core.async.t_cljs$core$async44808.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async44808.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async44808");

(cljs.core.async.t_cljs$core$async44808.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write.call(null,writer__4429__auto__,"cljs.core.async/t_cljs$core$async44808");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async44808.
 */
cljs.core.async.__GT_t_cljs$core$async44808 = (function cljs$core$async$mult_$___GT_t_cljs$core$async44808(ch__$1,cs__$1,meta44809){
return (new cljs.core.async.t_cljs$core$async44808(ch__$1,cs__$1,meta44809));
});

}

return (new cljs.core.async.t_cljs$core$async44808(ch,cs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var dchan = cljs.core.async.chan.call(null,(1));
var dctr = cljs.core.atom.call(null,null);
var done = (function (_){
if((cljs.core.swap_BANG_.call(null,dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.call(null,dchan,true);
} else {
return null;
}
});
var c__27715__auto___45026 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_44943){
var state_val_44944 = (state_44943[(1)]);
if((state_val_44944 === (7))){
var inst_44939 = (state_44943[(2)]);
var state_44943__$1 = state_44943;
var statearr_44945_45027 = state_44943__$1;
(statearr_44945_45027[(2)] = inst_44939);

(statearr_44945_45027[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (20))){
var inst_44844 = (state_44943[(7)]);
var inst_44856 = cljs.core.first.call(null,inst_44844);
var inst_44857 = cljs.core.nth.call(null,inst_44856,(0),null);
var inst_44858 = cljs.core.nth.call(null,inst_44856,(1),null);
var state_44943__$1 = (function (){var statearr_44946 = state_44943;
(statearr_44946[(8)] = inst_44857);

return statearr_44946;
})();
if(cljs.core.truth_(inst_44858)){
var statearr_44947_45028 = state_44943__$1;
(statearr_44947_45028[(1)] = (22));

} else {
var statearr_44948_45029 = state_44943__$1;
(statearr_44948_45029[(1)] = (23));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (27))){
var inst_44813 = (state_44943[(9)]);
var inst_44888 = (state_44943[(10)]);
var inst_44893 = (state_44943[(11)]);
var inst_44886 = (state_44943[(12)]);
var inst_44893__$1 = cljs.core._nth.call(null,inst_44886,inst_44888);
var inst_44894 = cljs.core.async.put_BANG_.call(null,inst_44893__$1,inst_44813,done);
var state_44943__$1 = (function (){var statearr_44949 = state_44943;
(statearr_44949[(11)] = inst_44893__$1);

return statearr_44949;
})();
if(cljs.core.truth_(inst_44894)){
var statearr_44950_45030 = state_44943__$1;
(statearr_44950_45030[(1)] = (30));

} else {
var statearr_44951_45031 = state_44943__$1;
(statearr_44951_45031[(1)] = (31));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (1))){
var state_44943__$1 = state_44943;
var statearr_44952_45032 = state_44943__$1;
(statearr_44952_45032[(2)] = null);

(statearr_44952_45032[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (24))){
var inst_44844 = (state_44943[(7)]);
var inst_44863 = (state_44943[(2)]);
var inst_44864 = cljs.core.next.call(null,inst_44844);
var inst_44822 = inst_44864;
var inst_44823 = null;
var inst_44824 = (0);
var inst_44825 = (0);
var state_44943__$1 = (function (){var statearr_44953 = state_44943;
(statearr_44953[(13)] = inst_44823);

(statearr_44953[(14)] = inst_44822);

(statearr_44953[(15)] = inst_44824);

(statearr_44953[(16)] = inst_44825);

(statearr_44953[(17)] = inst_44863);

return statearr_44953;
})();
var statearr_44954_45033 = state_44943__$1;
(statearr_44954_45033[(2)] = null);

(statearr_44954_45033[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (39))){
var state_44943__$1 = state_44943;
var statearr_44958_45034 = state_44943__$1;
(statearr_44958_45034[(2)] = null);

(statearr_44958_45034[(1)] = (41));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (4))){
var inst_44813 = (state_44943[(9)]);
var inst_44813__$1 = (state_44943[(2)]);
var inst_44814 = (inst_44813__$1 == null);
var state_44943__$1 = (function (){var statearr_44959 = state_44943;
(statearr_44959[(9)] = inst_44813__$1);

return statearr_44959;
})();
if(cljs.core.truth_(inst_44814)){
var statearr_44960_45035 = state_44943__$1;
(statearr_44960_45035[(1)] = (5));

} else {
var statearr_44961_45036 = state_44943__$1;
(statearr_44961_45036[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (15))){
var inst_44823 = (state_44943[(13)]);
var inst_44822 = (state_44943[(14)]);
var inst_44824 = (state_44943[(15)]);
var inst_44825 = (state_44943[(16)]);
var inst_44840 = (state_44943[(2)]);
var inst_44841 = (inst_44825 + (1));
var tmp44955 = inst_44823;
var tmp44956 = inst_44822;
var tmp44957 = inst_44824;
var inst_44822__$1 = tmp44956;
var inst_44823__$1 = tmp44955;
var inst_44824__$1 = tmp44957;
var inst_44825__$1 = inst_44841;
var state_44943__$1 = (function (){var statearr_44962 = state_44943;
(statearr_44962[(13)] = inst_44823__$1);

(statearr_44962[(18)] = inst_44840);

(statearr_44962[(14)] = inst_44822__$1);

(statearr_44962[(15)] = inst_44824__$1);

(statearr_44962[(16)] = inst_44825__$1);

return statearr_44962;
})();
var statearr_44963_45037 = state_44943__$1;
(statearr_44963_45037[(2)] = null);

(statearr_44963_45037[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (21))){
var inst_44867 = (state_44943[(2)]);
var state_44943__$1 = state_44943;
var statearr_44967_45038 = state_44943__$1;
(statearr_44967_45038[(2)] = inst_44867);

(statearr_44967_45038[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (31))){
var inst_44893 = (state_44943[(11)]);
var inst_44897 = cljs.core.async.untap_STAR_.call(null,m,inst_44893);
var state_44943__$1 = state_44943;
var statearr_44968_45039 = state_44943__$1;
(statearr_44968_45039[(2)] = inst_44897);

(statearr_44968_45039[(1)] = (32));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (32))){
var inst_44888 = (state_44943[(10)]);
var inst_44885 = (state_44943[(19)]);
var inst_44886 = (state_44943[(12)]);
var inst_44887 = (state_44943[(20)]);
var inst_44899 = (state_44943[(2)]);
var inst_44900 = (inst_44888 + (1));
var tmp44964 = inst_44885;
var tmp44965 = inst_44886;
var tmp44966 = inst_44887;
var inst_44885__$1 = tmp44964;
var inst_44886__$1 = tmp44965;
var inst_44887__$1 = tmp44966;
var inst_44888__$1 = inst_44900;
var state_44943__$1 = (function (){var statearr_44969 = state_44943;
(statearr_44969[(21)] = inst_44899);

(statearr_44969[(10)] = inst_44888__$1);

(statearr_44969[(19)] = inst_44885__$1);

(statearr_44969[(12)] = inst_44886__$1);

(statearr_44969[(20)] = inst_44887__$1);

return statearr_44969;
})();
var statearr_44970_45040 = state_44943__$1;
(statearr_44970_45040[(2)] = null);

(statearr_44970_45040[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (40))){
var inst_44912 = (state_44943[(22)]);
var inst_44916 = cljs.core.async.untap_STAR_.call(null,m,inst_44912);
var state_44943__$1 = state_44943;
var statearr_44971_45041 = state_44943__$1;
(statearr_44971_45041[(2)] = inst_44916);

(statearr_44971_45041[(1)] = (41));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (33))){
var inst_44903 = (state_44943[(23)]);
var inst_44905 = cljs.core.chunked_seq_QMARK_.call(null,inst_44903);
var state_44943__$1 = state_44943;
if(inst_44905){
var statearr_44972_45042 = state_44943__$1;
(statearr_44972_45042[(1)] = (36));

} else {
var statearr_44973_45043 = state_44943__$1;
(statearr_44973_45043[(1)] = (37));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (13))){
var inst_44834 = (state_44943[(24)]);
var inst_44837 = cljs.core.async.close_BANG_.call(null,inst_44834);
var state_44943__$1 = state_44943;
var statearr_44974_45044 = state_44943__$1;
(statearr_44974_45044[(2)] = inst_44837);

(statearr_44974_45044[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (22))){
var inst_44857 = (state_44943[(8)]);
var inst_44860 = cljs.core.async.close_BANG_.call(null,inst_44857);
var state_44943__$1 = state_44943;
var statearr_44975_45045 = state_44943__$1;
(statearr_44975_45045[(2)] = inst_44860);

(statearr_44975_45045[(1)] = (24));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (36))){
var inst_44903 = (state_44943[(23)]);
var inst_44907 = cljs.core.chunk_first.call(null,inst_44903);
var inst_44908 = cljs.core.chunk_rest.call(null,inst_44903);
var inst_44909 = cljs.core.count.call(null,inst_44907);
var inst_44885 = inst_44908;
var inst_44886 = inst_44907;
var inst_44887 = inst_44909;
var inst_44888 = (0);
var state_44943__$1 = (function (){var statearr_44976 = state_44943;
(statearr_44976[(10)] = inst_44888);

(statearr_44976[(19)] = inst_44885);

(statearr_44976[(12)] = inst_44886);

(statearr_44976[(20)] = inst_44887);

return statearr_44976;
})();
var statearr_44977_45046 = state_44943__$1;
(statearr_44977_45046[(2)] = null);

(statearr_44977_45046[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (41))){
var inst_44903 = (state_44943[(23)]);
var inst_44918 = (state_44943[(2)]);
var inst_44919 = cljs.core.next.call(null,inst_44903);
var inst_44885 = inst_44919;
var inst_44886 = null;
var inst_44887 = (0);
var inst_44888 = (0);
var state_44943__$1 = (function (){var statearr_44978 = state_44943;
(statearr_44978[(10)] = inst_44888);

(statearr_44978[(19)] = inst_44885);

(statearr_44978[(12)] = inst_44886);

(statearr_44978[(25)] = inst_44918);

(statearr_44978[(20)] = inst_44887);

return statearr_44978;
})();
var statearr_44979_45047 = state_44943__$1;
(statearr_44979_45047[(2)] = null);

(statearr_44979_45047[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (43))){
var state_44943__$1 = state_44943;
var statearr_44980_45048 = state_44943__$1;
(statearr_44980_45048[(2)] = null);

(statearr_44980_45048[(1)] = (44));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (29))){
var inst_44927 = (state_44943[(2)]);
var state_44943__$1 = state_44943;
var statearr_44981_45049 = state_44943__$1;
(statearr_44981_45049[(2)] = inst_44927);

(statearr_44981_45049[(1)] = (26));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (44))){
var inst_44936 = (state_44943[(2)]);
var state_44943__$1 = (function (){var statearr_44982 = state_44943;
(statearr_44982[(26)] = inst_44936);

return statearr_44982;
})();
var statearr_44983_45050 = state_44943__$1;
(statearr_44983_45050[(2)] = null);

(statearr_44983_45050[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (6))){
var inst_44877 = (state_44943[(27)]);
var inst_44876 = cljs.core.deref.call(null,cs);
var inst_44877__$1 = cljs.core.keys.call(null,inst_44876);
var inst_44878 = cljs.core.count.call(null,inst_44877__$1);
var inst_44879 = cljs.core.reset_BANG_.call(null,dctr,inst_44878);
var inst_44884 = cljs.core.seq.call(null,inst_44877__$1);
var inst_44885 = inst_44884;
var inst_44886 = null;
var inst_44887 = (0);
var inst_44888 = (0);
var state_44943__$1 = (function (){var statearr_44984 = state_44943;
(statearr_44984[(28)] = inst_44879);

(statearr_44984[(27)] = inst_44877__$1);

(statearr_44984[(10)] = inst_44888);

(statearr_44984[(19)] = inst_44885);

(statearr_44984[(12)] = inst_44886);

(statearr_44984[(20)] = inst_44887);

return statearr_44984;
})();
var statearr_44985_45051 = state_44943__$1;
(statearr_44985_45051[(2)] = null);

(statearr_44985_45051[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (28))){
var inst_44885 = (state_44943[(19)]);
var inst_44903 = (state_44943[(23)]);
var inst_44903__$1 = cljs.core.seq.call(null,inst_44885);
var state_44943__$1 = (function (){var statearr_44986 = state_44943;
(statearr_44986[(23)] = inst_44903__$1);

return statearr_44986;
})();
if(inst_44903__$1){
var statearr_44987_45052 = state_44943__$1;
(statearr_44987_45052[(1)] = (33));

} else {
var statearr_44988_45053 = state_44943__$1;
(statearr_44988_45053[(1)] = (34));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (25))){
var inst_44888 = (state_44943[(10)]);
var inst_44887 = (state_44943[(20)]);
var inst_44890 = (inst_44888 < inst_44887);
var inst_44891 = inst_44890;
var state_44943__$1 = state_44943;
if(cljs.core.truth_(inst_44891)){
var statearr_44989_45054 = state_44943__$1;
(statearr_44989_45054[(1)] = (27));

} else {
var statearr_44990_45055 = state_44943__$1;
(statearr_44990_45055[(1)] = (28));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (34))){
var state_44943__$1 = state_44943;
var statearr_44991_45056 = state_44943__$1;
(statearr_44991_45056[(2)] = null);

(statearr_44991_45056[(1)] = (35));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (17))){
var state_44943__$1 = state_44943;
var statearr_44992_45057 = state_44943__$1;
(statearr_44992_45057[(2)] = null);

(statearr_44992_45057[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (3))){
var inst_44941 = (state_44943[(2)]);
var state_44943__$1 = state_44943;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_44943__$1,inst_44941);
} else {
if((state_val_44944 === (12))){
var inst_44872 = (state_44943[(2)]);
var state_44943__$1 = state_44943;
var statearr_44993_45058 = state_44943__$1;
(statearr_44993_45058[(2)] = inst_44872);

(statearr_44993_45058[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (2))){
var state_44943__$1 = state_44943;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_44943__$1,(4),ch);
} else {
if((state_val_44944 === (23))){
var state_44943__$1 = state_44943;
var statearr_44994_45059 = state_44943__$1;
(statearr_44994_45059[(2)] = null);

(statearr_44994_45059[(1)] = (24));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (35))){
var inst_44925 = (state_44943[(2)]);
var state_44943__$1 = state_44943;
var statearr_44995_45060 = state_44943__$1;
(statearr_44995_45060[(2)] = inst_44925);

(statearr_44995_45060[(1)] = (29));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (19))){
var inst_44844 = (state_44943[(7)]);
var inst_44848 = cljs.core.chunk_first.call(null,inst_44844);
var inst_44849 = cljs.core.chunk_rest.call(null,inst_44844);
var inst_44850 = cljs.core.count.call(null,inst_44848);
var inst_44822 = inst_44849;
var inst_44823 = inst_44848;
var inst_44824 = inst_44850;
var inst_44825 = (0);
var state_44943__$1 = (function (){var statearr_44996 = state_44943;
(statearr_44996[(13)] = inst_44823);

(statearr_44996[(14)] = inst_44822);

(statearr_44996[(15)] = inst_44824);

(statearr_44996[(16)] = inst_44825);

return statearr_44996;
})();
var statearr_44997_45061 = state_44943__$1;
(statearr_44997_45061[(2)] = null);

(statearr_44997_45061[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (11))){
var inst_44822 = (state_44943[(14)]);
var inst_44844 = (state_44943[(7)]);
var inst_44844__$1 = cljs.core.seq.call(null,inst_44822);
var state_44943__$1 = (function (){var statearr_44998 = state_44943;
(statearr_44998[(7)] = inst_44844__$1);

return statearr_44998;
})();
if(inst_44844__$1){
var statearr_44999_45062 = state_44943__$1;
(statearr_44999_45062[(1)] = (16));

} else {
var statearr_45000_45063 = state_44943__$1;
(statearr_45000_45063[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (9))){
var inst_44874 = (state_44943[(2)]);
var state_44943__$1 = state_44943;
var statearr_45001_45064 = state_44943__$1;
(statearr_45001_45064[(2)] = inst_44874);

(statearr_45001_45064[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (5))){
var inst_44820 = cljs.core.deref.call(null,cs);
var inst_44821 = cljs.core.seq.call(null,inst_44820);
var inst_44822 = inst_44821;
var inst_44823 = null;
var inst_44824 = (0);
var inst_44825 = (0);
var state_44943__$1 = (function (){var statearr_45002 = state_44943;
(statearr_45002[(13)] = inst_44823);

(statearr_45002[(14)] = inst_44822);

(statearr_45002[(15)] = inst_44824);

(statearr_45002[(16)] = inst_44825);

return statearr_45002;
})();
var statearr_45003_45065 = state_44943__$1;
(statearr_45003_45065[(2)] = null);

(statearr_45003_45065[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (14))){
var state_44943__$1 = state_44943;
var statearr_45004_45066 = state_44943__$1;
(statearr_45004_45066[(2)] = null);

(statearr_45004_45066[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (45))){
var inst_44933 = (state_44943[(2)]);
var state_44943__$1 = state_44943;
var statearr_45005_45067 = state_44943__$1;
(statearr_45005_45067[(2)] = inst_44933);

(statearr_45005_45067[(1)] = (44));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (26))){
var inst_44877 = (state_44943[(27)]);
var inst_44929 = (state_44943[(2)]);
var inst_44930 = cljs.core.seq.call(null,inst_44877);
var state_44943__$1 = (function (){var statearr_45006 = state_44943;
(statearr_45006[(29)] = inst_44929);

return statearr_45006;
})();
if(inst_44930){
var statearr_45007_45068 = state_44943__$1;
(statearr_45007_45068[(1)] = (42));

} else {
var statearr_45008_45069 = state_44943__$1;
(statearr_45008_45069[(1)] = (43));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (16))){
var inst_44844 = (state_44943[(7)]);
var inst_44846 = cljs.core.chunked_seq_QMARK_.call(null,inst_44844);
var state_44943__$1 = state_44943;
if(inst_44846){
var statearr_45009_45070 = state_44943__$1;
(statearr_45009_45070[(1)] = (19));

} else {
var statearr_45010_45071 = state_44943__$1;
(statearr_45010_45071[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (38))){
var inst_44922 = (state_44943[(2)]);
var state_44943__$1 = state_44943;
var statearr_45011_45072 = state_44943__$1;
(statearr_45011_45072[(2)] = inst_44922);

(statearr_45011_45072[(1)] = (35));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (30))){
var state_44943__$1 = state_44943;
var statearr_45012_45073 = state_44943__$1;
(statearr_45012_45073[(2)] = null);

(statearr_45012_45073[(1)] = (32));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (10))){
var inst_44823 = (state_44943[(13)]);
var inst_44825 = (state_44943[(16)]);
var inst_44833 = cljs.core._nth.call(null,inst_44823,inst_44825);
var inst_44834 = cljs.core.nth.call(null,inst_44833,(0),null);
var inst_44835 = cljs.core.nth.call(null,inst_44833,(1),null);
var state_44943__$1 = (function (){var statearr_45013 = state_44943;
(statearr_45013[(24)] = inst_44834);

return statearr_45013;
})();
if(cljs.core.truth_(inst_44835)){
var statearr_45014_45074 = state_44943__$1;
(statearr_45014_45074[(1)] = (13));

} else {
var statearr_45015_45075 = state_44943__$1;
(statearr_45015_45075[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (18))){
var inst_44870 = (state_44943[(2)]);
var state_44943__$1 = state_44943;
var statearr_45016_45076 = state_44943__$1;
(statearr_45016_45076[(2)] = inst_44870);

(statearr_45016_45076[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (42))){
var state_44943__$1 = state_44943;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_44943__$1,(45),dchan);
} else {
if((state_val_44944 === (37))){
var inst_44813 = (state_44943[(9)]);
var inst_44903 = (state_44943[(23)]);
var inst_44912 = (state_44943[(22)]);
var inst_44912__$1 = cljs.core.first.call(null,inst_44903);
var inst_44913 = cljs.core.async.put_BANG_.call(null,inst_44912__$1,inst_44813,done);
var state_44943__$1 = (function (){var statearr_45017 = state_44943;
(statearr_45017[(22)] = inst_44912__$1);

return statearr_45017;
})();
if(cljs.core.truth_(inst_44913)){
var statearr_45018_45077 = state_44943__$1;
(statearr_45018_45077[(1)] = (39));

} else {
var statearr_45019_45078 = state_44943__$1;
(statearr_45019_45078[(1)] = (40));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_44944 === (8))){
var inst_44824 = (state_44943[(15)]);
var inst_44825 = (state_44943[(16)]);
var inst_44827 = (inst_44825 < inst_44824);
var inst_44828 = inst_44827;
var state_44943__$1 = state_44943;
if(cljs.core.truth_(inst_44828)){
var statearr_45020_45079 = state_44943__$1;
(statearr_45020_45079[(1)] = (10));

} else {
var statearr_45021_45080 = state_44943__$1;
(statearr_45021_45080[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$mult_$_state_machine__27525__auto__ = null;
var cljs$core$async$mult_$_state_machine__27525__auto____0 = (function (){
var statearr_45022 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_45022[(0)] = cljs$core$async$mult_$_state_machine__27525__auto__);

(statearr_45022[(1)] = (1));

return statearr_45022;
});
var cljs$core$async$mult_$_state_machine__27525__auto____1 = (function (state_44943){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_44943);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e45023){if((e45023 instanceof Object)){
var ex__27528__auto__ = e45023;
var statearr_45024_45081 = state_44943;
(statearr_45024_45081[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_44943);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e45023;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__45082 = state_44943;
state_44943 = G__45082;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$mult_$_state_machine__27525__auto__ = function(state_44943){
switch(arguments.length){
case 0:
return cljs$core$async$mult_$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$mult_$_state_machine__27525__auto____1.call(this,state_44943);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mult_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mult_$_state_machine__27525__auto____0;
cljs$core$async$mult_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mult_$_state_machine__27525__auto____1;
return cljs$core$async$mult_$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_45025 = f__27716__auto__.call(null);
(statearr_45025[(6)] = c__27715__auto___45026);

return statearr_45025;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


return m;
});
/**
 * Copies the mult source onto the supplied channel.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.tap = (function cljs$core$async$tap(var_args){
var G__45084 = arguments.length;
switch (G__45084) {
case 2:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2 = (function (mult,ch){
return cljs.core.async.tap.call(null,mult,ch,true);
}));

(cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3 = (function (mult,ch,close_QMARK_){
cljs.core.async.tap_STAR_.call(null,mult,ch,close_QMARK_);

return ch;
}));

(cljs.core.async.tap.cljs$lang$maxFixedArity = 3);

/**
 * Disconnects a target channel from a mult
 */
cljs.core.async.untap = (function cljs$core$async$untap(mult,ch){
return cljs.core.async.untap_STAR_.call(null,mult,ch);
});
/**
 * Disconnects all target channels from a mult
 */
cljs.core.async.untap_all = (function cljs$core$async$untap_all(mult){
return cljs.core.async.untap_all_STAR_.call(null,mult);
});

/**
 * @interface
 */
cljs.core.async.Mix = function(){};

cljs.core.async.admix_STAR_ = (function cljs$core$async$admix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$admix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$admix_STAR_$arity$2(m,ch);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.admix_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,m,ch);
} else {
var m__4485__auto__ = (cljs.core.async.admix_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,m,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.admix*",m);
}
}
}
});

cljs.core.async.unmix_STAR_ = (function cljs$core$async$unmix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$unmix_STAR_$arity$2(m,ch);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.unmix_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,m,ch);
} else {
var m__4485__auto__ = (cljs.core.async.unmix_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,m,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.unmix*",m);
}
}
}
});

cljs.core.async.unmix_all_STAR_ = (function cljs$core$async$unmix_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mix$unmix_all_STAR_$arity$1(m);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.unmix_all_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,m);
} else {
var m__4485__auto__ = (cljs.core.async.unmix_all_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,m);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.unmix-all*",m);
}
}
}
});

cljs.core.async.toggle_STAR_ = (function cljs$core$async$toggle_STAR_(m,state_map){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$toggle_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$toggle_STAR_$arity$2(m,state_map);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.toggle_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,m,state_map);
} else {
var m__4485__auto__ = (cljs.core.async.toggle_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,m,state_map);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.toggle*",m);
}
}
}
});

cljs.core.async.solo_mode_STAR_ = (function cljs$core$async$solo_mode_STAR_(m,mode){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$solo_mode_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$solo_mode_STAR_$arity$2(m,mode);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.solo_mode_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,m,mode);
} else {
var m__4485__auto__ = (cljs.core.async.solo_mode_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,m,mode);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.solo-mode*",m);
}
}
}
});

cljs.core.async.ioc_alts_BANG_ = (function cljs$core$async$ioc_alts_BANG_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___45096 = arguments.length;
var i__4790__auto___45097 = (0);
while(true){
if((i__4790__auto___45097 < len__4789__auto___45096)){
args__4795__auto__.push((arguments[i__4790__auto___45097]));

var G__45098 = (i__4790__auto___45097 + (1));
i__4790__auto___45097 = G__45098;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((3) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((3)),(0),null)):null);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__4796__auto__);
});

(cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (state,cont_block,ports,p__45090){
var map__45091 = p__45090;
var map__45091__$1 = (((((!((map__45091 == null))))?(((((map__45091.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__45091.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__45091):map__45091);
var opts = map__45091__$1;
var statearr_45093_45099 = state;
(statearr_45093_45099[(1)] = cont_block);


var temp__5735__auto__ = cljs.core.async.do_alts.call(null,(function (val){
var statearr_45094_45100 = state;
(statearr_45094_45100[(2)] = val);


return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state);
}),ports,opts);
if(cljs.core.truth_(temp__5735__auto__)){
var cb = temp__5735__auto__;
var statearr_45095_45101 = state;
(statearr_45095_45101[(2)] = cljs.core.deref.call(null,cb));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}));

(cljs.core.async.ioc_alts_BANG_.cljs$lang$maxFixedArity = (3));

/** @this {Function} */
(cljs.core.async.ioc_alts_BANG_.cljs$lang$applyTo = (function (seq45086){
var G__45087 = cljs.core.first.call(null,seq45086);
var seq45086__$1 = cljs.core.next.call(null,seq45086);
var G__45088 = cljs.core.first.call(null,seq45086__$1);
var seq45086__$2 = cljs.core.next.call(null,seq45086__$1);
var G__45089 = cljs.core.first.call(null,seq45086__$2);
var seq45086__$3 = cljs.core.next.call(null,seq45086__$2);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__45087,G__45088,G__45089,seq45086__$3);
}));

/**
 * Creates and returns a mix of one or more input channels which will
 *   be put on the supplied out channel. Input sources can be added to
 *   the mix with 'admix', and removed with 'unmix'. A mix supports
 *   soloing, muting and pausing multiple inputs atomically using
 *   'toggle', and can solo using either muting or pausing as determined
 *   by 'solo-mode'.
 * 
 *   Each channel can have zero or more boolean modes set via 'toggle':
 * 
 *   :solo - when true, only this (ond other soloed) channel(s) will appear
 *        in the mix output channel. :mute and :pause states of soloed
 *        channels are ignored. If solo-mode is :mute, non-soloed
 *        channels are muted, if :pause, non-soloed channels are
 *        paused.
 * 
 *   :mute - muted channels will have their contents consumed but not included in the mix
 *   :pause - paused channels will not have their contents consumed (and thus also not included in the mix)
 */
cljs.core.async.mix = (function cljs$core$async$mix(out){
var cs = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var solo_modes = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"pause","pause",-2095325672),null,new cljs.core.Keyword(null,"mute","mute",1151223646),null], null), null);
var attrs = cljs.core.conj.call(null,solo_modes,new cljs.core.Keyword(null,"solo","solo",-316350075));
var solo_mode = cljs.core.atom.call(null,new cljs.core.Keyword(null,"mute","mute",1151223646));
var change = cljs.core.async.chan.call(null,cljs.core.async.sliding_buffer.call(null,(1)));
var changed = (function (){
return cljs.core.async.put_BANG_.call(null,change,true);
});
var pick = (function (attr,chs){
return cljs.core.reduce_kv.call(null,(function (ret,c,v){
if(cljs.core.truth_(attr.call(null,v))){
return cljs.core.conj.call(null,ret,c);
} else {
return ret;
}
}),cljs.core.PersistentHashSet.EMPTY,chs);
});
var calc_state = (function (){
var chs = cljs.core.deref.call(null,cs);
var mode = cljs.core.deref.call(null,solo_mode);
var solos = pick.call(null,new cljs.core.Keyword(null,"solo","solo",-316350075),chs);
var pauses = pick.call(null,new cljs.core.Keyword(null,"pause","pause",-2095325672),chs);
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"solos","solos",1441458643),solos,new cljs.core.Keyword(null,"mutes","mutes",1068806309),pick.call(null,new cljs.core.Keyword(null,"mute","mute",1151223646),chs),new cljs.core.Keyword(null,"reads","reads",-1215067361),cljs.core.conj.call(null,((((cljs.core._EQ_.call(null,mode,new cljs.core.Keyword(null,"pause","pause",-2095325672))) && ((!(cljs.core.empty_QMARK_.call(null,solos))))))?cljs.core.vec.call(null,solos):cljs.core.vec.call(null,cljs.core.remove.call(null,pauses,cljs.core.keys.call(null,chs)))),change)], null);
});
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async45102 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mix}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async45102 = (function (change,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,meta45103){
this.change = change;
this.solo_mode = solo_mode;
this.pick = pick;
this.cs = cs;
this.calc_state = calc_state;
this.out = out;
this.changed = changed;
this.solo_modes = solo_modes;
this.attrs = attrs;
this.meta45103 = meta45103;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async45102.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_45104,meta45103__$1){
var self__ = this;
var _45104__$1 = this;
return (new cljs.core.async.t_cljs$core$async45102(self__.change,self__.solo_mode,self__.pick,self__.cs,self__.calc_state,self__.out,self__.changed,self__.solo_modes,self__.attrs,meta45103__$1));
}));

(cljs.core.async.t_cljs$core$async45102.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_45104){
var self__ = this;
var _45104__$1 = this;
return self__.meta45103;
}));

(cljs.core.async.t_cljs$core$async45102.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async45102.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.out;
}));

(cljs.core.async.t_cljs$core$async45102.prototype.cljs$core$async$Mix$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async45102.prototype.cljs$core$async$Mix$admix_STAR_$arity$2 = (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.assoc,ch,cljs.core.PersistentArrayMap.EMPTY);

return self__.changed.call(null);
}));

(cljs.core.async.t_cljs$core$async45102.prototype.cljs$core$async$Mix$unmix_STAR_$arity$2 = (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.dissoc,ch);

return self__.changed.call(null);
}));

(cljs.core.async.t_cljs$core$async45102.prototype.cljs$core$async$Mix$unmix_all_STAR_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_.call(null,self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return self__.changed.call(null);
}));

(cljs.core.async.t_cljs$core$async45102.prototype.cljs$core$async$Mix$toggle_STAR_$arity$2 = (function (_,state_map){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.partial.call(null,cljs.core.merge_with,cljs.core.merge),state_map);

return self__.changed.call(null);
}));

(cljs.core.async.t_cljs$core$async45102.prototype.cljs$core$async$Mix$solo_mode_STAR_$arity$2 = (function (_,mode){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_(self__.solo_modes.call(null,mode))){
} else {
throw (new Error(["Assert failed: ",["mode must be one of: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(self__.solo_modes)].join(''),"\n","(solo-modes mode)"].join('')));
}

cljs.core.reset_BANG_.call(null,self__.solo_mode,mode);

return self__.changed.call(null);
}));

(cljs.core.async.t_cljs$core$async45102.getBasis = (function (){
return new cljs.core.PersistentVector(null, 10, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"change","change",477485025,null),new cljs.core.Symbol(null,"solo-mode","solo-mode",2031788074,null),new cljs.core.Symbol(null,"pick","pick",1300068175,null),new cljs.core.Symbol(null,"cs","cs",-117024463,null),new cljs.core.Symbol(null,"calc-state","calc-state",-349968968,null),new cljs.core.Symbol(null,"out","out",729986010,null),new cljs.core.Symbol(null,"changed","changed",-2083710852,null),new cljs.core.Symbol(null,"solo-modes","solo-modes",882180540,null),new cljs.core.Symbol(null,"attrs","attrs",-450137186,null),new cljs.core.Symbol(null,"meta45103","meta45103",1512922732,null)], null);
}));

(cljs.core.async.t_cljs$core$async45102.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async45102.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async45102");

(cljs.core.async.t_cljs$core$async45102.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write.call(null,writer__4429__auto__,"cljs.core.async/t_cljs$core$async45102");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async45102.
 */
cljs.core.async.__GT_t_cljs$core$async45102 = (function cljs$core$async$mix_$___GT_t_cljs$core$async45102(change__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta45103){
return (new cljs.core.async.t_cljs$core$async45102(change__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta45103));
});

}

return (new cljs.core.async.t_cljs$core$async45102(change,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__27715__auto___45266 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_45206){
var state_val_45207 = (state_45206[(1)]);
if((state_val_45207 === (7))){
var inst_45121 = (state_45206[(2)]);
var state_45206__$1 = state_45206;
var statearr_45208_45267 = state_45206__$1;
(statearr_45208_45267[(2)] = inst_45121);

(statearr_45208_45267[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (20))){
var inst_45133 = (state_45206[(7)]);
var state_45206__$1 = state_45206;
var statearr_45209_45268 = state_45206__$1;
(statearr_45209_45268[(2)] = inst_45133);

(statearr_45209_45268[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (27))){
var state_45206__$1 = state_45206;
var statearr_45210_45269 = state_45206__$1;
(statearr_45210_45269[(2)] = null);

(statearr_45210_45269[(1)] = (28));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (1))){
var inst_45108 = (state_45206[(8)]);
var inst_45108__$1 = calc_state.call(null);
var inst_45110 = (inst_45108__$1 == null);
var inst_45111 = cljs.core.not.call(null,inst_45110);
var state_45206__$1 = (function (){var statearr_45211 = state_45206;
(statearr_45211[(8)] = inst_45108__$1);

return statearr_45211;
})();
if(inst_45111){
var statearr_45212_45270 = state_45206__$1;
(statearr_45212_45270[(1)] = (2));

} else {
var statearr_45213_45271 = state_45206__$1;
(statearr_45213_45271[(1)] = (3));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (24))){
var inst_45180 = (state_45206[(9)]);
var inst_45157 = (state_45206[(10)]);
var inst_45166 = (state_45206[(11)]);
var inst_45180__$1 = inst_45157.call(null,inst_45166);
var state_45206__$1 = (function (){var statearr_45214 = state_45206;
(statearr_45214[(9)] = inst_45180__$1);

return statearr_45214;
})();
if(cljs.core.truth_(inst_45180__$1)){
var statearr_45215_45272 = state_45206__$1;
(statearr_45215_45272[(1)] = (29));

} else {
var statearr_45216_45273 = state_45206__$1;
(statearr_45216_45273[(1)] = (30));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (4))){
var inst_45124 = (state_45206[(2)]);
var state_45206__$1 = state_45206;
if(cljs.core.truth_(inst_45124)){
var statearr_45217_45274 = state_45206__$1;
(statearr_45217_45274[(1)] = (8));

} else {
var statearr_45218_45275 = state_45206__$1;
(statearr_45218_45275[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (15))){
var inst_45151 = (state_45206[(2)]);
var state_45206__$1 = state_45206;
if(cljs.core.truth_(inst_45151)){
var statearr_45219_45276 = state_45206__$1;
(statearr_45219_45276[(1)] = (19));

} else {
var statearr_45220_45277 = state_45206__$1;
(statearr_45220_45277[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (21))){
var inst_45156 = (state_45206[(12)]);
var inst_45156__$1 = (state_45206[(2)]);
var inst_45157 = cljs.core.get.call(null,inst_45156__$1,new cljs.core.Keyword(null,"solos","solos",1441458643));
var inst_45158 = cljs.core.get.call(null,inst_45156__$1,new cljs.core.Keyword(null,"mutes","mutes",1068806309));
var inst_45159 = cljs.core.get.call(null,inst_45156__$1,new cljs.core.Keyword(null,"reads","reads",-1215067361));
var state_45206__$1 = (function (){var statearr_45221 = state_45206;
(statearr_45221[(13)] = inst_45158);

(statearr_45221[(10)] = inst_45157);

(statearr_45221[(12)] = inst_45156__$1);

return statearr_45221;
})();
return cljs.core.async.ioc_alts_BANG_.call(null,state_45206__$1,(22),inst_45159);
} else {
if((state_val_45207 === (31))){
var inst_45188 = (state_45206[(2)]);
var state_45206__$1 = state_45206;
if(cljs.core.truth_(inst_45188)){
var statearr_45222_45278 = state_45206__$1;
(statearr_45222_45278[(1)] = (32));

} else {
var statearr_45223_45279 = state_45206__$1;
(statearr_45223_45279[(1)] = (33));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (32))){
var inst_45165 = (state_45206[(14)]);
var state_45206__$1 = state_45206;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_45206__$1,(35),out,inst_45165);
} else {
if((state_val_45207 === (33))){
var inst_45156 = (state_45206[(12)]);
var inst_45133 = inst_45156;
var state_45206__$1 = (function (){var statearr_45224 = state_45206;
(statearr_45224[(7)] = inst_45133);

return statearr_45224;
})();
var statearr_45225_45280 = state_45206__$1;
(statearr_45225_45280[(2)] = null);

(statearr_45225_45280[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (13))){
var inst_45133 = (state_45206[(7)]);
var inst_45140 = inst_45133.cljs$lang$protocol_mask$partition0$;
var inst_45141 = (inst_45140 & (64));
var inst_45142 = inst_45133.cljs$core$ISeq$;
var inst_45143 = (cljs.core.PROTOCOL_SENTINEL === inst_45142);
var inst_45144 = ((inst_45141) || (inst_45143));
var state_45206__$1 = state_45206;
if(cljs.core.truth_(inst_45144)){
var statearr_45226_45281 = state_45206__$1;
(statearr_45226_45281[(1)] = (16));

} else {
var statearr_45227_45282 = state_45206__$1;
(statearr_45227_45282[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (22))){
var inst_45165 = (state_45206[(14)]);
var inst_45166 = (state_45206[(11)]);
var inst_45164 = (state_45206[(2)]);
var inst_45165__$1 = cljs.core.nth.call(null,inst_45164,(0),null);
var inst_45166__$1 = cljs.core.nth.call(null,inst_45164,(1),null);
var inst_45167 = (inst_45165__$1 == null);
var inst_45168 = cljs.core._EQ_.call(null,inst_45166__$1,change);
var inst_45169 = ((inst_45167) || (inst_45168));
var state_45206__$1 = (function (){var statearr_45228 = state_45206;
(statearr_45228[(14)] = inst_45165__$1);

(statearr_45228[(11)] = inst_45166__$1);

return statearr_45228;
})();
if(cljs.core.truth_(inst_45169)){
var statearr_45229_45283 = state_45206__$1;
(statearr_45229_45283[(1)] = (23));

} else {
var statearr_45230_45284 = state_45206__$1;
(statearr_45230_45284[(1)] = (24));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (36))){
var inst_45156 = (state_45206[(12)]);
var inst_45133 = inst_45156;
var state_45206__$1 = (function (){var statearr_45231 = state_45206;
(statearr_45231[(7)] = inst_45133);

return statearr_45231;
})();
var statearr_45232_45285 = state_45206__$1;
(statearr_45232_45285[(2)] = null);

(statearr_45232_45285[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (29))){
var inst_45180 = (state_45206[(9)]);
var state_45206__$1 = state_45206;
var statearr_45233_45286 = state_45206__$1;
(statearr_45233_45286[(2)] = inst_45180);

(statearr_45233_45286[(1)] = (31));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (6))){
var state_45206__$1 = state_45206;
var statearr_45234_45287 = state_45206__$1;
(statearr_45234_45287[(2)] = false);

(statearr_45234_45287[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (28))){
var inst_45176 = (state_45206[(2)]);
var inst_45177 = calc_state.call(null);
var inst_45133 = inst_45177;
var state_45206__$1 = (function (){var statearr_45235 = state_45206;
(statearr_45235[(15)] = inst_45176);

(statearr_45235[(7)] = inst_45133);

return statearr_45235;
})();
var statearr_45236_45288 = state_45206__$1;
(statearr_45236_45288[(2)] = null);

(statearr_45236_45288[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (25))){
var inst_45202 = (state_45206[(2)]);
var state_45206__$1 = state_45206;
var statearr_45237_45289 = state_45206__$1;
(statearr_45237_45289[(2)] = inst_45202);

(statearr_45237_45289[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (34))){
var inst_45200 = (state_45206[(2)]);
var state_45206__$1 = state_45206;
var statearr_45238_45290 = state_45206__$1;
(statearr_45238_45290[(2)] = inst_45200);

(statearr_45238_45290[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (17))){
var state_45206__$1 = state_45206;
var statearr_45239_45291 = state_45206__$1;
(statearr_45239_45291[(2)] = false);

(statearr_45239_45291[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (3))){
var state_45206__$1 = state_45206;
var statearr_45240_45292 = state_45206__$1;
(statearr_45240_45292[(2)] = false);

(statearr_45240_45292[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (12))){
var inst_45204 = (state_45206[(2)]);
var state_45206__$1 = state_45206;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_45206__$1,inst_45204);
} else {
if((state_val_45207 === (2))){
var inst_45108 = (state_45206[(8)]);
var inst_45113 = inst_45108.cljs$lang$protocol_mask$partition0$;
var inst_45114 = (inst_45113 & (64));
var inst_45115 = inst_45108.cljs$core$ISeq$;
var inst_45116 = (cljs.core.PROTOCOL_SENTINEL === inst_45115);
var inst_45117 = ((inst_45114) || (inst_45116));
var state_45206__$1 = state_45206;
if(cljs.core.truth_(inst_45117)){
var statearr_45241_45293 = state_45206__$1;
(statearr_45241_45293[(1)] = (5));

} else {
var statearr_45242_45294 = state_45206__$1;
(statearr_45242_45294[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (23))){
var inst_45165 = (state_45206[(14)]);
var inst_45171 = (inst_45165 == null);
var state_45206__$1 = state_45206;
if(cljs.core.truth_(inst_45171)){
var statearr_45243_45295 = state_45206__$1;
(statearr_45243_45295[(1)] = (26));

} else {
var statearr_45244_45296 = state_45206__$1;
(statearr_45244_45296[(1)] = (27));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (35))){
var inst_45191 = (state_45206[(2)]);
var state_45206__$1 = state_45206;
if(cljs.core.truth_(inst_45191)){
var statearr_45245_45297 = state_45206__$1;
(statearr_45245_45297[(1)] = (36));

} else {
var statearr_45246_45298 = state_45206__$1;
(statearr_45246_45298[(1)] = (37));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (19))){
var inst_45133 = (state_45206[(7)]);
var inst_45153 = cljs.core.apply.call(null,cljs.core.hash_map,inst_45133);
var state_45206__$1 = state_45206;
var statearr_45247_45299 = state_45206__$1;
(statearr_45247_45299[(2)] = inst_45153);

(statearr_45247_45299[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (11))){
var inst_45133 = (state_45206[(7)]);
var inst_45137 = (inst_45133 == null);
var inst_45138 = cljs.core.not.call(null,inst_45137);
var state_45206__$1 = state_45206;
if(inst_45138){
var statearr_45248_45300 = state_45206__$1;
(statearr_45248_45300[(1)] = (13));

} else {
var statearr_45249_45301 = state_45206__$1;
(statearr_45249_45301[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (9))){
var inst_45108 = (state_45206[(8)]);
var state_45206__$1 = state_45206;
var statearr_45250_45302 = state_45206__$1;
(statearr_45250_45302[(2)] = inst_45108);

(statearr_45250_45302[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (5))){
var state_45206__$1 = state_45206;
var statearr_45251_45303 = state_45206__$1;
(statearr_45251_45303[(2)] = true);

(statearr_45251_45303[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (14))){
var state_45206__$1 = state_45206;
var statearr_45252_45304 = state_45206__$1;
(statearr_45252_45304[(2)] = false);

(statearr_45252_45304[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (26))){
var inst_45166 = (state_45206[(11)]);
var inst_45173 = cljs.core.swap_BANG_.call(null,cs,cljs.core.dissoc,inst_45166);
var state_45206__$1 = state_45206;
var statearr_45253_45305 = state_45206__$1;
(statearr_45253_45305[(2)] = inst_45173);

(statearr_45253_45305[(1)] = (28));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (16))){
var state_45206__$1 = state_45206;
var statearr_45254_45306 = state_45206__$1;
(statearr_45254_45306[(2)] = true);

(statearr_45254_45306[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (38))){
var inst_45196 = (state_45206[(2)]);
var state_45206__$1 = state_45206;
var statearr_45255_45307 = state_45206__$1;
(statearr_45255_45307[(2)] = inst_45196);

(statearr_45255_45307[(1)] = (34));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (30))){
var inst_45158 = (state_45206[(13)]);
var inst_45157 = (state_45206[(10)]);
var inst_45166 = (state_45206[(11)]);
var inst_45183 = cljs.core.empty_QMARK_.call(null,inst_45157);
var inst_45184 = inst_45158.call(null,inst_45166);
var inst_45185 = cljs.core.not.call(null,inst_45184);
var inst_45186 = ((inst_45183) && (inst_45185));
var state_45206__$1 = state_45206;
var statearr_45256_45308 = state_45206__$1;
(statearr_45256_45308[(2)] = inst_45186);

(statearr_45256_45308[(1)] = (31));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (10))){
var inst_45108 = (state_45206[(8)]);
var inst_45129 = (state_45206[(2)]);
var inst_45130 = cljs.core.get.call(null,inst_45129,new cljs.core.Keyword(null,"solos","solos",1441458643));
var inst_45131 = cljs.core.get.call(null,inst_45129,new cljs.core.Keyword(null,"mutes","mutes",1068806309));
var inst_45132 = cljs.core.get.call(null,inst_45129,new cljs.core.Keyword(null,"reads","reads",-1215067361));
var inst_45133 = inst_45108;
var state_45206__$1 = (function (){var statearr_45257 = state_45206;
(statearr_45257[(16)] = inst_45131);

(statearr_45257[(17)] = inst_45132);

(statearr_45257[(18)] = inst_45130);

(statearr_45257[(7)] = inst_45133);

return statearr_45257;
})();
var statearr_45258_45309 = state_45206__$1;
(statearr_45258_45309[(2)] = null);

(statearr_45258_45309[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (18))){
var inst_45148 = (state_45206[(2)]);
var state_45206__$1 = state_45206;
var statearr_45259_45310 = state_45206__$1;
(statearr_45259_45310[(2)] = inst_45148);

(statearr_45259_45310[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (37))){
var state_45206__$1 = state_45206;
var statearr_45260_45311 = state_45206__$1;
(statearr_45260_45311[(2)] = null);

(statearr_45260_45311[(1)] = (38));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45207 === (8))){
var inst_45108 = (state_45206[(8)]);
var inst_45126 = cljs.core.apply.call(null,cljs.core.hash_map,inst_45108);
var state_45206__$1 = state_45206;
var statearr_45261_45312 = state_45206__$1;
(statearr_45261_45312[(2)] = inst_45126);

(statearr_45261_45312[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$mix_$_state_machine__27525__auto__ = null;
var cljs$core$async$mix_$_state_machine__27525__auto____0 = (function (){
var statearr_45262 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_45262[(0)] = cljs$core$async$mix_$_state_machine__27525__auto__);

(statearr_45262[(1)] = (1));

return statearr_45262;
});
var cljs$core$async$mix_$_state_machine__27525__auto____1 = (function (state_45206){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_45206);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e45263){if((e45263 instanceof Object)){
var ex__27528__auto__ = e45263;
var statearr_45264_45313 = state_45206;
(statearr_45264_45313[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_45206);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e45263;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__45314 = state_45206;
state_45206 = G__45314;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$mix_$_state_machine__27525__auto__ = function(state_45206){
switch(arguments.length){
case 0:
return cljs$core$async$mix_$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$mix_$_state_machine__27525__auto____1.call(this,state_45206);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mix_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mix_$_state_machine__27525__auto____0;
cljs$core$async$mix_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mix_$_state_machine__27525__auto____1;
return cljs$core$async$mix_$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_45265 = f__27716__auto__.call(null);
(statearr_45265[(6)] = c__27715__auto___45266);

return statearr_45265;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


return m;
});
/**
 * Adds ch as an input to the mix
 */
cljs.core.async.admix = (function cljs$core$async$admix(mix,ch){
return cljs.core.async.admix_STAR_.call(null,mix,ch);
});
/**
 * Removes ch as an input to the mix
 */
cljs.core.async.unmix = (function cljs$core$async$unmix(mix,ch){
return cljs.core.async.unmix_STAR_.call(null,mix,ch);
});
/**
 * removes all inputs from the mix
 */
cljs.core.async.unmix_all = (function cljs$core$async$unmix_all(mix){
return cljs.core.async.unmix_all_STAR_.call(null,mix);
});
/**
 * Atomically sets the state(s) of one or more channels in a mix. The
 *   state map is a map of channels -> channel-state-map. A
 *   channel-state-map is a map of attrs -> boolean, where attr is one or
 *   more of :mute, :pause or :solo. Any states supplied are merged with
 *   the current state.
 * 
 *   Note that channels can be added to a mix via toggle, which can be
 *   used to add channels in a particular (e.g. paused) state.
 */
cljs.core.async.toggle = (function cljs$core$async$toggle(mix,state_map){
return cljs.core.async.toggle_STAR_.call(null,mix,state_map);
});
/**
 * Sets the solo mode of the mix. mode must be one of :mute or :pause
 */
cljs.core.async.solo_mode = (function cljs$core$async$solo_mode(mix,mode){
return cljs.core.async.solo_mode_STAR_.call(null,mix,mode);
});

/**
 * @interface
 */
cljs.core.async.Pub = function(){};

cljs.core.async.sub_STAR_ = (function cljs$core$async$sub_STAR_(p,v,ch,close_QMARK_){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$sub_STAR_$arity$4 == null)))))){
return p.cljs$core$async$Pub$sub_STAR_$arity$4(p,v,ch,close_QMARK_);
} else {
var x__4487__auto__ = (((p == null))?null:p);
var m__4488__auto__ = (cljs.core.async.sub_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,p,v,ch,close_QMARK_);
} else {
var m__4485__auto__ = (cljs.core.async.sub_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,p,v,ch,close_QMARK_);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.sub*",p);
}
}
}
});

cljs.core.async.unsub_STAR_ = (function cljs$core$async$unsub_STAR_(p,v,ch){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_STAR_$arity$3 == null)))))){
return p.cljs$core$async$Pub$unsub_STAR_$arity$3(p,v,ch);
} else {
var x__4487__auto__ = (((p == null))?null:p);
var m__4488__auto__ = (cljs.core.async.unsub_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,p,v,ch);
} else {
var m__4485__auto__ = (cljs.core.async.unsub_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,p,v,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.unsub*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_ = (function cljs$core$async$unsub_all_STAR_(var_args){
var G__45316 = arguments.length;
switch (G__45316) {
case 1:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1 = (function (p){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$1 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$1(p);
} else {
var x__4487__auto__ = (((p == null))?null:p);
var m__4488__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,p);
} else {
var m__4485__auto__ = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,p);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.unsub-all*",p);
}
}
}
}));

(cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2 = (function (p,v){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$2 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$2(p,v);
} else {
var x__4487__auto__ = (((p == null))?null:p);
var m__4488__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,p,v);
} else {
var m__4485__auto__ = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,p,v);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.unsub-all*",p);
}
}
}
}));

(cljs.core.async.unsub_all_STAR_.cljs$lang$maxFixedArity = 2);


/**
 * Creates and returns a pub(lication) of the supplied channel,
 *   partitioned into topics by the topic-fn. topic-fn will be applied to
 *   each value on the channel and the result will determine the 'topic'
 *   on which that value will be put. Channels can be subscribed to
 *   receive copies of topics using 'sub', and unsubscribed using
 *   'unsub'. Each topic will be handled by an internal mult on a
 *   dedicated channel. By default these internal channels are
 *   unbuffered, but a buf-fn can be supplied which, given a topic,
 *   creates a buffer with desired properties.
 * 
 *   Each item is distributed to all subs in parallel and synchronously,
 *   i.e. each sub must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow subs from holding up the pub.
 * 
 *   Items received when there are no matching subs get dropped.
 * 
 *   Note that if buf-fns are used then each topic is handled
 *   asynchronously, i.e. if a channel is subscribed to more than one
 *   topic it should not expect them to be interleaved identically with
 *   the source.
 */
cljs.core.async.pub = (function cljs$core$async$pub(var_args){
var G__45320 = arguments.length;
switch (G__45320) {
case 2:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2 = (function (ch,topic_fn){
return cljs.core.async.pub.call(null,ch,topic_fn,cljs.core.constantly.call(null,null));
}));

(cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3 = (function (ch,topic_fn,buf_fn){
var mults = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var ensure_mult = (function (topic){
var or__4185__auto__ = cljs.core.get.call(null,cljs.core.deref.call(null,mults),topic);
if(cljs.core.truth_(or__4185__auto__)){
return or__4185__auto__;
} else {
return cljs.core.get.call(null,cljs.core.swap_BANG_.call(null,mults,(function (p1__45318_SHARP_){
if(cljs.core.truth_(p1__45318_SHARP_.call(null,topic))){
return p1__45318_SHARP_;
} else {
return cljs.core.assoc.call(null,p1__45318_SHARP_,topic,cljs.core.async.mult.call(null,cljs.core.async.chan.call(null,buf_fn.call(null,topic))));
}
})),topic);
}
});
var p = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async45321 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Pub}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async45321 = (function (ch,topic_fn,buf_fn,mults,ensure_mult,meta45322){
this.ch = ch;
this.topic_fn = topic_fn;
this.buf_fn = buf_fn;
this.mults = mults;
this.ensure_mult = ensure_mult;
this.meta45322 = meta45322;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async45321.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_45323,meta45322__$1){
var self__ = this;
var _45323__$1 = this;
return (new cljs.core.async.t_cljs$core$async45321(self__.ch,self__.topic_fn,self__.buf_fn,self__.mults,self__.ensure_mult,meta45322__$1));
}));

(cljs.core.async.t_cljs$core$async45321.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_45323){
var self__ = this;
var _45323__$1 = this;
return self__.meta45322;
}));

(cljs.core.async.t_cljs$core$async45321.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async45321.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
}));

(cljs.core.async.t_cljs$core$async45321.prototype.cljs$core$async$Pub$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async45321.prototype.cljs$core$async$Pub$sub_STAR_$arity$4 = (function (p,topic,ch__$1,close_QMARK_){
var self__ = this;
var p__$1 = this;
var m = self__.ensure_mult.call(null,topic);
return cljs.core.async.tap.call(null,m,ch__$1,close_QMARK_);
}));

(cljs.core.async.t_cljs$core$async45321.prototype.cljs$core$async$Pub$unsub_STAR_$arity$3 = (function (p,topic,ch__$1){
var self__ = this;
var p__$1 = this;
var temp__5735__auto__ = cljs.core.get.call(null,cljs.core.deref.call(null,self__.mults),topic);
if(cljs.core.truth_(temp__5735__auto__)){
var m = temp__5735__auto__;
return cljs.core.async.untap.call(null,m,ch__$1);
} else {
return null;
}
}));

(cljs.core.async.t_cljs$core$async45321.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.reset_BANG_.call(null,self__.mults,cljs.core.PersistentArrayMap.EMPTY);
}));

(cljs.core.async.t_cljs$core$async45321.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$2 = (function (_,topic){
var self__ = this;
var ___$1 = this;
return cljs.core.swap_BANG_.call(null,self__.mults,cljs.core.dissoc,topic);
}));

(cljs.core.async.t_cljs$core$async45321.getBasis = (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"topic-fn","topic-fn",-862449736,null),new cljs.core.Symbol(null,"buf-fn","buf-fn",-1200281591,null),new cljs.core.Symbol(null,"mults","mults",-461114485,null),new cljs.core.Symbol(null,"ensure-mult","ensure-mult",1796584816,null),new cljs.core.Symbol(null,"meta45322","meta45322",1406522519,null)], null);
}));

(cljs.core.async.t_cljs$core$async45321.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async45321.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async45321");

(cljs.core.async.t_cljs$core$async45321.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write.call(null,writer__4429__auto__,"cljs.core.async/t_cljs$core$async45321");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async45321.
 */
cljs.core.async.__GT_t_cljs$core$async45321 = (function cljs$core$async$__GT_t_cljs$core$async45321(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta45322){
return (new cljs.core.async.t_cljs$core$async45321(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta45322));
});

}

return (new cljs.core.async.t_cljs$core$async45321(ch,topic_fn,buf_fn,mults,ensure_mult,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__27715__auto___45441 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_45395){
var state_val_45396 = (state_45395[(1)]);
if((state_val_45396 === (7))){
var inst_45391 = (state_45395[(2)]);
var state_45395__$1 = state_45395;
var statearr_45397_45442 = state_45395__$1;
(statearr_45397_45442[(2)] = inst_45391);

(statearr_45397_45442[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (20))){
var state_45395__$1 = state_45395;
var statearr_45398_45443 = state_45395__$1;
(statearr_45398_45443[(2)] = null);

(statearr_45398_45443[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (1))){
var state_45395__$1 = state_45395;
var statearr_45399_45444 = state_45395__$1;
(statearr_45399_45444[(2)] = null);

(statearr_45399_45444[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (24))){
var inst_45374 = (state_45395[(7)]);
var inst_45383 = cljs.core.swap_BANG_.call(null,mults,cljs.core.dissoc,inst_45374);
var state_45395__$1 = state_45395;
var statearr_45400_45445 = state_45395__$1;
(statearr_45400_45445[(2)] = inst_45383);

(statearr_45400_45445[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (4))){
var inst_45326 = (state_45395[(8)]);
var inst_45326__$1 = (state_45395[(2)]);
var inst_45327 = (inst_45326__$1 == null);
var state_45395__$1 = (function (){var statearr_45401 = state_45395;
(statearr_45401[(8)] = inst_45326__$1);

return statearr_45401;
})();
if(cljs.core.truth_(inst_45327)){
var statearr_45402_45446 = state_45395__$1;
(statearr_45402_45446[(1)] = (5));

} else {
var statearr_45403_45447 = state_45395__$1;
(statearr_45403_45447[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (15))){
var inst_45368 = (state_45395[(2)]);
var state_45395__$1 = state_45395;
var statearr_45404_45448 = state_45395__$1;
(statearr_45404_45448[(2)] = inst_45368);

(statearr_45404_45448[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (21))){
var inst_45388 = (state_45395[(2)]);
var state_45395__$1 = (function (){var statearr_45405 = state_45395;
(statearr_45405[(9)] = inst_45388);

return statearr_45405;
})();
var statearr_45406_45449 = state_45395__$1;
(statearr_45406_45449[(2)] = null);

(statearr_45406_45449[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (13))){
var inst_45350 = (state_45395[(10)]);
var inst_45352 = cljs.core.chunked_seq_QMARK_.call(null,inst_45350);
var state_45395__$1 = state_45395;
if(inst_45352){
var statearr_45407_45450 = state_45395__$1;
(statearr_45407_45450[(1)] = (16));

} else {
var statearr_45408_45451 = state_45395__$1;
(statearr_45408_45451[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (22))){
var inst_45380 = (state_45395[(2)]);
var state_45395__$1 = state_45395;
if(cljs.core.truth_(inst_45380)){
var statearr_45409_45452 = state_45395__$1;
(statearr_45409_45452[(1)] = (23));

} else {
var statearr_45410_45453 = state_45395__$1;
(statearr_45410_45453[(1)] = (24));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (6))){
var inst_45376 = (state_45395[(11)]);
var inst_45374 = (state_45395[(7)]);
var inst_45326 = (state_45395[(8)]);
var inst_45374__$1 = topic_fn.call(null,inst_45326);
var inst_45375 = cljs.core.deref.call(null,mults);
var inst_45376__$1 = cljs.core.get.call(null,inst_45375,inst_45374__$1);
var state_45395__$1 = (function (){var statearr_45411 = state_45395;
(statearr_45411[(11)] = inst_45376__$1);

(statearr_45411[(7)] = inst_45374__$1);

return statearr_45411;
})();
if(cljs.core.truth_(inst_45376__$1)){
var statearr_45412_45454 = state_45395__$1;
(statearr_45412_45454[(1)] = (19));

} else {
var statearr_45413_45455 = state_45395__$1;
(statearr_45413_45455[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (25))){
var inst_45385 = (state_45395[(2)]);
var state_45395__$1 = state_45395;
var statearr_45414_45456 = state_45395__$1;
(statearr_45414_45456[(2)] = inst_45385);

(statearr_45414_45456[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (17))){
var inst_45350 = (state_45395[(10)]);
var inst_45359 = cljs.core.first.call(null,inst_45350);
var inst_45360 = cljs.core.async.muxch_STAR_.call(null,inst_45359);
var inst_45361 = cljs.core.async.close_BANG_.call(null,inst_45360);
var inst_45362 = cljs.core.next.call(null,inst_45350);
var inst_45336 = inst_45362;
var inst_45337 = null;
var inst_45338 = (0);
var inst_45339 = (0);
var state_45395__$1 = (function (){var statearr_45415 = state_45395;
(statearr_45415[(12)] = inst_45339);

(statearr_45415[(13)] = inst_45337);

(statearr_45415[(14)] = inst_45336);

(statearr_45415[(15)] = inst_45361);

(statearr_45415[(16)] = inst_45338);

return statearr_45415;
})();
var statearr_45416_45457 = state_45395__$1;
(statearr_45416_45457[(2)] = null);

(statearr_45416_45457[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (3))){
var inst_45393 = (state_45395[(2)]);
var state_45395__$1 = state_45395;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_45395__$1,inst_45393);
} else {
if((state_val_45396 === (12))){
var inst_45370 = (state_45395[(2)]);
var state_45395__$1 = state_45395;
var statearr_45417_45458 = state_45395__$1;
(statearr_45417_45458[(2)] = inst_45370);

(statearr_45417_45458[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (2))){
var state_45395__$1 = state_45395;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_45395__$1,(4),ch);
} else {
if((state_val_45396 === (23))){
var state_45395__$1 = state_45395;
var statearr_45418_45459 = state_45395__$1;
(statearr_45418_45459[(2)] = null);

(statearr_45418_45459[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (19))){
var inst_45376 = (state_45395[(11)]);
var inst_45326 = (state_45395[(8)]);
var inst_45378 = cljs.core.async.muxch_STAR_.call(null,inst_45376);
var state_45395__$1 = state_45395;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_45395__$1,(22),inst_45378,inst_45326);
} else {
if((state_val_45396 === (11))){
var inst_45336 = (state_45395[(14)]);
var inst_45350 = (state_45395[(10)]);
var inst_45350__$1 = cljs.core.seq.call(null,inst_45336);
var state_45395__$1 = (function (){var statearr_45419 = state_45395;
(statearr_45419[(10)] = inst_45350__$1);

return statearr_45419;
})();
if(inst_45350__$1){
var statearr_45420_45460 = state_45395__$1;
(statearr_45420_45460[(1)] = (13));

} else {
var statearr_45421_45461 = state_45395__$1;
(statearr_45421_45461[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (9))){
var inst_45372 = (state_45395[(2)]);
var state_45395__$1 = state_45395;
var statearr_45422_45462 = state_45395__$1;
(statearr_45422_45462[(2)] = inst_45372);

(statearr_45422_45462[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (5))){
var inst_45333 = cljs.core.deref.call(null,mults);
var inst_45334 = cljs.core.vals.call(null,inst_45333);
var inst_45335 = cljs.core.seq.call(null,inst_45334);
var inst_45336 = inst_45335;
var inst_45337 = null;
var inst_45338 = (0);
var inst_45339 = (0);
var state_45395__$1 = (function (){var statearr_45423 = state_45395;
(statearr_45423[(12)] = inst_45339);

(statearr_45423[(13)] = inst_45337);

(statearr_45423[(14)] = inst_45336);

(statearr_45423[(16)] = inst_45338);

return statearr_45423;
})();
var statearr_45424_45463 = state_45395__$1;
(statearr_45424_45463[(2)] = null);

(statearr_45424_45463[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (14))){
var state_45395__$1 = state_45395;
var statearr_45428_45464 = state_45395__$1;
(statearr_45428_45464[(2)] = null);

(statearr_45428_45464[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (16))){
var inst_45350 = (state_45395[(10)]);
var inst_45354 = cljs.core.chunk_first.call(null,inst_45350);
var inst_45355 = cljs.core.chunk_rest.call(null,inst_45350);
var inst_45356 = cljs.core.count.call(null,inst_45354);
var inst_45336 = inst_45355;
var inst_45337 = inst_45354;
var inst_45338 = inst_45356;
var inst_45339 = (0);
var state_45395__$1 = (function (){var statearr_45429 = state_45395;
(statearr_45429[(12)] = inst_45339);

(statearr_45429[(13)] = inst_45337);

(statearr_45429[(14)] = inst_45336);

(statearr_45429[(16)] = inst_45338);

return statearr_45429;
})();
var statearr_45430_45465 = state_45395__$1;
(statearr_45430_45465[(2)] = null);

(statearr_45430_45465[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (10))){
var inst_45339 = (state_45395[(12)]);
var inst_45337 = (state_45395[(13)]);
var inst_45336 = (state_45395[(14)]);
var inst_45338 = (state_45395[(16)]);
var inst_45344 = cljs.core._nth.call(null,inst_45337,inst_45339);
var inst_45345 = cljs.core.async.muxch_STAR_.call(null,inst_45344);
var inst_45346 = cljs.core.async.close_BANG_.call(null,inst_45345);
var inst_45347 = (inst_45339 + (1));
var tmp45425 = inst_45337;
var tmp45426 = inst_45336;
var tmp45427 = inst_45338;
var inst_45336__$1 = tmp45426;
var inst_45337__$1 = tmp45425;
var inst_45338__$1 = tmp45427;
var inst_45339__$1 = inst_45347;
var state_45395__$1 = (function (){var statearr_45431 = state_45395;
(statearr_45431[(12)] = inst_45339__$1);

(statearr_45431[(13)] = inst_45337__$1);

(statearr_45431[(14)] = inst_45336__$1);

(statearr_45431[(16)] = inst_45338__$1);

(statearr_45431[(17)] = inst_45346);

return statearr_45431;
})();
var statearr_45432_45466 = state_45395__$1;
(statearr_45432_45466[(2)] = null);

(statearr_45432_45466[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (18))){
var inst_45365 = (state_45395[(2)]);
var state_45395__$1 = state_45395;
var statearr_45433_45467 = state_45395__$1;
(statearr_45433_45467[(2)] = inst_45365);

(statearr_45433_45467[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45396 === (8))){
var inst_45339 = (state_45395[(12)]);
var inst_45338 = (state_45395[(16)]);
var inst_45341 = (inst_45339 < inst_45338);
var inst_45342 = inst_45341;
var state_45395__$1 = state_45395;
if(cljs.core.truth_(inst_45342)){
var statearr_45434_45468 = state_45395__$1;
(statearr_45434_45468[(1)] = (10));

} else {
var statearr_45435_45469 = state_45395__$1;
(statearr_45435_45469[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_45436 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_45436[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_45436[(1)] = (1));

return statearr_45436;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_45395){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_45395);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e45437){if((e45437 instanceof Object)){
var ex__27528__auto__ = e45437;
var statearr_45438_45470 = state_45395;
(statearr_45438_45470[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_45395);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e45437;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__45471 = state_45395;
state_45395 = G__45471;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_45395){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_45395);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_45439 = f__27716__auto__.call(null);
(statearr_45439[(6)] = c__27715__auto___45441);

return statearr_45439;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


return p;
}));

(cljs.core.async.pub.cljs$lang$maxFixedArity = 3);

/**
 * Subscribes a channel to a topic of a pub.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.sub = (function cljs$core$async$sub(var_args){
var G__45473 = arguments.length;
switch (G__45473) {
case 3:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3 = (function (p,topic,ch){
return cljs.core.async.sub.call(null,p,topic,ch,true);
}));

(cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4 = (function (p,topic,ch,close_QMARK_){
return cljs.core.async.sub_STAR_.call(null,p,topic,ch,close_QMARK_);
}));

(cljs.core.async.sub.cljs$lang$maxFixedArity = 4);

/**
 * Unsubscribes a channel from a topic of a pub
 */
cljs.core.async.unsub = (function cljs$core$async$unsub(p,topic,ch){
return cljs.core.async.unsub_STAR_.call(null,p,topic,ch);
});
/**
 * Unsubscribes all channels from a pub, or a topic of a pub
 */
cljs.core.async.unsub_all = (function cljs$core$async$unsub_all(var_args){
var G__45476 = arguments.length;
switch (G__45476) {
case 1:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1 = (function (p){
return cljs.core.async.unsub_all_STAR_.call(null,p);
}));

(cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2 = (function (p,topic){
return cljs.core.async.unsub_all_STAR_.call(null,p,topic);
}));

(cljs.core.async.unsub_all.cljs$lang$maxFixedArity = 2);

/**
 * Takes a function and a collection of source channels, and returns a
 *   channel which contains the values produced by applying f to the set
 *   of first items taken from each source channel, followed by applying
 *   f to the set of second items from each channel, until any one of the
 *   channels is closed, at which point the output channel will be
 *   closed. The returned channel will be unbuffered by default, or a
 *   buf-or-n can be supplied
 */
cljs.core.async.map = (function cljs$core$async$map(var_args){
var G__45479 = arguments.length;
switch (G__45479) {
case 2:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.map.cljs$core$IFn$_invoke$arity$2 = (function (f,chs){
return cljs.core.async.map.call(null,f,chs,null);
}));

(cljs.core.async.map.cljs$core$IFn$_invoke$arity$3 = (function (f,chs,buf_or_n){
var chs__$1 = cljs.core.vec.call(null,chs);
var out = cljs.core.async.chan.call(null,buf_or_n);
var cnt = cljs.core.count.call(null,chs__$1);
var rets = cljs.core.object_array.call(null,cnt);
var dchan = cljs.core.async.chan.call(null,(1));
var dctr = cljs.core.atom.call(null,null);
var done = cljs.core.mapv.call(null,(function (i){
return (function (ret){
(rets[i] = ret);

if((cljs.core.swap_BANG_.call(null,dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.call(null,dchan,rets.slice((0)));
} else {
return null;
}
});
}),cljs.core.range.call(null,cnt));
var c__27715__auto___45546 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_45518){
var state_val_45519 = (state_45518[(1)]);
if((state_val_45519 === (7))){
var state_45518__$1 = state_45518;
var statearr_45520_45547 = state_45518__$1;
(statearr_45520_45547[(2)] = null);

(statearr_45520_45547[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45519 === (1))){
var state_45518__$1 = state_45518;
var statearr_45521_45548 = state_45518__$1;
(statearr_45521_45548[(2)] = null);

(statearr_45521_45548[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45519 === (4))){
var inst_45482 = (state_45518[(7)]);
var inst_45484 = (inst_45482 < cnt);
var state_45518__$1 = state_45518;
if(cljs.core.truth_(inst_45484)){
var statearr_45522_45549 = state_45518__$1;
(statearr_45522_45549[(1)] = (6));

} else {
var statearr_45523_45550 = state_45518__$1;
(statearr_45523_45550[(1)] = (7));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45519 === (15))){
var inst_45514 = (state_45518[(2)]);
var state_45518__$1 = state_45518;
var statearr_45524_45551 = state_45518__$1;
(statearr_45524_45551[(2)] = inst_45514);

(statearr_45524_45551[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45519 === (13))){
var inst_45507 = cljs.core.async.close_BANG_.call(null,out);
var state_45518__$1 = state_45518;
var statearr_45525_45552 = state_45518__$1;
(statearr_45525_45552[(2)] = inst_45507);

(statearr_45525_45552[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45519 === (6))){
var state_45518__$1 = state_45518;
var statearr_45526_45553 = state_45518__$1;
(statearr_45526_45553[(2)] = null);

(statearr_45526_45553[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45519 === (3))){
var inst_45516 = (state_45518[(2)]);
var state_45518__$1 = state_45518;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_45518__$1,inst_45516);
} else {
if((state_val_45519 === (12))){
var inst_45504 = (state_45518[(8)]);
var inst_45504__$1 = (state_45518[(2)]);
var inst_45505 = cljs.core.some.call(null,cljs.core.nil_QMARK_,inst_45504__$1);
var state_45518__$1 = (function (){var statearr_45527 = state_45518;
(statearr_45527[(8)] = inst_45504__$1);

return statearr_45527;
})();
if(cljs.core.truth_(inst_45505)){
var statearr_45528_45554 = state_45518__$1;
(statearr_45528_45554[(1)] = (13));

} else {
var statearr_45529_45555 = state_45518__$1;
(statearr_45529_45555[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45519 === (2))){
var inst_45481 = cljs.core.reset_BANG_.call(null,dctr,cnt);
var inst_45482 = (0);
var state_45518__$1 = (function (){var statearr_45530 = state_45518;
(statearr_45530[(7)] = inst_45482);

(statearr_45530[(9)] = inst_45481);

return statearr_45530;
})();
var statearr_45531_45556 = state_45518__$1;
(statearr_45531_45556[(2)] = null);

(statearr_45531_45556[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45519 === (11))){
var inst_45482 = (state_45518[(7)]);
var _ = cljs.core.async.impl.ioc_helpers.add_exception_frame.call(null,state_45518,(10),Object,null,(9));
var inst_45491 = chs__$1.call(null,inst_45482);
var inst_45492 = done.call(null,inst_45482);
var inst_45493 = cljs.core.async.take_BANG_.call(null,inst_45491,inst_45492);
var state_45518__$1 = state_45518;
var statearr_45532_45557 = state_45518__$1;
(statearr_45532_45557[(2)] = inst_45493);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_45518__$1);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45519 === (9))){
var inst_45482 = (state_45518[(7)]);
var inst_45495 = (state_45518[(2)]);
var inst_45496 = (inst_45482 + (1));
var inst_45482__$1 = inst_45496;
var state_45518__$1 = (function (){var statearr_45533 = state_45518;
(statearr_45533[(10)] = inst_45495);

(statearr_45533[(7)] = inst_45482__$1);

return statearr_45533;
})();
var statearr_45534_45558 = state_45518__$1;
(statearr_45534_45558[(2)] = null);

(statearr_45534_45558[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45519 === (5))){
var inst_45502 = (state_45518[(2)]);
var state_45518__$1 = (function (){var statearr_45535 = state_45518;
(statearr_45535[(11)] = inst_45502);

return statearr_45535;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_45518__$1,(12),dchan);
} else {
if((state_val_45519 === (14))){
var inst_45504 = (state_45518[(8)]);
var inst_45509 = cljs.core.apply.call(null,f,inst_45504);
var state_45518__$1 = state_45518;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_45518__$1,(16),out,inst_45509);
} else {
if((state_val_45519 === (16))){
var inst_45511 = (state_45518[(2)]);
var state_45518__$1 = (function (){var statearr_45536 = state_45518;
(statearr_45536[(12)] = inst_45511);

return statearr_45536;
})();
var statearr_45537_45559 = state_45518__$1;
(statearr_45537_45559[(2)] = null);

(statearr_45537_45559[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45519 === (10))){
var inst_45486 = (state_45518[(2)]);
var inst_45487 = cljs.core.swap_BANG_.call(null,dctr,cljs.core.dec);
var state_45518__$1 = (function (){var statearr_45538 = state_45518;
(statearr_45538[(13)] = inst_45486);

return statearr_45538;
})();
var statearr_45539_45560 = state_45518__$1;
(statearr_45539_45560[(2)] = inst_45487);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_45518__$1);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45519 === (8))){
var inst_45500 = (state_45518[(2)]);
var state_45518__$1 = state_45518;
var statearr_45540_45561 = state_45518__$1;
(statearr_45540_45561[(2)] = inst_45500);

(statearr_45540_45561[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_45541 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_45541[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_45541[(1)] = (1));

return statearr_45541;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_45518){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_45518);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e45542){if((e45542 instanceof Object)){
var ex__27528__auto__ = e45542;
var statearr_45543_45562 = state_45518;
(statearr_45543_45562[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_45518);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e45542;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__45563 = state_45518;
state_45518 = G__45563;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_45518){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_45518);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_45544 = f__27716__auto__.call(null);
(statearr_45544[(6)] = c__27715__auto___45546);

return statearr_45544;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


return out;
}));

(cljs.core.async.map.cljs$lang$maxFixedArity = 3);

/**
 * Takes a collection of source channels and returns a channel which
 *   contains all values taken from them. The returned channel will be
 *   unbuffered by default, or a buf-or-n can be supplied. The channel
 *   will close after all the source channels have closed.
 */
cljs.core.async.merge = (function cljs$core$async$merge(var_args){
var G__45566 = arguments.length;
switch (G__45566) {
case 1:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1 = (function (chs){
return cljs.core.async.merge.call(null,chs,null);
}));

(cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2 = (function (chs,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__27715__auto___45620 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_45598){
var state_val_45599 = (state_45598[(1)]);
if((state_val_45599 === (7))){
var inst_45578 = (state_45598[(7)]);
var inst_45577 = (state_45598[(8)]);
var inst_45577__$1 = (state_45598[(2)]);
var inst_45578__$1 = cljs.core.nth.call(null,inst_45577__$1,(0),null);
var inst_45579 = cljs.core.nth.call(null,inst_45577__$1,(1),null);
var inst_45580 = (inst_45578__$1 == null);
var state_45598__$1 = (function (){var statearr_45600 = state_45598;
(statearr_45600[(9)] = inst_45579);

(statearr_45600[(7)] = inst_45578__$1);

(statearr_45600[(8)] = inst_45577__$1);

return statearr_45600;
})();
if(cljs.core.truth_(inst_45580)){
var statearr_45601_45621 = state_45598__$1;
(statearr_45601_45621[(1)] = (8));

} else {
var statearr_45602_45622 = state_45598__$1;
(statearr_45602_45622[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45599 === (1))){
var inst_45567 = cljs.core.vec.call(null,chs);
var inst_45568 = inst_45567;
var state_45598__$1 = (function (){var statearr_45603 = state_45598;
(statearr_45603[(10)] = inst_45568);

return statearr_45603;
})();
var statearr_45604_45623 = state_45598__$1;
(statearr_45604_45623[(2)] = null);

(statearr_45604_45623[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45599 === (4))){
var inst_45568 = (state_45598[(10)]);
var state_45598__$1 = state_45598;
return cljs.core.async.ioc_alts_BANG_.call(null,state_45598__$1,(7),inst_45568);
} else {
if((state_val_45599 === (6))){
var inst_45594 = (state_45598[(2)]);
var state_45598__$1 = state_45598;
var statearr_45605_45624 = state_45598__$1;
(statearr_45605_45624[(2)] = inst_45594);

(statearr_45605_45624[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45599 === (3))){
var inst_45596 = (state_45598[(2)]);
var state_45598__$1 = state_45598;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_45598__$1,inst_45596);
} else {
if((state_val_45599 === (2))){
var inst_45568 = (state_45598[(10)]);
var inst_45570 = cljs.core.count.call(null,inst_45568);
var inst_45571 = (inst_45570 > (0));
var state_45598__$1 = state_45598;
if(cljs.core.truth_(inst_45571)){
var statearr_45607_45625 = state_45598__$1;
(statearr_45607_45625[(1)] = (4));

} else {
var statearr_45608_45626 = state_45598__$1;
(statearr_45608_45626[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45599 === (11))){
var inst_45568 = (state_45598[(10)]);
var inst_45587 = (state_45598[(2)]);
var tmp45606 = inst_45568;
var inst_45568__$1 = tmp45606;
var state_45598__$1 = (function (){var statearr_45609 = state_45598;
(statearr_45609[(10)] = inst_45568__$1);

(statearr_45609[(11)] = inst_45587);

return statearr_45609;
})();
var statearr_45610_45627 = state_45598__$1;
(statearr_45610_45627[(2)] = null);

(statearr_45610_45627[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45599 === (9))){
var inst_45578 = (state_45598[(7)]);
var state_45598__$1 = state_45598;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_45598__$1,(11),out,inst_45578);
} else {
if((state_val_45599 === (5))){
var inst_45592 = cljs.core.async.close_BANG_.call(null,out);
var state_45598__$1 = state_45598;
var statearr_45611_45628 = state_45598__$1;
(statearr_45611_45628[(2)] = inst_45592);

(statearr_45611_45628[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45599 === (10))){
var inst_45590 = (state_45598[(2)]);
var state_45598__$1 = state_45598;
var statearr_45612_45629 = state_45598__$1;
(statearr_45612_45629[(2)] = inst_45590);

(statearr_45612_45629[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45599 === (8))){
var inst_45579 = (state_45598[(9)]);
var inst_45578 = (state_45598[(7)]);
var inst_45577 = (state_45598[(8)]);
var inst_45568 = (state_45598[(10)]);
var inst_45582 = (function (){var cs = inst_45568;
var vec__45573 = inst_45577;
var v = inst_45578;
var c = inst_45579;
return (function (p1__45564_SHARP_){
return cljs.core.not_EQ_.call(null,c,p1__45564_SHARP_);
});
})();
var inst_45583 = cljs.core.filterv.call(null,inst_45582,inst_45568);
var inst_45568__$1 = inst_45583;
var state_45598__$1 = (function (){var statearr_45613 = state_45598;
(statearr_45613[(10)] = inst_45568__$1);

return statearr_45613;
})();
var statearr_45614_45630 = state_45598__$1;
(statearr_45614_45630[(2)] = null);

(statearr_45614_45630[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_45615 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_45615[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_45615[(1)] = (1));

return statearr_45615;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_45598){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_45598);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e45616){if((e45616 instanceof Object)){
var ex__27528__auto__ = e45616;
var statearr_45617_45631 = state_45598;
(statearr_45617_45631[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_45598);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e45616;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__45632 = state_45598;
state_45598 = G__45632;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_45598){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_45598);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_45618 = f__27716__auto__.call(null);
(statearr_45618[(6)] = c__27715__auto___45620);

return statearr_45618;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


return out;
}));

(cljs.core.async.merge.cljs$lang$maxFixedArity = 2);

/**
 * Returns a channel containing the single (collection) result of the
 *   items taken from the channel conjoined to the supplied
 *   collection. ch must close before into produces a result.
 */
cljs.core.async.into = (function cljs$core$async$into(coll,ch){
return cljs.core.async.reduce.call(null,cljs.core.conj,coll,ch);
});
/**
 * Returns a channel that will return, at most, n items from ch. After n items
 * have been returned, or ch has been closed, the return chanel will close.
 * 
 *   The output channel is unbuffered by default, unless buf-or-n is given.
 */
cljs.core.async.take = (function cljs$core$async$take(var_args){
var G__45634 = arguments.length;
switch (G__45634) {
case 2:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.take.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.take.call(null,n,ch,null);
}));

(cljs.core.async.take.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__27715__auto___45679 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_45658){
var state_val_45659 = (state_45658[(1)]);
if((state_val_45659 === (7))){
var inst_45640 = (state_45658[(7)]);
var inst_45640__$1 = (state_45658[(2)]);
var inst_45641 = (inst_45640__$1 == null);
var inst_45642 = cljs.core.not.call(null,inst_45641);
var state_45658__$1 = (function (){var statearr_45660 = state_45658;
(statearr_45660[(7)] = inst_45640__$1);

return statearr_45660;
})();
if(inst_45642){
var statearr_45661_45680 = state_45658__$1;
(statearr_45661_45680[(1)] = (8));

} else {
var statearr_45662_45681 = state_45658__$1;
(statearr_45662_45681[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45659 === (1))){
var inst_45635 = (0);
var state_45658__$1 = (function (){var statearr_45663 = state_45658;
(statearr_45663[(8)] = inst_45635);

return statearr_45663;
})();
var statearr_45664_45682 = state_45658__$1;
(statearr_45664_45682[(2)] = null);

(statearr_45664_45682[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45659 === (4))){
var state_45658__$1 = state_45658;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_45658__$1,(7),ch);
} else {
if((state_val_45659 === (6))){
var inst_45653 = (state_45658[(2)]);
var state_45658__$1 = state_45658;
var statearr_45665_45683 = state_45658__$1;
(statearr_45665_45683[(2)] = inst_45653);

(statearr_45665_45683[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45659 === (3))){
var inst_45655 = (state_45658[(2)]);
var inst_45656 = cljs.core.async.close_BANG_.call(null,out);
var state_45658__$1 = (function (){var statearr_45666 = state_45658;
(statearr_45666[(9)] = inst_45655);

return statearr_45666;
})();
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_45658__$1,inst_45656);
} else {
if((state_val_45659 === (2))){
var inst_45635 = (state_45658[(8)]);
var inst_45637 = (inst_45635 < n);
var state_45658__$1 = state_45658;
if(cljs.core.truth_(inst_45637)){
var statearr_45667_45684 = state_45658__$1;
(statearr_45667_45684[(1)] = (4));

} else {
var statearr_45668_45685 = state_45658__$1;
(statearr_45668_45685[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45659 === (11))){
var inst_45635 = (state_45658[(8)]);
var inst_45645 = (state_45658[(2)]);
var inst_45646 = (inst_45635 + (1));
var inst_45635__$1 = inst_45646;
var state_45658__$1 = (function (){var statearr_45669 = state_45658;
(statearr_45669[(8)] = inst_45635__$1);

(statearr_45669[(10)] = inst_45645);

return statearr_45669;
})();
var statearr_45670_45686 = state_45658__$1;
(statearr_45670_45686[(2)] = null);

(statearr_45670_45686[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45659 === (9))){
var state_45658__$1 = state_45658;
var statearr_45671_45687 = state_45658__$1;
(statearr_45671_45687[(2)] = null);

(statearr_45671_45687[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45659 === (5))){
var state_45658__$1 = state_45658;
var statearr_45672_45688 = state_45658__$1;
(statearr_45672_45688[(2)] = null);

(statearr_45672_45688[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45659 === (10))){
var inst_45650 = (state_45658[(2)]);
var state_45658__$1 = state_45658;
var statearr_45673_45689 = state_45658__$1;
(statearr_45673_45689[(2)] = inst_45650);

(statearr_45673_45689[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45659 === (8))){
var inst_45640 = (state_45658[(7)]);
var state_45658__$1 = state_45658;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_45658__$1,(11),out,inst_45640);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_45674 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_45674[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_45674[(1)] = (1));

return statearr_45674;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_45658){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_45658);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e45675){if((e45675 instanceof Object)){
var ex__27528__auto__ = e45675;
var statearr_45676_45690 = state_45658;
(statearr_45676_45690[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_45658);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e45675;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__45691 = state_45658;
state_45658 = G__45691;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_45658){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_45658);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_45677 = f__27716__auto__.call(null);
(statearr_45677[(6)] = c__27715__auto___45679);

return statearr_45677;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


return out;
}));

(cljs.core.async.take.cljs$lang$maxFixedArity = 3);

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_LT_ = (function cljs$core$async$map_LT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async45693 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async45693 = (function (f,ch,meta45694){
this.f = f;
this.ch = ch;
this.meta45694 = meta45694;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async45693.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_45695,meta45694__$1){
var self__ = this;
var _45695__$1 = this;
return (new cljs.core.async.t_cljs$core$async45693(self__.f,self__.ch,meta45694__$1));
}));

(cljs.core.async.t_cljs$core$async45693.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_45695){
var self__ = this;
var _45695__$1 = this;
return self__.meta45694;
}));

(cljs.core.async.t_cljs$core$async45693.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async45693.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_.call(null,self__.ch);
}));

(cljs.core.async.t_cljs$core$async45693.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_.call(null,self__.ch);
}));

(cljs.core.async.t_cljs$core$async45693.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async45693.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
var ret = cljs.core.async.impl.protocols.take_BANG_.call(null,self__.ch,(function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async45696 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async45696 = (function (f,ch,meta45694,_,fn1,meta45697){
this.f = f;
this.ch = ch;
this.meta45694 = meta45694;
this._ = _;
this.fn1 = fn1;
this.meta45697 = meta45697;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async45696.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_45698,meta45697__$1){
var self__ = this;
var _45698__$1 = this;
return (new cljs.core.async.t_cljs$core$async45696(self__.f,self__.ch,self__.meta45694,self__._,self__.fn1,meta45697__$1));
}));

(cljs.core.async.t_cljs$core$async45696.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_45698){
var self__ = this;
var _45698__$1 = this;
return self__.meta45697;
}));

(cljs.core.async.t_cljs$core$async45696.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async45696.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (___$1){
var self__ = this;
var ___$2 = this;
return cljs.core.async.impl.protocols.active_QMARK_.call(null,self__.fn1);
}));

(cljs.core.async.t_cljs$core$async45696.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (___$1){
var self__ = this;
var ___$2 = this;
return true;
}));

(cljs.core.async.t_cljs$core$async45696.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (___$1){
var self__ = this;
var ___$2 = this;
var f1 = cljs.core.async.impl.protocols.commit.call(null,self__.fn1);
return (function (p1__45692_SHARP_){
return f1.call(null,(((p1__45692_SHARP_ == null))?null:self__.f.call(null,p1__45692_SHARP_)));
});
}));

(cljs.core.async.t_cljs$core$async45696.getBasis = (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta45694","meta45694",-91261908,null),cljs.core.with_meta(new cljs.core.Symbol(null,"_","_",-1201019570,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol("cljs.core.async","t_cljs$core$async45693","cljs.core.async/t_cljs$core$async45693",-12046400,null)], null)),new cljs.core.Symbol(null,"fn1","fn1",895834444,null),new cljs.core.Symbol(null,"meta45697","meta45697",-1221131674,null)], null);
}));

(cljs.core.async.t_cljs$core$async45696.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async45696.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async45696");

(cljs.core.async.t_cljs$core$async45696.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write.call(null,writer__4429__auto__,"cljs.core.async/t_cljs$core$async45696");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async45696.
 */
cljs.core.async.__GT_t_cljs$core$async45696 = (function cljs$core$async$map_LT__$___GT_t_cljs$core$async45696(f__$1,ch__$1,meta45694__$1,___$2,fn1__$1,meta45697){
return (new cljs.core.async.t_cljs$core$async45696(f__$1,ch__$1,meta45694__$1,___$2,fn1__$1,meta45697));
});

}

return (new cljs.core.async.t_cljs$core$async45696(self__.f,self__.ch,self__.meta45694,___$1,fn1,cljs.core.PersistentArrayMap.EMPTY));
})()
);
if(cljs.core.truth_((function (){var and__4174__auto__ = ret;
if(cljs.core.truth_(and__4174__auto__)){
return (!((cljs.core.deref.call(null,ret) == null)));
} else {
return and__4174__auto__;
}
})())){
return cljs.core.async.impl.channels.box.call(null,self__.f.call(null,cljs.core.deref.call(null,ret)));
} else {
return ret;
}
}));

(cljs.core.async.t_cljs$core$async45693.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async45693.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_.call(null,self__.ch,val,fn1);
}));

(cljs.core.async.t_cljs$core$async45693.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta45694","meta45694",-91261908,null)], null);
}));

(cljs.core.async.t_cljs$core$async45693.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async45693.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async45693");

(cljs.core.async.t_cljs$core$async45693.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write.call(null,writer__4429__auto__,"cljs.core.async/t_cljs$core$async45693");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async45693.
 */
cljs.core.async.__GT_t_cljs$core$async45693 = (function cljs$core$async$map_LT__$___GT_t_cljs$core$async45693(f__$1,ch__$1,meta45694){
return (new cljs.core.async.t_cljs$core$async45693(f__$1,ch__$1,meta45694));
});

}

return (new cljs.core.async.t_cljs$core$async45693(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_GT_ = (function cljs$core$async$map_GT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async45699 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async45699 = (function (f,ch,meta45700){
this.f = f;
this.ch = ch;
this.meta45700 = meta45700;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async45699.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_45701,meta45700__$1){
var self__ = this;
var _45701__$1 = this;
return (new cljs.core.async.t_cljs$core$async45699(self__.f,self__.ch,meta45700__$1));
}));

(cljs.core.async.t_cljs$core$async45699.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_45701){
var self__ = this;
var _45701__$1 = this;
return self__.meta45700;
}));

(cljs.core.async.t_cljs$core$async45699.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async45699.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_.call(null,self__.ch);
}));

(cljs.core.async.t_cljs$core$async45699.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async45699.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_.call(null,self__.ch,fn1);
}));

(cljs.core.async.t_cljs$core$async45699.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async45699.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_.call(null,self__.ch,self__.f.call(null,val),fn1);
}));

(cljs.core.async.t_cljs$core$async45699.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta45700","meta45700",1906785299,null)], null);
}));

(cljs.core.async.t_cljs$core$async45699.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async45699.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async45699");

(cljs.core.async.t_cljs$core$async45699.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write.call(null,writer__4429__auto__,"cljs.core.async/t_cljs$core$async45699");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async45699.
 */
cljs.core.async.__GT_t_cljs$core$async45699 = (function cljs$core$async$map_GT__$___GT_t_cljs$core$async45699(f__$1,ch__$1,meta45700){
return (new cljs.core.async.t_cljs$core$async45699(f__$1,ch__$1,meta45700));
});

}

return (new cljs.core.async.t_cljs$core$async45699(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_GT_ = (function cljs$core$async$filter_GT_(p,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async45702 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async45702 = (function (p,ch,meta45703){
this.p = p;
this.ch = ch;
this.meta45703 = meta45703;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async45702.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_45704,meta45703__$1){
var self__ = this;
var _45704__$1 = this;
return (new cljs.core.async.t_cljs$core$async45702(self__.p,self__.ch,meta45703__$1));
}));

(cljs.core.async.t_cljs$core$async45702.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_45704){
var self__ = this;
var _45704__$1 = this;
return self__.meta45703;
}));

(cljs.core.async.t_cljs$core$async45702.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async45702.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_.call(null,self__.ch);
}));

(cljs.core.async.t_cljs$core$async45702.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_.call(null,self__.ch);
}));

(cljs.core.async.t_cljs$core$async45702.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async45702.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_.call(null,self__.ch,fn1);
}));

(cljs.core.async.t_cljs$core$async45702.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async45702.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_(self__.p.call(null,val))){
return cljs.core.async.impl.protocols.put_BANG_.call(null,self__.ch,val,fn1);
} else {
return cljs.core.async.impl.channels.box.call(null,cljs.core.not.call(null,cljs.core.async.impl.protocols.closed_QMARK_.call(null,self__.ch)));
}
}));

(cljs.core.async.t_cljs$core$async45702.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"p","p",1791580836,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta45703","meta45703",-23420670,null)], null);
}));

(cljs.core.async.t_cljs$core$async45702.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async45702.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async45702");

(cljs.core.async.t_cljs$core$async45702.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write.call(null,writer__4429__auto__,"cljs.core.async/t_cljs$core$async45702");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async45702.
 */
cljs.core.async.__GT_t_cljs$core$async45702 = (function cljs$core$async$filter_GT__$___GT_t_cljs$core$async45702(p__$1,ch__$1,meta45703){
return (new cljs.core.async.t_cljs$core$async45702(p__$1,ch__$1,meta45703));
});

}

return (new cljs.core.async.t_cljs$core$async45702(p,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_GT_ = (function cljs$core$async$remove_GT_(p,ch){
return cljs.core.async.filter_GT_.call(null,cljs.core.complement.call(null,p),ch);
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_LT_ = (function cljs$core$async$filter_LT_(var_args){
var G__45706 = arguments.length;
switch (G__45706) {
case 2:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.filter_LT_.call(null,p,ch,null);
}));

(cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__27715__auto___45746 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_45727){
var state_val_45728 = (state_45727[(1)]);
if((state_val_45728 === (7))){
var inst_45723 = (state_45727[(2)]);
var state_45727__$1 = state_45727;
var statearr_45729_45747 = state_45727__$1;
(statearr_45729_45747[(2)] = inst_45723);

(statearr_45729_45747[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45728 === (1))){
var state_45727__$1 = state_45727;
var statearr_45730_45748 = state_45727__$1;
(statearr_45730_45748[(2)] = null);

(statearr_45730_45748[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45728 === (4))){
var inst_45709 = (state_45727[(7)]);
var inst_45709__$1 = (state_45727[(2)]);
var inst_45710 = (inst_45709__$1 == null);
var state_45727__$1 = (function (){var statearr_45731 = state_45727;
(statearr_45731[(7)] = inst_45709__$1);

return statearr_45731;
})();
if(cljs.core.truth_(inst_45710)){
var statearr_45732_45749 = state_45727__$1;
(statearr_45732_45749[(1)] = (5));

} else {
var statearr_45733_45750 = state_45727__$1;
(statearr_45733_45750[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45728 === (6))){
var inst_45709 = (state_45727[(7)]);
var inst_45714 = p.call(null,inst_45709);
var state_45727__$1 = state_45727;
if(cljs.core.truth_(inst_45714)){
var statearr_45734_45751 = state_45727__$1;
(statearr_45734_45751[(1)] = (8));

} else {
var statearr_45735_45752 = state_45727__$1;
(statearr_45735_45752[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45728 === (3))){
var inst_45725 = (state_45727[(2)]);
var state_45727__$1 = state_45727;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_45727__$1,inst_45725);
} else {
if((state_val_45728 === (2))){
var state_45727__$1 = state_45727;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_45727__$1,(4),ch);
} else {
if((state_val_45728 === (11))){
var inst_45717 = (state_45727[(2)]);
var state_45727__$1 = state_45727;
var statearr_45736_45753 = state_45727__$1;
(statearr_45736_45753[(2)] = inst_45717);

(statearr_45736_45753[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45728 === (9))){
var state_45727__$1 = state_45727;
var statearr_45737_45754 = state_45727__$1;
(statearr_45737_45754[(2)] = null);

(statearr_45737_45754[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45728 === (5))){
var inst_45712 = cljs.core.async.close_BANG_.call(null,out);
var state_45727__$1 = state_45727;
var statearr_45738_45755 = state_45727__$1;
(statearr_45738_45755[(2)] = inst_45712);

(statearr_45738_45755[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45728 === (10))){
var inst_45720 = (state_45727[(2)]);
var state_45727__$1 = (function (){var statearr_45739 = state_45727;
(statearr_45739[(8)] = inst_45720);

return statearr_45739;
})();
var statearr_45740_45756 = state_45727__$1;
(statearr_45740_45756[(2)] = null);

(statearr_45740_45756[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45728 === (8))){
var inst_45709 = (state_45727[(7)]);
var state_45727__$1 = state_45727;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_45727__$1,(11),out,inst_45709);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_45741 = [null,null,null,null,null,null,null,null,null];
(statearr_45741[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_45741[(1)] = (1));

return statearr_45741;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_45727){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_45727);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e45742){if((e45742 instanceof Object)){
var ex__27528__auto__ = e45742;
var statearr_45743_45757 = state_45727;
(statearr_45743_45757[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_45727);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e45742;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__45758 = state_45727;
state_45727 = G__45758;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_45727){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_45727);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_45744 = f__27716__auto__.call(null);
(statearr_45744[(6)] = c__27715__auto___45746);

return statearr_45744;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


return out;
}));

(cljs.core.async.filter_LT_.cljs$lang$maxFixedArity = 3);

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_LT_ = (function cljs$core$async$remove_LT_(var_args){
var G__45760 = arguments.length;
switch (G__45760) {
case 2:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.remove_LT_.call(null,p,ch,null);
}));

(cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
return cljs.core.async.filter_LT_.call(null,cljs.core.complement.call(null,p),ch,buf_or_n);
}));

(cljs.core.async.remove_LT_.cljs$lang$maxFixedArity = 3);

cljs.core.async.mapcat_STAR_ = (function cljs$core$async$mapcat_STAR_(f,in$,out){
var c__27715__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_45823){
var state_val_45824 = (state_45823[(1)]);
if((state_val_45824 === (7))){
var inst_45819 = (state_45823[(2)]);
var state_45823__$1 = state_45823;
var statearr_45825_45863 = state_45823__$1;
(statearr_45825_45863[(2)] = inst_45819);

(statearr_45825_45863[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (20))){
var inst_45789 = (state_45823[(7)]);
var inst_45800 = (state_45823[(2)]);
var inst_45801 = cljs.core.next.call(null,inst_45789);
var inst_45775 = inst_45801;
var inst_45776 = null;
var inst_45777 = (0);
var inst_45778 = (0);
var state_45823__$1 = (function (){var statearr_45826 = state_45823;
(statearr_45826[(8)] = inst_45776);

(statearr_45826[(9)] = inst_45775);

(statearr_45826[(10)] = inst_45778);

(statearr_45826[(11)] = inst_45800);

(statearr_45826[(12)] = inst_45777);

return statearr_45826;
})();
var statearr_45827_45864 = state_45823__$1;
(statearr_45827_45864[(2)] = null);

(statearr_45827_45864[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (1))){
var state_45823__$1 = state_45823;
var statearr_45828_45865 = state_45823__$1;
(statearr_45828_45865[(2)] = null);

(statearr_45828_45865[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (4))){
var inst_45764 = (state_45823[(13)]);
var inst_45764__$1 = (state_45823[(2)]);
var inst_45765 = (inst_45764__$1 == null);
var state_45823__$1 = (function (){var statearr_45829 = state_45823;
(statearr_45829[(13)] = inst_45764__$1);

return statearr_45829;
})();
if(cljs.core.truth_(inst_45765)){
var statearr_45830_45866 = state_45823__$1;
(statearr_45830_45866[(1)] = (5));

} else {
var statearr_45831_45867 = state_45823__$1;
(statearr_45831_45867[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (15))){
var state_45823__$1 = state_45823;
var statearr_45835_45868 = state_45823__$1;
(statearr_45835_45868[(2)] = null);

(statearr_45835_45868[(1)] = (16));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (21))){
var state_45823__$1 = state_45823;
var statearr_45836_45869 = state_45823__$1;
(statearr_45836_45869[(2)] = null);

(statearr_45836_45869[(1)] = (23));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (13))){
var inst_45776 = (state_45823[(8)]);
var inst_45775 = (state_45823[(9)]);
var inst_45778 = (state_45823[(10)]);
var inst_45777 = (state_45823[(12)]);
var inst_45785 = (state_45823[(2)]);
var inst_45786 = (inst_45778 + (1));
var tmp45832 = inst_45776;
var tmp45833 = inst_45775;
var tmp45834 = inst_45777;
var inst_45775__$1 = tmp45833;
var inst_45776__$1 = tmp45832;
var inst_45777__$1 = tmp45834;
var inst_45778__$1 = inst_45786;
var state_45823__$1 = (function (){var statearr_45837 = state_45823;
(statearr_45837[(8)] = inst_45776__$1);

(statearr_45837[(9)] = inst_45775__$1);

(statearr_45837[(10)] = inst_45778__$1);

(statearr_45837[(14)] = inst_45785);

(statearr_45837[(12)] = inst_45777__$1);

return statearr_45837;
})();
var statearr_45838_45870 = state_45823__$1;
(statearr_45838_45870[(2)] = null);

(statearr_45838_45870[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (22))){
var state_45823__$1 = state_45823;
var statearr_45839_45871 = state_45823__$1;
(statearr_45839_45871[(2)] = null);

(statearr_45839_45871[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (6))){
var inst_45764 = (state_45823[(13)]);
var inst_45773 = f.call(null,inst_45764);
var inst_45774 = cljs.core.seq.call(null,inst_45773);
var inst_45775 = inst_45774;
var inst_45776 = null;
var inst_45777 = (0);
var inst_45778 = (0);
var state_45823__$1 = (function (){var statearr_45840 = state_45823;
(statearr_45840[(8)] = inst_45776);

(statearr_45840[(9)] = inst_45775);

(statearr_45840[(10)] = inst_45778);

(statearr_45840[(12)] = inst_45777);

return statearr_45840;
})();
var statearr_45841_45872 = state_45823__$1;
(statearr_45841_45872[(2)] = null);

(statearr_45841_45872[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (17))){
var inst_45789 = (state_45823[(7)]);
var inst_45793 = cljs.core.chunk_first.call(null,inst_45789);
var inst_45794 = cljs.core.chunk_rest.call(null,inst_45789);
var inst_45795 = cljs.core.count.call(null,inst_45793);
var inst_45775 = inst_45794;
var inst_45776 = inst_45793;
var inst_45777 = inst_45795;
var inst_45778 = (0);
var state_45823__$1 = (function (){var statearr_45842 = state_45823;
(statearr_45842[(8)] = inst_45776);

(statearr_45842[(9)] = inst_45775);

(statearr_45842[(10)] = inst_45778);

(statearr_45842[(12)] = inst_45777);

return statearr_45842;
})();
var statearr_45843_45873 = state_45823__$1;
(statearr_45843_45873[(2)] = null);

(statearr_45843_45873[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (3))){
var inst_45821 = (state_45823[(2)]);
var state_45823__$1 = state_45823;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_45823__$1,inst_45821);
} else {
if((state_val_45824 === (12))){
var inst_45809 = (state_45823[(2)]);
var state_45823__$1 = state_45823;
var statearr_45844_45874 = state_45823__$1;
(statearr_45844_45874[(2)] = inst_45809);

(statearr_45844_45874[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (2))){
var state_45823__$1 = state_45823;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_45823__$1,(4),in$);
} else {
if((state_val_45824 === (23))){
var inst_45817 = (state_45823[(2)]);
var state_45823__$1 = state_45823;
var statearr_45845_45875 = state_45823__$1;
(statearr_45845_45875[(2)] = inst_45817);

(statearr_45845_45875[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (19))){
var inst_45804 = (state_45823[(2)]);
var state_45823__$1 = state_45823;
var statearr_45846_45876 = state_45823__$1;
(statearr_45846_45876[(2)] = inst_45804);

(statearr_45846_45876[(1)] = (16));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (11))){
var inst_45789 = (state_45823[(7)]);
var inst_45775 = (state_45823[(9)]);
var inst_45789__$1 = cljs.core.seq.call(null,inst_45775);
var state_45823__$1 = (function (){var statearr_45847 = state_45823;
(statearr_45847[(7)] = inst_45789__$1);

return statearr_45847;
})();
if(inst_45789__$1){
var statearr_45848_45877 = state_45823__$1;
(statearr_45848_45877[(1)] = (14));

} else {
var statearr_45849_45878 = state_45823__$1;
(statearr_45849_45878[(1)] = (15));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (9))){
var inst_45811 = (state_45823[(2)]);
var inst_45812 = cljs.core.async.impl.protocols.closed_QMARK_.call(null,out);
var state_45823__$1 = (function (){var statearr_45850 = state_45823;
(statearr_45850[(15)] = inst_45811);

return statearr_45850;
})();
if(cljs.core.truth_(inst_45812)){
var statearr_45851_45879 = state_45823__$1;
(statearr_45851_45879[(1)] = (21));

} else {
var statearr_45852_45880 = state_45823__$1;
(statearr_45852_45880[(1)] = (22));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (5))){
var inst_45767 = cljs.core.async.close_BANG_.call(null,out);
var state_45823__$1 = state_45823;
var statearr_45853_45881 = state_45823__$1;
(statearr_45853_45881[(2)] = inst_45767);

(statearr_45853_45881[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (14))){
var inst_45789 = (state_45823[(7)]);
var inst_45791 = cljs.core.chunked_seq_QMARK_.call(null,inst_45789);
var state_45823__$1 = state_45823;
if(inst_45791){
var statearr_45854_45882 = state_45823__$1;
(statearr_45854_45882[(1)] = (17));

} else {
var statearr_45855_45883 = state_45823__$1;
(statearr_45855_45883[(1)] = (18));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (16))){
var inst_45807 = (state_45823[(2)]);
var state_45823__$1 = state_45823;
var statearr_45856_45884 = state_45823__$1;
(statearr_45856_45884[(2)] = inst_45807);

(statearr_45856_45884[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45824 === (10))){
var inst_45776 = (state_45823[(8)]);
var inst_45778 = (state_45823[(10)]);
var inst_45783 = cljs.core._nth.call(null,inst_45776,inst_45778);
var state_45823__$1 = state_45823;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_45823__$1,(13),out,inst_45783);
} else {
if((state_val_45824 === (18))){
var inst_45789 = (state_45823[(7)]);
var inst_45798 = cljs.core.first.call(null,inst_45789);
var state_45823__$1 = state_45823;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_45823__$1,(20),out,inst_45798);
} else {
if((state_val_45824 === (8))){
var inst_45778 = (state_45823[(10)]);
var inst_45777 = (state_45823[(12)]);
var inst_45780 = (inst_45778 < inst_45777);
var inst_45781 = inst_45780;
var state_45823__$1 = state_45823;
if(cljs.core.truth_(inst_45781)){
var statearr_45857_45885 = state_45823__$1;
(statearr_45857_45885[(1)] = (10));

} else {
var statearr_45858_45886 = state_45823__$1;
(statearr_45858_45886[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$mapcat_STAR__$_state_machine__27525__auto__ = null;
var cljs$core$async$mapcat_STAR__$_state_machine__27525__auto____0 = (function (){
var statearr_45859 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_45859[(0)] = cljs$core$async$mapcat_STAR__$_state_machine__27525__auto__);

(statearr_45859[(1)] = (1));

return statearr_45859;
});
var cljs$core$async$mapcat_STAR__$_state_machine__27525__auto____1 = (function (state_45823){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_45823);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e45860){if((e45860 instanceof Object)){
var ex__27528__auto__ = e45860;
var statearr_45861_45887 = state_45823;
(statearr_45861_45887[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_45823);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e45860;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__45888 = state_45823;
state_45823 = G__45888;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$mapcat_STAR__$_state_machine__27525__auto__ = function(state_45823){
switch(arguments.length){
case 0:
return cljs$core$async$mapcat_STAR__$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$mapcat_STAR__$_state_machine__27525__auto____1.call(this,state_45823);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mapcat_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mapcat_STAR__$_state_machine__27525__auto____0;
cljs$core$async$mapcat_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mapcat_STAR__$_state_machine__27525__auto____1;
return cljs$core$async$mapcat_STAR__$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_45862 = f__27716__auto__.call(null);
(statearr_45862[(6)] = c__27715__auto__);

return statearr_45862;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));

return c__27715__auto__;
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_LT_ = (function cljs$core$async$mapcat_LT_(var_args){
var G__45890 = arguments.length;
switch (G__45890) {
case 2:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2 = (function (f,in$){
return cljs.core.async.mapcat_LT_.call(null,f,in$,null);
}));

(cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3 = (function (f,in$,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
cljs.core.async.mapcat_STAR_.call(null,f,in$,out);

return out;
}));

(cljs.core.async.mapcat_LT_.cljs$lang$maxFixedArity = 3);

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_GT_ = (function cljs$core$async$mapcat_GT_(var_args){
var G__45893 = arguments.length;
switch (G__45893) {
case 2:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2 = (function (f,out){
return cljs.core.async.mapcat_GT_.call(null,f,out,null);
}));

(cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3 = (function (f,out,buf_or_n){
var in$ = cljs.core.async.chan.call(null,buf_or_n);
cljs.core.async.mapcat_STAR_.call(null,f,in$,out);

return in$;
}));

(cljs.core.async.mapcat_GT_.cljs$lang$maxFixedArity = 3);

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.unique = (function cljs$core$async$unique(var_args){
var G__45896 = arguments.length;
switch (G__45896) {
case 1:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1 = (function (ch){
return cljs.core.async.unique.call(null,ch,null);
}));

(cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2 = (function (ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__27715__auto___45943 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_45920){
var state_val_45921 = (state_45920[(1)]);
if((state_val_45921 === (7))){
var inst_45915 = (state_45920[(2)]);
var state_45920__$1 = state_45920;
var statearr_45922_45944 = state_45920__$1;
(statearr_45922_45944[(2)] = inst_45915);

(statearr_45922_45944[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45921 === (1))){
var inst_45897 = null;
var state_45920__$1 = (function (){var statearr_45923 = state_45920;
(statearr_45923[(7)] = inst_45897);

return statearr_45923;
})();
var statearr_45924_45945 = state_45920__$1;
(statearr_45924_45945[(2)] = null);

(statearr_45924_45945[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45921 === (4))){
var inst_45900 = (state_45920[(8)]);
var inst_45900__$1 = (state_45920[(2)]);
var inst_45901 = (inst_45900__$1 == null);
var inst_45902 = cljs.core.not.call(null,inst_45901);
var state_45920__$1 = (function (){var statearr_45925 = state_45920;
(statearr_45925[(8)] = inst_45900__$1);

return statearr_45925;
})();
if(inst_45902){
var statearr_45926_45946 = state_45920__$1;
(statearr_45926_45946[(1)] = (5));

} else {
var statearr_45927_45947 = state_45920__$1;
(statearr_45927_45947[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45921 === (6))){
var state_45920__$1 = state_45920;
var statearr_45928_45948 = state_45920__$1;
(statearr_45928_45948[(2)] = null);

(statearr_45928_45948[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45921 === (3))){
var inst_45917 = (state_45920[(2)]);
var inst_45918 = cljs.core.async.close_BANG_.call(null,out);
var state_45920__$1 = (function (){var statearr_45929 = state_45920;
(statearr_45929[(9)] = inst_45917);

return statearr_45929;
})();
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_45920__$1,inst_45918);
} else {
if((state_val_45921 === (2))){
var state_45920__$1 = state_45920;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_45920__$1,(4),ch);
} else {
if((state_val_45921 === (11))){
var inst_45900 = (state_45920[(8)]);
var inst_45909 = (state_45920[(2)]);
var inst_45897 = inst_45900;
var state_45920__$1 = (function (){var statearr_45930 = state_45920;
(statearr_45930[(7)] = inst_45897);

(statearr_45930[(10)] = inst_45909);

return statearr_45930;
})();
var statearr_45931_45949 = state_45920__$1;
(statearr_45931_45949[(2)] = null);

(statearr_45931_45949[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45921 === (9))){
var inst_45900 = (state_45920[(8)]);
var state_45920__$1 = state_45920;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_45920__$1,(11),out,inst_45900);
} else {
if((state_val_45921 === (5))){
var inst_45900 = (state_45920[(8)]);
var inst_45897 = (state_45920[(7)]);
var inst_45904 = cljs.core._EQ_.call(null,inst_45900,inst_45897);
var state_45920__$1 = state_45920;
if(inst_45904){
var statearr_45933_45950 = state_45920__$1;
(statearr_45933_45950[(1)] = (8));

} else {
var statearr_45934_45951 = state_45920__$1;
(statearr_45934_45951[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45921 === (10))){
var inst_45912 = (state_45920[(2)]);
var state_45920__$1 = state_45920;
var statearr_45935_45952 = state_45920__$1;
(statearr_45935_45952[(2)] = inst_45912);

(statearr_45935_45952[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45921 === (8))){
var inst_45897 = (state_45920[(7)]);
var tmp45932 = inst_45897;
var inst_45897__$1 = tmp45932;
var state_45920__$1 = (function (){var statearr_45936 = state_45920;
(statearr_45936[(7)] = inst_45897__$1);

return statearr_45936;
})();
var statearr_45937_45953 = state_45920__$1;
(statearr_45937_45953[(2)] = null);

(statearr_45937_45953[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_45938 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_45938[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_45938[(1)] = (1));

return statearr_45938;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_45920){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_45920);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e45939){if((e45939 instanceof Object)){
var ex__27528__auto__ = e45939;
var statearr_45940_45954 = state_45920;
(statearr_45940_45954[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_45920);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e45939;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__45955 = state_45920;
state_45920 = G__45955;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_45920){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_45920);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_45941 = f__27716__auto__.call(null);
(statearr_45941[(6)] = c__27715__auto___45943);

return statearr_45941;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


return out;
}));

(cljs.core.async.unique.cljs$lang$maxFixedArity = 2);

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition = (function cljs$core$async$partition(var_args){
var G__45957 = arguments.length;
switch (G__45957) {
case 2:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.partition.call(null,n,ch,null);
}));

(cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__27715__auto___46023 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_45995){
var state_val_45996 = (state_45995[(1)]);
if((state_val_45996 === (7))){
var inst_45991 = (state_45995[(2)]);
var state_45995__$1 = state_45995;
var statearr_45997_46024 = state_45995__$1;
(statearr_45997_46024[(2)] = inst_45991);

(statearr_45997_46024[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45996 === (1))){
var inst_45958 = (new Array(n));
var inst_45959 = inst_45958;
var inst_45960 = (0);
var state_45995__$1 = (function (){var statearr_45998 = state_45995;
(statearr_45998[(7)] = inst_45960);

(statearr_45998[(8)] = inst_45959);

return statearr_45998;
})();
var statearr_45999_46025 = state_45995__$1;
(statearr_45999_46025[(2)] = null);

(statearr_45999_46025[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45996 === (4))){
var inst_45963 = (state_45995[(9)]);
var inst_45963__$1 = (state_45995[(2)]);
var inst_45964 = (inst_45963__$1 == null);
var inst_45965 = cljs.core.not.call(null,inst_45964);
var state_45995__$1 = (function (){var statearr_46000 = state_45995;
(statearr_46000[(9)] = inst_45963__$1);

return statearr_46000;
})();
if(inst_45965){
var statearr_46001_46026 = state_45995__$1;
(statearr_46001_46026[(1)] = (5));

} else {
var statearr_46002_46027 = state_45995__$1;
(statearr_46002_46027[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45996 === (15))){
var inst_45985 = (state_45995[(2)]);
var state_45995__$1 = state_45995;
var statearr_46003_46028 = state_45995__$1;
(statearr_46003_46028[(2)] = inst_45985);

(statearr_46003_46028[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45996 === (13))){
var state_45995__$1 = state_45995;
var statearr_46004_46029 = state_45995__$1;
(statearr_46004_46029[(2)] = null);

(statearr_46004_46029[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45996 === (6))){
var inst_45960 = (state_45995[(7)]);
var inst_45981 = (inst_45960 > (0));
var state_45995__$1 = state_45995;
if(cljs.core.truth_(inst_45981)){
var statearr_46005_46030 = state_45995__$1;
(statearr_46005_46030[(1)] = (12));

} else {
var statearr_46006_46031 = state_45995__$1;
(statearr_46006_46031[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45996 === (3))){
var inst_45993 = (state_45995[(2)]);
var state_45995__$1 = state_45995;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_45995__$1,inst_45993);
} else {
if((state_val_45996 === (12))){
var inst_45959 = (state_45995[(8)]);
var inst_45983 = cljs.core.vec.call(null,inst_45959);
var state_45995__$1 = state_45995;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_45995__$1,(15),out,inst_45983);
} else {
if((state_val_45996 === (2))){
var state_45995__$1 = state_45995;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_45995__$1,(4),ch);
} else {
if((state_val_45996 === (11))){
var inst_45975 = (state_45995[(2)]);
var inst_45976 = (new Array(n));
var inst_45959 = inst_45976;
var inst_45960 = (0);
var state_45995__$1 = (function (){var statearr_46007 = state_45995;
(statearr_46007[(7)] = inst_45960);

(statearr_46007[(10)] = inst_45975);

(statearr_46007[(8)] = inst_45959);

return statearr_46007;
})();
var statearr_46008_46032 = state_45995__$1;
(statearr_46008_46032[(2)] = null);

(statearr_46008_46032[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45996 === (9))){
var inst_45959 = (state_45995[(8)]);
var inst_45973 = cljs.core.vec.call(null,inst_45959);
var state_45995__$1 = state_45995;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_45995__$1,(11),out,inst_45973);
} else {
if((state_val_45996 === (5))){
var inst_45963 = (state_45995[(9)]);
var inst_45960 = (state_45995[(7)]);
var inst_45968 = (state_45995[(11)]);
var inst_45959 = (state_45995[(8)]);
var inst_45967 = (inst_45959[inst_45960] = inst_45963);
var inst_45968__$1 = (inst_45960 + (1));
var inst_45969 = (inst_45968__$1 < n);
var state_45995__$1 = (function (){var statearr_46009 = state_45995;
(statearr_46009[(12)] = inst_45967);

(statearr_46009[(11)] = inst_45968__$1);

return statearr_46009;
})();
if(cljs.core.truth_(inst_45969)){
var statearr_46010_46033 = state_45995__$1;
(statearr_46010_46033[(1)] = (8));

} else {
var statearr_46011_46034 = state_45995__$1;
(statearr_46011_46034[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45996 === (14))){
var inst_45988 = (state_45995[(2)]);
var inst_45989 = cljs.core.async.close_BANG_.call(null,out);
var state_45995__$1 = (function (){var statearr_46013 = state_45995;
(statearr_46013[(13)] = inst_45988);

return statearr_46013;
})();
var statearr_46014_46035 = state_45995__$1;
(statearr_46014_46035[(2)] = inst_45989);

(statearr_46014_46035[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45996 === (10))){
var inst_45979 = (state_45995[(2)]);
var state_45995__$1 = state_45995;
var statearr_46015_46036 = state_45995__$1;
(statearr_46015_46036[(2)] = inst_45979);

(statearr_46015_46036[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_45996 === (8))){
var inst_45968 = (state_45995[(11)]);
var inst_45959 = (state_45995[(8)]);
var tmp46012 = inst_45959;
var inst_45959__$1 = tmp46012;
var inst_45960 = inst_45968;
var state_45995__$1 = (function (){var statearr_46016 = state_45995;
(statearr_46016[(7)] = inst_45960);

(statearr_46016[(8)] = inst_45959__$1);

return statearr_46016;
})();
var statearr_46017_46037 = state_45995__$1;
(statearr_46017_46037[(2)] = null);

(statearr_46017_46037[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_46018 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_46018[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_46018[(1)] = (1));

return statearr_46018;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_45995){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_45995);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e46019){if((e46019 instanceof Object)){
var ex__27528__auto__ = e46019;
var statearr_46020_46038 = state_45995;
(statearr_46020_46038[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_45995);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e46019;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__46039 = state_45995;
state_45995 = G__46039;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_45995){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_45995);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_46021 = f__27716__auto__.call(null);
(statearr_46021[(6)] = c__27715__auto___46023);

return statearr_46021;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


return out;
}));

(cljs.core.async.partition.cljs$lang$maxFixedArity = 3);

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition_by = (function cljs$core$async$partition_by(var_args){
var G__46041 = arguments.length;
switch (G__46041) {
case 2:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2 = (function (f,ch){
return cljs.core.async.partition_by.call(null,f,ch,null);
}));

(cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3 = (function (f,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__27715__auto___46111 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_46083){
var state_val_46084 = (state_46083[(1)]);
if((state_val_46084 === (7))){
var inst_46079 = (state_46083[(2)]);
var state_46083__$1 = state_46083;
var statearr_46085_46112 = state_46083__$1;
(statearr_46085_46112[(2)] = inst_46079);

(statearr_46085_46112[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_46084 === (1))){
var inst_46042 = [];
var inst_46043 = inst_46042;
var inst_46044 = new cljs.core.Keyword("cljs.core.async","nothing","cljs.core.async/nothing",-69252123);
var state_46083__$1 = (function (){var statearr_46086 = state_46083;
(statearr_46086[(7)] = inst_46043);

(statearr_46086[(8)] = inst_46044);

return statearr_46086;
})();
var statearr_46087_46113 = state_46083__$1;
(statearr_46087_46113[(2)] = null);

(statearr_46087_46113[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_46084 === (4))){
var inst_46047 = (state_46083[(9)]);
var inst_46047__$1 = (state_46083[(2)]);
var inst_46048 = (inst_46047__$1 == null);
var inst_46049 = cljs.core.not.call(null,inst_46048);
var state_46083__$1 = (function (){var statearr_46088 = state_46083;
(statearr_46088[(9)] = inst_46047__$1);

return statearr_46088;
})();
if(inst_46049){
var statearr_46089_46114 = state_46083__$1;
(statearr_46089_46114[(1)] = (5));

} else {
var statearr_46090_46115 = state_46083__$1;
(statearr_46090_46115[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_46084 === (15))){
var inst_46073 = (state_46083[(2)]);
var state_46083__$1 = state_46083;
var statearr_46091_46116 = state_46083__$1;
(statearr_46091_46116[(2)] = inst_46073);

(statearr_46091_46116[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_46084 === (13))){
var state_46083__$1 = state_46083;
var statearr_46092_46117 = state_46083__$1;
(statearr_46092_46117[(2)] = null);

(statearr_46092_46117[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_46084 === (6))){
var inst_46043 = (state_46083[(7)]);
var inst_46068 = inst_46043.length;
var inst_46069 = (inst_46068 > (0));
var state_46083__$1 = state_46083;
if(cljs.core.truth_(inst_46069)){
var statearr_46093_46118 = state_46083__$1;
(statearr_46093_46118[(1)] = (12));

} else {
var statearr_46094_46119 = state_46083__$1;
(statearr_46094_46119[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_46084 === (3))){
var inst_46081 = (state_46083[(2)]);
var state_46083__$1 = state_46083;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_46083__$1,inst_46081);
} else {
if((state_val_46084 === (12))){
var inst_46043 = (state_46083[(7)]);
var inst_46071 = cljs.core.vec.call(null,inst_46043);
var state_46083__$1 = state_46083;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_46083__$1,(15),out,inst_46071);
} else {
if((state_val_46084 === (2))){
var state_46083__$1 = state_46083;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_46083__$1,(4),ch);
} else {
if((state_val_46084 === (11))){
var inst_46051 = (state_46083[(10)]);
var inst_46047 = (state_46083[(9)]);
var inst_46061 = (state_46083[(2)]);
var inst_46062 = [];
var inst_46063 = inst_46062.push(inst_46047);
var inst_46043 = inst_46062;
var inst_46044 = inst_46051;
var state_46083__$1 = (function (){var statearr_46095 = state_46083;
(statearr_46095[(7)] = inst_46043);

(statearr_46095[(8)] = inst_46044);

(statearr_46095[(11)] = inst_46061);

(statearr_46095[(12)] = inst_46063);

return statearr_46095;
})();
var statearr_46096_46120 = state_46083__$1;
(statearr_46096_46120[(2)] = null);

(statearr_46096_46120[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_46084 === (9))){
var inst_46043 = (state_46083[(7)]);
var inst_46059 = cljs.core.vec.call(null,inst_46043);
var state_46083__$1 = state_46083;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_46083__$1,(11),out,inst_46059);
} else {
if((state_val_46084 === (5))){
var inst_46051 = (state_46083[(10)]);
var inst_46047 = (state_46083[(9)]);
var inst_46044 = (state_46083[(8)]);
var inst_46051__$1 = f.call(null,inst_46047);
var inst_46052 = cljs.core._EQ_.call(null,inst_46051__$1,inst_46044);
var inst_46053 = cljs.core.keyword_identical_QMARK_.call(null,inst_46044,new cljs.core.Keyword("cljs.core.async","nothing","cljs.core.async/nothing",-69252123));
var inst_46054 = ((inst_46052) || (inst_46053));
var state_46083__$1 = (function (){var statearr_46097 = state_46083;
(statearr_46097[(10)] = inst_46051__$1);

return statearr_46097;
})();
if(cljs.core.truth_(inst_46054)){
var statearr_46098_46121 = state_46083__$1;
(statearr_46098_46121[(1)] = (8));

} else {
var statearr_46099_46122 = state_46083__$1;
(statearr_46099_46122[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_46084 === (14))){
var inst_46076 = (state_46083[(2)]);
var inst_46077 = cljs.core.async.close_BANG_.call(null,out);
var state_46083__$1 = (function (){var statearr_46101 = state_46083;
(statearr_46101[(13)] = inst_46076);

return statearr_46101;
})();
var statearr_46102_46123 = state_46083__$1;
(statearr_46102_46123[(2)] = inst_46077);

(statearr_46102_46123[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_46084 === (10))){
var inst_46066 = (state_46083[(2)]);
var state_46083__$1 = state_46083;
var statearr_46103_46124 = state_46083__$1;
(statearr_46103_46124[(2)] = inst_46066);

(statearr_46103_46124[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_46084 === (8))){
var inst_46051 = (state_46083[(10)]);
var inst_46047 = (state_46083[(9)]);
var inst_46043 = (state_46083[(7)]);
var inst_46056 = inst_46043.push(inst_46047);
var tmp46100 = inst_46043;
var inst_46043__$1 = tmp46100;
var inst_46044 = inst_46051;
var state_46083__$1 = (function (){var statearr_46104 = state_46083;
(statearr_46104[(7)] = inst_46043__$1);

(statearr_46104[(14)] = inst_46056);

(statearr_46104[(8)] = inst_46044);

return statearr_46104;
})();
var statearr_46105_46125 = state_46083__$1;
(statearr_46105_46125[(2)] = null);

(statearr_46105_46125[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_46106 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_46106[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_46106[(1)] = (1));

return statearr_46106;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_46083){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__.call(null,state_46083);
if(cljs.core.keyword_identical_QMARK_.call(null,result__27527__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e46107){if((e46107 instanceof Object)){
var ex__27528__auto__ = e46107;
var statearr_46108_46126 = state_46083;
(statearr_46108_46126[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_46083);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e46107;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__27526__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__46127 = state_46083;
state_46083 = G__46127;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_46083){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_46083);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_46109 = f__27716__auto__.call(null);
(statearr_46109[(6)] = c__27715__auto___46111);

return statearr_46109;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__27717__auto__);
}));


return out;
}));

(cljs.core.async.partition_by.cljs$lang$maxFixedArity = 3);


//# sourceMappingURL=async.js.map
