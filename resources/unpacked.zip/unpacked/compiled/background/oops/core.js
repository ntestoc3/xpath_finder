// Compiled by ClojureScript 1.10.597 {}
goog.provide('oops.core');
goog.require('cljs.core');
goog.require('cljs.spec.alpha');
goog.require('goog.object');
goog.require('oops.sdefs');
goog.require('oops.state');
goog.require('oops.config');
goog.require('oops.messages');
goog.require('oops.helpers');
goog.require('oops.schema');
oops.core.report_error_dynamically = (function oops$core$report_error_dynamically(msg,data){
if(oops.state.was_error_reported_QMARK_.call(null)){
return null;
} else {
oops.state.mark_error_reported_BANG_.call(null);

var G__47893 = oops.config.get_error_reporting.call(null);
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"throw","throw",-1044625833),G__47893)){
throw oops.state.prepare_error_from_call_site.call(null,msg,oops.helpers.wrap_data_in_enveloper_if_possible.call(null,oops.config.use_envelope_QMARK_.call(null),data));
} else {
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"console","console",1228072057),G__47893)){
return oops.state.get_console_reporter.call(null).call(null,(console["error"]),msg,oops.helpers.wrap_data_in_enveloper_if_possible.call(null,oops.config.use_envelope_QMARK_.call(null),data));
} else {
if(cljs.core._EQ_.call(null,false,G__47893)){
return null;
} else {
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__47893)].join('')));

}
}
}
}
});
oops.core.report_warning_dynamically = (function oops$core$report_warning_dynamically(msg,data){
var G__47894 = oops.config.get_warning_reporting.call(null);
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"throw","throw",-1044625833),G__47894)){
throw oops.state.prepare_error_from_call_site.call(null,msg,oops.helpers.wrap_data_in_enveloper_if_possible.call(null,oops.config.use_envelope_QMARK_.call(null),data));
} else {
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"console","console",1228072057),G__47894)){
return oops.state.get_console_reporter.call(null).call(null,(console["warn"]),msg,oops.helpers.wrap_data_in_enveloper_if_possible.call(null,oops.config.use_envelope_QMARK_.call(null),data));
} else {
if(cljs.core._EQ_.call(null,false,G__47894)){
return null;
} else {
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__47894)].join('')));

}
}
}
});
oops.core.report_if_needed_dynamically = (function oops$core$report_if_needed_dynamically(var_args){
var args__4795__auto__ = [];
var len__4789__auto___47902 = arguments.length;
var i__4790__auto___47903 = (0);
while(true){
if((i__4790__auto___47903 < len__4789__auto___47902)){
args__4795__auto__.push((arguments[i__4790__auto___47903]));

var G__47904 = (i__4790__auto___47903 + (1));
i__4790__auto___47903 = G__47904;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((1) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((1)),(0),null)):null);
return oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4796__auto__);
});

(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic = (function (msg_id,p__47897){
var vec__47898 = p__47897;
var info = cljs.core.nth.call(null,vec__47898,(0),null);

if(cljs.core.contains_QMARK_.call(null,oops.config.get_suppress_reporting.call(null),msg_id)){
} else {
var G__47901_47905 = oops.config.get_config_key.call(null,msg_id);
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"warn","warn",-436710552),G__47901_47905)){
oops.core.report_warning_dynamically.call(null,oops.messages.runtime_message.call(null,msg_id,info),info);
} else {
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"error","error",-978969032),G__47901_47905)){
oops.core.report_error_dynamically.call(null,oops.messages.runtime_message.call(null,msg_id,info),info);
} else {
if(cljs.core._EQ_.call(null,false,G__47901_47905)){
} else {
if(cljs.core._EQ_.call(null,null,G__47901_47905)){
} else {
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__47901_47905)].join('')));

}
}
}
}
}

return null;
}));

(oops.core.report_if_needed_dynamically.cljs$lang$maxFixedArity = (1));

/** @this {Function} */
(oops.core.report_if_needed_dynamically.cljs$lang$applyTo = (function (seq47895){
var G__47896 = cljs.core.first.call(null,seq47895);
var seq47895__$1 = cljs.core.next.call(null,seq47895);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__47896,seq47895__$1);
}));

oops.core.validate_object_access_dynamically = (function oops$core$validate_object_access_dynamically(obj,mode,key,push_QMARK_,check_key_read_QMARK_,check_key_write_QMARK_){
if(((((cljs.core._EQ_.call(null,mode,(0))) && ((void 0 === obj))))?((cljs.core.contains_QMARK_.call(null,oops.config.get_suppress_reporting.call(null),new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301)))?true:(function (){
oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"path","path",-188191168),oops.state.get_key_path_str.call(null),new cljs.core.Keyword(null,"flavor","flavor",-1331636636),"undefined",new cljs.core.Keyword(null,"obj","obj",981763962),oops.state.get_target_object.call(null)], null));

return false;
})()
):((((cljs.core._EQ_.call(null,mode,(0))) && ((obj == null))))?((cljs.core.contains_QMARK_.call(null,oops.config.get_suppress_reporting.call(null),new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301)))?true:(function (){
oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"path","path",-188191168),oops.state.get_key_path_str.call(null),new cljs.core.Keyword(null,"flavor","flavor",-1331636636),"nil",new cljs.core.Keyword(null,"obj","obj",981763962),oops.state.get_target_object.call(null)], null));

return false;
})()
):(cljs.core.truth_(goog.isBoolean(obj))?((cljs.core.contains_QMARK_.call(null,oops.config.get_suppress_reporting.call(null),new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301)))?true:(function (){
oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"path","path",-188191168),oops.state.get_key_path_str.call(null),new cljs.core.Keyword(null,"flavor","flavor",-1331636636),"boolean",new cljs.core.Keyword(null,"obj","obj",981763962),oops.state.get_target_object.call(null)], null));

return false;
})()
):(cljs.core.truth_(goog.isNumber(obj))?((cljs.core.contains_QMARK_.call(null,oops.config.get_suppress_reporting.call(null),new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301)))?true:(function (){
oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"path","path",-188191168),oops.state.get_key_path_str.call(null),new cljs.core.Keyword(null,"flavor","flavor",-1331636636),"number",new cljs.core.Keyword(null,"obj","obj",981763962),oops.state.get_target_object.call(null)], null));

return false;
})()
):(cljs.core.truth_(goog.isString(obj))?((cljs.core.contains_QMARK_.call(null,oops.config.get_suppress_reporting.call(null),new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301)))?true:(function (){
oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"path","path",-188191168),oops.state.get_key_path_str.call(null),new cljs.core.Keyword(null,"flavor","flavor",-1331636636),"string",new cljs.core.Keyword(null,"obj","obj",981763962),oops.state.get_target_object.call(null)], null));

return false;
})()
):((cljs.core.not.call(null,goog.isObject(obj)))?((cljs.core.contains_QMARK_.call(null,oops.config.get_suppress_reporting.call(null),new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301)))?true:(function (){
oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"path","path",-188191168),oops.state.get_key_path_str.call(null),new cljs.core.Keyword(null,"flavor","flavor",-1331636636),"non-object",new cljs.core.Keyword(null,"obj","obj",981763962),oops.state.get_target_object.call(null)], null));

return false;
})()
):(cljs.core.truth_(goog.isDateLike(obj))?((cljs.core.contains_QMARK_.call(null,oops.config.get_suppress_reporting.call(null),new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301)))?true:(function (){
oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"path","path",-188191168),oops.state.get_key_path_str.call(null),new cljs.core.Keyword(null,"flavor","flavor",-1331636636),"date-like",new cljs.core.Keyword(null,"obj","obj",981763962),oops.state.get_target_object.call(null)], null));

return true;
})()
):(cljs.core.truth_(oops.helpers.cljs_type_QMARK_.call(null,obj))?((cljs.core.contains_QMARK_.call(null,oops.config.get_suppress_reporting.call(null),new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301)))?true:(function (){
oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"path","path",-188191168),oops.state.get_key_path_str.call(null),new cljs.core.Keyword(null,"flavor","flavor",-1331636636),"cljs type",new cljs.core.Keyword(null,"obj","obj",981763962),oops.state.get_target_object.call(null)], null));

return true;
})()
):(cljs.core.truth_(oops.helpers.cljs_instance_QMARK_.call(null,obj))?((cljs.core.contains_QMARK_.call(null,oops.config.get_suppress_reporting.call(null),new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301)))?true:(function (){
oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"unexpected-object-value","unexpected-object-value",-1214439301),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"path","path",-188191168),oops.state.get_key_path_str.call(null),new cljs.core.Keyword(null,"flavor","flavor",-1331636636),"cljs instance",new cljs.core.Keyword(null,"obj","obj",981763962),oops.state.get_target_object.call(null)], null));

return true;
})()
):true
)))))))))){
if(cljs.core.truth_(push_QMARK_)){
oops.state.add_key_to_current_path_BANG_.call(null,key);

oops.state.set_last_access_modifier_BANG_.call(null,mode);
} else {
}

var and__4174__auto__ = (cljs.core.truth_(check_key_read_QMARK_)?((((cljs.core._EQ_.call(null,mode,(0))) && ((!(goog.object.containsKey(obj,key))))))?oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"missing-object-key","missing-object-key",-1300201731),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"path","path",-188191168),oops.state.get_key_path_str.call(null),new cljs.core.Keyword(null,"key","key",-1516042587),key,new cljs.core.Keyword(null,"obj","obj",981763962),oops.state.get_target_object.call(null)], null)):true):true);
if(cljs.core.truth_(and__4174__auto__)){
if(cljs.core.truth_(check_key_write_QMARK_)){
var temp__5737__auto__ = oops.helpers.get_property_descriptor.call(null,obj,key);
if((temp__5737__auto__ == null)){
if(cljs.core.truth_(oops.helpers.is_object_frozen_QMARK_.call(null,obj))){
return oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"object-is-frozen","object-is-frozen",-1391578096),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"path","path",-188191168),oops.state.get_key_path_str.call(null),new cljs.core.Keyword(null,"key","key",-1516042587),key,new cljs.core.Keyword(null,"obj","obj",981763962),oops.state.get_target_object.call(null)], null));
} else {
if(cljs.core.truth_(oops.helpers.is_object_sealed_QMARK_.call(null,obj))){
return oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"object-is-sealed","object-is-sealed",-1791813926),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"path","path",-188191168),oops.state.get_key_path_str.call(null),new cljs.core.Keyword(null,"key","key",-1516042587),key,new cljs.core.Keyword(null,"obj","obj",981763962),oops.state.get_target_object.call(null)], null));
} else {
return true;

}
}
} else {
var descriptor_47906 = temp__5737__auto__;
var temp__5737__auto____$1 = oops.helpers.determine_property_non_writable_reason.call(null,descriptor_47906);
if((temp__5737__auto____$1 == null)){
return true;
} else {
var reason_47907 = temp__5737__auto____$1;
return oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"object-key-not-writable","object-key-not-writable",206336031),new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"path","path",-188191168),oops.state.get_key_path_str.call(null),new cljs.core.Keyword(null,"key","key",-1516042587),key,new cljs.core.Keyword(null,"frozen?","frozen?",613726824),oops.helpers.is_object_frozen_QMARK_.call(null,obj),new cljs.core.Keyword(null,"reason","reason",-2070751759),reason_47907,new cljs.core.Keyword(null,"obj","obj",981763962),oops.state.get_target_object.call(null)], null));
}
}
} else {
return true;
}
} else {
return and__4174__auto__;
}
} else {
return null;
}
});
oops.core.validate_fn_call_dynamically = (function oops$core$validate_fn_call_dynamically(fn,mode){
if(((cljs.core._EQ_.call(null,mode,(1))) && ((fn == null)))){
return true;
} else {
if(cljs.core.truth_(goog.isFunction(fn))){
return true;
} else {
return oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"expected-function-value","expected-function-value",-1399123630),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"path","path",-188191168),oops.state.get_key_path_str.call(null),new cljs.core.Keyword(null,"soft?","soft?",-1339668477),cljs.core._EQ_.call(null,mode,(1)),new cljs.core.Keyword(null,"fn","fn",-1175266204),fn,new cljs.core.Keyword(null,"obj","obj",981763962),oops.state.get_target_object.call(null)], null));

}
}
});
oops.core.punch_key_dynamically_BANG_ = (function oops$core$punch_key_dynamically_BANG_(obj,key){
var child_factory_47909 = oops.config.get_child_factory.call(null);
var child_factory_47909__$1 = (function (){var G__47910 = child_factory_47909;
var G__47910__$1 = (((G__47910 instanceof cljs.core.Keyword))?G__47910.fqn:null);
switch (G__47910__$1) {
case "js-obj":
return (function (){
return ({});
});

break;
case "js-array":
return (function (){
return [];
});

break;
default:
return child_factory_47909;

}
})();

var child_obj_47908 = child_factory_47909__$1.call(null,obj,key);
if(oops.core.validate_object_access_dynamically.call(null,obj,(2),key,false,true,true)){
(obj[key] = child_obj_47908);
} else {
}

return child_obj_47908;
});
oops.core.build_path_dynamically = (function oops$core$build_path_dynamically(selector){
if(((typeof selector === 'string') || ((selector instanceof cljs.core.Keyword)))){
var selector_path_47914 = [];
oops.schema.prepare_simple_path_BANG_.call(null,selector,selector_path_47914);

return selector_path_47914;
} else {
var selector_path_47915 = [];
oops.schema.prepare_path_BANG_.call(null,selector,selector_path_47915);

return selector_path_47915;

}
});
oops.core.check_path_dynamically = (function oops$core$check_path_dynamically(path,op){
var temp__5739__auto__ = oops.schema.check_dynamic_path_BANG_.call(null,path,op);
if((temp__5739__auto__ == null)){
return null;
} else {
var issue_47916 = temp__5739__auto__;
return cljs.core.apply.call(null,oops.core.report_if_needed_dynamically,issue_47916);
}
});
oops.core.get_key_dynamically = (function oops$core$get_key_dynamically(obj,key,mode){
if(oops.core.validate_object_access_dynamically.call(null,obj,mode,key,true,true,false)){
return (obj[key]);
} else {
return null;
}
});
oops.core.set_key_dynamically = (function oops$core$set_key_dynamically(obj,key,val,mode){
if(oops.core.validate_object_access_dynamically.call(null,obj,mode,key,true,true,true)){
return (obj[key] = val);
} else {
return null;
}
});
oops.core.get_selector_dynamically = (function oops$core$get_selector_dynamically(obj,selector){
if(cljs.core.truth_((((!(cljs.spec.alpha.valid_QMARK_.call(null,new cljs.core.Keyword("oops.sdefs","obj-selector","oops.sdefs/obj-selector",655346305),selector))))?(function (){var explanation_47925 = cljs.spec.alpha.explain_data.call(null,new cljs.core.Keyword("oops.sdefs","obj-selector","oops.sdefs/obj-selector",655346305),selector);
return oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"invalid-selector","invalid-selector",1262807990),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"explanation","explanation",-1426612608),explanation_47925,new cljs.core.Keyword(null,"selector","selector",762528866),selector], null));
})():true))){
var path_47918 = (function (){var path_47917 = oops.core.build_path_dynamically.call(null,selector);
oops.core.check_path_dynamically.call(null,path_47917,(0));

return path_47917;
})();
var len_47919 = path_47918.length;
var i_47920 = (0);
var obj_47921 = obj;
while(true){
if((i_47920 < len_47919)){
var mode_47922 = (path_47918[i_47920]);
var key_47923 = (path_47918[(i_47920 + (1))]);
var next_obj_47924 = oops.core.get_key_dynamically.call(null,obj_47921,key_47923,mode_47922);
var G__47926 = mode_47922;
switch (G__47926) {
case (0):
var G__47928 = (i_47920 + (2));
var G__47929 = next_obj_47924;
i_47920 = G__47928;
obj_47921 = G__47929;
continue;

break;
case (1):
if((!((next_obj_47924 == null)))){
var G__47930 = (i_47920 + (2));
var G__47931 = next_obj_47924;
i_47920 = G__47930;
obj_47921 = G__47931;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_47924 == null)))){
var G__47932 = (i_47920 + (2));
var G__47933 = next_obj_47924;
i_47920 = G__47932;
obj_47921 = G__47933;
continue;
} else {
var G__47934 = (i_47920 + (2));
var G__47935 = oops.core.punch_key_dynamically_BANG_.call(null,obj_47921,key_47923);
i_47920 = G__47934;
obj_47921 = G__47935;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__47926)].join('')));

}
} else {
return obj_47921;
}
break;
}
} else {
return null;
}
});
oops.core.get_selector_call_info_dynamically = (function oops$core$get_selector_call_info_dynamically(obj,selector){
if(cljs.core.truth_((((!(cljs.spec.alpha.valid_QMARK_.call(null,new cljs.core.Keyword("oops.sdefs","obj-selector","oops.sdefs/obj-selector",655346305),selector))))?(function (){var explanation_47961 = cljs.spec.alpha.explain_data.call(null,new cljs.core.Keyword("oops.sdefs","obj-selector","oops.sdefs/obj-selector",655346305),selector);
return oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"invalid-selector","invalid-selector",1262807990),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"explanation","explanation",-1426612608),explanation_47961,new cljs.core.Keyword(null,"selector","selector",762528866),selector], null));
})():true))){
var path_47937 = (function (){var path_47936 = oops.core.build_path_dynamically.call(null,selector);
oops.core.check_path_dynamically.call(null,path_47936,(0));

return path_47936;
})();
var len_47938 = path_47937.length;
if((len_47938 < (4))){
return [obj,(function (){var path_47940 = path_47937;
var len_47941 = path_47940.length;
var i_47942 = (0);
var obj_47943 = obj;
while(true){
if((i_47942 < len_47941)){
var mode_47944 = (path_47940[i_47942]);
var key_47945 = (path_47940[(i_47942 + (1))]);
var next_obj_47946 = oops.core.get_key_dynamically.call(null,obj_47943,key_47945,mode_47944);
var G__47962 = mode_47944;
switch (G__47962) {
case (0):
var G__47966 = (i_47942 + (2));
var G__47967 = next_obj_47946;
i_47942 = G__47966;
obj_47943 = G__47967;
continue;

break;
case (1):
if((!((next_obj_47946 == null)))){
var G__47968 = (i_47942 + (2));
var G__47969 = next_obj_47946;
i_47942 = G__47968;
obj_47943 = G__47969;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_47946 == null)))){
var G__47970 = (i_47942 + (2));
var G__47971 = next_obj_47946;
i_47942 = G__47970;
obj_47943 = G__47971;
continue;
} else {
var G__47972 = (i_47942 + (2));
var G__47973 = oops.core.punch_key_dynamically_BANG_.call(null,obj_47943,key_47945);
i_47942 = G__47972;
obj_47943 = G__47973;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__47962)].join('')));

}
} else {
return obj_47943;
}
break;
}
})()];
} else {
var target_obj_47939 = (function (){var path_47947 = path_47937.slice((0),(len_47938 - (2)));
var len_47948 = path_47947.length;
var i_47949 = (0);
var obj_47950 = obj;
while(true){
if((i_47949 < len_47948)){
var mode_47951 = (path_47947[i_47949]);
var key_47952 = (path_47947[(i_47949 + (1))]);
var next_obj_47953 = oops.core.get_key_dynamically.call(null,obj_47950,key_47952,mode_47951);
var G__47963 = mode_47951;
switch (G__47963) {
case (0):
var G__47975 = (i_47949 + (2));
var G__47976 = next_obj_47953;
i_47949 = G__47975;
obj_47950 = G__47976;
continue;

break;
case (1):
if((!((next_obj_47953 == null)))){
var G__47977 = (i_47949 + (2));
var G__47978 = next_obj_47953;
i_47949 = G__47977;
obj_47950 = G__47978;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_47953 == null)))){
var G__47979 = (i_47949 + (2));
var G__47980 = next_obj_47953;
i_47949 = G__47979;
obj_47950 = G__47980;
continue;
} else {
var G__47981 = (i_47949 + (2));
var G__47982 = oops.core.punch_key_dynamically_BANG_.call(null,obj_47950,key_47952);
i_47949 = G__47981;
obj_47950 = G__47982;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__47963)].join('')));

}
} else {
return obj_47950;
}
break;
}
})();
return [target_obj_47939,(function (){var path_47954 = [(path_47937[(len_47938 - (2))]),(path_47937[(len_47938 - (1))])];
var len_47955 = path_47954.length;
var i_47956 = (0);
var obj_47957 = target_obj_47939;
while(true){
if((i_47956 < len_47955)){
var mode_47958 = (path_47954[i_47956]);
var key_47959 = (path_47954[(i_47956 + (1))]);
var next_obj_47960 = oops.core.get_key_dynamically.call(null,obj_47957,key_47959,mode_47958);
var G__47964 = mode_47958;
switch (G__47964) {
case (0):
var G__47984 = (i_47956 + (2));
var G__47985 = next_obj_47960;
i_47956 = G__47984;
obj_47957 = G__47985;
continue;

break;
case (1):
if((!((next_obj_47960 == null)))){
var G__47986 = (i_47956 + (2));
var G__47987 = next_obj_47960;
i_47956 = G__47986;
obj_47957 = G__47987;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_47960 == null)))){
var G__47988 = (i_47956 + (2));
var G__47989 = next_obj_47960;
i_47956 = G__47988;
obj_47957 = G__47989;
continue;
} else {
var G__47990 = (i_47956 + (2));
var G__47991 = oops.core.punch_key_dynamically_BANG_.call(null,obj_47957,key_47959);
i_47956 = G__47990;
obj_47957 = G__47991;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__47964)].join('')));

}
} else {
return obj_47957;
}
break;
}
})()];
}
} else {
return null;
}
});
oops.core.set_selector_dynamically = (function oops$core$set_selector_dynamically(obj,selector,val){
if(cljs.core.truth_((((!(cljs.spec.alpha.valid_QMARK_.call(null,new cljs.core.Keyword("oops.sdefs","obj-selector","oops.sdefs/obj-selector",655346305),selector))))?(function (){var explanation_48006 = cljs.spec.alpha.explain_data.call(null,new cljs.core.Keyword("oops.sdefs","obj-selector","oops.sdefs/obj-selector",655346305),selector);
return oops.core.report_if_needed_dynamically.call(null,new cljs.core.Keyword(null,"invalid-selector","invalid-selector",1262807990),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"explanation","explanation",-1426612608),explanation_48006,new cljs.core.Keyword(null,"selector","selector",762528866),selector], null));
})():true))){
var path_47993 = (function (){var path_47992 = oops.core.build_path_dynamically.call(null,selector);
oops.core.check_path_dynamically.call(null,path_47992,(1));

return path_47992;
})();
var len_47996 = path_47993.length;
var parent_obj_path_47997 = path_47993.slice((0),(len_47996 - (2)));
var key_47994 = (path_47993[(len_47996 - (1))]);
var mode_47995 = (path_47993[(len_47996 - (2))]);
var parent_obj_47998 = (function (){var path_47999 = parent_obj_path_47997;
var len_48000 = path_47999.length;
var i_48001 = (0);
var obj_48002 = obj;
while(true){
if((i_48001 < len_48000)){
var mode_48003 = (path_47999[i_48001]);
var key_48004 = (path_47999[(i_48001 + (1))]);
var next_obj_48005 = oops.core.get_key_dynamically.call(null,obj_48002,key_48004,mode_48003);
var G__48007 = mode_48003;
switch (G__48007) {
case (0):
var G__48009 = (i_48001 + (2));
var G__48010 = next_obj_48005;
i_48001 = G__48009;
obj_48002 = G__48010;
continue;

break;
case (1):
if((!((next_obj_48005 == null)))){
var G__48011 = (i_48001 + (2));
var G__48012 = next_obj_48005;
i_48001 = G__48011;
obj_48002 = G__48012;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_48005 == null)))){
var G__48013 = (i_48001 + (2));
var G__48014 = next_obj_48005;
i_48001 = G__48013;
obj_48002 = G__48014;
continue;
} else {
var G__48015 = (i_48001 + (2));
var G__48016 = oops.core.punch_key_dynamically_BANG_.call(null,obj_48002,key_48004);
i_48001 = G__48015;
obj_48002 = G__48016;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__48007)].join('')));

}
} else {
return obj_48002;
}
break;
}
})();
return oops.core.set_key_dynamically.call(null,parent_obj_47998,key_47994,val,mode_47995);
} else {
return null;
}
});

//# sourceMappingURL=core.js.map
