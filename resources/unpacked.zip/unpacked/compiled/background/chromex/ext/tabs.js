// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex.ext.tabs');
goog.require('cljs.core');
goog.require('chromex.core');
chromex.ext.tabs.tab_id_none_STAR_ = (function chromex$ext$tabs$tab_id_none_STAR_(config){
var result_51510 = (function (){var final_args_array_51511 = chromex.support.prepare_final_args_array.call(null,cljs.core.PersistentVector.EMPTY,"chrome.tabs.TAB_ID_NONE");
var ns_51512 = (function (){var target_obj_51515 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51518 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51519 = oops.state.prepare_state.call(null,target_obj_51515,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51519);

try{var next_obj_51516 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51515,(0),"chrome",true,true,false))?(target_obj_51515["chrome"]):null);
var next_obj_51517 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51516,(0),"tabs",true,true,false))?(next_obj_51516["tabs"]):null);
return next_obj_51517;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51518);
}})();
var missing_api_51513 = null;
if(missing_api_51513 === true){
return null;
} else {
var config__25890__auto___51524 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51524))){
var logger__25891__auto___51525 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51524);
var prefix__25892__auto___51526 = ["accessing:","chrome.tabs.TAB_ID_NONE"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51525)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51524)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51525.apply(null,prefix__25892__auto___51526.concat(final_args_array_51511));
} else {
}

var target_51514 = (function (){var target_obj_51520 = ns_51512;
var _STAR_runtime_state_STAR__orig_val__51522 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51523 = oops.state.prepare_state.call(null,target_obj_51520,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51523);

try{var next_obj_51521 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51520,(1),"TAB_ID_NONE",true,true,false))?(target_obj_51520["TAB_ID_NONE"]):null);
if((!((next_obj_51521 == null)))){
return next_obj_51521;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51522);
}})();
return target_51514;
}
})();
return result_51510;
});
chromex.ext.tabs.get_STAR_ = (function chromex$ext$tabs$get_STAR_(config,tab_id){
var callback_chan_51527 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_51529_51546 = (function (){var omit_test_51535 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51535,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51535;
}
})();
var marshalled_callback_51530_51547 = (function (cb_tab_51536){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","get","chromex.ext.tabs/get",-316093846),new cljs.core.Keyword(null,"name","name",1843675177),"get",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"tab",new cljs.core.Keyword(null,"type","type",1174270348),"tabs.Tab"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51527);
})().call(null,cb_tab_51536);
});
var result_51528_51548 = (function (){var final_args_array_51531 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_51529_51546,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51530_51547,"callback",null], null)], null),"chrome.tabs.get");
var ns_51532 = (function (){var target_obj_51537 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51540 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51541 = oops.state.prepare_state.call(null,target_obj_51537,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51541);

try{var next_obj_51538 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51537,(0),"chrome",true,true,false))?(target_obj_51537["chrome"]):null);
var next_obj_51539 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51538,(0),"tabs",true,true,false))?(next_obj_51538["tabs"]):null);
return next_obj_51539;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51540);
}})();
var missing_api_51533 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.get",ns_51532,"get");
})();
if(missing_api_51533 === true){
return null;
} else {
var config__25890__auto___51549 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51549))){
var logger__25891__auto___51550 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51549);
var prefix__25892__auto___51551 = ["calling:","chrome.tabs.get"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51550)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51549)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51550.apply(null,prefix__25892__auto___51551.concat(final_args_array_51531));
} else {
}

var target_51534 = (function (){var target_obj_51542 = ns_51532;
var _STAR_runtime_state_STAR__orig_val__51544 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51545 = oops.state.prepare_state.call(null,target_obj_51542,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51545);

try{var next_obj_51543 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51542,(1),"get",true,true,false))?(target_obj_51542["get"]):null);
if((!((next_obj_51543 == null)))){
return next_obj_51543;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51544);
}})();
return target_51534.apply(ns_51532,final_args_array_51531);
}
})();

return callback_chan_51527;
});
chromex.ext.tabs.get_current_STAR_ = (function chromex$ext$tabs$get_current_STAR_(config){
var callback_chan_51552 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_callback_51554_51569 = (function (cb_tab_51559){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","get-current","chromex.ext.tabs/get-current",1123704981),new cljs.core.Keyword(null,"name","name",1843675177),"getCurrent",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"tab",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"tabs.Tab"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51552);
})().call(null,cb_tab_51559);
});
var result_51553_51570 = (function (){var final_args_array_51555 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51554_51569,"callback",null], null)], null),"chrome.tabs.getCurrent");
var ns_51556 = (function (){var target_obj_51560 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51563 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51564 = oops.state.prepare_state.call(null,target_obj_51560,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51564);

try{var next_obj_51561 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51560,(0),"chrome",true,true,false))?(target_obj_51560["chrome"]):null);
var next_obj_51562 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51561,(0),"tabs",true,true,false))?(next_obj_51561["tabs"]):null);
return next_obj_51562;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51563);
}})();
var missing_api_51557 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.getCurrent",ns_51556,"getCurrent");
})();
if(missing_api_51557 === true){
return null;
} else {
var config__25890__auto___51571 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51571))){
var logger__25891__auto___51572 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51571);
var prefix__25892__auto___51573 = ["calling:","chrome.tabs.getCurrent"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51572)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51571)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51572.apply(null,prefix__25892__auto___51573.concat(final_args_array_51555));
} else {
}

var target_51558 = (function (){var target_obj_51565 = ns_51556;
var _STAR_runtime_state_STAR__orig_val__51567 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51568 = oops.state.prepare_state.call(null,target_obj_51565,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51568);

try{var next_obj_51566 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51565,(1),"getCurrent",true,true,false))?(target_obj_51565["getCurrent"]):null);
if((!((next_obj_51566 == null)))){
return next_obj_51566;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51567);
}})();
return target_51558.apply(ns_51556,final_args_array_51555);
}
})();

return callback_chan_51552;
});
chromex.ext.tabs.connect_STAR_ = (function chromex$ext$tabs$connect_STAR_(config,tab_id,connect_info){
var marshalled_tab_id_51575 = (function (){var omit_test_51581 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51581,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51581;
}
})();
var marshalled_connect_info_51576 = (function (){var omit_test_51582 = connect_info;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51582,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51582;
}
})();
var result_51574 = (function (){var final_args_array_51577 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_51575,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_connect_info_51576,"connect-info",true], null)], null),"chrome.tabs.connect");
var ns_51578 = (function (){var target_obj_51583 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51586 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51587 = oops.state.prepare_state.call(null,target_obj_51583,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51587);

try{var next_obj_51584 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51583,(0),"chrome",true,true,false))?(target_obj_51583["chrome"]):null);
var next_obj_51585 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51584,(0),"tabs",true,true,false))?(next_obj_51584["tabs"]):null);
return next_obj_51585;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51586);
}})();
var missing_api_51579 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.connect",ns_51578,"connect");
})();
if(missing_api_51579 === true){
return null;
} else {
var config__25890__auto___51592 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51592))){
var logger__25891__auto___51593 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51592);
var prefix__25892__auto___51594 = ["calling:","chrome.tabs.connect"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51593)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51592)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51593.apply(null,prefix__25892__auto___51594.concat(final_args_array_51577));
} else {
}

var target_51580 = (function (){var target_obj_51588 = ns_51578;
var _STAR_runtime_state_STAR__orig_val__51590 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51591 = oops.state.prepare_state.call(null,target_obj_51588,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51591);

try{var next_obj_51589 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51588,(1),"connect",true,true,false))?(target_obj_51588["connect"]):null);
if((!((next_obj_51589 == null)))){
return next_obj_51589;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51590);
}})();
return target_51580.apply(ns_51578,final_args_array_51577);
}
})();
return chromex.marshalling.from_native_chrome_port.call(null,config,result_51574);
});
chromex.ext.tabs.send_request_STAR_ = (function chromex$ext$tabs$send_request_STAR_(config,tab_id,request){
var callback_chan_51595 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_51597_51616 = (function (){var omit_test_51604 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51604,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51604;
}
})();
var marshalled_request_51598_51617 = (function (){var omit_test_51605 = request;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51605,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51605;
}
})();
var marshalled_response_callback_51599_51618 = (function (cb_response_51606){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 7, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","send-request","chromex.ext.tabs/send-request",1841664260),new cljs.core.Keyword(null,"name","name",1843675177),"sendRequest",new cljs.core.Keyword(null,"since","since",315379842),"33",new cljs.core.Keyword(null,"deprecated","deprecated",1498275348),"Please use 'runtime.sendMessage'.",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"request",new cljs.core.Keyword(null,"type","type",1174270348),"any"], null),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"response-callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"response",new cljs.core.Keyword(null,"type","type",1174270348),"any"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51595);
})().call(null,cb_response_51606);
});
var result_51596_51619 = (function (){var final_args_array_51600 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_51597_51616,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_request_51598_51617,"request",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_51599_51618,"response-callback",true], null)], null),"chrome.tabs.sendRequest");
var ns_51601 = (function (){var target_obj_51607 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51610 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51611 = oops.state.prepare_state.call(null,target_obj_51607,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51611);

try{var next_obj_51608 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51607,(0),"chrome",true,true,false))?(target_obj_51607["chrome"]):null);
var next_obj_51609 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51608,(0),"tabs",true,true,false))?(next_obj_51608["tabs"]):null);
return next_obj_51609;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51610);
}})();
var missing_api_51602 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.sendRequest",ns_51601,"sendRequest");
})();
if(missing_api_51602 === true){
return null;
} else {
var config__25890__auto___51620 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51620))){
var logger__25891__auto___51621 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51620);
var prefix__25892__auto___51622 = ["calling:","chrome.tabs.sendRequest"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51621)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51620)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51621.apply(null,prefix__25892__auto___51622.concat(final_args_array_51600));
} else {
}

var target_51603 = (function (){var target_obj_51612 = ns_51601;
var _STAR_runtime_state_STAR__orig_val__51614 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51615 = oops.state.prepare_state.call(null,target_obj_51612,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51615);

try{var next_obj_51613 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51612,(1),"sendRequest",true,true,false))?(target_obj_51612["sendRequest"]):null);
if((!((next_obj_51613 == null)))){
return next_obj_51613;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51614);
}})();
return target_51603.apply(ns_51601,final_args_array_51600);
}
})();

return callback_chan_51595;
});
chromex.ext.tabs.send_message_STAR_ = (function chromex$ext$tabs$send_message_STAR_(config,tab_id,message,options){
var callback_chan_51623 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_51625_51646 = (function (){var omit_test_51633 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51633,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51633;
}
})();
var marshalled_message_51626_51647 = (function (){var omit_test_51634 = message;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51634,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51634;
}
})();
var marshalled_options_51627_51648 = (function (){var omit_test_51635 = options;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51635,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51635;
}
})();
var marshalled_response_callback_51628_51649 = (function (cb_response_51636){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","send-message","chromex.ext.tabs/send-message",852348520),new cljs.core.Keyword(null,"name","name",1843675177),"sendMessage",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"message",new cljs.core.Keyword(null,"type","type",1174270348),"any"], null),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"options",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"since","since",315379842),"41",new cljs.core.Keyword(null,"type","type",1174270348),"object"], null),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"response-callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"response",new cljs.core.Keyword(null,"type","type",1174270348),"any"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51623);
})().call(null,cb_response_51636);
});
var result_51624_51650 = (function (){var final_args_array_51629 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_51625_51646,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_51626_51647,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_51627_51648,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_51628_51649,"response-callback",true], null)], null),"chrome.tabs.sendMessage");
var ns_51630 = (function (){var target_obj_51637 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51640 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51641 = oops.state.prepare_state.call(null,target_obj_51637,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51641);

try{var next_obj_51638 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51637,(0),"chrome",true,true,false))?(target_obj_51637["chrome"]):null);
var next_obj_51639 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51638,(0),"tabs",true,true,false))?(next_obj_51638["tabs"]):null);
return next_obj_51639;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51640);
}})();
var missing_api_51631 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.sendMessage",ns_51630,"sendMessage");
})();
if(missing_api_51631 === true){
return null;
} else {
var config__25890__auto___51651 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51651))){
var logger__25891__auto___51652 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51651);
var prefix__25892__auto___51653 = ["calling:","chrome.tabs.sendMessage"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51652)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51651)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51652.apply(null,prefix__25892__auto___51653.concat(final_args_array_51629));
} else {
}

var target_51632 = (function (){var target_obj_51642 = ns_51630;
var _STAR_runtime_state_STAR__orig_val__51644 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51645 = oops.state.prepare_state.call(null,target_obj_51642,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51645);

try{var next_obj_51643 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51642,(1),"sendMessage",true,true,false))?(target_obj_51642["sendMessage"]):null);
if((!((next_obj_51643 == null)))){
return next_obj_51643;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51644);
}})();
return target_51632.apply(ns_51630,final_args_array_51629);
}
})();

return callback_chan_51623;
});
chromex.ext.tabs.get_selected_STAR_ = (function chromex$ext$tabs$get_selected_STAR_(config,window_id){
var callback_chan_51654 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_window_id_51656_51673 = (function (){var omit_test_51662 = window_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51662,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51662;
}
})();
var marshalled_callback_51657_51674 = (function (cb_tab_51663){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 7, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","get-selected","chromex.ext.tabs/get-selected",703911016),new cljs.core.Keyword(null,"name","name",1843675177),"getSelected",new cljs.core.Keyword(null,"since","since",315379842),"33",new cljs.core.Keyword(null,"deprecated","deprecated",1498275348),"Please use 'tabs.query' {active: true}.",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"window-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"tab",new cljs.core.Keyword(null,"type","type",1174270348),"tabs.Tab"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51654);
})().call(null,cb_tab_51663);
});
var result_51655_51675 = (function (){var final_args_array_51658 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_51656_51673,"window-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51657_51674,"callback",null], null)], null),"chrome.tabs.getSelected");
var ns_51659 = (function (){var target_obj_51664 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51667 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51668 = oops.state.prepare_state.call(null,target_obj_51664,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51668);

try{var next_obj_51665 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51664,(0),"chrome",true,true,false))?(target_obj_51664["chrome"]):null);
var next_obj_51666 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51665,(0),"tabs",true,true,false))?(next_obj_51665["tabs"]):null);
return next_obj_51666;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51667);
}})();
var missing_api_51660 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.getSelected",ns_51659,"getSelected");
})();
if(missing_api_51660 === true){
return null;
} else {
var config__25890__auto___51676 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51676))){
var logger__25891__auto___51677 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51676);
var prefix__25892__auto___51678 = ["calling:","chrome.tabs.getSelected"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51677)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51676)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51677.apply(null,prefix__25892__auto___51678.concat(final_args_array_51658));
} else {
}

var target_51661 = (function (){var target_obj_51669 = ns_51659;
var _STAR_runtime_state_STAR__orig_val__51671 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51672 = oops.state.prepare_state.call(null,target_obj_51669,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51672);

try{var next_obj_51670 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51669,(1),"getSelected",true,true,false))?(target_obj_51669["getSelected"]):null);
if((!((next_obj_51670 == null)))){
return next_obj_51670;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51671);
}})();
return target_51661.apply(ns_51659,final_args_array_51658);
}
})();

return callback_chan_51654;
});
chromex.ext.tabs.get_all_in_window_STAR_ = (function chromex$ext$tabs$get_all_in_window_STAR_(config,window_id){
var callback_chan_51679 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_window_id_51681_51698 = (function (){var omit_test_51687 = window_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51687,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51687;
}
})();
var marshalled_callback_51682_51699 = (function (cb_tabs_51688){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 7, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","get-all-in-window","chromex.ext.tabs/get-all-in-window",-1792427692),new cljs.core.Keyword(null,"name","name",1843675177),"getAllInWindow",new cljs.core.Keyword(null,"since","since",315379842),"33",new cljs.core.Keyword(null,"deprecated","deprecated",1498275348),"Please use 'tabs.query' {windowId: windowId}.",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"window-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"tabs",new cljs.core.Keyword(null,"type","type",1174270348),"[array-of-tabs.Tabs]"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51679);
})().call(null,cb_tabs_51688);
});
var result_51680_51700 = (function (){var final_args_array_51683 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_51681_51698,"window-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51682_51699,"callback",null], null)], null),"chrome.tabs.getAllInWindow");
var ns_51684 = (function (){var target_obj_51689 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51692 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51693 = oops.state.prepare_state.call(null,target_obj_51689,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51693);

try{var next_obj_51690 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51689,(0),"chrome",true,true,false))?(target_obj_51689["chrome"]):null);
var next_obj_51691 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51690,(0),"tabs",true,true,false))?(next_obj_51690["tabs"]):null);
return next_obj_51691;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51692);
}})();
var missing_api_51685 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.getAllInWindow",ns_51684,"getAllInWindow");
})();
if(missing_api_51685 === true){
return null;
} else {
var config__25890__auto___51701 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51701))){
var logger__25891__auto___51702 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51701);
var prefix__25892__auto___51703 = ["calling:","chrome.tabs.getAllInWindow"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51702)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51701)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51702.apply(null,prefix__25892__auto___51703.concat(final_args_array_51683));
} else {
}

var target_51686 = (function (){var target_obj_51694 = ns_51684;
var _STAR_runtime_state_STAR__orig_val__51696 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51697 = oops.state.prepare_state.call(null,target_obj_51694,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51697);

try{var next_obj_51695 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51694,(1),"getAllInWindow",true,true,false))?(target_obj_51694["getAllInWindow"]):null);
if((!((next_obj_51695 == null)))){
return next_obj_51695;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51696);
}})();
return target_51686.apply(ns_51684,final_args_array_51683);
}
})();

return callback_chan_51679;
});
chromex.ext.tabs.create_STAR_ = (function chromex$ext$tabs$create_STAR_(config,create_properties){
var callback_chan_51704 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_create_properties_51706_51723 = (function (){var omit_test_51712 = create_properties;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51712,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51712;
}
})();
var marshalled_callback_51707_51724 = (function (cb_tab_51713){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","create","chromex.ext.tabs/create",977742829),new cljs.core.Keyword(null,"name","name",1843675177),"create",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"create-properties",new cljs.core.Keyword(null,"type","type",1174270348),"object"], null),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"tab",new cljs.core.Keyword(null,"type","type",1174270348),"tabs.Tab"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51704);
})().call(null,cb_tab_51713);
});
var result_51705_51725 = (function (){var final_args_array_51708 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_create_properties_51706_51723,"create-properties",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51707_51724,"callback",true], null)], null),"chrome.tabs.create");
var ns_51709 = (function (){var target_obj_51714 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51717 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51718 = oops.state.prepare_state.call(null,target_obj_51714,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51718);

try{var next_obj_51715 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51714,(0),"chrome",true,true,false))?(target_obj_51714["chrome"]):null);
var next_obj_51716 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51715,(0),"tabs",true,true,false))?(next_obj_51715["tabs"]):null);
return next_obj_51716;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51717);
}})();
var missing_api_51710 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.create",ns_51709,"create");
})();
if(missing_api_51710 === true){
return null;
} else {
var config__25890__auto___51726 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51726))){
var logger__25891__auto___51727 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51726);
var prefix__25892__auto___51728 = ["calling:","chrome.tabs.create"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51727)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51726)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51727.apply(null,prefix__25892__auto___51728.concat(final_args_array_51708));
} else {
}

var target_51711 = (function (){var target_obj_51719 = ns_51709;
var _STAR_runtime_state_STAR__orig_val__51721 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51722 = oops.state.prepare_state.call(null,target_obj_51719,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51722);

try{var next_obj_51720 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51719,(1),"create",true,true,false))?(target_obj_51719["create"]):null);
if((!((next_obj_51720 == null)))){
return next_obj_51720;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51721);
}})();
return target_51711.apply(ns_51709,final_args_array_51708);
}
})();

return callback_chan_51704;
});
chromex.ext.tabs.duplicate_STAR_ = (function chromex$ext$tabs$duplicate_STAR_(config,tab_id){
var callback_chan_51729 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_51731_51748 = (function (){var omit_test_51737 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51737,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51737;
}
})();
var marshalled_callback_51732_51749 = (function (cb_tab_51738){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","duplicate","chromex.ext.tabs/duplicate",-2107191215),new cljs.core.Keyword(null,"name","name",1843675177),"duplicate",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"tab",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"tabs.Tab"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51729);
})().call(null,cb_tab_51738);
});
var result_51730_51750 = (function (){var final_args_array_51733 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_51731_51748,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51732_51749,"callback",true], null)], null),"chrome.tabs.duplicate");
var ns_51734 = (function (){var target_obj_51739 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51742 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51743 = oops.state.prepare_state.call(null,target_obj_51739,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51743);

try{var next_obj_51740 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51739,(0),"chrome",true,true,false))?(target_obj_51739["chrome"]):null);
var next_obj_51741 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51740,(0),"tabs",true,true,false))?(next_obj_51740["tabs"]):null);
return next_obj_51741;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51742);
}})();
var missing_api_51735 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.duplicate",ns_51734,"duplicate");
})();
if(missing_api_51735 === true){
return null;
} else {
var config__25890__auto___51751 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51751))){
var logger__25891__auto___51752 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51751);
var prefix__25892__auto___51753 = ["calling:","chrome.tabs.duplicate"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51752)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51751)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51752.apply(null,prefix__25892__auto___51753.concat(final_args_array_51733));
} else {
}

var target_51736 = (function (){var target_obj_51744 = ns_51734;
var _STAR_runtime_state_STAR__orig_val__51746 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51747 = oops.state.prepare_state.call(null,target_obj_51744,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51747);

try{var next_obj_51745 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51744,(1),"duplicate",true,true,false))?(target_obj_51744["duplicate"]):null);
if((!((next_obj_51745 == null)))){
return next_obj_51745;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51746);
}})();
return target_51736.apply(ns_51734,final_args_array_51733);
}
})();

return callback_chan_51729;
});
chromex.ext.tabs.query_STAR_ = (function chromex$ext$tabs$query_STAR_(config,query_info){
var callback_chan_51754 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_query_info_51756_51773 = (function (){var omit_test_51762 = query_info;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51762,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51762;
}
})();
var marshalled_callback_51757_51774 = (function (cb_result_51763){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","query","chromex.ext.tabs/query",994669091),new cljs.core.Keyword(null,"name","name",1843675177),"query",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"query-info",new cljs.core.Keyword(null,"type","type",1174270348),"object"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"result",new cljs.core.Keyword(null,"type","type",1174270348),"[array-of-tabs.Tabs]"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51754);
})().call(null,cb_result_51763);
});
var result_51755_51775 = (function (){var final_args_array_51758 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_query_info_51756_51773,"query-info",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51757_51774,"callback",null], null)], null),"chrome.tabs.query");
var ns_51759 = (function (){var target_obj_51764 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51767 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51768 = oops.state.prepare_state.call(null,target_obj_51764,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51768);

try{var next_obj_51765 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51764,(0),"chrome",true,true,false))?(target_obj_51764["chrome"]):null);
var next_obj_51766 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51765,(0),"tabs",true,true,false))?(next_obj_51765["tabs"]):null);
return next_obj_51766;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51767);
}})();
var missing_api_51760 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.query",ns_51759,"query");
})();
if(missing_api_51760 === true){
return null;
} else {
var config__25890__auto___51776 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51776))){
var logger__25891__auto___51777 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51776);
var prefix__25892__auto___51778 = ["calling:","chrome.tabs.query"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51777)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51776)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51777.apply(null,prefix__25892__auto___51778.concat(final_args_array_51758));
} else {
}

var target_51761 = (function (){var target_obj_51769 = ns_51759;
var _STAR_runtime_state_STAR__orig_val__51771 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51772 = oops.state.prepare_state.call(null,target_obj_51769,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51772);

try{var next_obj_51770 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51769,(1),"query",true,true,false))?(target_obj_51769["query"]):null);
if((!((next_obj_51770 == null)))){
return next_obj_51770;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51771);
}})();
return target_51761.apply(ns_51759,final_args_array_51758);
}
})();

return callback_chan_51754;
});
chromex.ext.tabs.highlight_STAR_ = (function chromex$ext$tabs$highlight_STAR_(config,highlight_info){
var callback_chan_51779 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_highlight_info_51781_51798 = (function (){var omit_test_51787 = highlight_info;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51787,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51787;
}
})();
var marshalled_callback_51782_51799 = (function (cb_window_51788){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","highlight","chromex.ext.tabs/highlight",1227370148),new cljs.core.Keyword(null,"name","name",1843675177),"highlight",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"highlight-info",new cljs.core.Keyword(null,"type","type",1174270348),"object"], null),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"window",new cljs.core.Keyword(null,"type","type",1174270348),"windows.Window"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51779);
})().call(null,cb_window_51788);
});
var result_51780_51800 = (function (){var final_args_array_51783 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_highlight_info_51781_51798,"highlight-info",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51782_51799,"callback",true], null)], null),"chrome.tabs.highlight");
var ns_51784 = (function (){var target_obj_51789 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51792 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51793 = oops.state.prepare_state.call(null,target_obj_51789,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51793);

try{var next_obj_51790 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51789,(0),"chrome",true,true,false))?(target_obj_51789["chrome"]):null);
var next_obj_51791 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51790,(0),"tabs",true,true,false))?(next_obj_51790["tabs"]):null);
return next_obj_51791;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51792);
}})();
var missing_api_51785 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.highlight",ns_51784,"highlight");
})();
if(missing_api_51785 === true){
return null;
} else {
var config__25890__auto___51801 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51801))){
var logger__25891__auto___51802 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51801);
var prefix__25892__auto___51803 = ["calling:","chrome.tabs.highlight"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51802)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51801)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51802.apply(null,prefix__25892__auto___51803.concat(final_args_array_51783));
} else {
}

var target_51786 = (function (){var target_obj_51794 = ns_51784;
var _STAR_runtime_state_STAR__orig_val__51796 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51797 = oops.state.prepare_state.call(null,target_obj_51794,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51797);

try{var next_obj_51795 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51794,(1),"highlight",true,true,false))?(target_obj_51794["highlight"]):null);
if((!((next_obj_51795 == null)))){
return next_obj_51795;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51796);
}})();
return target_51786.apply(ns_51784,final_args_array_51783);
}
})();

return callback_chan_51779;
});
chromex.ext.tabs.update_STAR_ = (function chromex$ext$tabs$update_STAR_(config,tab_id,update_properties){
var callback_chan_51804 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_51806_51825 = (function (){var omit_test_51813 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51813,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51813;
}
})();
var marshalled_update_properties_51807_51826 = (function (){var omit_test_51814 = update_properties;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51814,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51814;
}
})();
var marshalled_callback_51808_51827 = (function (cb_tab_51815){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","update","chromex.ext.tabs/update",-965021465),new cljs.core.Keyword(null,"name","name",1843675177),"update",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"update-properties",new cljs.core.Keyword(null,"type","type",1174270348),"object"], null),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"tab",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"tabs.Tab"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51804);
})().call(null,cb_tab_51815);
});
var result_51805_51828 = (function (){var final_args_array_51809 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_51806_51825,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_update_properties_51807_51826,"update-properties",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51808_51827,"callback",true], null)], null),"chrome.tabs.update");
var ns_51810 = (function (){var target_obj_51816 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51819 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51820 = oops.state.prepare_state.call(null,target_obj_51816,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51820);

try{var next_obj_51817 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51816,(0),"chrome",true,true,false))?(target_obj_51816["chrome"]):null);
var next_obj_51818 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51817,(0),"tabs",true,true,false))?(next_obj_51817["tabs"]):null);
return next_obj_51818;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51819);
}})();
var missing_api_51811 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.update",ns_51810,"update");
})();
if(missing_api_51811 === true){
return null;
} else {
var config__25890__auto___51829 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51829))){
var logger__25891__auto___51830 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51829);
var prefix__25892__auto___51831 = ["calling:","chrome.tabs.update"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51830)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51829)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51830.apply(null,prefix__25892__auto___51831.concat(final_args_array_51809));
} else {
}

var target_51812 = (function (){var target_obj_51821 = ns_51810;
var _STAR_runtime_state_STAR__orig_val__51823 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51824 = oops.state.prepare_state.call(null,target_obj_51821,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51824);

try{var next_obj_51822 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51821,(1),"update",true,true,false))?(target_obj_51821["update"]):null);
if((!((next_obj_51822 == null)))){
return next_obj_51822;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51823);
}})();
return target_51812.apply(ns_51810,final_args_array_51809);
}
})();

return callback_chan_51804;
});
chromex.ext.tabs.move_STAR_ = (function chromex$ext$tabs$move_STAR_(config,tab_ids,move_properties){
var callback_chan_51832 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_ids_51834_51853 = (function (){var omit_test_51841 = tab_ids;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51841,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51841;
}
})();
var marshalled_move_properties_51835_51854 = (function (){var omit_test_51842 = move_properties;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51842,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51842;
}
})();
var marshalled_callback_51836_51855 = (function (cb_tabs_51843){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","move","chromex.ext.tabs/move",434564936),new cljs.core.Keyword(null,"name","name",1843675177),"move",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-ids",new cljs.core.Keyword(null,"type","type",1174270348),"integer-or-[array-of-integers]"], null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"move-properties",new cljs.core.Keyword(null,"type","type",1174270348),"object"], null),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"tabs",new cljs.core.Keyword(null,"type","type",1174270348),"tabs.Tab-or-[array-of-tabs.Tabs]"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51832);
})().call(null,cb_tabs_51843);
});
var result_51833_51856 = (function (){var final_args_array_51837 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_ids_51834_51853,"tab-ids",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_move_properties_51835_51854,"move-properties",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51836_51855,"callback",true], null)], null),"chrome.tabs.move");
var ns_51838 = (function (){var target_obj_51844 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51847 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51848 = oops.state.prepare_state.call(null,target_obj_51844,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51848);

try{var next_obj_51845 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51844,(0),"chrome",true,true,false))?(target_obj_51844["chrome"]):null);
var next_obj_51846 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51845,(0),"tabs",true,true,false))?(next_obj_51845["tabs"]):null);
return next_obj_51846;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51847);
}})();
var missing_api_51839 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.move",ns_51838,"move");
})();
if(missing_api_51839 === true){
return null;
} else {
var config__25890__auto___51857 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51857))){
var logger__25891__auto___51858 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51857);
var prefix__25892__auto___51859 = ["calling:","chrome.tabs.move"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51858)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51857)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51858.apply(null,prefix__25892__auto___51859.concat(final_args_array_51837));
} else {
}

var target_51840 = (function (){var target_obj_51849 = ns_51838;
var _STAR_runtime_state_STAR__orig_val__51851 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51852 = oops.state.prepare_state.call(null,target_obj_51849,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51852);

try{var next_obj_51850 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51849,(1),"move",true,true,false))?(target_obj_51849["move"]):null);
if((!((next_obj_51850 == null)))){
return next_obj_51850;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51851);
}})();
return target_51840.apply(ns_51838,final_args_array_51837);
}
})();

return callback_chan_51832;
});
chromex.ext.tabs.reload_STAR_ = (function chromex$ext$tabs$reload_STAR_(config,tab_id,reload_properties){
var callback_chan_51860 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_51862_51880 = (function (){var omit_test_51869 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51869,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51869;
}
})();
var marshalled_reload_properties_51863_51881 = (function (){var omit_test_51870 = reload_properties;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51870,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51870;
}
})();
var marshalled_callback_51864_51882 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","reload","chromex.ext.tabs/reload",-1146320662),new cljs.core.Keyword(null,"name","name",1843675177),"reload",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"reload-properties",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"object"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51860);
})();
var result_51861_51883 = (function (){var final_args_array_51865 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_51862_51880,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_reload_properties_51863_51881,"reload-properties",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51864_51882,"callback",true], null)], null),"chrome.tabs.reload");
var ns_51866 = (function (){var target_obj_51871 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51874 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51875 = oops.state.prepare_state.call(null,target_obj_51871,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51875);

try{var next_obj_51872 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51871,(0),"chrome",true,true,false))?(target_obj_51871["chrome"]):null);
var next_obj_51873 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51872,(0),"tabs",true,true,false))?(next_obj_51872["tabs"]):null);
return next_obj_51873;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51874);
}})();
var missing_api_51867 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.reload",ns_51866,"reload");
})();
if(missing_api_51867 === true){
return null;
} else {
var config__25890__auto___51884 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51884))){
var logger__25891__auto___51885 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51884);
var prefix__25892__auto___51886 = ["calling:","chrome.tabs.reload"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51885)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51884)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51885.apply(null,prefix__25892__auto___51886.concat(final_args_array_51865));
} else {
}

var target_51868 = (function (){var target_obj_51876 = ns_51866;
var _STAR_runtime_state_STAR__orig_val__51878 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51879 = oops.state.prepare_state.call(null,target_obj_51876,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51879);

try{var next_obj_51877 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51876,(1),"reload",true,true,false))?(target_obj_51876["reload"]):null);
if((!((next_obj_51877 == null)))){
return next_obj_51877;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51878);
}})();
return target_51868.apply(ns_51866,final_args_array_51865);
}
})();

return callback_chan_51860;
});
chromex.ext.tabs.remove_STAR_ = (function chromex$ext$tabs$remove_STAR_(config,tab_ids){
var callback_chan_51887 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_ids_51889_51905 = (function (){var omit_test_51895 = tab_ids;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51895,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51895;
}
})();
var marshalled_callback_51890_51906 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","remove","chromex.ext.tabs/remove",1073817227),new cljs.core.Keyword(null,"name","name",1843675177),"remove",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-ids",new cljs.core.Keyword(null,"type","type",1174270348),"integer-or-[array-of-integers]"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51887);
})();
var result_51888_51907 = (function (){var final_args_array_51891 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_ids_51889_51905,"tab-ids",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51890_51906,"callback",true], null)], null),"chrome.tabs.remove");
var ns_51892 = (function (){var target_obj_51896 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51899 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51900 = oops.state.prepare_state.call(null,target_obj_51896,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51900);

try{var next_obj_51897 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51896,(0),"chrome",true,true,false))?(target_obj_51896["chrome"]):null);
var next_obj_51898 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51897,(0),"tabs",true,true,false))?(next_obj_51897["tabs"]):null);
return next_obj_51898;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51899);
}})();
var missing_api_51893 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.remove",ns_51892,"remove");
})();
if(missing_api_51893 === true){
return null;
} else {
var config__25890__auto___51908 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51908))){
var logger__25891__auto___51909 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51908);
var prefix__25892__auto___51910 = ["calling:","chrome.tabs.remove"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51909)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51908)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51909.apply(null,prefix__25892__auto___51910.concat(final_args_array_51891));
} else {
}

var target_51894 = (function (){var target_obj_51901 = ns_51892;
var _STAR_runtime_state_STAR__orig_val__51903 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51904 = oops.state.prepare_state.call(null,target_obj_51901,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51904);

try{var next_obj_51902 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51901,(1),"remove",true,true,false))?(target_obj_51901["remove"]):null);
if((!((next_obj_51902 == null)))){
return next_obj_51902;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51903);
}})();
return target_51894.apply(ns_51892,final_args_array_51891);
}
})();

return callback_chan_51887;
});
chromex.ext.tabs.detect_language_STAR_ = (function chromex$ext$tabs$detect_language_STAR_(config,tab_id){
var callback_chan_51911 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_51913_51930 = (function (){var omit_test_51919 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51919,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51919;
}
})();
var marshalled_callback_51914_51931 = (function (cb_language_51920){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","detect-language","chromex.ext.tabs/detect-language",803336595),new cljs.core.Keyword(null,"name","name",1843675177),"detectLanguage",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"language",new cljs.core.Keyword(null,"type","type",1174270348),"string"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51911);
})().call(null,cb_language_51920);
});
var result_51912_51932 = (function (){var final_args_array_51915 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_51913_51930,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51914_51931,"callback",null], null)], null),"chrome.tabs.detectLanguage");
var ns_51916 = (function (){var target_obj_51921 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51924 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51925 = oops.state.prepare_state.call(null,target_obj_51921,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51925);

try{var next_obj_51922 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51921,(0),"chrome",true,true,false))?(target_obj_51921["chrome"]):null);
var next_obj_51923 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51922,(0),"tabs",true,true,false))?(next_obj_51922["tabs"]):null);
return next_obj_51923;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51924);
}})();
var missing_api_51917 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.detectLanguage",ns_51916,"detectLanguage");
})();
if(missing_api_51917 === true){
return null;
} else {
var config__25890__auto___51933 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51933))){
var logger__25891__auto___51934 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51933);
var prefix__25892__auto___51935 = ["calling:","chrome.tabs.detectLanguage"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51934)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51933)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51934.apply(null,prefix__25892__auto___51935.concat(final_args_array_51915));
} else {
}

var target_51918 = (function (){var target_obj_51926 = ns_51916;
var _STAR_runtime_state_STAR__orig_val__51928 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51929 = oops.state.prepare_state.call(null,target_obj_51926,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51929);

try{var next_obj_51927 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51926,(1),"detectLanguage",true,true,false))?(target_obj_51926["detectLanguage"]):null);
if((!((next_obj_51927 == null)))){
return next_obj_51927;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51928);
}})();
return target_51918.apply(ns_51916,final_args_array_51915);
}
})();

return callback_chan_51911;
});
chromex.ext.tabs.capture_visible_tab_STAR_ = (function chromex$ext$tabs$capture_visible_tab_STAR_(config,window_id,options){
var callback_chan_51936 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_window_id_51938_51957 = (function (){var omit_test_51945 = window_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51945,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51945;
}
})();
var marshalled_options_51939_51958 = (function (){var omit_test_51946 = options;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51946,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51946;
}
})();
var marshalled_callback_51940_51959 = (function (cb_data_url_51947){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","capture-visible-tab","chromex.ext.tabs/capture-visible-tab",-1662122182),new cljs.core.Keyword(null,"name","name",1843675177),"captureVisibleTab",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"window-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"options",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"object"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"data-url",new cljs.core.Keyword(null,"type","type",1174270348),"string"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51936);
})().call(null,cb_data_url_51947);
});
var result_51937_51960 = (function (){var final_args_array_51941 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_51938_51957,"window-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_51939_51958,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51940_51959,"callback",null], null)], null),"chrome.tabs.captureVisibleTab");
var ns_51942 = (function (){var target_obj_51948 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51951 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51952 = oops.state.prepare_state.call(null,target_obj_51948,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51952);

try{var next_obj_51949 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51948,(0),"chrome",true,true,false))?(target_obj_51948["chrome"]):null);
var next_obj_51950 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51949,(0),"tabs",true,true,false))?(next_obj_51949["tabs"]):null);
return next_obj_51950;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51951);
}})();
var missing_api_51943 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.captureVisibleTab",ns_51942,"captureVisibleTab");
})();
if(missing_api_51943 === true){
return null;
} else {
var config__25890__auto___51961 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51961))){
var logger__25891__auto___51962 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51961);
var prefix__25892__auto___51963 = ["calling:","chrome.tabs.captureVisibleTab"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51962)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51961)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51962.apply(null,prefix__25892__auto___51963.concat(final_args_array_51941));
} else {
}

var target_51944 = (function (){var target_obj_51953 = ns_51942;
var _STAR_runtime_state_STAR__orig_val__51955 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51956 = oops.state.prepare_state.call(null,target_obj_51953,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51956);

try{var next_obj_51954 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51953,(1),"captureVisibleTab",true,true,false))?(target_obj_51953["captureVisibleTab"]):null);
if((!((next_obj_51954 == null)))){
return next_obj_51954;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51955);
}})();
return target_51944.apply(ns_51942,final_args_array_51941);
}
})();

return callback_chan_51936;
});
chromex.ext.tabs.execute_script_STAR_ = (function chromex$ext$tabs$execute_script_STAR_(config,tab_id,details){
var callback_chan_51964 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_51966_51985 = (function (){var omit_test_51973 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51973,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51973;
}
})();
var marshalled_details_51967_51986 = (function (){var omit_test_51974 = details;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_51974,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_51974;
}
})();
var marshalled_callback_51968_51987 = (function (cb_result_51975){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","execute-script","chromex.ext.tabs/execute-script",-648872434),new cljs.core.Keyword(null,"name","name",1843675177),"executeScript",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"details",new cljs.core.Keyword(null,"type","type",1174270348),"object"], null),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"result",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"[array-of-anys]"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51964);
})().call(null,cb_result_51975);
});
var result_51965_51988 = (function (){var final_args_array_51969 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_51966_51985,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_51967_51986,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51968_51987,"callback",true], null)], null),"chrome.tabs.executeScript");
var ns_51970 = (function (){var target_obj_51976 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__51979 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51980 = oops.state.prepare_state.call(null,target_obj_51976,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51980);

try{var next_obj_51977 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51976,(0),"chrome",true,true,false))?(target_obj_51976["chrome"]):null);
var next_obj_51978 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_51977,(0),"tabs",true,true,false))?(next_obj_51977["tabs"]):null);
return next_obj_51978;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51979);
}})();
var missing_api_51971 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.executeScript",ns_51970,"executeScript");
})();
if(missing_api_51971 === true){
return null;
} else {
var config__25890__auto___51989 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51989))){
var logger__25891__auto___51990 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___51989);
var prefix__25892__auto___51991 = ["calling:","chrome.tabs.executeScript"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___51990)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___51989)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___51990.apply(null,prefix__25892__auto___51991.concat(final_args_array_51969));
} else {
}

var target_51972 = (function (){var target_obj_51981 = ns_51970;
var _STAR_runtime_state_STAR__orig_val__51983 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__51984 = oops.state.prepare_state.call(null,target_obj_51981,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__51984);

try{var next_obj_51982 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_51981,(1),"executeScript",true,true,false))?(target_obj_51981["executeScript"]):null);
if((!((next_obj_51982 == null)))){
return next_obj_51982;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__51983);
}})();
return target_51972.apply(ns_51970,final_args_array_51969);
}
})();

return callback_chan_51964;
});
chromex.ext.tabs.insert_css_STAR_ = (function chromex$ext$tabs$insert_css_STAR_(config,tab_id,details){
var callback_chan_51992 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_51994_52012 = (function (){var omit_test_52001 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_52001,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_52001;
}
})();
var marshalled_details_51995_52013 = (function (){var omit_test_52002 = details;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_52002,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_52002;
}
})();
var marshalled_callback_51996_52014 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","insert-css","chromex.ext.tabs/insert-css",-2032426194),new cljs.core.Keyword(null,"name","name",1843675177),"insertCSS",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"details",new cljs.core.Keyword(null,"type","type",1174270348),"object"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_51992);
})();
var result_51993_52015 = (function (){var final_args_array_51997 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_51994_52012,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_51995_52013,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_51996_52014,"callback",true], null)], null),"chrome.tabs.insertCSS");
var ns_51998 = (function (){var target_obj_52003 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52006 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52007 = oops.state.prepare_state.call(null,target_obj_52003,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52007);

try{var next_obj_52004 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52003,(0),"chrome",true,true,false))?(target_obj_52003["chrome"]):null);
var next_obj_52005 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52004,(0),"tabs",true,true,false))?(next_obj_52004["tabs"]):null);
return next_obj_52005;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52006);
}})();
var missing_api_51999 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.insertCSS",ns_51998,"insertCSS");
})();
if(missing_api_51999 === true){
return null;
} else {
var config__25890__auto___52016 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52016))){
var logger__25891__auto___52017 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52016);
var prefix__25892__auto___52018 = ["calling:","chrome.tabs.insertCSS"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52017)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52016)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52017.apply(null,prefix__25892__auto___52018.concat(final_args_array_51997));
} else {
}

var target_52000 = (function (){var target_obj_52008 = ns_51998;
var _STAR_runtime_state_STAR__orig_val__52010 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52011 = oops.state.prepare_state.call(null,target_obj_52008,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52011);

try{var next_obj_52009 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52008,(1),"insertCSS",true,true,false))?(target_obj_52008["insertCSS"]):null);
if((!((next_obj_52009 == null)))){
return next_obj_52009;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52010);
}})();
return target_52000.apply(ns_51998,final_args_array_51997);
}
})();

return callback_chan_51992;
});
chromex.ext.tabs.set_zoom_STAR_ = (function chromex$ext$tabs$set_zoom_STAR_(config,tab_id,zoom_factor){
var callback_chan_52019 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_52021_52039 = (function (){var omit_test_52028 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_52028,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_52028;
}
})();
var marshalled_zoom_factor_52022_52040 = (function (){var omit_test_52029 = zoom_factor;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_52029,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_52029;
}
})();
var marshalled_callback_52023_52041 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","set-zoom","chromex.ext.tabs/set-zoom",1740190670),new cljs.core.Keyword(null,"name","name",1843675177),"setZoom",new cljs.core.Keyword(null,"since","since",315379842),"42",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"since","since",315379842),"38",new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"zoom-factor",new cljs.core.Keyword(null,"since","since",315379842),"38",new cljs.core.Keyword(null,"type","type",1174270348),"double"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_52019);
})();
var result_52020_52042 = (function (){var final_args_array_52024 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_52021_52039,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_zoom_factor_52022_52040,"zoom-factor",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_52023_52041,"callback",true], null)], null),"chrome.tabs.setZoom");
var ns_52025 = (function (){var target_obj_52030 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52033 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52034 = oops.state.prepare_state.call(null,target_obj_52030,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52034);

try{var next_obj_52031 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52030,(0),"chrome",true,true,false))?(target_obj_52030["chrome"]):null);
var next_obj_52032 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52031,(0),"tabs",true,true,false))?(next_obj_52031["tabs"]):null);
return next_obj_52032;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52033);
}})();
var missing_api_52026 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.setZoom",ns_52025,"setZoom");
})();
if(missing_api_52026 === true){
return null;
} else {
var config__25890__auto___52043 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52043))){
var logger__25891__auto___52044 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52043);
var prefix__25892__auto___52045 = ["calling:","chrome.tabs.setZoom"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52044)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52043)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52044.apply(null,prefix__25892__auto___52045.concat(final_args_array_52024));
} else {
}

var target_52027 = (function (){var target_obj_52035 = ns_52025;
var _STAR_runtime_state_STAR__orig_val__52037 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52038 = oops.state.prepare_state.call(null,target_obj_52035,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52038);

try{var next_obj_52036 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52035,(1),"setZoom",true,true,false))?(target_obj_52035["setZoom"]):null);
if((!((next_obj_52036 == null)))){
return next_obj_52036;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52037);
}})();
return target_52027.apply(ns_52025,final_args_array_52024);
}
})();

return callback_chan_52019;
});
chromex.ext.tabs.get_zoom_STAR_ = (function chromex$ext$tabs$get_zoom_STAR_(config,tab_id){
var callback_chan_52046 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_52048_52065 = (function (){var omit_test_52054 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_52054,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_52054;
}
})();
var marshalled_callback_52049_52066 = (function (cb_zoom_factor_52055){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","get-zoom","chromex.ext.tabs/get-zoom",747134311),new cljs.core.Keyword(null,"name","name",1843675177),"getZoom",new cljs.core.Keyword(null,"since","since",315379842),"42",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"since","since",315379842),"38",new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"zoom-factor",new cljs.core.Keyword(null,"type","type",1174270348),"double"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_52046);
})().call(null,cb_zoom_factor_52055);
});
var result_52047_52067 = (function (){var final_args_array_52050 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_52048_52065,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_52049_52066,"callback",null], null)], null),"chrome.tabs.getZoom");
var ns_52051 = (function (){var target_obj_52056 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52059 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52060 = oops.state.prepare_state.call(null,target_obj_52056,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52060);

try{var next_obj_52057 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52056,(0),"chrome",true,true,false))?(target_obj_52056["chrome"]):null);
var next_obj_52058 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52057,(0),"tabs",true,true,false))?(next_obj_52057["tabs"]):null);
return next_obj_52058;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52059);
}})();
var missing_api_52052 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.getZoom",ns_52051,"getZoom");
})();
if(missing_api_52052 === true){
return null;
} else {
var config__25890__auto___52068 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52068))){
var logger__25891__auto___52069 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52068);
var prefix__25892__auto___52070 = ["calling:","chrome.tabs.getZoom"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52069)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52068)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52069.apply(null,prefix__25892__auto___52070.concat(final_args_array_52050));
} else {
}

var target_52053 = (function (){var target_obj_52061 = ns_52051;
var _STAR_runtime_state_STAR__orig_val__52063 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52064 = oops.state.prepare_state.call(null,target_obj_52061,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52064);

try{var next_obj_52062 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52061,(1),"getZoom",true,true,false))?(target_obj_52061["getZoom"]):null);
if((!((next_obj_52062 == null)))){
return next_obj_52062;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52063);
}})();
return target_52053.apply(ns_52051,final_args_array_52050);
}
})();

return callback_chan_52046;
});
chromex.ext.tabs.set_zoom_settings_STAR_ = (function chromex$ext$tabs$set_zoom_settings_STAR_(config,tab_id,zoom_settings){
var callback_chan_52071 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_52073_52091 = (function (){var omit_test_52080 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_52080,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_52080;
}
})();
var marshalled_zoom_settings_52074_52092 = (function (){var omit_test_52081 = zoom_settings;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_52081,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_52081;
}
})();
var marshalled_callback_52075_52093 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","set-zoom-settings","chromex.ext.tabs/set-zoom-settings",-1121343767),new cljs.core.Keyword(null,"name","name",1843675177),"setZoomSettings",new cljs.core.Keyword(null,"since","since",315379842),"42",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"since","since",315379842),"38",new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"zoom-settings",new cljs.core.Keyword(null,"since","since",315379842),"38",new cljs.core.Keyword(null,"type","type",1174270348),"tabs.ZoomSettings"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_52071);
})();
var result_52072_52094 = (function (){var final_args_array_52076 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_52073_52091,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_zoom_settings_52074_52092,"zoom-settings",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_52075_52093,"callback",true], null)], null),"chrome.tabs.setZoomSettings");
var ns_52077 = (function (){var target_obj_52082 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52085 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52086 = oops.state.prepare_state.call(null,target_obj_52082,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52086);

try{var next_obj_52083 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52082,(0),"chrome",true,true,false))?(target_obj_52082["chrome"]):null);
var next_obj_52084 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52083,(0),"tabs",true,true,false))?(next_obj_52083["tabs"]):null);
return next_obj_52084;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52085);
}})();
var missing_api_52078 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.setZoomSettings",ns_52077,"setZoomSettings");
})();
if(missing_api_52078 === true){
return null;
} else {
var config__25890__auto___52095 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52095))){
var logger__25891__auto___52096 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52095);
var prefix__25892__auto___52097 = ["calling:","chrome.tabs.setZoomSettings"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52096)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52095)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52096.apply(null,prefix__25892__auto___52097.concat(final_args_array_52076));
} else {
}

var target_52079 = (function (){var target_obj_52087 = ns_52077;
var _STAR_runtime_state_STAR__orig_val__52089 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52090 = oops.state.prepare_state.call(null,target_obj_52087,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52090);

try{var next_obj_52088 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52087,(1),"setZoomSettings",true,true,false))?(target_obj_52087["setZoomSettings"]):null);
if((!((next_obj_52088 == null)))){
return next_obj_52088;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52089);
}})();
return target_52079.apply(ns_52077,final_args_array_52076);
}
})();

return callback_chan_52071;
});
chromex.ext.tabs.get_zoom_settings_STAR_ = (function chromex$ext$tabs$get_zoom_settings_STAR_(config,tab_id){
var callback_chan_52098 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_52100_52117 = (function (){var omit_test_52106 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_52106,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_52106;
}
})();
var marshalled_callback_52101_52118 = (function (cb_zoom_settings_52107){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","get-zoom-settings","chromex.ext.tabs/get-zoom-settings",-585298770),new cljs.core.Keyword(null,"name","name",1843675177),"getZoomSettings",new cljs.core.Keyword(null,"since","since",315379842),"42",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"since","since",315379842),"38",new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"zoom-settings",new cljs.core.Keyword(null,"type","type",1174270348),"tabs.ZoomSettings"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_52098);
})().call(null,cb_zoom_settings_52107);
});
var result_52099_52119 = (function (){var final_args_array_52102 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_52100_52117,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_52101_52118,"callback",null], null)], null),"chrome.tabs.getZoomSettings");
var ns_52103 = (function (){var target_obj_52108 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52111 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52112 = oops.state.prepare_state.call(null,target_obj_52108,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52112);

try{var next_obj_52109 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52108,(0),"chrome",true,true,false))?(target_obj_52108["chrome"]):null);
var next_obj_52110 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52109,(0),"tabs",true,true,false))?(next_obj_52109["tabs"]):null);
return next_obj_52110;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52111);
}})();
var missing_api_52104 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.getZoomSettings",ns_52103,"getZoomSettings");
})();
if(missing_api_52104 === true){
return null;
} else {
var config__25890__auto___52120 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52120))){
var logger__25891__auto___52121 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52120);
var prefix__25892__auto___52122 = ["calling:","chrome.tabs.getZoomSettings"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52121)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52120)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52121.apply(null,prefix__25892__auto___52122.concat(final_args_array_52102));
} else {
}

var target_52105 = (function (){var target_obj_52113 = ns_52103;
var _STAR_runtime_state_STAR__orig_val__52115 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52116 = oops.state.prepare_state.call(null,target_obj_52113,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52116);

try{var next_obj_52114 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52113,(1),"getZoomSettings",true,true,false))?(target_obj_52113["getZoomSettings"]):null);
if((!((next_obj_52114 == null)))){
return next_obj_52114;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52115);
}})();
return target_52105.apply(ns_52103,final_args_array_52102);
}
})();

return callback_chan_52098;
});
chromex.ext.tabs.discard_STAR_ = (function chromex$ext$tabs$discard_STAR_(config,tab_id){
var callback_chan_52123 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_52125_52142 = (function (){var omit_test_52131 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_52131,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_52131;
}
})();
var marshalled_callback_52126_52143 = (function (cb_tab_52132){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","discard","chromex.ext.tabs/discard",71213150),new cljs.core.Keyword(null,"name","name",1843675177),"discard",new cljs.core.Keyword(null,"since","since",315379842),"54",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"tab",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"tabs.Tab"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_52123);
})().call(null,cb_tab_52132);
});
var result_52124_52144 = (function (){var final_args_array_52127 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_52125_52142,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_52126_52143,"callback",true], null)], null),"chrome.tabs.discard");
var ns_52128 = (function (){var target_obj_52133 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52136 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52137 = oops.state.prepare_state.call(null,target_obj_52133,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52137);

try{var next_obj_52134 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52133,(0),"chrome",true,true,false))?(target_obj_52133["chrome"]):null);
var next_obj_52135 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52134,(0),"tabs",true,true,false))?(next_obj_52134["tabs"]):null);
return next_obj_52135;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52136);
}})();
var missing_api_52129 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.discard",ns_52128,"discard");
})();
if(missing_api_52129 === true){
return null;
} else {
var config__25890__auto___52145 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52145))){
var logger__25891__auto___52146 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52145);
var prefix__25892__auto___52147 = ["calling:","chrome.tabs.discard"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52146)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52145)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52146.apply(null,prefix__25892__auto___52147.concat(final_args_array_52127));
} else {
}

var target_52130 = (function (){var target_obj_52138 = ns_52128;
var _STAR_runtime_state_STAR__orig_val__52140 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52141 = oops.state.prepare_state.call(null,target_obj_52138,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52141);

try{var next_obj_52139 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52138,(1),"discard",true,true,false))?(target_obj_52138["discard"]):null);
if((!((next_obj_52139 == null)))){
return next_obj_52139;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52140);
}})();
return target_52130.apply(ns_52128,final_args_array_52127);
}
})();

return callback_chan_52123;
});
chromex.ext.tabs.go_forward_STAR_ = (function chromex$ext$tabs$go_forward_STAR_(config,tab_id){
var callback_chan_52148 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_52150_52166 = (function (){var omit_test_52156 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_52156,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_52156;
}
})();
var marshalled_callback_52151_52167 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","go-forward","chromex.ext.tabs/go-forward",-1879983745),new cljs.core.Keyword(null,"name","name",1843675177),"goForward",new cljs.core.Keyword(null,"since","since",315379842),"72",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_52148);
})();
var result_52149_52168 = (function (){var final_args_array_52152 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_52150_52166,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_52151_52167,"callback",true], null)], null),"chrome.tabs.goForward");
var ns_52153 = (function (){var target_obj_52157 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52160 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52161 = oops.state.prepare_state.call(null,target_obj_52157,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52161);

try{var next_obj_52158 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52157,(0),"chrome",true,true,false))?(target_obj_52157["chrome"]):null);
var next_obj_52159 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52158,(0),"tabs",true,true,false))?(next_obj_52158["tabs"]):null);
return next_obj_52159;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52160);
}})();
var missing_api_52154 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.goForward",ns_52153,"goForward");
})();
if(missing_api_52154 === true){
return null;
} else {
var config__25890__auto___52169 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52169))){
var logger__25891__auto___52170 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52169);
var prefix__25892__auto___52171 = ["calling:","chrome.tabs.goForward"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52170)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52169)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52170.apply(null,prefix__25892__auto___52171.concat(final_args_array_52152));
} else {
}

var target_52155 = (function (){var target_obj_52162 = ns_52153;
var _STAR_runtime_state_STAR__orig_val__52164 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52165 = oops.state.prepare_state.call(null,target_obj_52162,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52165);

try{var next_obj_52163 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52162,(1),"goForward",true,true,false))?(target_obj_52162["goForward"]):null);
if((!((next_obj_52163 == null)))){
return next_obj_52163;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52164);
}})();
return target_52155.apply(ns_52153,final_args_array_52152);
}
})();

return callback_chan_52148;
});
chromex.ext.tabs.go_back_STAR_ = (function chromex$ext$tabs$go_back_STAR_(config,tab_id){
var callback_chan_52172 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_tab_id_52174_52190 = (function (){var omit_test_52180 = tab_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_52180,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_52180;
}
})();
var marshalled_callback_52175_52191 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.tabs","go-back","chromex.ext.tabs/go-back",-373825326),new cljs.core.Keyword(null,"name","name",1843675177),"goBack",new cljs.core.Keyword(null,"since","since",315379842),"72",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"tab-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_52172);
})();
var result_52173_52192 = (function (){var final_args_array_52176 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_52174_52190,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_52175_52191,"callback",true], null)], null),"chrome.tabs.goBack");
var ns_52177 = (function (){var target_obj_52181 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52184 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52185 = oops.state.prepare_state.call(null,target_obj_52181,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52185);

try{var next_obj_52182 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52181,(0),"chrome",true,true,false))?(target_obj_52181["chrome"]):null);
var next_obj_52183 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52182,(0),"tabs",true,true,false))?(next_obj_52182["tabs"]):null);
return next_obj_52183;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52184);
}})();
var missing_api_52178 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.goBack",ns_52177,"goBack");
})();
if(missing_api_52178 === true){
return null;
} else {
var config__25890__auto___52193 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52193))){
var logger__25891__auto___52194 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52193);
var prefix__25892__auto___52195 = ["calling:","chrome.tabs.goBack"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52194)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52193)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52194.apply(null,prefix__25892__auto___52195.concat(final_args_array_52176));
} else {
}

var target_52179 = (function (){var target_obj_52186 = ns_52177;
var _STAR_runtime_state_STAR__orig_val__52188 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52189 = oops.state.prepare_state.call(null,target_obj_52186,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52189);

try{var next_obj_52187 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52186,(1),"goBack",true,true,false))?(target_obj_52186["goBack"]):null);
if((!((next_obj_52187 == null)))){
return next_obj_52187;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52188);
}})();
return target_52179.apply(ns_52177,final_args_array_52176);
}
})();

return callback_chan_52172;
});
chromex.ext.tabs.on_created_STAR_ = (function chromex$ext$tabs$on_created_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___52217 = arguments.length;
var i__4790__auto___52218 = (0);
while(true){
if((i__4790__auto___52218 < len__4789__auto___52217)){
args__4795__auto__.push((arguments[i__4790__auto___52218]));

var G__52219 = (i__4790__auto___52218 + (1));
i__4790__auto___52218 = G__52219;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_created_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.tabs.on_created_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_52199 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.tabs","on-created","chromex.ext.tabs/on-created",234051309),channel);
})();
var handler_fn_52200 = (function (cb_tab_52206){
return event_fn_52199.call(null,cb_tab_52206);
});
var logging_fn_52201 = (function (cb_param_tab_52207){
var config__25890__auto___52220 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52220))){
var logger__25891__auto___52221 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52220);
var prefix__25892__auto___52222 = ["event:","chrome.tabs.onCreated"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52221)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52220)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52221.apply(null,prefix__25892__auto___52222.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_tab_52207], null))));
} else {
}

return handler_fn_52200.call(null,cb_param_tab_52207);
});
var ns_obj_52204 = (function (){var target_obj_52208 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52211 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52212 = oops.state.prepare_state.call(null,target_obj_52208,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52212);

try{var next_obj_52209 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52208,(0),"chrome",true,true,false))?(target_obj_52208["chrome"]):null);
var next_obj_52210 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52209,(0),"tabs",true,true,false))?(next_obj_52209["tabs"]):null);
return next_obj_52210;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52211);
}})();
var missing_api_52205 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.onCreated",ns_obj_52204,"onCreated");
})();
if(missing_api_52205 === true){
return null;
} else {
var event_obj_52202 = (function (){var target_obj_52213 = ns_obj_52204;
var _STAR_runtime_state_STAR__orig_val__52215 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52216 = oops.state.prepare_state.call(null,target_obj_52213,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52216);

try{var next_obj_52214 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52213,(0),"onCreated",true,true,false))?(target_obj_52213["onCreated"]):null);
return next_obj_52214;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52215);
}})();
var result_52203 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_52202,logging_fn_52201,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_52203,args);

return result_52203;
}
}));

(chromex.ext.tabs.on_created_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.tabs.on_created_STAR_.cljs$lang$applyTo = (function (seq52196){
var G__52197 = cljs.core.first.call(null,seq52196);
var seq52196__$1 = cljs.core.next.call(null,seq52196);
var G__52198 = cljs.core.first.call(null,seq52196__$1);
var seq52196__$2 = cljs.core.next.call(null,seq52196__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__52197,G__52198,seq52196__$2);
}));

chromex.ext.tabs.on_updated_STAR_ = (function chromex$ext$tabs$on_updated_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___52248 = arguments.length;
var i__4790__auto___52249 = (0);
while(true){
if((i__4790__auto___52249 < len__4789__auto___52248)){
args__4795__auto__.push((arguments[i__4790__auto___52249]));

var G__52250 = (i__4790__auto___52249 + (1));
i__4790__auto___52249 = G__52250;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_updated_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.tabs.on_updated_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_52226 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.tabs","on-updated","chromex.ext.tabs/on-updated",513718938),channel);
})();
var handler_fn_52227 = (function (cb_tab_id_52233,cb_change_info_52234,cb_tab_52235){
return event_fn_52226.call(null,cb_tab_id_52233,cb_change_info_52234,cb_tab_52235);
});
var logging_fn_52228 = (function (cb_param_tab_id_52236,cb_param_change_info_52237,cb_param_tab_52238){
var config__25890__auto___52251 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52251))){
var logger__25891__auto___52252 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52251);
var prefix__25892__auto___52253 = ["event:","chrome.tabs.onUpdated"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52252)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52251)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52252.apply(null,prefix__25892__auto___52253.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_tab_id_52236,cb_param_change_info_52237,cb_param_tab_52238], null))));
} else {
}

return handler_fn_52227.call(null,cb_param_tab_id_52236,cb_param_change_info_52237,cb_param_tab_52238);
});
var ns_obj_52231 = (function (){var target_obj_52239 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52242 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52243 = oops.state.prepare_state.call(null,target_obj_52239,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52243);

try{var next_obj_52240 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52239,(0),"chrome",true,true,false))?(target_obj_52239["chrome"]):null);
var next_obj_52241 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52240,(0),"tabs",true,true,false))?(next_obj_52240["tabs"]):null);
return next_obj_52241;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52242);
}})();
var missing_api_52232 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.onUpdated",ns_obj_52231,"onUpdated");
})();
if(missing_api_52232 === true){
return null;
} else {
var event_obj_52229 = (function (){var target_obj_52244 = ns_obj_52231;
var _STAR_runtime_state_STAR__orig_val__52246 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52247 = oops.state.prepare_state.call(null,target_obj_52244,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52247);

try{var next_obj_52245 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52244,(0),"onUpdated",true,true,false))?(target_obj_52244["onUpdated"]):null);
return next_obj_52245;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52246);
}})();
var result_52230 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_52229,logging_fn_52228,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_52230,args);

return result_52230;
}
}));

(chromex.ext.tabs.on_updated_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.tabs.on_updated_STAR_.cljs$lang$applyTo = (function (seq52223){
var G__52224 = cljs.core.first.call(null,seq52223);
var seq52223__$1 = cljs.core.next.call(null,seq52223);
var G__52225 = cljs.core.first.call(null,seq52223__$1);
var seq52223__$2 = cljs.core.next.call(null,seq52223__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__52224,G__52225,seq52223__$2);
}));

chromex.ext.tabs.on_moved_STAR_ = (function chromex$ext$tabs$on_moved_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___52277 = arguments.length;
var i__4790__auto___52278 = (0);
while(true){
if((i__4790__auto___52278 < len__4789__auto___52277)){
args__4795__auto__.push((arguments[i__4790__auto___52278]));

var G__52279 = (i__4790__auto___52278 + (1));
i__4790__auto___52278 = G__52279;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_moved_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.tabs.on_moved_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_52257 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.tabs","on-moved","chromex.ext.tabs/on-moved",-680724148),channel);
})();
var handler_fn_52258 = (function (cb_tab_id_52264,cb_move_info_52265){
return event_fn_52257.call(null,cb_tab_id_52264,cb_move_info_52265);
});
var logging_fn_52259 = (function (cb_param_tab_id_52266,cb_param_move_info_52267){
var config__25890__auto___52280 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52280))){
var logger__25891__auto___52281 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52280);
var prefix__25892__auto___52282 = ["event:","chrome.tabs.onMoved"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52281)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52280)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52281.apply(null,prefix__25892__auto___52282.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_tab_id_52266,cb_param_move_info_52267], null))));
} else {
}

return handler_fn_52258.call(null,cb_param_tab_id_52266,cb_param_move_info_52267);
});
var ns_obj_52262 = (function (){var target_obj_52268 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52271 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52272 = oops.state.prepare_state.call(null,target_obj_52268,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52272);

try{var next_obj_52269 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52268,(0),"chrome",true,true,false))?(target_obj_52268["chrome"]):null);
var next_obj_52270 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52269,(0),"tabs",true,true,false))?(next_obj_52269["tabs"]):null);
return next_obj_52270;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52271);
}})();
var missing_api_52263 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.onMoved",ns_obj_52262,"onMoved");
})();
if(missing_api_52263 === true){
return null;
} else {
var event_obj_52260 = (function (){var target_obj_52273 = ns_obj_52262;
var _STAR_runtime_state_STAR__orig_val__52275 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52276 = oops.state.prepare_state.call(null,target_obj_52273,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52276);

try{var next_obj_52274 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52273,(0),"onMoved",true,true,false))?(target_obj_52273["onMoved"]):null);
return next_obj_52274;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52275);
}})();
var result_52261 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_52260,logging_fn_52259,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_52261,args);

return result_52261;
}
}));

(chromex.ext.tabs.on_moved_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.tabs.on_moved_STAR_.cljs$lang$applyTo = (function (seq52254){
var G__52255 = cljs.core.first.call(null,seq52254);
var seq52254__$1 = cljs.core.next.call(null,seq52254);
var G__52256 = cljs.core.first.call(null,seq52254__$1);
var seq52254__$2 = cljs.core.next.call(null,seq52254__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__52255,G__52256,seq52254__$2);
}));

chromex.ext.tabs.on_selection_changed_STAR_ = (function chromex$ext$tabs$on_selection_changed_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___52306 = arguments.length;
var i__4790__auto___52307 = (0);
while(true){
if((i__4790__auto___52307 < len__4789__auto___52306)){
args__4795__auto__.push((arguments[i__4790__auto___52307]));

var G__52308 = (i__4790__auto___52307 + (1));
i__4790__auto___52307 = G__52308;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_selection_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.tabs.on_selection_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_52286 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.tabs","on-selection-changed","chromex.ext.tabs/on-selection-changed",1241767140),channel);
})();
var handler_fn_52287 = (function (cb_tab_id_52293,cb_select_info_52294){
return event_fn_52286.call(null,cb_tab_id_52293,cb_select_info_52294);
});
var logging_fn_52288 = (function (cb_param_tab_id_52295,cb_param_select_info_52296){
var config__25890__auto___52309 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52309))){
var logger__25891__auto___52310 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52309);
var prefix__25892__auto___52311 = ["event:","chrome.tabs.onSelectionChanged"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52310)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52309)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52310.apply(null,prefix__25892__auto___52311.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_tab_id_52295,cb_param_select_info_52296], null))));
} else {
}

return handler_fn_52287.call(null,cb_param_tab_id_52295,cb_param_select_info_52296);
});
var ns_obj_52291 = (function (){var target_obj_52297 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52300 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52301 = oops.state.prepare_state.call(null,target_obj_52297,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52301);

try{var next_obj_52298 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52297,(0),"chrome",true,true,false))?(target_obj_52297["chrome"]):null);
var next_obj_52299 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52298,(0),"tabs",true,true,false))?(next_obj_52298["tabs"]):null);
return next_obj_52299;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52300);
}})();
var missing_api_52292 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.onSelectionChanged",ns_obj_52291,"onSelectionChanged");
})();
if(missing_api_52292 === true){
return null;
} else {
var event_obj_52289 = (function (){var target_obj_52302 = ns_obj_52291;
var _STAR_runtime_state_STAR__orig_val__52304 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52305 = oops.state.prepare_state.call(null,target_obj_52302,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52305);

try{var next_obj_52303 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52302,(0),"onSelectionChanged",true,true,false))?(target_obj_52302["onSelectionChanged"]):null);
return next_obj_52303;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52304);
}})();
var result_52290 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_52289,logging_fn_52288,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_52290,args);

return result_52290;
}
}));

(chromex.ext.tabs.on_selection_changed_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.tabs.on_selection_changed_STAR_.cljs$lang$applyTo = (function (seq52283){
var G__52284 = cljs.core.first.call(null,seq52283);
var seq52283__$1 = cljs.core.next.call(null,seq52283);
var G__52285 = cljs.core.first.call(null,seq52283__$1);
var seq52283__$2 = cljs.core.next.call(null,seq52283__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__52284,G__52285,seq52283__$2);
}));

chromex.ext.tabs.on_active_changed_STAR_ = (function chromex$ext$tabs$on_active_changed_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___52335 = arguments.length;
var i__4790__auto___52336 = (0);
while(true){
if((i__4790__auto___52336 < len__4789__auto___52335)){
args__4795__auto__.push((arguments[i__4790__auto___52336]));

var G__52337 = (i__4790__auto___52336 + (1));
i__4790__auto___52336 = G__52337;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_active_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.tabs.on_active_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_52315 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.tabs","on-active-changed","chromex.ext.tabs/on-active-changed",1369383993),channel);
})();
var handler_fn_52316 = (function (cb_tab_id_52322,cb_select_info_52323){
return event_fn_52315.call(null,cb_tab_id_52322,cb_select_info_52323);
});
var logging_fn_52317 = (function (cb_param_tab_id_52324,cb_param_select_info_52325){
var config__25890__auto___52338 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52338))){
var logger__25891__auto___52339 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52338);
var prefix__25892__auto___52340 = ["event:","chrome.tabs.onActiveChanged"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52339)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52338)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52339.apply(null,prefix__25892__auto___52340.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_tab_id_52324,cb_param_select_info_52325], null))));
} else {
}

return handler_fn_52316.call(null,cb_param_tab_id_52324,cb_param_select_info_52325);
});
var ns_obj_52320 = (function (){var target_obj_52326 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52329 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52330 = oops.state.prepare_state.call(null,target_obj_52326,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52330);

try{var next_obj_52327 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52326,(0),"chrome",true,true,false))?(target_obj_52326["chrome"]):null);
var next_obj_52328 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52327,(0),"tabs",true,true,false))?(next_obj_52327["tabs"]):null);
return next_obj_52328;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52329);
}})();
var missing_api_52321 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.onActiveChanged",ns_obj_52320,"onActiveChanged");
})();
if(missing_api_52321 === true){
return null;
} else {
var event_obj_52318 = (function (){var target_obj_52331 = ns_obj_52320;
var _STAR_runtime_state_STAR__orig_val__52333 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52334 = oops.state.prepare_state.call(null,target_obj_52331,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52334);

try{var next_obj_52332 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52331,(0),"onActiveChanged",true,true,false))?(target_obj_52331["onActiveChanged"]):null);
return next_obj_52332;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52333);
}})();
var result_52319 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_52318,logging_fn_52317,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_52319,args);

return result_52319;
}
}));

(chromex.ext.tabs.on_active_changed_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.tabs.on_active_changed_STAR_.cljs$lang$applyTo = (function (seq52312){
var G__52313 = cljs.core.first.call(null,seq52312);
var seq52312__$1 = cljs.core.next.call(null,seq52312);
var G__52314 = cljs.core.first.call(null,seq52312__$1);
var seq52312__$2 = cljs.core.next.call(null,seq52312__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__52313,G__52314,seq52312__$2);
}));

chromex.ext.tabs.on_activated_STAR_ = (function chromex$ext$tabs$on_activated_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___52362 = arguments.length;
var i__4790__auto___52363 = (0);
while(true){
if((i__4790__auto___52363 < len__4789__auto___52362)){
args__4795__auto__.push((arguments[i__4790__auto___52363]));

var G__52364 = (i__4790__auto___52363 + (1));
i__4790__auto___52363 = G__52364;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_activated_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.tabs.on_activated_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_52344 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.tabs","on-activated","chromex.ext.tabs/on-activated",1422935115),channel);
})();
var handler_fn_52345 = (function (cb_active_info_52351){
return event_fn_52344.call(null,cb_active_info_52351);
});
var logging_fn_52346 = (function (cb_param_active_info_52352){
var config__25890__auto___52365 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52365))){
var logger__25891__auto___52366 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52365);
var prefix__25892__auto___52367 = ["event:","chrome.tabs.onActivated"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52366)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52365)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52366.apply(null,prefix__25892__auto___52367.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_active_info_52352], null))));
} else {
}

return handler_fn_52345.call(null,cb_param_active_info_52352);
});
var ns_obj_52349 = (function (){var target_obj_52353 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52356 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52357 = oops.state.prepare_state.call(null,target_obj_52353,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52357);

try{var next_obj_52354 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52353,(0),"chrome",true,true,false))?(target_obj_52353["chrome"]):null);
var next_obj_52355 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52354,(0),"tabs",true,true,false))?(next_obj_52354["tabs"]):null);
return next_obj_52355;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52356);
}})();
var missing_api_52350 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.onActivated",ns_obj_52349,"onActivated");
})();
if(missing_api_52350 === true){
return null;
} else {
var event_obj_52347 = (function (){var target_obj_52358 = ns_obj_52349;
var _STAR_runtime_state_STAR__orig_val__52360 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52361 = oops.state.prepare_state.call(null,target_obj_52358,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52361);

try{var next_obj_52359 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52358,(0),"onActivated",true,true,false))?(target_obj_52358["onActivated"]):null);
return next_obj_52359;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52360);
}})();
var result_52348 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_52347,logging_fn_52346,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_52348,args);

return result_52348;
}
}));

(chromex.ext.tabs.on_activated_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.tabs.on_activated_STAR_.cljs$lang$applyTo = (function (seq52341){
var G__52342 = cljs.core.first.call(null,seq52341);
var seq52341__$1 = cljs.core.next.call(null,seq52341);
var G__52343 = cljs.core.first.call(null,seq52341__$1);
var seq52341__$2 = cljs.core.next.call(null,seq52341__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__52342,G__52343,seq52341__$2);
}));

chromex.ext.tabs.on_highlight_changed_STAR_ = (function chromex$ext$tabs$on_highlight_changed_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___52389 = arguments.length;
var i__4790__auto___52390 = (0);
while(true){
if((i__4790__auto___52390 < len__4789__auto___52389)){
args__4795__auto__.push((arguments[i__4790__auto___52390]));

var G__52391 = (i__4790__auto___52390 + (1));
i__4790__auto___52390 = G__52391;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_highlight_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.tabs.on_highlight_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_52371 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.tabs","on-highlight-changed","chromex.ext.tabs/on-highlight-changed",-970888983),channel);
})();
var handler_fn_52372 = (function (cb_select_info_52378){
return event_fn_52371.call(null,cb_select_info_52378);
});
var logging_fn_52373 = (function (cb_param_select_info_52379){
var config__25890__auto___52392 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52392))){
var logger__25891__auto___52393 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52392);
var prefix__25892__auto___52394 = ["event:","chrome.tabs.onHighlightChanged"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52393)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52392)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52393.apply(null,prefix__25892__auto___52394.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_select_info_52379], null))));
} else {
}

return handler_fn_52372.call(null,cb_param_select_info_52379);
});
var ns_obj_52376 = (function (){var target_obj_52380 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52383 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52384 = oops.state.prepare_state.call(null,target_obj_52380,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52384);

try{var next_obj_52381 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52380,(0),"chrome",true,true,false))?(target_obj_52380["chrome"]):null);
var next_obj_52382 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52381,(0),"tabs",true,true,false))?(next_obj_52381["tabs"]):null);
return next_obj_52382;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52383);
}})();
var missing_api_52377 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.onHighlightChanged",ns_obj_52376,"onHighlightChanged");
})();
if(missing_api_52377 === true){
return null;
} else {
var event_obj_52374 = (function (){var target_obj_52385 = ns_obj_52376;
var _STAR_runtime_state_STAR__orig_val__52387 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52388 = oops.state.prepare_state.call(null,target_obj_52385,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52388);

try{var next_obj_52386 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52385,(0),"onHighlightChanged",true,true,false))?(target_obj_52385["onHighlightChanged"]):null);
return next_obj_52386;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52387);
}})();
var result_52375 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_52374,logging_fn_52373,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_52375,args);

return result_52375;
}
}));

(chromex.ext.tabs.on_highlight_changed_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.tabs.on_highlight_changed_STAR_.cljs$lang$applyTo = (function (seq52368){
var G__52369 = cljs.core.first.call(null,seq52368);
var seq52368__$1 = cljs.core.next.call(null,seq52368);
var G__52370 = cljs.core.first.call(null,seq52368__$1);
var seq52368__$2 = cljs.core.next.call(null,seq52368__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__52369,G__52370,seq52368__$2);
}));

chromex.ext.tabs.on_highlighted_STAR_ = (function chromex$ext$tabs$on_highlighted_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___52416 = arguments.length;
var i__4790__auto___52417 = (0);
while(true){
if((i__4790__auto___52417 < len__4789__auto___52416)){
args__4795__auto__.push((arguments[i__4790__auto___52417]));

var G__52418 = (i__4790__auto___52417 + (1));
i__4790__auto___52417 = G__52418;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_highlighted_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.tabs.on_highlighted_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_52398 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.tabs","on-highlighted","chromex.ext.tabs/on-highlighted",-1775951984),channel);
})();
var handler_fn_52399 = (function (cb_highlight_info_52405){
return event_fn_52398.call(null,cb_highlight_info_52405);
});
var logging_fn_52400 = (function (cb_param_highlight_info_52406){
var config__25890__auto___52419 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52419))){
var logger__25891__auto___52420 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52419);
var prefix__25892__auto___52421 = ["event:","chrome.tabs.onHighlighted"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52420)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52419)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52420.apply(null,prefix__25892__auto___52421.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_highlight_info_52406], null))));
} else {
}

return handler_fn_52399.call(null,cb_param_highlight_info_52406);
});
var ns_obj_52403 = (function (){var target_obj_52407 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52410 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52411 = oops.state.prepare_state.call(null,target_obj_52407,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52411);

try{var next_obj_52408 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52407,(0),"chrome",true,true,false))?(target_obj_52407["chrome"]):null);
var next_obj_52409 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52408,(0),"tabs",true,true,false))?(next_obj_52408["tabs"]):null);
return next_obj_52409;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52410);
}})();
var missing_api_52404 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.onHighlighted",ns_obj_52403,"onHighlighted");
})();
if(missing_api_52404 === true){
return null;
} else {
var event_obj_52401 = (function (){var target_obj_52412 = ns_obj_52403;
var _STAR_runtime_state_STAR__orig_val__52414 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52415 = oops.state.prepare_state.call(null,target_obj_52412,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52415);

try{var next_obj_52413 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52412,(0),"onHighlighted",true,true,false))?(target_obj_52412["onHighlighted"]):null);
return next_obj_52413;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52414);
}})();
var result_52402 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_52401,logging_fn_52400,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_52402,args);

return result_52402;
}
}));

(chromex.ext.tabs.on_highlighted_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.tabs.on_highlighted_STAR_.cljs$lang$applyTo = (function (seq52395){
var G__52396 = cljs.core.first.call(null,seq52395);
var seq52395__$1 = cljs.core.next.call(null,seq52395);
var G__52397 = cljs.core.first.call(null,seq52395__$1);
var seq52395__$2 = cljs.core.next.call(null,seq52395__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__52396,G__52397,seq52395__$2);
}));

chromex.ext.tabs.on_detached_STAR_ = (function chromex$ext$tabs$on_detached_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___52445 = arguments.length;
var i__4790__auto___52446 = (0);
while(true){
if((i__4790__auto___52446 < len__4789__auto___52445)){
args__4795__auto__.push((arguments[i__4790__auto___52446]));

var G__52447 = (i__4790__auto___52446 + (1));
i__4790__auto___52446 = G__52447;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_detached_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.tabs.on_detached_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_52425 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.tabs","on-detached","chromex.ext.tabs/on-detached",-1496085468),channel);
})();
var handler_fn_52426 = (function (cb_tab_id_52432,cb_detach_info_52433){
return event_fn_52425.call(null,cb_tab_id_52432,cb_detach_info_52433);
});
var logging_fn_52427 = (function (cb_param_tab_id_52434,cb_param_detach_info_52435){
var config__25890__auto___52448 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52448))){
var logger__25891__auto___52449 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52448);
var prefix__25892__auto___52450 = ["event:","chrome.tabs.onDetached"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52449)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52448)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52449.apply(null,prefix__25892__auto___52450.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_tab_id_52434,cb_param_detach_info_52435], null))));
} else {
}

return handler_fn_52426.call(null,cb_param_tab_id_52434,cb_param_detach_info_52435);
});
var ns_obj_52430 = (function (){var target_obj_52436 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52439 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52440 = oops.state.prepare_state.call(null,target_obj_52436,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52440);

try{var next_obj_52437 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52436,(0),"chrome",true,true,false))?(target_obj_52436["chrome"]):null);
var next_obj_52438 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52437,(0),"tabs",true,true,false))?(next_obj_52437["tabs"]):null);
return next_obj_52438;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52439);
}})();
var missing_api_52431 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.onDetached",ns_obj_52430,"onDetached");
})();
if(missing_api_52431 === true){
return null;
} else {
var event_obj_52428 = (function (){var target_obj_52441 = ns_obj_52430;
var _STAR_runtime_state_STAR__orig_val__52443 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52444 = oops.state.prepare_state.call(null,target_obj_52441,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52444);

try{var next_obj_52442 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52441,(0),"onDetached",true,true,false))?(target_obj_52441["onDetached"]):null);
return next_obj_52442;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52443);
}})();
var result_52429 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_52428,logging_fn_52427,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_52429,args);

return result_52429;
}
}));

(chromex.ext.tabs.on_detached_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.tabs.on_detached_STAR_.cljs$lang$applyTo = (function (seq52422){
var G__52423 = cljs.core.first.call(null,seq52422);
var seq52422__$1 = cljs.core.next.call(null,seq52422);
var G__52424 = cljs.core.first.call(null,seq52422__$1);
var seq52422__$2 = cljs.core.next.call(null,seq52422__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__52423,G__52424,seq52422__$2);
}));

chromex.ext.tabs.on_attached_STAR_ = (function chromex$ext$tabs$on_attached_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___52474 = arguments.length;
var i__4790__auto___52475 = (0);
while(true){
if((i__4790__auto___52475 < len__4789__auto___52474)){
args__4795__auto__.push((arguments[i__4790__auto___52475]));

var G__52476 = (i__4790__auto___52475 + (1));
i__4790__auto___52475 = G__52476;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_attached_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.tabs.on_attached_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_52454 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.tabs","on-attached","chromex.ext.tabs/on-attached",1214482162),channel);
})();
var handler_fn_52455 = (function (cb_tab_id_52461,cb_attach_info_52462){
return event_fn_52454.call(null,cb_tab_id_52461,cb_attach_info_52462);
});
var logging_fn_52456 = (function (cb_param_tab_id_52463,cb_param_attach_info_52464){
var config__25890__auto___52477 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52477))){
var logger__25891__auto___52478 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52477);
var prefix__25892__auto___52479 = ["event:","chrome.tabs.onAttached"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52478)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52477)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52478.apply(null,prefix__25892__auto___52479.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_tab_id_52463,cb_param_attach_info_52464], null))));
} else {
}

return handler_fn_52455.call(null,cb_param_tab_id_52463,cb_param_attach_info_52464);
});
var ns_obj_52459 = (function (){var target_obj_52465 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52468 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52469 = oops.state.prepare_state.call(null,target_obj_52465,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52469);

try{var next_obj_52466 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52465,(0),"chrome",true,true,false))?(target_obj_52465["chrome"]):null);
var next_obj_52467 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52466,(0),"tabs",true,true,false))?(next_obj_52466["tabs"]):null);
return next_obj_52467;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52468);
}})();
var missing_api_52460 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.onAttached",ns_obj_52459,"onAttached");
})();
if(missing_api_52460 === true){
return null;
} else {
var event_obj_52457 = (function (){var target_obj_52470 = ns_obj_52459;
var _STAR_runtime_state_STAR__orig_val__52472 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52473 = oops.state.prepare_state.call(null,target_obj_52470,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52473);

try{var next_obj_52471 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52470,(0),"onAttached",true,true,false))?(target_obj_52470["onAttached"]):null);
return next_obj_52471;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52472);
}})();
var result_52458 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_52457,logging_fn_52456,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_52458,args);

return result_52458;
}
}));

(chromex.ext.tabs.on_attached_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.tabs.on_attached_STAR_.cljs$lang$applyTo = (function (seq52451){
var G__52452 = cljs.core.first.call(null,seq52451);
var seq52451__$1 = cljs.core.next.call(null,seq52451);
var G__52453 = cljs.core.first.call(null,seq52451__$1);
var seq52451__$2 = cljs.core.next.call(null,seq52451__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__52452,G__52453,seq52451__$2);
}));

chromex.ext.tabs.on_removed_STAR_ = (function chromex$ext$tabs$on_removed_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___52503 = arguments.length;
var i__4790__auto___52504 = (0);
while(true){
if((i__4790__auto___52504 < len__4789__auto___52503)){
args__4795__auto__.push((arguments[i__4790__auto___52504]));

var G__52505 = (i__4790__auto___52504 + (1));
i__4790__auto___52504 = G__52505;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_removed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.tabs.on_removed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_52483 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.tabs","on-removed","chromex.ext.tabs/on-removed",972024471),channel);
})();
var handler_fn_52484 = (function (cb_tab_id_52490,cb_remove_info_52491){
return event_fn_52483.call(null,cb_tab_id_52490,cb_remove_info_52491);
});
var logging_fn_52485 = (function (cb_param_tab_id_52492,cb_param_remove_info_52493){
var config__25890__auto___52506 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52506))){
var logger__25891__auto___52507 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52506);
var prefix__25892__auto___52508 = ["event:","chrome.tabs.onRemoved"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52507)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52506)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52507.apply(null,prefix__25892__auto___52508.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_tab_id_52492,cb_param_remove_info_52493], null))));
} else {
}

return handler_fn_52484.call(null,cb_param_tab_id_52492,cb_param_remove_info_52493);
});
var ns_obj_52488 = (function (){var target_obj_52494 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52497 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52498 = oops.state.prepare_state.call(null,target_obj_52494,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52498);

try{var next_obj_52495 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52494,(0),"chrome",true,true,false))?(target_obj_52494["chrome"]):null);
var next_obj_52496 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52495,(0),"tabs",true,true,false))?(next_obj_52495["tabs"]):null);
return next_obj_52496;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52497);
}})();
var missing_api_52489 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.onRemoved",ns_obj_52488,"onRemoved");
})();
if(missing_api_52489 === true){
return null;
} else {
var event_obj_52486 = (function (){var target_obj_52499 = ns_obj_52488;
var _STAR_runtime_state_STAR__orig_val__52501 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52502 = oops.state.prepare_state.call(null,target_obj_52499,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52502);

try{var next_obj_52500 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52499,(0),"onRemoved",true,true,false))?(target_obj_52499["onRemoved"]):null);
return next_obj_52500;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52501);
}})();
var result_52487 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_52486,logging_fn_52485,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_52487,args);

return result_52487;
}
}));

(chromex.ext.tabs.on_removed_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.tabs.on_removed_STAR_.cljs$lang$applyTo = (function (seq52480){
var G__52481 = cljs.core.first.call(null,seq52480);
var seq52480__$1 = cljs.core.next.call(null,seq52480);
var G__52482 = cljs.core.first.call(null,seq52480__$1);
var seq52480__$2 = cljs.core.next.call(null,seq52480__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__52481,G__52482,seq52480__$2);
}));

chromex.ext.tabs.on_replaced_STAR_ = (function chromex$ext$tabs$on_replaced_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___52532 = arguments.length;
var i__4790__auto___52533 = (0);
while(true){
if((i__4790__auto___52533 < len__4789__auto___52532)){
args__4795__auto__.push((arguments[i__4790__auto___52533]));

var G__52534 = (i__4790__auto___52533 + (1));
i__4790__auto___52533 = G__52534;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_replaced_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.tabs.on_replaced_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_52512 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.tabs","on-replaced","chromex.ext.tabs/on-replaced",-2107870101),channel);
})();
var handler_fn_52513 = (function (cb_added_tab_id_52519,cb_removed_tab_id_52520){
return event_fn_52512.call(null,cb_added_tab_id_52519,cb_removed_tab_id_52520);
});
var logging_fn_52514 = (function (cb_param_added_tab_id_52521,cb_param_removed_tab_id_52522){
var config__25890__auto___52535 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52535))){
var logger__25891__auto___52536 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52535);
var prefix__25892__auto___52537 = ["event:","chrome.tabs.onReplaced"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52536)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52535)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52536.apply(null,prefix__25892__auto___52537.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_added_tab_id_52521,cb_param_removed_tab_id_52522], null))));
} else {
}

return handler_fn_52513.call(null,cb_param_added_tab_id_52521,cb_param_removed_tab_id_52522);
});
var ns_obj_52517 = (function (){var target_obj_52523 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52526 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52527 = oops.state.prepare_state.call(null,target_obj_52523,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52527);

try{var next_obj_52524 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52523,(0),"chrome",true,true,false))?(target_obj_52523["chrome"]):null);
var next_obj_52525 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52524,(0),"tabs",true,true,false))?(next_obj_52524["tabs"]):null);
return next_obj_52525;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52526);
}})();
var missing_api_52518 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.onReplaced",ns_obj_52517,"onReplaced");
})();
if(missing_api_52518 === true){
return null;
} else {
var event_obj_52515 = (function (){var target_obj_52528 = ns_obj_52517;
var _STAR_runtime_state_STAR__orig_val__52530 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52531 = oops.state.prepare_state.call(null,target_obj_52528,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52531);

try{var next_obj_52529 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52528,(0),"onReplaced",true,true,false))?(target_obj_52528["onReplaced"]):null);
return next_obj_52529;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52530);
}})();
var result_52516 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_52515,logging_fn_52514,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_52516,args);

return result_52516;
}
}));

(chromex.ext.tabs.on_replaced_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.tabs.on_replaced_STAR_.cljs$lang$applyTo = (function (seq52509){
var G__52510 = cljs.core.first.call(null,seq52509);
var seq52509__$1 = cljs.core.next.call(null,seq52509);
var G__52511 = cljs.core.first.call(null,seq52509__$1);
var seq52509__$2 = cljs.core.next.call(null,seq52509__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__52510,G__52511,seq52509__$2);
}));

chromex.ext.tabs.on_zoom_change_STAR_ = (function chromex$ext$tabs$on_zoom_change_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___52559 = arguments.length;
var i__4790__auto___52560 = (0);
while(true){
if((i__4790__auto___52560 < len__4789__auto___52559)){
args__4795__auto__.push((arguments[i__4790__auto___52560]));

var G__52561 = (i__4790__auto___52560 + (1));
i__4790__auto___52560 = G__52561;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_zoom_change_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.tabs.on_zoom_change_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_52541 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.tabs","on-zoom-change","chromex.ext.tabs/on-zoom-change",1403421586),channel);
})();
var handler_fn_52542 = (function (cb_zoom_change_info_52548){
return event_fn_52541.call(null,cb_zoom_change_info_52548);
});
var logging_fn_52543 = (function (cb_param_zoom_change_info_52549){
var config__25890__auto___52562 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52562))){
var logger__25891__auto___52563 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___52562);
var prefix__25892__auto___52564 = ["event:","chrome.tabs.onZoomChange"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___52563)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___52562)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___52563.apply(null,prefix__25892__auto___52564.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_zoom_change_info_52549], null))));
} else {
}

return handler_fn_52542.call(null,cb_param_zoom_change_info_52549);
});
var ns_obj_52546 = (function (){var target_obj_52550 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__52553 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52554 = oops.state.prepare_state.call(null,target_obj_52550,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52554);

try{var next_obj_52551 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52550,(0),"chrome",true,true,false))?(target_obj_52550["chrome"]):null);
var next_obj_52552 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_52551,(0),"tabs",true,true,false))?(next_obj_52551["tabs"]):null);
return next_obj_52552;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52553);
}})();
var missing_api_52547 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.tabs.onZoomChange",ns_obj_52546,"onZoomChange");
})();
if(missing_api_52547 === true){
return null;
} else {
var event_obj_52544 = (function (){var target_obj_52555 = ns_obj_52546;
var _STAR_runtime_state_STAR__orig_val__52557 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__52558 = oops.state.prepare_state.call(null,target_obj_52555,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__52558);

try{var next_obj_52556 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_52555,(0),"onZoomChange",true,true,false))?(target_obj_52555["onZoomChange"]):null);
return next_obj_52556;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__52557);
}})();
var result_52545 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_52544,logging_fn_52543,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_52545,args);

return result_52545;
}
}));

(chromex.ext.tabs.on_zoom_change_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.tabs.on_zoom_change_STAR_.cljs$lang$applyTo = (function (seq52538){
var G__52539 = cljs.core.first.call(null,seq52538);
var seq52538__$1 = cljs.core.next.call(null,seq52538);
var G__52540 = cljs.core.first.call(null,seq52538__$1);
var seq52538__$2 = cljs.core.next.call(null,seq52538__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__52539,G__52540,seq52538__$2);
}));


//# sourceMappingURL=tabs.js.map
