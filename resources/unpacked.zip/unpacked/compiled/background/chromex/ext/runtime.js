// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex.ext.runtime');
goog.require('cljs.core');
goog.require('chromex.core');
chromex.ext.runtime.last_error_STAR_ = (function chromex$ext$runtime$last_error_STAR_(config){
var result_49221 = (function (){var final_args_array_49222 = chromex.support.prepare_final_args_array.call(null,cljs.core.PersistentVector.EMPTY,"chrome.runtime.lastError");
var ns_49223 = (function (){var target_obj_49226 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49229 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49230 = oops.state.prepare_state.call(null,target_obj_49226,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49230);

try{var next_obj_49227 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49226,(0),"chrome",true,true,false))?(target_obj_49226["chrome"]):null);
var next_obj_49228 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49227,(0),"runtime",true,true,false))?(next_obj_49227["runtime"]):null);
return next_obj_49228;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49229);
}})();
var missing_api_49224 = null;
if(missing_api_49224 === true){
return null;
} else {
var config__25890__auto___49235 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49235))){
var logger__25891__auto___49236 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49235);
var prefix__25892__auto___49237 = ["accessing:","chrome.runtime.lastError"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49236)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49235)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49236.apply(null,prefix__25892__auto___49237.concat(final_args_array_49222));
} else {
}

var target_49225 = (function (){var target_obj_49231 = ns_49223;
var _STAR_runtime_state_STAR__orig_val__49233 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49234 = oops.state.prepare_state.call(null,target_obj_49231,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49234);

try{var next_obj_49232 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49231,(1),"lastError",true,true,false))?(target_obj_49231["lastError"]):null);
if((!((next_obj_49232 == null)))){
return next_obj_49232;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49233);
}})();
return target_49225;
}
})();
return result_49221;
});
chromex.ext.runtime.id_STAR_ = (function chromex$ext$runtime$id_STAR_(config){
var result_49238 = (function (){var final_args_array_49239 = chromex.support.prepare_final_args_array.call(null,cljs.core.PersistentVector.EMPTY,"chrome.runtime.id");
var ns_49240 = (function (){var target_obj_49243 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49246 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49247 = oops.state.prepare_state.call(null,target_obj_49243,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49247);

try{var next_obj_49244 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49243,(0),"chrome",true,true,false))?(target_obj_49243["chrome"]):null);
var next_obj_49245 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49244,(0),"runtime",true,true,false))?(next_obj_49244["runtime"]):null);
return next_obj_49245;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49246);
}})();
var missing_api_49241 = null;
if(missing_api_49241 === true){
return null;
} else {
var config__25890__auto___49252 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49252))){
var logger__25891__auto___49253 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49252);
var prefix__25892__auto___49254 = ["accessing:","chrome.runtime.id"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49253)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49252)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49253.apply(null,prefix__25892__auto___49254.concat(final_args_array_49239));
} else {
}

var target_49242 = (function (){var target_obj_49248 = ns_49240;
var _STAR_runtime_state_STAR__orig_val__49250 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49251 = oops.state.prepare_state.call(null,target_obj_49248,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49251);

try{var next_obj_49249 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49248,(1),"id",true,true,false))?(target_obj_49248["id"]):null);
if((!((next_obj_49249 == null)))){
return next_obj_49249;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49250);
}})();
return target_49242;
}
})();
return result_49238;
});
chromex.ext.runtime.get_background_page_STAR_ = (function chromex$ext$runtime$get_background_page_STAR_(config){
var callback_chan_49255 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_callback_49257_49272 = (function (cb_background_page_49262){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.runtime","get-background-page","chromex.ext.runtime/get-background-page",2138227095),new cljs.core.Keyword(null,"name","name",1843675177),"getBackgroundPage",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"background-page",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"Window"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_49255);
})().call(null,cb_background_page_49262);
});
var result_49256_49273 = (function (){var final_args_array_49258 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_49257_49272,"callback",null], null)], null),"chrome.runtime.getBackgroundPage");
var ns_49259 = (function (){var target_obj_49263 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49266 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49267 = oops.state.prepare_state.call(null,target_obj_49263,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49267);

try{var next_obj_49264 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49263,(0),"chrome",true,true,false))?(target_obj_49263["chrome"]):null);
var next_obj_49265 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49264,(0),"runtime",true,true,false))?(next_obj_49264["runtime"]):null);
return next_obj_49265;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49266);
}})();
var missing_api_49260 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.getBackgroundPage",ns_49259,"getBackgroundPage");
})();
if(missing_api_49260 === true){
return null;
} else {
var config__25890__auto___49274 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49274))){
var logger__25891__auto___49275 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49274);
var prefix__25892__auto___49276 = ["calling:","chrome.runtime.getBackgroundPage"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49275)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49274)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49275.apply(null,prefix__25892__auto___49276.concat(final_args_array_49258));
} else {
}

var target_49261 = (function (){var target_obj_49268 = ns_49259;
var _STAR_runtime_state_STAR__orig_val__49270 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49271 = oops.state.prepare_state.call(null,target_obj_49268,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49271);

try{var next_obj_49269 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49268,(1),"getBackgroundPage",true,true,false))?(target_obj_49268["getBackgroundPage"]):null);
if((!((next_obj_49269 == null)))){
return next_obj_49269;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49270);
}})();
return target_49261.apply(ns_49259,final_args_array_49258);
}
})();

return callback_chan_49255;
});
chromex.ext.runtime.open_options_page_STAR_ = (function chromex$ext$runtime$open_options_page_STAR_(config){
var callback_chan_49277 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_callback_49279_49293 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.runtime","open-options-page","chromex.ext.runtime/open-options-page",-236868215),new cljs.core.Keyword(null,"name","name",1843675177),"openOptionsPage",new cljs.core.Keyword(null,"since","since",315379842),"42",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_49277);
})();
var result_49278_49294 = (function (){var final_args_array_49280 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_49279_49293,"callback",true], null)], null),"chrome.runtime.openOptionsPage");
var ns_49281 = (function (){var target_obj_49284 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49287 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49288 = oops.state.prepare_state.call(null,target_obj_49284,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49288);

try{var next_obj_49285 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49284,(0),"chrome",true,true,false))?(target_obj_49284["chrome"]):null);
var next_obj_49286 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49285,(0),"runtime",true,true,false))?(next_obj_49285["runtime"]):null);
return next_obj_49286;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49287);
}})();
var missing_api_49282 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.openOptionsPage",ns_49281,"openOptionsPage");
})();
if(missing_api_49282 === true){
return null;
} else {
var config__25890__auto___49295 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49295))){
var logger__25891__auto___49296 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49295);
var prefix__25892__auto___49297 = ["calling:","chrome.runtime.openOptionsPage"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49296)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49295)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49296.apply(null,prefix__25892__auto___49297.concat(final_args_array_49280));
} else {
}

var target_49283 = (function (){var target_obj_49289 = ns_49281;
var _STAR_runtime_state_STAR__orig_val__49291 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49292 = oops.state.prepare_state.call(null,target_obj_49289,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49292);

try{var next_obj_49290 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49289,(1),"openOptionsPage",true,true,false))?(target_obj_49289["openOptionsPage"]):null);
if((!((next_obj_49290 == null)))){
return next_obj_49290;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49291);
}})();
return target_49283.apply(ns_49281,final_args_array_49280);
}
})();

return callback_chan_49277;
});
chromex.ext.runtime.get_manifest_STAR_ = (function chromex$ext$runtime$get_manifest_STAR_(config){
var result_49298 = (function (){var final_args_array_49299 = chromex.support.prepare_final_args_array.call(null,cljs.core.PersistentVector.EMPTY,"chrome.runtime.getManifest");
var ns_49300 = (function (){var target_obj_49303 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49306 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49307 = oops.state.prepare_state.call(null,target_obj_49303,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49307);

try{var next_obj_49304 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49303,(0),"chrome",true,true,false))?(target_obj_49303["chrome"]):null);
var next_obj_49305 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49304,(0),"runtime",true,true,false))?(next_obj_49304["runtime"]):null);
return next_obj_49305;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49306);
}})();
var missing_api_49301 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.getManifest",ns_49300,"getManifest");
})();
if(missing_api_49301 === true){
return null;
} else {
var config__25890__auto___49312 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49312))){
var logger__25891__auto___49313 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49312);
var prefix__25892__auto___49314 = ["calling:","chrome.runtime.getManifest"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49313)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49312)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49313.apply(null,prefix__25892__auto___49314.concat(final_args_array_49299));
} else {
}

var target_49302 = (function (){var target_obj_49308 = ns_49300;
var _STAR_runtime_state_STAR__orig_val__49310 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49311 = oops.state.prepare_state.call(null,target_obj_49308,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49311);

try{var next_obj_49309 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49308,(1),"getManifest",true,true,false))?(target_obj_49308["getManifest"]):null);
if((!((next_obj_49309 == null)))){
return next_obj_49309;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49310);
}})();
return target_49302.apply(ns_49300,final_args_array_49299);
}
})();
return result_49298;
});
chromex.ext.runtime.get_url_STAR_ = (function chromex$ext$runtime$get_url_STAR_(config,path){
var marshalled_path_49316 = (function (){var omit_test_49321 = path;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_49321,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_49321;
}
})();
var result_49315 = (function (){var final_args_array_49317 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_path_49316,"path",null], null)], null),"chrome.runtime.getURL");
var ns_49318 = (function (){var target_obj_49322 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49325 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49326 = oops.state.prepare_state.call(null,target_obj_49322,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49326);

try{var next_obj_49323 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49322,(0),"chrome",true,true,false))?(target_obj_49322["chrome"]):null);
var next_obj_49324 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49323,(0),"runtime",true,true,false))?(next_obj_49323["runtime"]):null);
return next_obj_49324;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49325);
}})();
var missing_api_49319 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.getURL",ns_49318,"getURL");
})();
if(missing_api_49319 === true){
return null;
} else {
var config__25890__auto___49331 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49331))){
var logger__25891__auto___49332 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49331);
var prefix__25892__auto___49333 = ["calling:","chrome.runtime.getURL"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49332)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49331)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49332.apply(null,prefix__25892__auto___49333.concat(final_args_array_49317));
} else {
}

var target_49320 = (function (){var target_obj_49327 = ns_49318;
var _STAR_runtime_state_STAR__orig_val__49329 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49330 = oops.state.prepare_state.call(null,target_obj_49327,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49330);

try{var next_obj_49328 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49327,(1),"getURL",true,true,false))?(target_obj_49327["getURL"]):null);
if((!((next_obj_49328 == null)))){
return next_obj_49328;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49329);
}})();
return target_49320.apply(ns_49318,final_args_array_49317);
}
})();
return result_49315;
});
chromex.ext.runtime.set_uninstall_url_STAR_ = (function chromex$ext$runtime$set_uninstall_url_STAR_(config,url){
var callback_chan_49334 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_url_49336_49352 = (function (){var omit_test_49342 = url;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_49342,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_49342;
}
})();
var marshalled_callback_49337_49353 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.runtime","set-uninstall-url","chromex.ext.runtime/set-uninstall-url",-1010845784),new cljs.core.Keyword(null,"name","name",1843675177),"setUninstallURL",new cljs.core.Keyword(null,"since","since",315379842),"41",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"url",new cljs.core.Keyword(null,"since","since",315379842),"34",new cljs.core.Keyword(null,"type","type",1174270348),"string"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_49334);
})();
var result_49335_49354 = (function (){var final_args_array_49338 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_url_49336_49352,"url",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_49337_49353,"callback",true], null)], null),"chrome.runtime.setUninstallURL");
var ns_49339 = (function (){var target_obj_49343 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49346 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49347 = oops.state.prepare_state.call(null,target_obj_49343,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49347);

try{var next_obj_49344 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49343,(0),"chrome",true,true,false))?(target_obj_49343["chrome"]):null);
var next_obj_49345 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49344,(0),"runtime",true,true,false))?(next_obj_49344["runtime"]):null);
return next_obj_49345;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49346);
}})();
var missing_api_49340 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.setUninstallURL",ns_49339,"setUninstallURL");
})();
if(missing_api_49340 === true){
return null;
} else {
var config__25890__auto___49355 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49355))){
var logger__25891__auto___49356 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49355);
var prefix__25892__auto___49357 = ["calling:","chrome.runtime.setUninstallURL"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49356)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49355)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49356.apply(null,prefix__25892__auto___49357.concat(final_args_array_49338));
} else {
}

var target_49341 = (function (){var target_obj_49348 = ns_49339;
var _STAR_runtime_state_STAR__orig_val__49350 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49351 = oops.state.prepare_state.call(null,target_obj_49348,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49351);

try{var next_obj_49349 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49348,(1),"setUninstallURL",true,true,false))?(target_obj_49348["setUninstallURL"]):null);
if((!((next_obj_49349 == null)))){
return next_obj_49349;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49350);
}})();
return target_49341.apply(ns_49339,final_args_array_49338);
}
})();

return callback_chan_49334;
});
chromex.ext.runtime.reload_STAR_ = (function chromex$ext$runtime$reload_STAR_(config){
var result_49358 = (function (){var final_args_array_49359 = chromex.support.prepare_final_args_array.call(null,cljs.core.PersistentVector.EMPTY,"chrome.runtime.reload");
var ns_49360 = (function (){var target_obj_49363 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49366 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49367 = oops.state.prepare_state.call(null,target_obj_49363,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49367);

try{var next_obj_49364 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49363,(0),"chrome",true,true,false))?(target_obj_49363["chrome"]):null);
var next_obj_49365 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49364,(0),"runtime",true,true,false))?(next_obj_49364["runtime"]):null);
return next_obj_49365;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49366);
}})();
var missing_api_49361 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.reload",ns_49360,"reload");
})();
if(missing_api_49361 === true){
return null;
} else {
var config__25890__auto___49372 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49372))){
var logger__25891__auto___49373 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49372);
var prefix__25892__auto___49374 = ["calling:","chrome.runtime.reload"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49373)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49372)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49373.apply(null,prefix__25892__auto___49374.concat(final_args_array_49359));
} else {
}

var target_49362 = (function (){var target_obj_49368 = ns_49360;
var _STAR_runtime_state_STAR__orig_val__49370 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49371 = oops.state.prepare_state.call(null,target_obj_49368,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49371);

try{var next_obj_49369 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49368,(1),"reload",true,true,false))?(target_obj_49368["reload"]):null);
if((!((next_obj_49369 == null)))){
return next_obj_49369;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49370);
}})();
return target_49362.apply(ns_49360,final_args_array_49359);
}
})();
return result_49358;
});
chromex.ext.runtime.request_update_check_STAR_ = (function chromex$ext$runtime$request_update_check_STAR_(config){
var callback_chan_49375 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_callback_49377_49393 = (function (cb_status_49382,cb_details_49383){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.runtime","request-update-check","chromex.ext.runtime/request-update-check",-1504783873),new cljs.core.Keyword(null,"name","name",1843675177),"requestUpdateCheck",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"status",new cljs.core.Keyword(null,"type","type",1174270348),"runtime.RequestUpdateCheckStatus"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"details",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"object"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_49375);
})().call(null,cb_status_49382,cb_details_49383);
});
var result_49376_49394 = (function (){var final_args_array_49378 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_49377_49393,"callback",null], null)], null),"chrome.runtime.requestUpdateCheck");
var ns_49379 = (function (){var target_obj_49384 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49387 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49388 = oops.state.prepare_state.call(null,target_obj_49384,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49388);

try{var next_obj_49385 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49384,(0),"chrome",true,true,false))?(target_obj_49384["chrome"]):null);
var next_obj_49386 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49385,(0),"runtime",true,true,false))?(next_obj_49385["runtime"]):null);
return next_obj_49386;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49387);
}})();
var missing_api_49380 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.requestUpdateCheck",ns_49379,"requestUpdateCheck");
})();
if(missing_api_49380 === true){
return null;
} else {
var config__25890__auto___49395 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49395))){
var logger__25891__auto___49396 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49395);
var prefix__25892__auto___49397 = ["calling:","chrome.runtime.requestUpdateCheck"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49396)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49395)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49396.apply(null,prefix__25892__auto___49397.concat(final_args_array_49378));
} else {
}

var target_49381 = (function (){var target_obj_49389 = ns_49379;
var _STAR_runtime_state_STAR__orig_val__49391 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49392 = oops.state.prepare_state.call(null,target_obj_49389,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49392);

try{var next_obj_49390 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49389,(1),"requestUpdateCheck",true,true,false))?(target_obj_49389["requestUpdateCheck"]):null);
if((!((next_obj_49390 == null)))){
return next_obj_49390;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49391);
}})();
return target_49381.apply(ns_49379,final_args_array_49378);
}
})();

return callback_chan_49375;
});
chromex.ext.runtime.restart_STAR_ = (function chromex$ext$runtime$restart_STAR_(config){
var result_49398 = (function (){var final_args_array_49399 = chromex.support.prepare_final_args_array.call(null,cljs.core.PersistentVector.EMPTY,"chrome.runtime.restart");
var ns_49400 = (function (){var target_obj_49403 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49406 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49407 = oops.state.prepare_state.call(null,target_obj_49403,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49407);

try{var next_obj_49404 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49403,(0),"chrome",true,true,false))?(target_obj_49403["chrome"]):null);
var next_obj_49405 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49404,(0),"runtime",true,true,false))?(next_obj_49404["runtime"]):null);
return next_obj_49405;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49406);
}})();
var missing_api_49401 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.restart",ns_49400,"restart");
})();
if(missing_api_49401 === true){
return null;
} else {
var config__25890__auto___49412 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49412))){
var logger__25891__auto___49413 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49412);
var prefix__25892__auto___49414 = ["calling:","chrome.runtime.restart"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49413)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49412)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49413.apply(null,prefix__25892__auto___49414.concat(final_args_array_49399));
} else {
}

var target_49402 = (function (){var target_obj_49408 = ns_49400;
var _STAR_runtime_state_STAR__orig_val__49410 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49411 = oops.state.prepare_state.call(null,target_obj_49408,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49411);

try{var next_obj_49409 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49408,(1),"restart",true,true,false))?(target_obj_49408["restart"]):null);
if((!((next_obj_49409 == null)))){
return next_obj_49409;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49410);
}})();
return target_49402.apply(ns_49400,final_args_array_49399);
}
})();
return result_49398;
});
chromex.ext.runtime.restart_after_delay_STAR_ = (function chromex$ext$runtime$restart_after_delay_STAR_(config,seconds){
var callback_chan_49415 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_seconds_49417_49433 = (function (){var omit_test_49423 = seconds;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_49423,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_49423;
}
})();
var marshalled_callback_49418_49434 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.runtime","restart-after-delay","chromex.ext.runtime/restart-after-delay",-1851581361),new cljs.core.Keyword(null,"name","name",1843675177),"restartAfterDelay",new cljs.core.Keyword(null,"since","since",315379842),"53",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"seconds",new cljs.core.Keyword(null,"type","type",1174270348),"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_49415);
})();
var result_49416_49435 = (function (){var final_args_array_49419 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_seconds_49417_49433,"seconds",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_49418_49434,"callback",true], null)], null),"chrome.runtime.restartAfterDelay");
var ns_49420 = (function (){var target_obj_49424 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49427 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49428 = oops.state.prepare_state.call(null,target_obj_49424,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49428);

try{var next_obj_49425 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49424,(0),"chrome",true,true,false))?(target_obj_49424["chrome"]):null);
var next_obj_49426 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49425,(0),"runtime",true,true,false))?(next_obj_49425["runtime"]):null);
return next_obj_49426;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49427);
}})();
var missing_api_49421 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.restartAfterDelay",ns_49420,"restartAfterDelay");
})();
if(missing_api_49421 === true){
return null;
} else {
var config__25890__auto___49436 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49436))){
var logger__25891__auto___49437 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49436);
var prefix__25892__auto___49438 = ["calling:","chrome.runtime.restartAfterDelay"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49437)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49436)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49437.apply(null,prefix__25892__auto___49438.concat(final_args_array_49419));
} else {
}

var target_49422 = (function (){var target_obj_49429 = ns_49420;
var _STAR_runtime_state_STAR__orig_val__49431 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49432 = oops.state.prepare_state.call(null,target_obj_49429,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49432);

try{var next_obj_49430 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49429,(1),"restartAfterDelay",true,true,false))?(target_obj_49429["restartAfterDelay"]):null);
if((!((next_obj_49430 == null)))){
return next_obj_49430;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49431);
}})();
return target_49422.apply(ns_49420,final_args_array_49419);
}
})();

return callback_chan_49415;
});
chromex.ext.runtime.connect_STAR_ = (function chromex$ext$runtime$connect_STAR_(config,extension_id,connect_info){
var marshalled_extension_id_49440 = (function (){var omit_test_49446 = extension_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_49446,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_49446;
}
})();
var marshalled_connect_info_49441 = (function (){var omit_test_49447 = connect_info;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_49447,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_49447;
}
})();
var result_49439 = (function (){var final_args_array_49442 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_49440,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_connect_info_49441,"connect-info",true], null)], null),"chrome.runtime.connect");
var ns_49443 = (function (){var target_obj_49448 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49451 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49452 = oops.state.prepare_state.call(null,target_obj_49448,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49452);

try{var next_obj_49449 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49448,(0),"chrome",true,true,false))?(target_obj_49448["chrome"]):null);
var next_obj_49450 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49449,(0),"runtime",true,true,false))?(next_obj_49449["runtime"]):null);
return next_obj_49450;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49451);
}})();
var missing_api_49444 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.connect",ns_49443,"connect");
})();
if(missing_api_49444 === true){
return null;
} else {
var config__25890__auto___49457 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49457))){
var logger__25891__auto___49458 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49457);
var prefix__25892__auto___49459 = ["calling:","chrome.runtime.connect"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49458)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49457)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49458.apply(null,prefix__25892__auto___49459.concat(final_args_array_49442));
} else {
}

var target_49445 = (function (){var target_obj_49453 = ns_49443;
var _STAR_runtime_state_STAR__orig_val__49455 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49456 = oops.state.prepare_state.call(null,target_obj_49453,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49456);

try{var next_obj_49454 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49453,(1),"connect",true,true,false))?(target_obj_49453["connect"]):null);
if((!((next_obj_49454 == null)))){
return next_obj_49454;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49455);
}})();
return target_49445.apply(ns_49443,final_args_array_49442);
}
})();
return chromex.marshalling.from_native_chrome_port.call(null,config,result_49439);
});
chromex.ext.runtime.connect_native_STAR_ = (function chromex$ext$runtime$connect_native_STAR_(config,application){
var marshalled_application_49461 = (function (){var omit_test_49466 = application;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_49466,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_49466;
}
})();
var result_49460 = (function (){var final_args_array_49462 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_49461,"application",null], null)], null),"chrome.runtime.connectNative");
var ns_49463 = (function (){var target_obj_49467 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49470 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49471 = oops.state.prepare_state.call(null,target_obj_49467,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49471);

try{var next_obj_49468 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49467,(0),"chrome",true,true,false))?(target_obj_49467["chrome"]):null);
var next_obj_49469 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49468,(0),"runtime",true,true,false))?(next_obj_49468["runtime"]):null);
return next_obj_49469;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49470);
}})();
var missing_api_49464 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.connectNative",ns_49463,"connectNative");
})();
if(missing_api_49464 === true){
return null;
} else {
var config__25890__auto___49476 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49476))){
var logger__25891__auto___49477 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49476);
var prefix__25892__auto___49478 = ["calling:","chrome.runtime.connectNative"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49477)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49476)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49477.apply(null,prefix__25892__auto___49478.concat(final_args_array_49462));
} else {
}

var target_49465 = (function (){var target_obj_49472 = ns_49463;
var _STAR_runtime_state_STAR__orig_val__49474 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49475 = oops.state.prepare_state.call(null,target_obj_49472,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49475);

try{var next_obj_49473 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49472,(1),"connectNative",true,true,false))?(target_obj_49472["connectNative"]):null);
if((!((next_obj_49473 == null)))){
return next_obj_49473;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49474);
}})();
return target_49465.apply(ns_49463,final_args_array_49462);
}
})();
return chromex.marshalling.from_native_chrome_port.call(null,config,result_49460);
});
chromex.ext.runtime.send_message_STAR_ = (function chromex$ext$runtime$send_message_STAR_(config,extension_id,message,options){
var callback_chan_49479 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_extension_id_49481_49502 = (function (){var omit_test_49489 = extension_id;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_49489,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_49489;
}
})();
var marshalled_message_49482_49503 = (function (){var omit_test_49490 = message;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_49490,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_49490;
}
})();
var marshalled_options_49483_49504 = (function (){var omit_test_49491 = options;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_49491,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_49491;
}
})();
var marshalled_response_callback_49484_49505 = (function (cb_response_49492){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.runtime","send-message","chromex.ext.runtime/send-message",-500803608),new cljs.core.Keyword(null,"name","name",1843675177),"sendMessage",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"extension-id",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"string"], null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"message",new cljs.core.Keyword(null,"type","type",1174270348),"any"], null),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"options",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),"object"], null),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"response-callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"response",new cljs.core.Keyword(null,"type","type",1174270348),"any"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_49479);
})().call(null,cb_response_49492);
});
var result_49480_49506 = (function (){var final_args_array_49485 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_49481_49502,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_49482_49503,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_49483_49504,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_49484_49505,"response-callback",true], null)], null),"chrome.runtime.sendMessage");
var ns_49486 = (function (){var target_obj_49493 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49496 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49497 = oops.state.prepare_state.call(null,target_obj_49493,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49497);

try{var next_obj_49494 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49493,(0),"chrome",true,true,false))?(target_obj_49493["chrome"]):null);
var next_obj_49495 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49494,(0),"runtime",true,true,false))?(next_obj_49494["runtime"]):null);
return next_obj_49495;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49496);
}})();
var missing_api_49487 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.sendMessage",ns_49486,"sendMessage");
})();
if(missing_api_49487 === true){
return null;
} else {
var config__25890__auto___49507 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49507))){
var logger__25891__auto___49508 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49507);
var prefix__25892__auto___49509 = ["calling:","chrome.runtime.sendMessage"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49508)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49507)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49508.apply(null,prefix__25892__auto___49509.concat(final_args_array_49485));
} else {
}

var target_49488 = (function (){var target_obj_49498 = ns_49486;
var _STAR_runtime_state_STAR__orig_val__49500 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49501 = oops.state.prepare_state.call(null,target_obj_49498,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49501);

try{var next_obj_49499 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49498,(1),"sendMessage",true,true,false))?(target_obj_49498["sendMessage"]):null);
if((!((next_obj_49499 == null)))){
return next_obj_49499;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49500);
}})();
return target_49488.apply(ns_49486,final_args_array_49485);
}
})();

return callback_chan_49479;
});
chromex.ext.runtime.send_native_message_STAR_ = (function chromex$ext$runtime$send_native_message_STAR_(config,application,message){
var callback_chan_49510 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_application_49512_49531 = (function (){var omit_test_49519 = application;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_49519,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_49519;
}
})();
var marshalled_message_49513_49532 = (function (){var omit_test_49520 = message;
if(cljs.core.keyword_identical_QMARK_.call(null,omit_test_49520,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
return new cljs.core.Keyword(null,"omit","omit",-1917972325);
} else {
return omit_test_49520;
}
})();
var marshalled_response_callback_49514_49533 = (function (cb_response_49521){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.runtime","send-native-message","chromex.ext.runtime/send-native-message",-489769559),new cljs.core.Keyword(null,"name","name",1843675177),"sendNativeMessage",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"application",new cljs.core.Keyword(null,"type","type",1174270348),"string"], null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"message",new cljs.core.Keyword(null,"type","type",1174270348),"object"], null),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"name","name",1843675177),"response-callback",new cljs.core.Keyword(null,"optional?","optional?",1184638129),true,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"response",new cljs.core.Keyword(null,"type","type",1174270348),"any"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_49510);
})().call(null,cb_response_49521);
});
var result_49511_49534 = (function (){var final_args_array_49515 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_49512_49531,"application",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_49513_49532,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_49514_49533,"response-callback",true], null)], null),"chrome.runtime.sendNativeMessage");
var ns_49516 = (function (){var target_obj_49522 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49525 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49526 = oops.state.prepare_state.call(null,target_obj_49522,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49526);

try{var next_obj_49523 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49522,(0),"chrome",true,true,false))?(target_obj_49522["chrome"]):null);
var next_obj_49524 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49523,(0),"runtime",true,true,false))?(next_obj_49523["runtime"]):null);
return next_obj_49524;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49525);
}})();
var missing_api_49517 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.sendNativeMessage",ns_49516,"sendNativeMessage");
})();
if(missing_api_49517 === true){
return null;
} else {
var config__25890__auto___49535 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49535))){
var logger__25891__auto___49536 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49535);
var prefix__25892__auto___49537 = ["calling:","chrome.runtime.sendNativeMessage"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49536)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49535)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49536.apply(null,prefix__25892__auto___49537.concat(final_args_array_49515));
} else {
}

var target_49518 = (function (){var target_obj_49527 = ns_49516;
var _STAR_runtime_state_STAR__orig_val__49529 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49530 = oops.state.prepare_state.call(null,target_obj_49527,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49530);

try{var next_obj_49528 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49527,(1),"sendNativeMessage",true,true,false))?(target_obj_49527["sendNativeMessage"]):null);
if((!((next_obj_49528 == null)))){
return next_obj_49528;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49529);
}})();
return target_49518.apply(ns_49516,final_args_array_49515);
}
})();

return callback_chan_49510;
});
chromex.ext.runtime.get_platform_info_STAR_ = (function chromex$ext$runtime$get_platform_info_STAR_(config){
var callback_chan_49538 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_callback_49540_49555 = (function (cb_platform_info_49545){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.runtime","get-platform-info","chromex.ext.runtime/get-platform-info",573309082),new cljs.core.Keyword(null,"name","name",1843675177),"getPlatformInfo",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"platform-info",new cljs.core.Keyword(null,"type","type",1174270348),"runtime.PlatformInfo"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_49538);
})().call(null,cb_platform_info_49545);
});
var result_49539_49556 = (function (){var final_args_array_49541 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_49540_49555,"callback",null], null)], null),"chrome.runtime.getPlatformInfo");
var ns_49542 = (function (){var target_obj_49546 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49549 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49550 = oops.state.prepare_state.call(null,target_obj_49546,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49550);

try{var next_obj_49547 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49546,(0),"chrome",true,true,false))?(target_obj_49546["chrome"]):null);
var next_obj_49548 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49547,(0),"runtime",true,true,false))?(next_obj_49547["runtime"]):null);
return next_obj_49548;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49549);
}})();
var missing_api_49543 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.getPlatformInfo",ns_49542,"getPlatformInfo");
})();
if(missing_api_49543 === true){
return null;
} else {
var config__25890__auto___49557 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49557))){
var logger__25891__auto___49558 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49557);
var prefix__25892__auto___49559 = ["calling:","chrome.runtime.getPlatformInfo"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49558)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49557)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49558.apply(null,prefix__25892__auto___49559.concat(final_args_array_49541));
} else {
}

var target_49544 = (function (){var target_obj_49551 = ns_49542;
var _STAR_runtime_state_STAR__orig_val__49553 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49554 = oops.state.prepare_state.call(null,target_obj_49551,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49554);

try{var next_obj_49552 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49551,(1),"getPlatformInfo",true,true,false))?(target_obj_49551["getPlatformInfo"]):null);
if((!((next_obj_49552 == null)))){
return next_obj_49552;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49553);
}})();
return target_49544.apply(ns_49542,final_args_array_49541);
}
})();

return callback_chan_49538;
});
chromex.ext.runtime.get_package_directory_entry_STAR_ = (function chromex$ext$runtime$get_package_directory_entry_STAR_(config){
var callback_chan_49560 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var marshalled_callback_49562_49577 = (function (cb_directory_entry_49567){
return (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword("chromex.ext.runtime","get-package-directory-entry","chromex.ext.runtime/get-package-directory-entry",-1404865573),new cljs.core.Keyword(null,"name","name",1843675177),"getPackageDirectoryEntry",new cljs.core.Keyword(null,"callback?","callback?",-1081196295),true,new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"name","name",1843675177),"callback",new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.Keyword(null,"callback","callback",-705136228),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"params","params",710516235),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"name","name",1843675177),"directory-entry",new cljs.core.Keyword(null,"type","type",1174270348),"DirectoryEntry"], null)], null)], null)], null)], null),new cljs.core.Keyword(null,"function?","function?",88718602),true], null),callback_chan_49560);
})().call(null,cb_directory_entry_49567);
});
var result_49561_49578 = (function (){var final_args_array_49563 = chromex.support.prepare_final_args_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_49562_49577,"callback",null], null)], null),"chrome.runtime.getPackageDirectoryEntry");
var ns_49564 = (function (){var target_obj_49568 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49571 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49572 = oops.state.prepare_state.call(null,target_obj_49568,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49572);

try{var next_obj_49569 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49568,(0),"chrome",true,true,false))?(target_obj_49568["chrome"]):null);
var next_obj_49570 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49569,(0),"runtime",true,true,false))?(next_obj_49569["runtime"]):null);
return next_obj_49570;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49571);
}})();
var missing_api_49565 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.getPackageDirectoryEntry",ns_49564,"getPackageDirectoryEntry");
})();
if(missing_api_49565 === true){
return null;
} else {
var config__25890__auto___49579 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49579))){
var logger__25891__auto___49580 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49579);
var prefix__25892__auto___49581 = ["calling:","chrome.runtime.getPackageDirectoryEntry"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49580)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49579)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49580.apply(null,prefix__25892__auto___49581.concat(final_args_array_49563));
} else {
}

var target_49566 = (function (){var target_obj_49573 = ns_49564;
var _STAR_runtime_state_STAR__orig_val__49575 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49576 = oops.state.prepare_state.call(null,target_obj_49573,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49576);

try{var next_obj_49574 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49573,(1),"getPackageDirectoryEntry",true,true,false))?(target_obj_49573["getPackageDirectoryEntry"]):null);
if((!((next_obj_49574 == null)))){
return next_obj_49574;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49575);
}})();
return target_49566.apply(ns_49564,final_args_array_49563);
}
})();

return callback_chan_49560;
});
chromex.ext.runtime.on_startup_STAR_ = (function chromex$ext$runtime$on_startup_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___49601 = arguments.length;
var i__4790__auto___49602 = (0);
while(true){
if((i__4790__auto___49602 < len__4789__auto___49601)){
args__4795__auto__.push((arguments[i__4790__auto___49602]));

var G__49603 = (i__4790__auto___49602 + (1));
i__4790__auto___49602 = G__49603;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_49585 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.runtime","on-startup","chromex.ext.runtime/on-startup",-1208972204),channel);
})();
var handler_fn_49586 = event_fn_49585;
var logging_fn_49587 = (function (){
var config__25890__auto___49604 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49604))){
var logger__25891__auto___49605 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49604);
var prefix__25892__auto___49606 = ["event:","chrome.runtime.onStartup"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49605)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49604)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49605.apply(null,prefix__25892__auto___49606.concat(cljs.core.into_array.call(null,cljs.core.PersistentVector.EMPTY)));
} else {
}

return handler_fn_49586.call(null);
});
var ns_obj_49590 = (function (){var target_obj_49592 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49595 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49596 = oops.state.prepare_state.call(null,target_obj_49592,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49596);

try{var next_obj_49593 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49592,(0),"chrome",true,true,false))?(target_obj_49592["chrome"]):null);
var next_obj_49594 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49593,(0),"runtime",true,true,false))?(next_obj_49593["runtime"]):null);
return next_obj_49594;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49595);
}})();
var missing_api_49591 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.onStartup",ns_obj_49590,"onStartup");
})();
if(missing_api_49591 === true){
return null;
} else {
var event_obj_49588 = (function (){var target_obj_49597 = ns_obj_49590;
var _STAR_runtime_state_STAR__orig_val__49599 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49600 = oops.state.prepare_state.call(null,target_obj_49597,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49600);

try{var next_obj_49598 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49597,(0),"onStartup",true,true,false))?(target_obj_49597["onStartup"]):null);
return next_obj_49598;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49599);
}})();
var result_49589 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_49588,logging_fn_49587,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_49589,args);

return result_49589;
}
}));

(chromex.ext.runtime.on_startup_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_startup_STAR_.cljs$lang$applyTo = (function (seq49582){
var G__49583 = cljs.core.first.call(null,seq49582);
var seq49582__$1 = cljs.core.next.call(null,seq49582);
var G__49584 = cljs.core.first.call(null,seq49582__$1);
var seq49582__$2 = cljs.core.next.call(null,seq49582__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__49583,G__49584,seq49582__$2);
}));

chromex.ext.runtime.on_installed_STAR_ = (function chromex$ext$runtime$on_installed_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___49628 = arguments.length;
var i__4790__auto___49629 = (0);
while(true){
if((i__4790__auto___49629 < len__4789__auto___49628)){
args__4795__auto__.push((arguments[i__4790__auto___49629]));

var G__49630 = (i__4790__auto___49629 + (1));
i__4790__auto___49629 = G__49630;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_49610 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.runtime","on-installed","chromex.ext.runtime/on-installed",1653814653),channel);
})();
var handler_fn_49611 = (function (cb_details_49617){
return event_fn_49610.call(null,cb_details_49617);
});
var logging_fn_49612 = (function (cb_param_details_49618){
var config__25890__auto___49631 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49631))){
var logger__25891__auto___49632 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49631);
var prefix__25892__auto___49633 = ["event:","chrome.runtime.onInstalled"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49632)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49631)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49632.apply(null,prefix__25892__auto___49633.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_details_49618], null))));
} else {
}

return handler_fn_49611.call(null,cb_param_details_49618);
});
var ns_obj_49615 = (function (){var target_obj_49619 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49622 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49623 = oops.state.prepare_state.call(null,target_obj_49619,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49623);

try{var next_obj_49620 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49619,(0),"chrome",true,true,false))?(target_obj_49619["chrome"]):null);
var next_obj_49621 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49620,(0),"runtime",true,true,false))?(next_obj_49620["runtime"]):null);
return next_obj_49621;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49622);
}})();
var missing_api_49616 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.onInstalled",ns_obj_49615,"onInstalled");
})();
if(missing_api_49616 === true){
return null;
} else {
var event_obj_49613 = (function (){var target_obj_49624 = ns_obj_49615;
var _STAR_runtime_state_STAR__orig_val__49626 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49627 = oops.state.prepare_state.call(null,target_obj_49624,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49627);

try{var next_obj_49625 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49624,(0),"onInstalled",true,true,false))?(target_obj_49624["onInstalled"]):null);
return next_obj_49625;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49626);
}})();
var result_49614 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_49613,logging_fn_49612,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_49614,args);

return result_49614;
}
}));

(chromex.ext.runtime.on_installed_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_installed_STAR_.cljs$lang$applyTo = (function (seq49607){
var G__49608 = cljs.core.first.call(null,seq49607);
var seq49607__$1 = cljs.core.next.call(null,seq49607);
var G__49609 = cljs.core.first.call(null,seq49607__$1);
var seq49607__$2 = cljs.core.next.call(null,seq49607__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__49608,G__49609,seq49607__$2);
}));

chromex.ext.runtime.on_suspend_STAR_ = (function chromex$ext$runtime$on_suspend_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___49653 = arguments.length;
var i__4790__auto___49654 = (0);
while(true){
if((i__4790__auto___49654 < len__4789__auto___49653)){
args__4795__auto__.push((arguments[i__4790__auto___49654]));

var G__49655 = (i__4790__auto___49654 + (1));
i__4790__auto___49654 = G__49655;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_49637 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.runtime","on-suspend","chromex.ext.runtime/on-suspend",-1228920175),channel);
})();
var handler_fn_49638 = event_fn_49637;
var logging_fn_49639 = (function (){
var config__25890__auto___49656 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49656))){
var logger__25891__auto___49657 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49656);
var prefix__25892__auto___49658 = ["event:","chrome.runtime.onSuspend"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49657)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49656)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49657.apply(null,prefix__25892__auto___49658.concat(cljs.core.into_array.call(null,cljs.core.PersistentVector.EMPTY)));
} else {
}

return handler_fn_49638.call(null);
});
var ns_obj_49642 = (function (){var target_obj_49644 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49647 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49648 = oops.state.prepare_state.call(null,target_obj_49644,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49648);

try{var next_obj_49645 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49644,(0),"chrome",true,true,false))?(target_obj_49644["chrome"]):null);
var next_obj_49646 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49645,(0),"runtime",true,true,false))?(next_obj_49645["runtime"]):null);
return next_obj_49646;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49647);
}})();
var missing_api_49643 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.onSuspend",ns_obj_49642,"onSuspend");
})();
if(missing_api_49643 === true){
return null;
} else {
var event_obj_49640 = (function (){var target_obj_49649 = ns_obj_49642;
var _STAR_runtime_state_STAR__orig_val__49651 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49652 = oops.state.prepare_state.call(null,target_obj_49649,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49652);

try{var next_obj_49650 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49649,(0),"onSuspend",true,true,false))?(target_obj_49649["onSuspend"]):null);
return next_obj_49650;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49651);
}})();
var result_49641 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_49640,logging_fn_49639,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_49641,args);

return result_49641;
}
}));

(chromex.ext.runtime.on_suspend_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_suspend_STAR_.cljs$lang$applyTo = (function (seq49634){
var G__49635 = cljs.core.first.call(null,seq49634);
var seq49634__$1 = cljs.core.next.call(null,seq49634);
var G__49636 = cljs.core.first.call(null,seq49634__$1);
var seq49634__$2 = cljs.core.next.call(null,seq49634__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__49635,G__49636,seq49634__$2);
}));

chromex.ext.runtime.on_suspend_canceled_STAR_ = (function chromex$ext$runtime$on_suspend_canceled_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___49678 = arguments.length;
var i__4790__auto___49679 = (0);
while(true){
if((i__4790__auto___49679 < len__4789__auto___49678)){
args__4795__auto__.push((arguments[i__4790__auto___49679]));

var G__49680 = (i__4790__auto___49679 + (1));
i__4790__auto___49679 = G__49680;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_49662 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.runtime","on-suspend-canceled","chromex.ext.runtime/on-suspend-canceled",-827432771),channel);
})();
var handler_fn_49663 = event_fn_49662;
var logging_fn_49664 = (function (){
var config__25890__auto___49681 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49681))){
var logger__25891__auto___49682 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49681);
var prefix__25892__auto___49683 = ["event:","chrome.runtime.onSuspendCanceled"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49682)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49681)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49682.apply(null,prefix__25892__auto___49683.concat(cljs.core.into_array.call(null,cljs.core.PersistentVector.EMPTY)));
} else {
}

return handler_fn_49663.call(null);
});
var ns_obj_49667 = (function (){var target_obj_49669 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49672 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49673 = oops.state.prepare_state.call(null,target_obj_49669,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49673);

try{var next_obj_49670 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49669,(0),"chrome",true,true,false))?(target_obj_49669["chrome"]):null);
var next_obj_49671 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49670,(0),"runtime",true,true,false))?(next_obj_49670["runtime"]):null);
return next_obj_49671;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49672);
}})();
var missing_api_49668 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.onSuspendCanceled",ns_obj_49667,"onSuspendCanceled");
})();
if(missing_api_49668 === true){
return null;
} else {
var event_obj_49665 = (function (){var target_obj_49674 = ns_obj_49667;
var _STAR_runtime_state_STAR__orig_val__49676 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49677 = oops.state.prepare_state.call(null,target_obj_49674,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49677);

try{var next_obj_49675 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49674,(0),"onSuspendCanceled",true,true,false))?(target_obj_49674["onSuspendCanceled"]):null);
return next_obj_49675;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49676);
}})();
var result_49666 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_49665,logging_fn_49664,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_49666,args);

return result_49666;
}
}));

(chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$applyTo = (function (seq49659){
var G__49660 = cljs.core.first.call(null,seq49659);
var seq49659__$1 = cljs.core.next.call(null,seq49659);
var G__49661 = cljs.core.first.call(null,seq49659__$1);
var seq49659__$2 = cljs.core.next.call(null,seq49659__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__49660,G__49661,seq49659__$2);
}));

chromex.ext.runtime.on_update_available_STAR_ = (function chromex$ext$runtime$on_update_available_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___49705 = arguments.length;
var i__4790__auto___49706 = (0);
while(true){
if((i__4790__auto___49706 < len__4789__auto___49705)){
args__4795__auto__.push((arguments[i__4790__auto___49706]));

var G__49707 = (i__4790__auto___49706 + (1));
i__4790__auto___49706 = G__49707;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_49687 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.runtime","on-update-available","chromex.ext.runtime/on-update-available",-1242137249),channel);
})();
var handler_fn_49688 = (function (cb_details_49694){
return event_fn_49687.call(null,cb_details_49694);
});
var logging_fn_49689 = (function (cb_param_details_49695){
var config__25890__auto___49708 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49708))){
var logger__25891__auto___49709 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49708);
var prefix__25892__auto___49710 = ["event:","chrome.runtime.onUpdateAvailable"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49709)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49708)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49709.apply(null,prefix__25892__auto___49710.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_details_49695], null))));
} else {
}

return handler_fn_49688.call(null,cb_param_details_49695);
});
var ns_obj_49692 = (function (){var target_obj_49696 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49699 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49700 = oops.state.prepare_state.call(null,target_obj_49696,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49700);

try{var next_obj_49697 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49696,(0),"chrome",true,true,false))?(target_obj_49696["chrome"]):null);
var next_obj_49698 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49697,(0),"runtime",true,true,false))?(next_obj_49697["runtime"]):null);
return next_obj_49698;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49699);
}})();
var missing_api_49693 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.onUpdateAvailable",ns_obj_49692,"onUpdateAvailable");
})();
if(missing_api_49693 === true){
return null;
} else {
var event_obj_49690 = (function (){var target_obj_49701 = ns_obj_49692;
var _STAR_runtime_state_STAR__orig_val__49703 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49704 = oops.state.prepare_state.call(null,target_obj_49701,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49704);

try{var next_obj_49702 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49701,(0),"onUpdateAvailable",true,true,false))?(target_obj_49701["onUpdateAvailable"]):null);
return next_obj_49702;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49703);
}})();
var result_49691 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_49690,logging_fn_49689,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_49691,args);

return result_49691;
}
}));

(chromex.ext.runtime.on_update_available_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_update_available_STAR_.cljs$lang$applyTo = (function (seq49684){
var G__49685 = cljs.core.first.call(null,seq49684);
var seq49684__$1 = cljs.core.next.call(null,seq49684);
var G__49686 = cljs.core.first.call(null,seq49684__$1);
var seq49684__$2 = cljs.core.next.call(null,seq49684__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__49685,G__49686,seq49684__$2);
}));

chromex.ext.runtime.on_browser_update_available_STAR_ = (function chromex$ext$runtime$on_browser_update_available_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___49730 = arguments.length;
var i__4790__auto___49731 = (0);
while(true){
if((i__4790__auto___49731 < len__4789__auto___49730)){
args__4795__auto__.push((arguments[i__4790__auto___49731]));

var G__49732 = (i__4790__auto___49731 + (1));
i__4790__auto___49731 = G__49732;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_49714 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.runtime","on-browser-update-available","chromex.ext.runtime/on-browser-update-available",-2070315485),channel);
})();
var handler_fn_49715 = event_fn_49714;
var logging_fn_49716 = (function (){
var config__25890__auto___49733 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49733))){
var logger__25891__auto___49734 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49733);
var prefix__25892__auto___49735 = ["event:","chrome.runtime.onBrowserUpdateAvailable"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49734)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49733)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49734.apply(null,prefix__25892__auto___49735.concat(cljs.core.into_array.call(null,cljs.core.PersistentVector.EMPTY)));
} else {
}

return handler_fn_49715.call(null);
});
var ns_obj_49719 = (function (){var target_obj_49721 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49724 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49725 = oops.state.prepare_state.call(null,target_obj_49721,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49725);

try{var next_obj_49722 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49721,(0),"chrome",true,true,false))?(target_obj_49721["chrome"]):null);
var next_obj_49723 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49722,(0),"runtime",true,true,false))?(next_obj_49722["runtime"]):null);
return next_obj_49723;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49724);
}})();
var missing_api_49720 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.onBrowserUpdateAvailable",ns_obj_49719,"onBrowserUpdateAvailable");
})();
if(missing_api_49720 === true){
return null;
} else {
var event_obj_49717 = (function (){var target_obj_49726 = ns_obj_49719;
var _STAR_runtime_state_STAR__orig_val__49728 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49729 = oops.state.prepare_state.call(null,target_obj_49726,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49729);

try{var next_obj_49727 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49726,(0),"onBrowserUpdateAvailable",true,true,false))?(target_obj_49726["onBrowserUpdateAvailable"]):null);
return next_obj_49727;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49728);
}})();
var result_49718 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_49717,logging_fn_49716,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_49718,args);

return result_49718;
}
}));

(chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$applyTo = (function (seq49711){
var G__49712 = cljs.core.first.call(null,seq49711);
var seq49711__$1 = cljs.core.next.call(null,seq49711);
var G__49713 = cljs.core.first.call(null,seq49711__$1);
var seq49711__$2 = cljs.core.next.call(null,seq49711__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__49712,G__49713,seq49711__$2);
}));

chromex.ext.runtime.on_connect_STAR_ = (function chromex$ext$runtime$on_connect_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___49757 = arguments.length;
var i__4790__auto___49758 = (0);
while(true){
if((i__4790__auto___49758 < len__4789__auto___49757)){
args__4795__auto__.push((arguments[i__4790__auto___49758]));

var G__49759 = (i__4790__auto___49758 + (1));
i__4790__auto___49758 = G__49759;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_49739 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.runtime","on-connect","chromex.ext.runtime/on-connect",-693825711),channel);
})();
var handler_fn_49740 = (function (cb_port_49746){
return event_fn_49739.call(null,chromex.marshalling.from_native_chrome_port.call(null,config,cb_port_49746));
});
var logging_fn_49741 = (function (cb_param_port_49747){
var config__25890__auto___49760 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49760))){
var logger__25891__auto___49761 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49760);
var prefix__25892__auto___49762 = ["event:","chrome.runtime.onConnect"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49761)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49760)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49761.apply(null,prefix__25892__auto___49762.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_port_49747], null))));
} else {
}

return handler_fn_49740.call(null,cb_param_port_49747);
});
var ns_obj_49744 = (function (){var target_obj_49748 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49751 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49752 = oops.state.prepare_state.call(null,target_obj_49748,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49752);

try{var next_obj_49749 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49748,(0),"chrome",true,true,false))?(target_obj_49748["chrome"]):null);
var next_obj_49750 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49749,(0),"runtime",true,true,false))?(next_obj_49749["runtime"]):null);
return next_obj_49750;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49751);
}})();
var missing_api_49745 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.onConnect",ns_obj_49744,"onConnect");
})();
if(missing_api_49745 === true){
return null;
} else {
var event_obj_49742 = (function (){var target_obj_49753 = ns_obj_49744;
var _STAR_runtime_state_STAR__orig_val__49755 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49756 = oops.state.prepare_state.call(null,target_obj_49753,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49756);

try{var next_obj_49754 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49753,(0),"onConnect",true,true,false))?(target_obj_49753["onConnect"]):null);
return next_obj_49754;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49755);
}})();
var result_49743 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_49742,logging_fn_49741,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_49743,args);

return result_49743;
}
}));

(chromex.ext.runtime.on_connect_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_connect_STAR_.cljs$lang$applyTo = (function (seq49736){
var G__49737 = cljs.core.first.call(null,seq49736);
var seq49736__$1 = cljs.core.next.call(null,seq49736);
var G__49738 = cljs.core.first.call(null,seq49736__$1);
var seq49736__$2 = cljs.core.next.call(null,seq49736__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__49737,G__49738,seq49736__$2);
}));

chromex.ext.runtime.on_connect_external_STAR_ = (function chromex$ext$runtime$on_connect_external_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___49784 = arguments.length;
var i__4790__auto___49785 = (0);
while(true){
if((i__4790__auto___49785 < len__4789__auto___49784)){
args__4795__auto__.push((arguments[i__4790__auto___49785]));

var G__49786 = (i__4790__auto___49785 + (1));
i__4790__auto___49785 = G__49786;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_49766 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.runtime","on-connect-external","chromex.ext.runtime/on-connect-external",-2057644994),channel);
})();
var handler_fn_49767 = (function (cb_port_49773){
return event_fn_49766.call(null,chromex.marshalling.from_native_chrome_port.call(null,config,cb_port_49773));
});
var logging_fn_49768 = (function (cb_param_port_49774){
var config__25890__auto___49787 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49787))){
var logger__25891__auto___49788 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49787);
var prefix__25892__auto___49789 = ["event:","chrome.runtime.onConnectExternal"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49788)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49787)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49788.apply(null,prefix__25892__auto___49789.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_port_49774], null))));
} else {
}

return handler_fn_49767.call(null,cb_param_port_49774);
});
var ns_obj_49771 = (function (){var target_obj_49775 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49778 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49779 = oops.state.prepare_state.call(null,target_obj_49775,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49779);

try{var next_obj_49776 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49775,(0),"chrome",true,true,false))?(target_obj_49775["chrome"]):null);
var next_obj_49777 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49776,(0),"runtime",true,true,false))?(next_obj_49776["runtime"]):null);
return next_obj_49777;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49778);
}})();
var missing_api_49772 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.onConnectExternal",ns_obj_49771,"onConnectExternal");
})();
if(missing_api_49772 === true){
return null;
} else {
var event_obj_49769 = (function (){var target_obj_49780 = ns_obj_49771;
var _STAR_runtime_state_STAR__orig_val__49782 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49783 = oops.state.prepare_state.call(null,target_obj_49780,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49783);

try{var next_obj_49781 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49780,(0),"onConnectExternal",true,true,false))?(target_obj_49780["onConnectExternal"]):null);
return next_obj_49781;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49782);
}})();
var result_49770 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_49769,logging_fn_49768,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_49770,args);

return result_49770;
}
}));

(chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$applyTo = (function (seq49763){
var G__49764 = cljs.core.first.call(null,seq49763);
var seq49763__$1 = cljs.core.next.call(null,seq49763);
var G__49765 = cljs.core.first.call(null,seq49763__$1);
var seq49763__$2 = cljs.core.next.call(null,seq49763__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__49764,G__49765,seq49763__$2);
}));

chromex.ext.runtime.on_connect_native_STAR_ = (function chromex$ext$runtime$on_connect_native_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___49811 = arguments.length;
var i__4790__auto___49812 = (0);
while(true){
if((i__4790__auto___49812 < len__4789__auto___49811)){
args__4795__auto__.push((arguments[i__4790__auto___49812]));

var G__49813 = (i__4790__auto___49812 + (1));
i__4790__auto___49812 = G__49813;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_native_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_connect_native_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_49793 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.runtime","on-connect-native","chromex.ext.runtime/on-connect-native",1159506857),channel);
})();
var handler_fn_49794 = (function (cb_port_49800){
return event_fn_49793.call(null,chromex.marshalling.from_native_chrome_port.call(null,config,cb_port_49800));
});
var logging_fn_49795 = (function (cb_param_port_49801){
var config__25890__auto___49814 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49814))){
var logger__25891__auto___49815 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49814);
var prefix__25892__auto___49816 = ["event:","chrome.runtime.onConnectNative"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49815)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49814)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49815.apply(null,prefix__25892__auto___49816.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_port_49801], null))));
} else {
}

return handler_fn_49794.call(null,cb_param_port_49801);
});
var ns_obj_49798 = (function (){var target_obj_49802 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49805 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49806 = oops.state.prepare_state.call(null,target_obj_49802,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49806);

try{var next_obj_49803 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49802,(0),"chrome",true,true,false))?(target_obj_49802["chrome"]):null);
var next_obj_49804 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49803,(0),"runtime",true,true,false))?(next_obj_49803["runtime"]):null);
return next_obj_49804;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49805);
}})();
var missing_api_49799 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.onConnectNative",ns_obj_49798,"onConnectNative");
})();
if(missing_api_49799 === true){
return null;
} else {
var event_obj_49796 = (function (){var target_obj_49807 = ns_obj_49798;
var _STAR_runtime_state_STAR__orig_val__49809 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49810 = oops.state.prepare_state.call(null,target_obj_49807,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49810);

try{var next_obj_49808 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49807,(0),"onConnectNative",true,true,false))?(target_obj_49807["onConnectNative"]):null);
return next_obj_49808;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49809);
}})();
var result_49797 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_49796,logging_fn_49795,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_49797,args);

return result_49797;
}
}));

(chromex.ext.runtime.on_connect_native_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_connect_native_STAR_.cljs$lang$applyTo = (function (seq49790){
var G__49791 = cljs.core.first.call(null,seq49790);
var seq49790__$1 = cljs.core.next.call(null,seq49790);
var G__49792 = cljs.core.first.call(null,seq49790__$1);
var seq49790__$2 = cljs.core.next.call(null,seq49790__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__49791,G__49792,seq49790__$2);
}));

chromex.ext.runtime.on_message_STAR_ = (function chromex$ext$runtime$on_message_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___49842 = arguments.length;
var i__4790__auto___49843 = (0);
while(true){
if((i__4790__auto___49843 < len__4789__auto___49842)){
args__4795__auto__.push((arguments[i__4790__auto___49843]));

var G__49844 = (i__4790__auto___49843 + (1));
i__4790__auto___49843 = G__49844;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_49820 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.runtime","on-message","chromex.ext.runtime/on-message",2147364293),channel);
})();
var handler_fn_49821 = (function (cb_message_49827,cb_sender_49828,cb_send_response_49829){
return event_fn_49820.call(null,cb_message_49827,cb_sender_49828,cb_send_response_49829);
});
var logging_fn_49822 = (function (cb_param_message_49830,cb_param_sender_49831,cb_param_send_response_49832){
var config__25890__auto___49845 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49845))){
var logger__25891__auto___49846 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49845);
var prefix__25892__auto___49847 = ["event:","chrome.runtime.onMessage"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49846)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49845)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49846.apply(null,prefix__25892__auto___49847.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_message_49830,cb_param_sender_49831,cb_param_send_response_49832], null))));
} else {
}

return handler_fn_49821.call(null,cb_param_message_49830,cb_param_sender_49831,cb_param_send_response_49832);
});
var ns_obj_49825 = (function (){var target_obj_49833 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49836 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49837 = oops.state.prepare_state.call(null,target_obj_49833,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49837);

try{var next_obj_49834 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49833,(0),"chrome",true,true,false))?(target_obj_49833["chrome"]):null);
var next_obj_49835 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49834,(0),"runtime",true,true,false))?(next_obj_49834["runtime"]):null);
return next_obj_49835;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49836);
}})();
var missing_api_49826 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.onMessage",ns_obj_49825,"onMessage");
})();
if(missing_api_49826 === true){
return null;
} else {
var event_obj_49823 = (function (){var target_obj_49838 = ns_obj_49825;
var _STAR_runtime_state_STAR__orig_val__49840 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49841 = oops.state.prepare_state.call(null,target_obj_49838,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49841);

try{var next_obj_49839 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49838,(0),"onMessage",true,true,false))?(target_obj_49838["onMessage"]):null);
return next_obj_49839;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49840);
}})();
var result_49824 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_49823,logging_fn_49822,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_49824,args);

return result_49824;
}
}));

(chromex.ext.runtime.on_message_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_message_STAR_.cljs$lang$applyTo = (function (seq49817){
var G__49818 = cljs.core.first.call(null,seq49817);
var seq49817__$1 = cljs.core.next.call(null,seq49817);
var G__49819 = cljs.core.first.call(null,seq49817__$1);
var seq49817__$2 = cljs.core.next.call(null,seq49817__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__49818,G__49819,seq49817__$2);
}));

chromex.ext.runtime.on_message_external_STAR_ = (function chromex$ext$runtime$on_message_external_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___49873 = arguments.length;
var i__4790__auto___49874 = (0);
while(true){
if((i__4790__auto___49874 < len__4789__auto___49873)){
args__4795__auto__.push((arguments[i__4790__auto___49874]));

var G__49875 = (i__4790__auto___49874 + (1));
i__4790__auto___49874 = G__49875;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_49851 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.runtime","on-message-external","chromex.ext.runtime/on-message-external",-779703990),channel);
})();
var handler_fn_49852 = (function (cb_message_49858,cb_sender_49859,cb_send_response_49860){
return event_fn_49851.call(null,cb_message_49858,cb_sender_49859,cb_send_response_49860);
});
var logging_fn_49853 = (function (cb_param_message_49861,cb_param_sender_49862,cb_param_send_response_49863){
var config__25890__auto___49876 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49876))){
var logger__25891__auto___49877 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49876);
var prefix__25892__auto___49878 = ["event:","chrome.runtime.onMessageExternal"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49877)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49876)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49877.apply(null,prefix__25892__auto___49878.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_message_49861,cb_param_sender_49862,cb_param_send_response_49863], null))));
} else {
}

return handler_fn_49852.call(null,cb_param_message_49861,cb_param_sender_49862,cb_param_send_response_49863);
});
var ns_obj_49856 = (function (){var target_obj_49864 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49867 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49868 = oops.state.prepare_state.call(null,target_obj_49864,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49868);

try{var next_obj_49865 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49864,(0),"chrome",true,true,false))?(target_obj_49864["chrome"]):null);
var next_obj_49866 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49865,(0),"runtime",true,true,false))?(next_obj_49865["runtime"]):null);
return next_obj_49866;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49867);
}})();
var missing_api_49857 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.onMessageExternal",ns_obj_49856,"onMessageExternal");
})();
if(missing_api_49857 === true){
return null;
} else {
var event_obj_49854 = (function (){var target_obj_49869 = ns_obj_49856;
var _STAR_runtime_state_STAR__orig_val__49871 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49872 = oops.state.prepare_state.call(null,target_obj_49869,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49872);

try{var next_obj_49870 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49869,(0),"onMessageExternal",true,true,false))?(target_obj_49869["onMessageExternal"]):null);
return next_obj_49870;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49871);
}})();
var result_49855 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_49854,logging_fn_49853,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_49855,args);

return result_49855;
}
}));

(chromex.ext.runtime.on_message_external_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_message_external_STAR_.cljs$lang$applyTo = (function (seq49848){
var G__49849 = cljs.core.first.call(null,seq49848);
var seq49848__$1 = cljs.core.next.call(null,seq49848);
var G__49850 = cljs.core.first.call(null,seq49848__$1);
var seq49848__$2 = cljs.core.next.call(null,seq49848__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__49849,G__49850,seq49848__$2);
}));

chromex.ext.runtime.on_restart_required_STAR_ = (function chromex$ext$runtime$on_restart_required_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___49900 = arguments.length;
var i__4790__auto___49901 = (0);
while(true){
if((i__4790__auto___49901 < len__4789__auto___49900)){
args__4795__auto__.push((arguments[i__4790__auto___49901]));

var G__49902 = (i__4790__auto___49901 + (1));
i__4790__auto___49901 = G__49902;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_49882 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.runtime","on-restart-required","chromex.ext.runtime/on-restart-required",-754128621),channel);
})();
var handler_fn_49883 = (function (cb_reason_49889){
return event_fn_49882.call(null,cb_reason_49889);
});
var logging_fn_49884 = (function (cb_param_reason_49890){
var config__25890__auto___49903 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49903))){
var logger__25891__auto___49904 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___49903);
var prefix__25892__auto___49905 = ["event:","chrome.runtime.onRestartRequired"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___49904)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___49903)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___49904.apply(null,prefix__25892__auto___49905.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_reason_49890], null))));
} else {
}

return handler_fn_49883.call(null,cb_param_reason_49890);
});
var ns_obj_49887 = (function (){var target_obj_49891 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__49894 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49895 = oops.state.prepare_state.call(null,target_obj_49891,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49895);

try{var next_obj_49892 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49891,(0),"chrome",true,true,false))?(target_obj_49891["chrome"]):null);
var next_obj_49893 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_49892,(0),"runtime",true,true,false))?(next_obj_49892["runtime"]):null);
return next_obj_49893;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49894);
}})();
var missing_api_49888 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.runtime.onRestartRequired",ns_obj_49887,"onRestartRequired");
})();
if(missing_api_49888 === true){
return null;
} else {
var event_obj_49885 = (function (){var target_obj_49896 = ns_obj_49887;
var _STAR_runtime_state_STAR__orig_val__49898 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__49899 = oops.state.prepare_state.call(null,target_obj_49896,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__49899);

try{var next_obj_49897 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_49896,(0),"onRestartRequired",true,true,false))?(target_obj_49896["onRestartRequired"]):null);
return next_obj_49897;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__49898);
}})();
var result_49886 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_49885,logging_fn_49884,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_49886,args);

return result_49886;
}
}));

(chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$applyTo = (function (seq49879){
var G__49880 = cljs.core.first.call(null,seq49879);
var seq49879__$1 = cljs.core.next.call(null,seq49879);
var G__49881 = cljs.core.first.call(null,seq49879__$1);
var seq49879__$2 = cljs.core.next.call(null,seq49879__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__49880,G__49881,seq49879__$2);
}));


//# sourceMappingURL=runtime.js.map
