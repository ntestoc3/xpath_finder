// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex.ext.storage');
goog.require('cljs.core');
goog.require('chromex.core');
chromex.ext.storage.sync_STAR_ = (function chromex$ext$storage$sync_STAR_(config){
var result_50034 = (function (){var final_args_array_50035 = chromex.support.prepare_final_args_array.call(null,cljs.core.PersistentVector.EMPTY,"chrome.storage.sync");
var ns_50036 = (function (){var target_obj_50039 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__50042 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50043 = oops.state.prepare_state.call(null,target_obj_50039,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50043);

try{var next_obj_50040 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50039,(0),"chrome",true,true,false))?(target_obj_50039["chrome"]):null);
var next_obj_50041 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_50040,(0),"storage",true,true,false))?(next_obj_50040["storage"]):null);
return next_obj_50041;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50042);
}})();
var missing_api_50037 = null;
if(missing_api_50037 === true){
return null;
} else {
var config__25890__auto___50048 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___50048))){
var logger__25891__auto___50049 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___50048);
var prefix__25892__auto___50050 = ["accessing:","chrome.storage.sync"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___50049)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___50048)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___50049.apply(null,prefix__25892__auto___50050.concat(final_args_array_50035));
} else {
}

var target_50038 = (function (){var target_obj_50044 = ns_50036;
var _STAR_runtime_state_STAR__orig_val__50046 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50047 = oops.state.prepare_state.call(null,target_obj_50044,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50047);

try{var next_obj_50045 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50044,(1),"sync",true,true,false))?(target_obj_50044["sync"]):null);
if((!((next_obj_50045 == null)))){
return next_obj_50045;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50046);
}})();
return target_50038;
}
})();
return chromex.marshalling.from_native_chrome_storage_area.call(null,config,result_50034);
});
chromex.ext.storage.local_STAR_ = (function chromex$ext$storage$local_STAR_(config){
var result_50051 = (function (){var final_args_array_50052 = chromex.support.prepare_final_args_array.call(null,cljs.core.PersistentVector.EMPTY,"chrome.storage.local");
var ns_50053 = (function (){var target_obj_50056 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__50059 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50060 = oops.state.prepare_state.call(null,target_obj_50056,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50060);

try{var next_obj_50057 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50056,(0),"chrome",true,true,false))?(target_obj_50056["chrome"]):null);
var next_obj_50058 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_50057,(0),"storage",true,true,false))?(next_obj_50057["storage"]):null);
return next_obj_50058;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50059);
}})();
var missing_api_50054 = null;
if(missing_api_50054 === true){
return null;
} else {
var config__25890__auto___50065 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___50065))){
var logger__25891__auto___50066 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___50065);
var prefix__25892__auto___50067 = ["accessing:","chrome.storage.local"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___50066)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___50065)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___50066.apply(null,prefix__25892__auto___50067.concat(final_args_array_50052));
} else {
}

var target_50055 = (function (){var target_obj_50061 = ns_50053;
var _STAR_runtime_state_STAR__orig_val__50063 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50064 = oops.state.prepare_state.call(null,target_obj_50061,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50064);

try{var next_obj_50062 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50061,(1),"local",true,true,false))?(target_obj_50061["local"]):null);
if((!((next_obj_50062 == null)))){
return next_obj_50062;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50063);
}})();
return target_50055;
}
})();
return chromex.marshalling.from_native_chrome_storage_area.call(null,config,result_50051);
});
chromex.ext.storage.managed_STAR_ = (function chromex$ext$storage$managed_STAR_(config){
var result_50068 = (function (){var final_args_array_50069 = chromex.support.prepare_final_args_array.call(null,cljs.core.PersistentVector.EMPTY,"chrome.storage.managed");
var ns_50070 = (function (){var target_obj_50073 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__50076 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50077 = oops.state.prepare_state.call(null,target_obj_50073,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50077);

try{var next_obj_50074 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50073,(0),"chrome",true,true,false))?(target_obj_50073["chrome"]):null);
var next_obj_50075 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_50074,(0),"storage",true,true,false))?(next_obj_50074["storage"]):null);
return next_obj_50075;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50076);
}})();
var missing_api_50071 = null;
if(missing_api_50071 === true){
return null;
} else {
var config__25890__auto___50082 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___50082))){
var logger__25891__auto___50083 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___50082);
var prefix__25892__auto___50084 = ["accessing:","chrome.storage.managed"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___50083)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___50082)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___50083.apply(null,prefix__25892__auto___50084.concat(final_args_array_50069));
} else {
}

var target_50072 = (function (){var target_obj_50078 = ns_50070;
var _STAR_runtime_state_STAR__orig_val__50080 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50081 = oops.state.prepare_state.call(null,target_obj_50078,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50081);

try{var next_obj_50079 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50078,(1),"managed",true,true,false))?(target_obj_50078["managed"]):null);
if((!((next_obj_50079 == null)))){
return next_obj_50079;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50080);
}})();
return target_50072;
}
})();
return chromex.marshalling.from_native_chrome_storage_area.call(null,config,result_50068);
});
chromex.ext.storage.on_changed_STAR_ = (function chromex$ext$storage$on_changed_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___50108 = arguments.length;
var i__4790__auto___50109 = (0);
while(true){
if((i__4790__auto___50109 < len__4789__auto___50108)){
args__4795__auto__.push((arguments[i__4790__auto___50109]));

var G__50110 = (i__4790__auto___50109 + (1));
i__4790__auto___50109 = G__50110;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.storage.on_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.storage.on_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_50088 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,new cljs.core.Keyword("chromex.ext.storage","on-changed","chromex.ext.storage/on-changed",-1738146817),channel);
})();
var handler_fn_50089 = (function (cb_changes_50095,cb_area_name_50096){
return event_fn_50088.call(null,cb_changes_50095,cb_area_name_50096);
});
var logging_fn_50090 = (function (cb_param_changes_50097,cb_param_area_name_50098){
var config__25890__auto___50111 = config;
if(cljs.core.truth_(new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909).cljs$core$IFn$_invoke$arity$1(config__25890__auto___50111))){
var logger__25891__auto___50112 = new cljs.core.Keyword(null,"logger","logger",-220675947).cljs$core$IFn$_invoke$arity$1(config__25890__auto___50111);
var prefix__25892__auto___50113 = ["event:","chrome.storage.onChanged"];
if(cljs.core.fn_QMARK_.call(null,logger__25891__auto___50112)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___50111)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___50112.apply(null,prefix__25892__auto___50113.concat(cljs.core.into_array.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_changes_50097,cb_param_area_name_50098], null))));
} else {
}

return handler_fn_50089.call(null,cb_param_changes_50097,cb_param_area_name_50098);
});
var ns_obj_50093 = (function (){var target_obj_50099 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__50102 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50103 = oops.state.prepare_state.call(null,target_obj_50099,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50103);

try{var next_obj_50100 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50099,(0),"chrome",true,true,false))?(target_obj_50099["chrome"]):null);
var next_obj_50101 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_50100,(0),"storage",true,true,false))?(next_obj_50100["storage"]):null);
return next_obj_50101;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50102);
}})();
var missing_api_50094 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703).cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_.call(null,api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return api_check_fn__25895__auto__.call(null,"chrome.storage.onChanged",ns_obj_50093,"onChanged");
})();
if(missing_api_50094 === true){
return null;
} else {
var event_obj_50091 = (function (){var target_obj_50104 = ns_obj_50093;
var _STAR_runtime_state_STAR__orig_val__50106 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50107 = oops.state.prepare_state.call(null,target_obj_50104,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50107);

try{var next_obj_50105 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50104,(0),"onChanged",true,true,false))?(target_obj_50104["onChanged"]):null);
return next_obj_50105;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50106);
}})();
var result_50092 = chromex.chrome_event_subscription.make_chrome_event_subscription.call(null,event_obj_50091,logging_fn_50090,channel);
chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,result_50092,args);

return result_50092;
}
}));

(chromex.ext.storage.on_changed_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.storage.on_changed_STAR_.cljs$lang$applyTo = (function (seq50085){
var G__50086 = cljs.core.first.call(null,seq50085);
var seq50085__$1 = cljs.core.next.call(null,seq50085);
var G__50087 = cljs.core.first.call(null,seq50085__$1);
var seq50085__$2 = cljs.core.next.call(null,seq50085__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__50086,G__50087,seq50085__$2);
}));


//# sourceMappingURL=storage.js.map
