(ns chromex.logging
  (:require-macros [chromex.logging]))

; ---------------------------------------------------------------------------------------------------------------------------
; just a stub namespace for macros
