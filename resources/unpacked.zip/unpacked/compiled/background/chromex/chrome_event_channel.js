// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex.chrome_event_channel');
goog.require('cljs.core');
goog.require('chromex.protocols.chrome_event_channel');
goog.require('chromex.protocols.chrome_event_subscription');
goog.require('cljs.core.async.impl.protocols');

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {chromex.protocols.chrome_event_channel.IChromeEventChannel}
*/
chromex.chrome_event_channel.ChromeEventChannel = (function (chan,subscriptions){
this.chan = chan;
this.subscriptions = subscriptions;
});
(chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$ = cljs.core.PROTOCOL_SENTINEL);

(chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$register_BANG_$arity$2 = (function (_this,subscription){
var self__ = this;
var _this__$1 = this;
return (self__.subscriptions = cljs.core.conj.call(null,self__.subscriptions,subscription));
}));

(chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$unregister_BANG_$arity$2 = (function (_this,subscription){
var self__ = this;
var _this__$1 = this;
return (self__.subscriptions = cljs.core.disj.call(null,self__.subscriptions,subscription));
}));

(chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$unsubscribe_all_BANG_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var seq__48131_48135 = cljs.core.seq.call(null,self__.subscriptions);
var chunk__48132_48136 = null;
var count__48133_48137 = (0);
var i__48134_48138 = (0);
while(true){
if((i__48134_48138 < count__48133_48137)){
var subscription_48139 = cljs.core._nth.call(null,chunk__48132_48136,i__48134_48138);
chromex.protocols.chrome_event_subscription.unsubscribe_BANG_.call(null,subscription_48139);


var G__48140 = seq__48131_48135;
var G__48141 = chunk__48132_48136;
var G__48142 = count__48133_48137;
var G__48143 = (i__48134_48138 + (1));
seq__48131_48135 = G__48140;
chunk__48132_48136 = G__48141;
count__48133_48137 = G__48142;
i__48134_48138 = G__48143;
continue;
} else {
var temp__5735__auto___48144 = cljs.core.seq.call(null,seq__48131_48135);
if(temp__5735__auto___48144){
var seq__48131_48145__$1 = temp__5735__auto___48144;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__48131_48145__$1)){
var c__4609__auto___48146 = cljs.core.chunk_first.call(null,seq__48131_48145__$1);
var G__48147 = cljs.core.chunk_rest.call(null,seq__48131_48145__$1);
var G__48148 = c__4609__auto___48146;
var G__48149 = cljs.core.count.call(null,c__4609__auto___48146);
var G__48150 = (0);
seq__48131_48135 = G__48147;
chunk__48132_48136 = G__48148;
count__48133_48137 = G__48149;
i__48134_48138 = G__48150;
continue;
} else {
var subscription_48151 = cljs.core.first.call(null,seq__48131_48145__$1);
chromex.protocols.chrome_event_subscription.unsubscribe_BANG_.call(null,subscription_48151);


var G__48152 = cljs.core.next.call(null,seq__48131_48145__$1);
var G__48153 = null;
var G__48154 = (0);
var G__48155 = (0);
seq__48131_48135 = G__48152;
chunk__48132_48136 = G__48153;
count__48133_48137 = G__48154;
i__48134_48138 = G__48155;
continue;
}
} else {
}
}
break;
}

return (self__.subscriptions = cljs.core.PersistentHashSet.EMPTY);
}));

(chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL);

(chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_this,val,handler){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.put_BANG_.call(null,self__.chan,val,handler);
}));

(chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL);

(chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_this,handler){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.take_BANG_.call(null,self__.chan,handler);
}));

(chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL);

(chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_.call(null,self__.chan);
}));

(chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
chromex.protocols.chrome_event_channel.unsubscribe_all_BANG_.call(null,this$__$1);

return cljs.core.async.impl.protocols.close_BANG_.call(null,self__.chan);
}));

(chromex.chrome_event_channel.ChromeEventChannel.getBasis = (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"chan","chan",-462490168,null),cljs.core.with_meta(new cljs.core.Symbol(null,"subscriptions","subscriptions",-1403485993,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"mutable","mutable",875778266),true], null))], null);
}));

(chromex.chrome_event_channel.ChromeEventChannel.cljs$lang$type = true);

(chromex.chrome_event_channel.ChromeEventChannel.cljs$lang$ctorStr = "chromex.chrome-event-channel/ChromeEventChannel");

(chromex.chrome_event_channel.ChromeEventChannel.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write.call(null,writer__4429__auto__,"chromex.chrome-event-channel/ChromeEventChannel");
}));

/**
 * Positional factory function for chromex.chrome-event-channel/ChromeEventChannel.
 */
chromex.chrome_event_channel.__GT_ChromeEventChannel = (function chromex$chrome_event_channel$__GT_ChromeEventChannel(chan,subscriptions){
return (new chromex.chrome_event_channel.ChromeEventChannel(chan,subscriptions));
});

chromex.chrome_event_channel.make_chrome_event_channel = (function chromex$chrome_event_channel$make_chrome_event_channel(chan){
return (new chromex.chrome_event_channel.ChromeEventChannel(chan,cljs.core.PersistentHashSet.EMPTY));
});

//# sourceMappingURL=chrome_event_channel.js.map
