// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex.chrome_storage_area');
goog.require('cljs.core');
goog.require('chromex.protocols.chrome_storage_area');
goog.require('chromex.support');
goog.require('oops.core');

/**
* @constructor
 * @implements {chromex.protocols.chrome_storage_area.IChromeStorageArea}
*/
chromex.chrome_storage_area.ChromeStorageArea = (function (native_chrome_storage_area,channel_factory,callback_factory){
this.native_chrome_storage_area = native_chrome_storage_area;
this.channel_factory = channel_factory;
this.callback_factory = callback_factory;
});
(chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$ = cljs.core.PROTOCOL_SENTINEL);

(chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_native_storage_area$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_storage_area;
}));

(chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return chromex.protocols.chrome_storage_area.get.call(null,this$__$1,null);
}));

(chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get$arity$2 = (function (_this,keys){
var self__ = this;
var _this__$1 = this;
var channel = self__.channel_factory.call(null);
var target_obj_48461_48491 = self__.native_chrome_storage_area;
var _STAR_runtime_state_STAR__orig_val__48465_48492 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48466_48493 = oops.state.prepare_state.call(null,target_obj_48461_48491,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48466_48493);

try{var call_info_48463_48494 = [target_obj_48461_48491,(function (){var next_obj_48464 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48461_48491,(0),"get",true,true,false))?(target_obj_48461_48491["get"]):null);
return next_obj_48464;
})()];
var fn_48462_48495 = (call_info_48463_48494[(1)]);
if(oops.core.validate_fn_call_dynamically.call(null,fn_48462_48495,oops.state.get_last_access_modifier.call(null))){
if((!((fn_48462_48495 == null)))){
fn_48462_48495.call((call_info_48463_48494[(0)]),keys,self__.callback_factory.call(null,channel));
} else {
}
} else {
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48465_48492);
}
return channel;
}));

(chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_bytes_in_use$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return chromex.protocols.chrome_storage_area.get_bytes_in_use.call(null,this$__$1,null);
}));

(chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_bytes_in_use$arity$2 = (function (_this,keys){
var self__ = this;
var _this__$1 = this;
var channel = self__.channel_factory.call(null);
var target_obj_48467_48496 = self__.native_chrome_storage_area;
var _STAR_runtime_state_STAR__orig_val__48471_48497 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48472_48498 = oops.state.prepare_state.call(null,target_obj_48467_48496,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48472_48498);

try{var call_info_48469_48499 = [target_obj_48467_48496,(function (){var next_obj_48470 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48467_48496,(0),"getBytesInUse",true,true,false))?(target_obj_48467_48496["getBytesInUse"]):null);
return next_obj_48470;
})()];
var fn_48468_48500 = (call_info_48469_48499[(1)]);
if(oops.core.validate_fn_call_dynamically.call(null,fn_48468_48500,oops.state.get_last_access_modifier.call(null))){
if((!((fn_48468_48500 == null)))){
fn_48468_48500.call((call_info_48469_48499[(0)]),keys,self__.callback_factory.call(null,channel));
} else {
}
} else {
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48471_48497);
}
return channel;
}));

(chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$set$arity$2 = (function (_this,items){
var self__ = this;
var _this__$1 = this;
var channel = self__.channel_factory.call(null);
var target_obj_48473_48501 = self__.native_chrome_storage_area;
var _STAR_runtime_state_STAR__orig_val__48477_48502 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48478_48503 = oops.state.prepare_state.call(null,target_obj_48473_48501,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48478_48503);

try{var call_info_48475_48504 = [target_obj_48473_48501,(function (){var next_obj_48476 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48473_48501,(0),"set",true,true,false))?(target_obj_48473_48501["set"]):null);
return next_obj_48476;
})()];
var fn_48474_48505 = (call_info_48475_48504[(1)]);
if(oops.core.validate_fn_call_dynamically.call(null,fn_48474_48505,oops.state.get_last_access_modifier.call(null))){
if((!((fn_48474_48505 == null)))){
fn_48474_48505.call((call_info_48475_48504[(0)]),items,self__.callback_factory.call(null,channel));
} else {
}
} else {
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48477_48502);
}
return channel;
}));

(chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$remove$arity$2 = (function (_this,keys){
var self__ = this;
var _this__$1 = this;
var channel = self__.channel_factory.call(null);
var target_obj_48479_48506 = self__.native_chrome_storage_area;
var _STAR_runtime_state_STAR__orig_val__48483_48507 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48484_48508 = oops.state.prepare_state.call(null,target_obj_48479_48506,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48484_48508);

try{var call_info_48481_48509 = [target_obj_48479_48506,(function (){var next_obj_48482 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48479_48506,(0),"remove",true,true,false))?(target_obj_48479_48506["remove"]):null);
return next_obj_48482;
})()];
var fn_48480_48510 = (call_info_48481_48509[(1)]);
if(oops.core.validate_fn_call_dynamically.call(null,fn_48480_48510,oops.state.get_last_access_modifier.call(null))){
if((!((fn_48480_48510 == null)))){
fn_48480_48510.call((call_info_48481_48509[(0)]),keys,self__.callback_factory.call(null,channel));
} else {
}
} else {
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48483_48507);
}
return channel;
}));

(chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$clear$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var channel = self__.channel_factory.call(null);
var target_obj_48485_48511 = self__.native_chrome_storage_area;
var _STAR_runtime_state_STAR__orig_val__48489_48512 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48490_48513 = oops.state.prepare_state.call(null,target_obj_48485_48511,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48490_48513);

try{var call_info_48487_48514 = [target_obj_48485_48511,(function (){var next_obj_48488 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48485_48511,(0),"clear",true,true,false))?(target_obj_48485_48511["clear"]):null);
return next_obj_48488;
})()];
var fn_48486_48515 = (call_info_48487_48514[(1)]);
if(oops.core.validate_fn_call_dynamically.call(null,fn_48486_48515,oops.state.get_last_access_modifier.call(null))){
if((!((fn_48486_48515 == null)))){
fn_48486_48515.call((call_info_48487_48514[(0)]),self__.callback_factory.call(null,channel));
} else {
}
} else {
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48489_48512);
}
return channel;
}));

(chromex.chrome_storage_area.ChromeStorageArea.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"native-chrome-storage-area","native-chrome-storage-area",-1884589295,null),new cljs.core.Symbol(null,"channel-factory","channel-factory",-705139767,null),new cljs.core.Symbol(null,"callback-factory","callback-factory",-808206009,null)], null);
}));

(chromex.chrome_storage_area.ChromeStorageArea.cljs$lang$type = true);

(chromex.chrome_storage_area.ChromeStorageArea.cljs$lang$ctorStr = "chromex.chrome-storage-area/ChromeStorageArea");

(chromex.chrome_storage_area.ChromeStorageArea.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write.call(null,writer__4429__auto__,"chromex.chrome-storage-area/ChromeStorageArea");
}));

/**
 * Positional factory function for chromex.chrome-storage-area/ChromeStorageArea.
 */
chromex.chrome_storage_area.__GT_ChromeStorageArea = (function chromex$chrome_storage_area$__GT_ChromeStorageArea(native_chrome_storage_area,channel_factory,callback_factory){
return (new chromex.chrome_storage_area.ChromeStorageArea(native_chrome_storage_area,channel_factory,callback_factory));
});

chromex.chrome_storage_area.make_chrome_storage_area = (function chromex$chrome_storage_area$make_chrome_storage_area(config,native_chrome_storage_area){
if(cljs.core.truth_(native_chrome_storage_area)){
} else {
throw (new Error("Assert failed: native-chrome-storage-area"));
}

return (new chromex.chrome_storage_area.ChromeStorageArea(native_chrome_storage_area,(function (){var config__25865__auto__ = config;
var handler_key__25866__auto__ = new cljs.core.Keyword(null,"chrome-storage-area-callback-channel-factory","chrome-storage-area-callback-channel-factory",573191526);
var handler__25867__auto__ = handler_key__25866__auto__.cljs$core$IFn$_invoke$arity$1(config__25865__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25867__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25866__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25865__auto__)].join(''),"\n","(clojure.core/fn? handler__25867__auto__)"].join('')));
}

return cljs.core.partial.call(null,handler__25867__auto__,config__25865__auto__);
})(),(function (){var config__25865__auto__ = config;
var handler_key__25866__auto__ = new cljs.core.Keyword(null,"chrome-storage-area-callback-fn-factory","chrome-storage-area-callback-fn-factory",575077111);
var handler__25867__auto__ = handler_key__25866__auto__.cljs$core$IFn$_invoke$arity$1(config__25865__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25867__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25866__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25865__auto__)].join(''),"\n","(clojure.core/fn? handler__25867__auto__)"].join('')));
}

return cljs.core.partial.call(null,handler__25867__auto__,config__25865__auto__);
})()));
});

//# sourceMappingURL=chrome_storage_area.js.map
