// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex.marshalling');
goog.require('cljs.core');
goog.require('chromex.chrome_content_setting');
goog.require('chromex.chrome_port');
goog.require('chromex.chrome_storage_area');
goog.require('chromex.config');
goog.require('chromex.protocols.chrome_content_setting');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.protocols.chrome_storage_area');
chromex.marshalling.from_native_chrome_port = (function chromex$marshalling$from_native_chrome_port(config,native_chrome_port){
if((!((native_chrome_port == null)))){
return chromex.chrome_port.make_chrome_port.call(null,config,native_chrome_port);
} else {
return null;
}
});
chromex.marshalling.to_native_chrome_port = (function chromex$marshalling$to_native_chrome_port(_config,chrome_port){
if((!((chrome_port == null)))){
if((((!((chrome_port == null))))?((((false) || ((cljs.core.PROTOCOL_SENTINEL === chrome_port.chromex$protocols$chrome_port$IChromePort$))))?true:(((!chrome_port.cljs$lang$protocol_mask$partition$))?cljs.core.native_satisfies_QMARK_.call(null,chromex.protocols.chrome_port.IChromePort,chrome_port):false)):cljs.core.native_satisfies_QMARK_.call(null,chromex.protocols.chrome_port.IChromePort,chrome_port))){
} else {
throw (new Error("Assert failed: (satisfies? IChromePort chrome-port)"));
}

return chromex.protocols.chrome_port.get_native_port.call(null,chrome_port);
} else {
return null;
}
});
chromex.marshalling.from_native_chrome_storage_area = (function chromex$marshalling$from_native_chrome_storage_area(config,native_chrome_storage_area){
if((!((native_chrome_storage_area == null)))){
return chromex.chrome_storage_area.make_chrome_storage_area.call(null,config,native_chrome_storage_area);
} else {
return null;
}
});
chromex.marshalling.to_native_chrome_storage_area = (function chromex$marshalling$to_native_chrome_storage_area(_config,chrome_storage_area){
if((!((chrome_storage_area == null)))){
if((((!((chrome_storage_area == null))))?((((false) || ((cljs.core.PROTOCOL_SENTINEL === chrome_storage_area.chromex$protocols$chrome_storage_area$IChromeStorageArea$))))?true:(((!chrome_storage_area.cljs$lang$protocol_mask$partition$))?cljs.core.native_satisfies_QMARK_.call(null,chromex.protocols.chrome_storage_area.IChromeStorageArea,chrome_storage_area):false)):cljs.core.native_satisfies_QMARK_.call(null,chromex.protocols.chrome_storage_area.IChromeStorageArea,chrome_storage_area))){
} else {
throw (new Error("Assert failed: (satisfies? IChromeStorageArea chrome-storage-area)"));
}

return chromex.protocols.chrome_storage_area.get_native_storage_area.call(null,chrome_storage_area);
} else {
return null;
}
});
chromex.marshalling.from_native_chrome_content_setting = (function chromex$marshalling$from_native_chrome_content_setting(config,native_chrome_content_setting){
if((!((native_chrome_content_setting == null)))){
return chromex.chrome_content_setting.make_chrome_content_setting.call(null,config,native_chrome_content_setting);
} else {
return null;
}
});
chromex.marshalling.to_native_chrome_content_setting = (function chromex$marshalling$to_native_chrome_content_setting(_config,chrome_content_setting){
if((!((chrome_content_setting == null)))){
if((((!((chrome_content_setting == null))))?((((false) || ((cljs.core.PROTOCOL_SENTINEL === chrome_content_setting.chromex$protocols$chrome_content_setting$IChromeContentSetting$))))?true:(((!chrome_content_setting.cljs$lang$protocol_mask$partition$))?cljs.core.native_satisfies_QMARK_.call(null,chromex.protocols.chrome_content_setting.IChromeContentSetting,chrome_content_setting):false)):cljs.core.native_satisfies_QMARK_.call(null,chromex.protocols.chrome_content_setting.IChromeContentSetting,chrome_content_setting))){
} else {
throw (new Error("Assert failed: (satisfies? IChromeContentSetting chrome-content-setting)"));
}

return chromex.protocols.chrome_content_setting.get_native_content_setting.call(null,chrome_content_setting);
} else {
return null;
}
});

//# sourceMappingURL=marshalling.js.map
