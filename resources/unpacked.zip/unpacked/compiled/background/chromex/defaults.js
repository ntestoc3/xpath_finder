// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex.defaults');
goog.require('cljs.core');
goog.require('chromex.error');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.protocols.chrome_port_state');
goog.require('chromex.support');
goog.require('cljs.core.async');
goog.require('goog.object');
goog.require('oops.core');
chromex.defaults.log_prefix = "[chromex]";
chromex.defaults.console_log = (function chromex$defaults$console_log(var_args){
var args__4795__auto__ = [];
var len__4789__auto___48251 = arguments.length;
var i__4790__auto___48252 = (0);
while(true){
if((i__4790__auto___48252 < len__4789__auto___48251)){
args__4795__auto__.push((arguments[i__4790__auto___48252]));

var G__48253 = (i__4790__auto___48252 + (1));
i__4790__auto___48252 = G__48253;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((0) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((0)),(0),null)):null);
return chromex.defaults.console_log.cljs$core$IFn$_invoke$arity$variadic(argseq__4796__auto__);
});

(chromex.defaults.console_log.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return console.log.apply(console,cljs.core.into_array.call(null,args));
}));

(chromex.defaults.console_log.cljs$lang$maxFixedArity = (0));

/** @this {Function} */
(chromex.defaults.console_log.cljs$lang$applyTo = (function (seq48250){
var self__4777__auto__ = this;
return self__4777__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq48250));
}));

chromex.defaults.console_error = (function chromex$defaults$console_error(var_args){
var args__4795__auto__ = [];
var len__4789__auto___48255 = arguments.length;
var i__4790__auto___48256 = (0);
while(true){
if((i__4790__auto___48256 < len__4789__auto___48255)){
args__4795__auto__.push((arguments[i__4790__auto___48256]));

var G__48257 = (i__4790__auto___48256 + (1));
i__4790__auto___48256 = G__48257;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((0) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((0)),(0),null)):null);
return chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic(argseq__4796__auto__);
});

(chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return console.error.apply(console,cljs.core.into_array.call(null,args));
}));

(chromex.defaults.console_error.cljs$lang$maxFixedArity = (0));

/** @this {Function} */
(chromex.defaults.console_error.cljs$lang$applyTo = (function (seq48254){
var self__4777__auto__ = this;
return self__4777__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq48254));
}));

chromex.defaults.default_logger = (function chromex$defaults$default_logger(var_args){
var args__4795__auto__ = [];
var len__4789__auto___48259 = arguments.length;
var i__4790__auto___48260 = (0);
while(true){
if((i__4790__auto___48260 < len__4789__auto___48259)){
args__4795__auto__.push((arguments[i__4790__auto___48260]));

var G__48261 = (i__4790__auto___48260 + (1));
i__4790__auto___48260 = G__48261;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((0) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((0)),(0),null)):null);
return chromex.defaults.default_logger.cljs$core$IFn$_invoke$arity$variadic(argseq__4796__auto__);
});

(chromex.defaults.default_logger.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return cljs.core.apply.call(null,chromex.defaults.console_log,chromex.defaults.log_prefix,args);
}));

(chromex.defaults.default_logger.cljs$lang$maxFixedArity = (0));

/** @this {Function} */
(chromex.defaults.default_logger.cljs$lang$applyTo = (function (seq48258){
var self__4777__auto__ = this;
return self__4777__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq48258));
}));

chromex.defaults.default_callback_error_reporter = (function chromex$defaults$default_callback_error_reporter(descriptor,error){
var function$ = (function (){var or__4185__auto__ = [cljs.core.namespace.call(null,new cljs.core.Keyword(null,"id","id",-1388402092).cljs$core$IFn$_invoke$arity$1(descriptor)),"/",cljs.core.name.call(null,new cljs.core.Keyword(null,"id","id",-1388402092).cljs$core$IFn$_invoke$arity$1(descriptor))].join('');
if(cljs.core.truth_(or__4185__auto__)){
return or__4185__auto__;
} else {
return "an unknown function";
}
})();
var explanation = (function (){var target_obj_48262 = error;
var _STAR_runtime_state_STAR__orig_val__48264 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48265 = oops.state.prepare_state.call(null,target_obj_48262,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48265);

try{var next_obj_48263 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48262,(0),"message",true,true,false))?(target_obj_48262["message"]):null);
return next_obj_48263;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48264);
}})();
var message = ["an error occurred during the call to ",function$,(cljs.core.truth_(explanation)?[": ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(explanation)].join(''):null)].join('');
return chromex.defaults.console_error.call(null,chromex.defaults.log_prefix,message,"Details:",error);
});
chromex.defaults.report_error_if_needed_BANG_ = (function chromex$defaults$report_error_if_needed_BANG_(config,descriptor,error){
var temp__5735__auto__ = new cljs.core.Keyword(null,"callback-error-reporter","callback-error-reporter",-2104016040).cljs$core$IFn$_invoke$arity$1(config);
if(cljs.core.truth_(temp__5735__auto__)){
var error_reporter = temp__5735__auto__;
if(cljs.core.fn_QMARK_.call(null,error_reporter)){
} else {
throw (new Error("Assert failed: (fn? error-reporter)"));
}

return error_reporter.call(null,descriptor,error);
} else {
return null;
}
});
chromex.defaults.normalize_args = (function chromex$defaults$normalize_args(args){
return cljs.core.vec.call(null,args);
});
chromex.defaults.default_callback_fn_factory = (function chromex$defaults$default_callback_fn_factory(config,descriptor,chan){
return (function() { 
var G__48272__delegate = function (args){
var normalized_args = chromex.defaults.normalize_args.call(null,args);
var temp__5737__auto__ = (function (){var target_obj_48266 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__48270 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48271 = oops.state.prepare_state.call(null,target_obj_48266,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48271);

try{var next_obj_48267 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48266,(0),"chrome",true,true,false))?(target_obj_48266["chrome"]):null);
var next_obj_48268 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_48267,(0),"runtime",true,true,false))?(next_obj_48267["runtime"]):null);
var next_obj_48269 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_48268,(1),"lastError",true,true,false))?(next_obj_48268["lastError"]):null);
if((!((next_obj_48269 == null)))){
return next_obj_48269;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48270);
}})();
if((temp__5737__auto__ == null)){
chromex.error.set_last_error_BANG_.call(null,null);

chromex.error.set_last_error_args_BANG_.call(null,null);

return cljs.core.async.put_BANG_.call(null,chan,normalized_args);
} else {
var error = temp__5737__auto__;
chromex.error.set_last_error_BANG_.call(null,error);

chromex.error.set_last_error_args_BANG_.call(null,normalized_args);

chromex.defaults.report_error_if_needed_BANG_.call(null,config,descriptor,error);

return cljs.core.async.close_BANG_.call(null,chan);
}
};
var G__48272 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__48273__i = 0, G__48273__a = new Array(arguments.length -  0);
while (G__48273__i < G__48273__a.length) {G__48273__a[G__48273__i] = arguments[G__48273__i + 0]; ++G__48273__i;}
  args = new cljs.core.IndexedSeq(G__48273__a,0,null);
} 
return G__48272__delegate.call(this,args);};
G__48272.cljs$lang$maxFixedArity = 0;
G__48272.cljs$lang$applyTo = (function (arglist__48274){
var args = cljs.core.seq(arglist__48274);
return G__48272__delegate(args);
});
G__48272.cljs$core$IFn$_invoke$arity$variadic = G__48272__delegate;
return G__48272;
})()
;
});
chromex.defaults.default_callback_channel_factory = (function chromex$defaults$default_callback_channel_factory(_config){
return cljs.core.async.promise_chan.call(null);
});
chromex.defaults.default_event_listener_factory = (function chromex$defaults$default_event_listener_factory(_config,event_id,chan){
return (function() { 
var G__48275__delegate = function (args){
return cljs.core.async.put_BANG_.call(null,chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [event_id,cljs.core.vec.call(null,args)], null));
};
var G__48275 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__48276__i = 0, G__48276__a = new Array(arguments.length -  0);
while (G__48276__i < G__48276__a.length) {G__48276__a[G__48276__i] = arguments[G__48276__i + 0]; ++G__48276__i;}
  args = new cljs.core.IndexedSeq(G__48276__a,0,null);
} 
return G__48275__delegate.call(this,args);};
G__48275.cljs$lang$maxFixedArity = 0;
G__48275.cljs$lang$applyTo = (function (arglist__48277){
var args = cljs.core.seq(arglist__48277);
return G__48275__delegate(args);
});
G__48275.cljs$core$IFn$_invoke$arity$variadic = G__48275__delegate;
return G__48275;
})()
;
});
chromex.defaults.default_missing_api_check = (function chromex$defaults$default_missing_api_check(api,obj,key){
if(goog.object.containsKey(obj,key)){
return null;
} else {
console.error((new Error(["Chromex library tried to access a missing Chrome API object '",cljs.core.str.cljs$core$IFn$_invoke$arity$1(api),"'.\n","Your Chrome version might be too old or too recent for running this extension.\n","This is a failure which probably requires a software update."].join(''))));

return true;
}
});
chromex.defaults.default_chrome_content_setting_callback_fn_factory = (function chromex$defaults$default_chrome_content_setting_callback_fn_factory(config,chan){
return (function() { 
var G__48284__delegate = function (args){
var last_error = (function (){var target_obj_48278 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__48282 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48283 = oops.state.prepare_state.call(null,target_obj_48278,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48283);

try{var next_obj_48279 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48278,(0),"chrome",true,true,false))?(target_obj_48278["chrome"]):null);
var next_obj_48280 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_48279,(0),"runtime",true,true,false))?(next_obj_48279["runtime"]):null);
var next_obj_48281 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_48280,(1),"lastError",true,true,false))?(next_obj_48280["lastError"]):null);
if((!((next_obj_48281 == null)))){
return next_obj_48281;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48282);
}})();
return cljs.core.async.put_BANG_.call(null,chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.vec.call(null,args),last_error], null));
};
var G__48284 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__48285__i = 0, G__48285__a = new Array(arguments.length -  0);
while (G__48285__i < G__48285__a.length) {G__48285__a[G__48285__i] = arguments[G__48285__i + 0]; ++G__48285__i;}
  args = new cljs.core.IndexedSeq(G__48285__a,0,null);
} 
return G__48284__delegate.call(this,args);};
G__48284.cljs$lang$maxFixedArity = 0;
G__48284.cljs$lang$applyTo = (function (arglist__48286){
var args = cljs.core.seq(arglist__48286);
return G__48284__delegate(args);
});
G__48284.cljs$core$IFn$_invoke$arity$variadic = G__48284__delegate;
return G__48284;
})()
;
});
chromex.defaults.default_chrome_content_setting_callback_channel_factory = (function chromex$defaults$default_chrome_content_setting_callback_channel_factory(_config){
return cljs.core.async.promise_chan.call(null);
});
chromex.defaults.default_chrome_storage_area_callback_fn_factory = (function chromex$defaults$default_chrome_storage_area_callback_fn_factory(config,chan){
return (function() { 
var G__48293__delegate = function (args){
var last_error = (function (){var target_obj_48287 = new cljs.core.Keyword(null,"root","root",-448657453).cljs$core$IFn$_invoke$arity$1(config);
var _STAR_runtime_state_STAR__orig_val__48291 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48292 = oops.state.prepare_state.call(null,target_obj_48287,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48292);

try{var next_obj_48288 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48287,(0),"chrome",true,true,false))?(target_obj_48287["chrome"]):null);
var next_obj_48289 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_48288,(0),"runtime",true,true,false))?(next_obj_48288["runtime"]):null);
var next_obj_48290 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_48289,(1),"lastError",true,true,false))?(next_obj_48289["lastError"]):null);
if((!((next_obj_48290 == null)))){
return next_obj_48290;
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48291);
}})();
return cljs.core.async.put_BANG_.call(null,chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.vec.call(null,args),last_error], null));
};
var G__48293 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__48294__i = 0, G__48294__a = new Array(arguments.length -  0);
while (G__48294__i < G__48294__a.length) {G__48294__a[G__48294__i] = arguments[G__48294__i + 0]; ++G__48294__i;}
  args = new cljs.core.IndexedSeq(G__48294__a,0,null);
} 
return G__48293__delegate.call(this,args);};
G__48293.cljs$lang$maxFixedArity = 0;
G__48293.cljs$lang$applyTo = (function (arglist__48295){
var args = cljs.core.seq(arglist__48295);
return G__48293__delegate(args);
});
G__48293.cljs$core$IFn$_invoke$arity$variadic = G__48293__delegate;
return G__48293;
})()
;
});
chromex.defaults.default_chrome_storage_area_callback_channel_factory = (function chromex$defaults$default_chrome_storage_area_callback_channel_factory(_config){
return cljs.core.async.promise_chan.call(null);
});
chromex.defaults.default_chrome_port_channel_factory = (function chromex$defaults$default_chrome_port_channel_factory(_config){
return cljs.core.async.chan.call(null);
});
chromex.defaults.default_chrome_port_on_message_fn_factory = (function chromex$defaults$default_chrome_port_on_message_fn_factory(config,chrome_port){
return (function (message){
if((message == null)){
var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"chrome-port-received-nil-message","chrome-port-received-nil-message",-1593119285);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,chrome_port);
} else {
chromex.protocols.chrome_port_state.put_message_BANG_.call(null,chrome_port,message);

return null;
}
});
});
chromex.defaults.default_chrome_port_on_disconnect_fn_factory = (function chromex$defaults$default_chrome_port_on_disconnect_fn_factory(_config,chrome_port){
return (function (){
chromex.protocols.chrome_port_state.close_resources_BANG_.call(null,chrome_port);

chromex.protocols.chrome_port_state.set_connected_BANG_.call(null,chrome_port,false);

return null;
});
});
chromex.defaults.default_chrome_port_disconnect_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_disconnect_called_on_disconnected_port(_config,_chrome_port){
throw (new Error(["Assert failed: ","ChromePort: disconnect! called on already disconnected port","\n","false"].join('')));

});
chromex.defaults.default_chrome_port_post_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_post_message_called_on_disconnected_port(_config,_chrome_port){
throw (new Error(["Assert failed: ","ChromePort: post-message! called on already disconnected port","\n","false"].join('')));

});
chromex.defaults.default_chrome_port_on_disconnect_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_on_disconnect_called_on_disconnected_port(_config,_chrome_port){
throw (new Error(["Assert failed: ","ChromePort: on-disconnect! called on already disconnected port","\n","false"].join('')));

});
chromex.defaults.default_chrome_port_on_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_on_message_called_on_disconnected_port(_config,_chrome_port){
throw (new Error(["Assert failed: ","ChromePort: on-message! called on already disconnected port","\n","false"].join('')));

});
chromex.defaults.default_chrome_port_post_message_called_with_nil = (function chromex$defaults$default_chrome_port_post_message_called_with_nil(_config,_chrome_port){
throw (new Error(["Assert failed: ","ChromePort: post-message! called with nil message. Nil cannot be delivered via a core.async channel.","\n","false"].join('')));

});
chromex.defaults.default_chrome_port_received_nil_message = (function chromex$defaults$default_chrome_port_received_nil_message(_config,_chrome_port){
throw (new Error(["Assert failed: ","ChromePort: received a nil message. Nil cannot be delivered via a core.async channel.","\n","false"].join('')));

});
chromex.defaults.default_chrome_port_put_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_put_message_called_on_disconnected_port(_config,_chrome_port,message){
throw (new Error(["Assert failed: ",["ChromePort: put-message! called on already disconnected port.\n","message: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(message)].join(''),"\n","false"].join('')));

});
chromex.defaults.default_config = cljs.core.PersistentHashMap.fromArrays([new cljs.core.Keyword(null,"chrome-port-post-message-called-on-disconnected-port","chrome-port-post-message-called-on-disconnected-port",-1329006944),new cljs.core.Keyword(null,"chrome-port-put-message-called-on-disconnected-port","chrome-port-put-message-called-on-disconnected-port",1479634211),new cljs.core.Keyword(null,"chrome-port-on-disconnect-called-on-disconnected-port","chrome-port-on-disconnect-called-on-disconnected-port",-269858172),new cljs.core.Keyword(null,"chrome-storage-area-callback-channel-factory","chrome-storage-area-callback-channel-factory",573191526),new cljs.core.Keyword(null,"chrome-port-post-message-called-with-nil","chrome-port-post-message-called-with-nil",864934312),new cljs.core.Keyword(null,"chrome-port-channel-factory","chrome-port-channel-factory",393485192),new cljs.core.Keyword(null,"missing-api-check-fn","missing-api-check-fn",-1196803703),new cljs.core.Keyword(null,"chrome-port-received-nil-message","chrome-port-received-nil-message",-1593119285),new cljs.core.Keyword(null,"chrome-port-on-message-called-on-disconnected-port","chrome-port-on-message-called-on-disconnected-port",1590595021),new cljs.core.Keyword(null,"chrome-port-on-message-fn-factory","chrome-port-on-message-fn-factory",1295000398),new cljs.core.Keyword(null,"chrome-port-disconnect-called-on-disconnected-port","chrome-port-disconnect-called-on-disconnected-port",-1526797777),new cljs.core.Keyword(null,"chrome-content-setting-callback-channel-factory","chrome-content-setting-callback-channel-factory",357153969),new cljs.core.Keyword(null,"root","root",-448657453),new cljs.core.Keyword(null,"logger","logger",-220675947),new cljs.core.Keyword(null,"event-listener-factory","event-listener-factory",-1976310091),new cljs.core.Keyword(null,"callback-fn-factory","callback-fn-factory",2078895029),new cljs.core.Keyword(null,"chrome-content-setting-callback-fn-factory","chrome-content-setting-callback-fn-factory",-825214441),new cljs.core.Keyword(null,"chrome-storage-area-callback-fn-factory","chrome-storage-area-callback-fn-factory",575077111),new cljs.core.Keyword(null,"callback-error-reporter","callback-error-reporter",-2104016040),new cljs.core.Keyword(null,"verbose-logging","verbose-logging",-1125099909),new cljs.core.Keyword(null,"callback-channel-factory","callback-channel-factory",196315003),new cljs.core.Keyword(null,"chrome-port-on-disconnect-fn-factory","chrome-port-on-disconnect-fn-factory",-501244675)],[chromex.defaults.default_chrome_port_post_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_put_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_on_disconnect_called_on_disconnected_port,chromex.defaults.default_chrome_storage_area_callback_channel_factory,chromex.defaults.default_chrome_port_post_message_called_with_nil,chromex.defaults.default_chrome_port_channel_factory,chromex.defaults.default_missing_api_check,chromex.defaults.default_chrome_port_received_nil_message,chromex.defaults.default_chrome_port_on_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_on_message_fn_factory,chromex.defaults.default_chrome_port_disconnect_called_on_disconnected_port,chromex.defaults.default_chrome_content_setting_callback_channel_factory,goog.global,chromex.defaults.default_logger,chromex.defaults.default_event_listener_factory,chromex.defaults.default_callback_fn_factory,chromex.defaults.default_chrome_content_setting_callback_fn_factory,chromex.defaults.default_chrome_storage_area_callback_fn_factory,chromex.defaults.default_callback_error_reporter,false,chromex.defaults.default_callback_channel_factory,chromex.defaults.default_chrome_port_on_disconnect_fn_factory]);

//# sourceMappingURL=defaults.js.map
