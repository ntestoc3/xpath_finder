// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex.chrome_event_subscription');
goog.require('cljs.core');
goog.require('chromex.protocols.chrome_event_channel');
goog.require('chromex.protocols.chrome_event_subscription');
goog.require('oops.core');

/**
* @constructor
 * @implements {chromex.protocols.chrome_event_subscription.IChromeEventSubscription}
*/
chromex.chrome_event_subscription.ChromeEventSubscription = (function (chrome_event,listener,chan,subscribed_count){
this.chrome_event = chrome_event;
this.listener = listener;
this.chan = chan;
this.subscribed_count = subscribed_count;
});
(chromex.chrome_event_subscription.ChromeEventSubscription.prototype.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$ = cljs.core.PROTOCOL_SENTINEL);

(chromex.chrome_event_subscription.ChromeEventSubscription.prototype.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return chromex.protocols.chrome_event_subscription.subscribe_BANG_.call(null,this$__$1,null);
}));

(chromex.chrome_event_subscription.ChromeEventSubscription.prototype.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2 = (function (this$,extra_args){
var self__ = this;
var this$__$1 = this;
new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"pre","pre",2118456869),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [(((extra_args == null)) || (cljs.core.seq_QMARK_.call(null,extra_args)))], null)], null);

if((!(cljs.core._EQ_.call(null,self__.subscribed_count,(0))))){
return chromex.chrome_event_subscription._STAR_subscribe_called_while_subscribed_STAR_.call(null,this$__$1);
} else {
if((((!((self__.chan == null))))?((((false) || ((cljs.core.PROTOCOL_SENTINEL === self__.chan.chromex$protocols$chrome_event_channel$IChromeEventChannel$))))?true:(((!self__.chan.cljs$lang$protocol_mask$partition$))?cljs.core.native_satisfies_QMARK_.call(null,chromex.protocols.chrome_event_channel.IChromeEventChannel,self__.chan):false)):cljs.core.native_satisfies_QMARK_.call(null,chromex.protocols.chrome_event_channel.IChromeEventChannel,self__.chan))){
chromex.protocols.chrome_event_channel.register_BANG_.call(null,self__.chan,this$__$1);
} else {
}

(self__.subscribed_count = (self__.subscribed_count + (1)));

var target_obj_48180 = self__.chrome_event;
var _STAR_runtime_state_STAR__orig_val__48184 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48185 = oops.state.prepare_state.call(null,target_obj_48180,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48185);

try{var call_info_48182 = [target_obj_48180,(function (){var next_obj_48183 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48180,(0),"addListener",true,true,false))?(target_obj_48180["addListener"]):null);
return next_obj_48183;
})()];
var fn_48181 = (call_info_48182[(1)]);
if(oops.core.validate_fn_call_dynamically.call(null,fn_48181,oops.state.get_last_access_modifier.call(null))){
if((!((fn_48181 == null)))){
return fn_48181.apply((call_info_48182[(0)]),oops.helpers.to_native_array.call(null,cljs.core.cons.call(null,self__.listener,extra_args)));
} else {
return null;
}
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48184);
}}
}));

(chromex.chrome_event_subscription.ChromeEventSubscription.prototype.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$unsubscribe_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
if((!(cljs.core._EQ_.call(null,self__.subscribed_count,(1))))){
return chromex.chrome_event_subscription._STAR_unsubscribe_called_while_not_subscribed_STAR_.call(null,this$__$1);
} else {
(self__.subscribed_count = (self__.subscribed_count - (1)));

var target_obj_48186_48193 = self__.chrome_event;
var _STAR_runtime_state_STAR__orig_val__48190_48194 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48191_48195 = oops.state.prepare_state.call(null,target_obj_48186_48193,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48191_48195);

try{var call_info_48188_48196 = [target_obj_48186_48193,(function (){var next_obj_48189 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48186_48193,(0),"removeListener",true,true,false))?(target_obj_48186_48193["removeListener"]):null);
return next_obj_48189;
})()];
var fn_48187_48197 = (call_info_48188_48196[(1)]);
if(oops.core.validate_fn_call_dynamically.call(null,fn_48187_48197,oops.state.get_last_access_modifier.call(null))){
if((!((fn_48187_48197 == null)))){
fn_48187_48197.call((call_info_48188_48196[(0)]),self__.listener);
} else {
}
} else {
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48190_48194);
}
if((((!((self__.chan == null))))?((((false) || ((cljs.core.PROTOCOL_SENTINEL === self__.chan.chromex$protocols$chrome_event_channel$IChromeEventChannel$))))?true:(((!self__.chan.cljs$lang$protocol_mask$partition$))?cljs.core.native_satisfies_QMARK_.call(null,chromex.protocols.chrome_event_channel.IChromeEventChannel,self__.chan):false)):cljs.core.native_satisfies_QMARK_.call(null,chromex.protocols.chrome_event_channel.IChromeEventChannel,self__.chan))){
return chromex.protocols.chrome_event_channel.unregister_BANG_.call(null,self__.chan,this$__$1);
} else {
return null;
}
}
}));

(chromex.chrome_event_subscription.ChromeEventSubscription.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"chrome-event","chrome-event",-2110595104,null),new cljs.core.Symbol(null,"listener","listener",-1772288521,null),new cljs.core.Symbol(null,"chan","chan",-462490168,null),cljs.core.with_meta(new cljs.core.Symbol(null,"subscribed-count","subscribed-count",1987758776,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"mutable","mutable",875778266),true], null))], null);
}));

(chromex.chrome_event_subscription.ChromeEventSubscription.cljs$lang$type = true);

(chromex.chrome_event_subscription.ChromeEventSubscription.cljs$lang$ctorStr = "chromex.chrome-event-subscription/ChromeEventSubscription");

(chromex.chrome_event_subscription.ChromeEventSubscription.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write.call(null,writer__4429__auto__,"chromex.chrome-event-subscription/ChromeEventSubscription");
}));

/**
 * Positional factory function for chromex.chrome-event-subscription/ChromeEventSubscription.
 */
chromex.chrome_event_subscription.__GT_ChromeEventSubscription = (function chromex$chrome_event_subscription$__GT_ChromeEventSubscription(chrome_event,listener,chan,subscribed_count){
return (new chromex.chrome_event_subscription.ChromeEventSubscription(chrome_event,listener,chan,subscribed_count));
});

chromex.chrome_event_subscription.make_chrome_event_subscription = (function chromex$chrome_event_subscription$make_chrome_event_subscription(chrome_event,listener,chan){
if(cljs.core.truth_(chrome_event)){
} else {
throw (new Error("Assert failed: chrome-event"));
}

if(cljs.core.truth_(listener)){
} else {
throw (new Error("Assert failed: listener"));
}

if(cljs.core.truth_(chan)){
} else {
throw (new Error("Assert failed: chan"));
}

return (new chromex.chrome_event_subscription.ChromeEventSubscription(chrome_event,listener,chan,(0)));
});
chromex.chrome_event_subscription._STAR_subscribe_called_while_subscribed_STAR_ = (function chromex$chrome_event_subscription$_STAR_subscribe_called_while_subscribed_STAR_(_chrome_event_subscription){
throw (new Error(["Assert failed: ","ChromeEventSubscription: subscribe called while already subscribed","\n","false"].join('')));

});
chromex.chrome_event_subscription._STAR_unsubscribe_called_while_not_subscribed_STAR_ = (function chromex$chrome_event_subscription$_STAR_unsubscribe_called_while_not_subscribed_STAR_(_chrome_event_subscription){
throw (new Error(["Assert failed: ","ChromeEventSubscription: unsubscribe called while not subscribed","\n","false"].join('')));

});

//# sourceMappingURL=chrome_event_subscription.js.map
