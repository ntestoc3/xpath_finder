// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex.logging');
goog.require('cljs.core');

//# sourceMappingURL=logging.js.map
