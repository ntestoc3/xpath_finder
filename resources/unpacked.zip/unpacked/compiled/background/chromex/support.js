// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex.support');
goog.require('cljs.core');
goog.require('goog.object');
chromex.support.prepare_final_args_array = (function chromex$support$prepare_final_args_array(arg_descriptors,api){
var should_omit_QMARK_ = (function (p__42089){
var vec__42090 = p__42089;
var val = cljs.core.nth.call(null,vec__42090,(0),null);
var param_name = cljs.core.nth.call(null,vec__42090,(1),null);
var can_be_omitted_QMARK_ = cljs.core.nth.call(null,vec__42090,(2),null);
if(cljs.core.keyword_identical_QMARK_.call(null,val,new cljs.core.Keyword(null,"omit","omit",-1917972325))){
if(cljs.core.truth_(can_be_omitted_QMARK_)){
} else {
throw (new Error(["Assert failed: ",["Parameter '",cljs.core.str.cljs$core$IFn$_invoke$arity$1(param_name),"' cannot be omitted in a call to '",cljs.core.str.cljs$core$IFn$_invoke$arity$1(api),"'. ","The parameter not declared as optional."].join(''),"\n","can-be-omitted?"].join('')));
}

return true;
} else {
return null;
}
});
return cljs.core.into_array.call(null,cljs.core.map.call(null,cljs.core.first,cljs.core.remove.call(null,should_omit_QMARK_,arg_descriptors)));
});

//# sourceMappingURL=support.js.map
