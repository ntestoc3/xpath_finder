// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex.chrome_content_setting');
goog.require('cljs.core');
goog.require('chromex.protocols.chrome_content_setting');
goog.require('chromex.support');
goog.require('oops.core');

/**
* @constructor
 * @implements {chromex.protocols.chrome_content_setting.IChromeContentSetting}
*/
chromex.chrome_content_setting.ChromeContentSetting = (function (native_chrome_content_setting,channel_factory,callback_factory){
this.native_chrome_content_setting = native_chrome_content_setting;
this.channel_factory = channel_factory;
this.callback_factory = callback_factory;
});
(chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$ = cljs.core.PROTOCOL_SENTINEL);

(chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_native_content_setting$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_content_setting;
}));

(chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = self__.channel_factory.call(null);
var target_obj_48358_48382 = self__.native_chrome_content_setting;
var _STAR_runtime_state_STAR__orig_val__48362_48383 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48363_48384 = oops.state.prepare_state.call(null,target_obj_48358_48382,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48363_48384);

try{var call_info_48360_48385 = [target_obj_48358_48382,(function (){var next_obj_48361 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48358_48382,(0),"get",true,true,false))?(target_obj_48358_48382["get"]):null);
return next_obj_48361;
})()];
var fn_48359_48386 = (call_info_48360_48385[(1)]);
if(oops.core.validate_fn_call_dynamically.call(null,fn_48359_48386,oops.state.get_last_access_modifier.call(null))){
if((!((fn_48359_48386 == null)))){
fn_48359_48386.call((call_info_48360_48385[(0)]),details,self__.callback_factory.call(null,channel));
} else {
}
} else {
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48362_48383);
}
return channel;
}));

(chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$set$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = self__.channel_factory.call(null);
var target_obj_48364_48387 = self__.native_chrome_content_setting;
var _STAR_runtime_state_STAR__orig_val__48368_48388 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48369_48389 = oops.state.prepare_state.call(null,target_obj_48364_48387,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48369_48389);

try{var call_info_48366_48390 = [target_obj_48364_48387,(function (){var next_obj_48367 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48364_48387,(0),"set",true,true,false))?(target_obj_48364_48387["set"]):null);
return next_obj_48367;
})()];
var fn_48365_48391 = (call_info_48366_48390[(1)]);
if(oops.core.validate_fn_call_dynamically.call(null,fn_48365_48391,oops.state.get_last_access_modifier.call(null))){
if((!((fn_48365_48391 == null)))){
fn_48365_48391.call((call_info_48366_48390[(0)]),details,self__.callback_factory.call(null,channel));
} else {
}
} else {
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48368_48388);
}
return channel;
}));

(chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$clear$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = self__.channel_factory.call(null);
var target_obj_48370_48392 = self__.native_chrome_content_setting;
var _STAR_runtime_state_STAR__orig_val__48374_48393 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48375_48394 = oops.state.prepare_state.call(null,target_obj_48370_48392,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48375_48394);

try{var call_info_48372_48395 = [target_obj_48370_48392,(function (){var next_obj_48373 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48370_48392,(0),"clear",true,true,false))?(target_obj_48370_48392["clear"]):null);
return next_obj_48373;
})()];
var fn_48371_48396 = (call_info_48372_48395[(1)]);
if(oops.core.validate_fn_call_dynamically.call(null,fn_48371_48396,oops.state.get_last_access_modifier.call(null))){
if((!((fn_48371_48396 == null)))){
fn_48371_48396.call((call_info_48372_48395[(0)]),details,self__.callback_factory.call(null,channel));
} else {
}
} else {
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48374_48393);
}
return channel;
}));

(chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_resource_identifiers$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var channel = self__.channel_factory.call(null);
var target_obj_48376_48397 = self__.native_chrome_content_setting;
var _STAR_runtime_state_STAR__orig_val__48380_48398 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48381_48399 = oops.state.prepare_state.call(null,target_obj_48376_48397,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48381_48399);

try{var call_info_48378_48400 = [target_obj_48376_48397,(function (){var next_obj_48379 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48376_48397,(0),"getResourceIdentifiers",true,true,false))?(target_obj_48376_48397["getResourceIdentifiers"]):null);
return next_obj_48379;
})()];
var fn_48377_48401 = (call_info_48378_48400[(1)]);
if(oops.core.validate_fn_call_dynamically.call(null,fn_48377_48401,oops.state.get_last_access_modifier.call(null))){
if((!((fn_48377_48401 == null)))){
fn_48377_48401.call((call_info_48378_48400[(0)]),self__.callback_factory.call(null,channel));
} else {
}
} else {
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48380_48398);
}
return channel;
}));

(chromex.chrome_content_setting.ChromeContentSetting.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"native-chrome-content-setting","native-chrome-content-setting",-1995806457,null),new cljs.core.Symbol(null,"channel-factory","channel-factory",-705139767,null),new cljs.core.Symbol(null,"callback-factory","callback-factory",-808206009,null)], null);
}));

(chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$type = true);

(chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$ctorStr = "chromex.chrome-content-setting/ChromeContentSetting");

(chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write.call(null,writer__4429__auto__,"chromex.chrome-content-setting/ChromeContentSetting");
}));

/**
 * Positional factory function for chromex.chrome-content-setting/ChromeContentSetting.
 */
chromex.chrome_content_setting.__GT_ChromeContentSetting = (function chromex$chrome_content_setting$__GT_ChromeContentSetting(native_chrome_content_setting,channel_factory,callback_factory){
return (new chromex.chrome_content_setting.ChromeContentSetting(native_chrome_content_setting,channel_factory,callback_factory));
});

chromex.chrome_content_setting.make_chrome_content_setting = (function chromex$chrome_content_setting$make_chrome_content_setting(config,native_chrome_content_setting){
if(cljs.core.truth_(native_chrome_content_setting)){
} else {
throw (new Error("Assert failed: native-chrome-content-setting"));
}

return (new chromex.chrome_content_setting.ChromeContentSetting(native_chrome_content_setting,(function (){var config__25865__auto__ = config;
var handler_key__25866__auto__ = new cljs.core.Keyword(null,"chrome-content-setting-callback-channel-factory","chrome-content-setting-callback-channel-factory",357153969);
var handler__25867__auto__ = handler_key__25866__auto__.cljs$core$IFn$_invoke$arity$1(config__25865__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25867__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25866__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25865__auto__)].join(''),"\n","(clojure.core/fn? handler__25867__auto__)"].join('')));
}

return cljs.core.partial.call(null,handler__25867__auto__,config__25865__auto__);
})(),(function (){var config__25865__auto__ = config;
var handler_key__25866__auto__ = new cljs.core.Keyword(null,"chrome-content-setting-callback-fn-factory","chrome-content-setting-callback-fn-factory",-825214441);
var handler__25867__auto__ = handler_key__25866__auto__.cljs$core$IFn$_invoke$arity$1(config__25865__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25867__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25866__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25865__auto__)].join(''),"\n","(clojure.core/fn? handler__25867__auto__)"].join('')));
}

return cljs.core.partial.call(null,handler__25867__auto__,config__25865__auto__);
})()));
});

//# sourceMappingURL=chrome_content_setting.js.map
