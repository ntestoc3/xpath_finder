// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex.chrome_port');
goog.require('cljs.core');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.protocols.chrome_port_state');
goog.require('chromex.support');
goog.require('cljs.core.async');
goog.require('cljs.core.async.impl.protocols');
goog.require('oops.core');

/**
* @constructor
 * @implements {chromex.protocols.chrome_port.IChromePort}
 * @implements {chromex.protocols.chrome_port_state.IChromePortState}
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
*/
chromex.chrome_port.ChromePort = (function (config,native_chrome_port,channel,connected_QMARK_){
this.config = config;
this.native_chrome_port = native_chrome_port;
this.channel = channel;
this.connected_QMARK_ = connected_QMARK_;
});
(chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$ = cljs.core.PROTOCOL_SENTINEL);

(chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$get_native_port$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_port;
}));

(chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$get_name$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var target_obj_48059 = self__.native_chrome_port;
var _STAR_runtime_state_STAR__orig_val__48061 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48062 = oops.state.prepare_state.call(null,target_obj_48059,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48062);

try{var next_obj_48060 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48059,(0),"name",true,true,false))?(target_obj_48059["name"]):null);
return next_obj_48060;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48061);
}}));

(chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$get_sender$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var target_obj_48063 = self__.native_chrome_port;
var _STAR_runtime_state_STAR__orig_val__48065 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48066 = oops.state.prepare_state.call(null,target_obj_48063,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48066);

try{var next_obj_48064 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48063,(0),"sender",true,true,false))?(target_obj_48063["sender"]):null);
return next_obj_48064;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48065);
}}));

(chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$post_message_BANG_$arity$2 = (function (this$,message){
var self__ = this;
var this$__$1 = this;
if((message == null)){
var config__25856__auto__ = self__.config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"chrome-port-post-message-called-with-nil","chrome-port-post-message-called-with-nil",864934312);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,this$__$1);
} else {
if(cljs.core.truth_(self__.connected_QMARK_)){
var target_obj_48067 = self__.native_chrome_port;
var _STAR_runtime_state_STAR__orig_val__48071 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48072 = oops.state.prepare_state.call(null,target_obj_48067,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48072);

try{var call_info_48069 = [target_obj_48067,(function (){var next_obj_48070 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48067,(0),"postMessage",true,true,false))?(target_obj_48067["postMessage"]):null);
return next_obj_48070;
})()];
var fn_48068 = (call_info_48069[(1)]);
if(oops.core.validate_fn_call_dynamically.call(null,fn_48068,oops.state.get_last_access_modifier.call(null))){
if((!((fn_48068 == null)))){
return fn_48068.call((call_info_48069[(0)]),message);
} else {
return null;
}
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48071);
}} else {
var config__25856__auto__ = self__.config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"chrome-port-post-message-called-on-disconnected-port","chrome-port-post-message-called-on-disconnected-port",-1329006944);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,this$__$1);
}
}
}));

(chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$disconnect_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
var target_obj_48073 = self__.native_chrome_port;
var _STAR_runtime_state_STAR__orig_val__48077 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48078 = oops.state.prepare_state.call(null,target_obj_48073,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48078);

try{var call_info_48075 = [target_obj_48073,(function (){var next_obj_48076 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48073,(0),"disconnect",true,true,false))?(target_obj_48073["disconnect"]):null);
return next_obj_48076;
})()];
var fn_48074 = (call_info_48075[(1)]);
if(oops.core.validate_fn_call_dynamically.call(null,fn_48074,oops.state.get_last_access_modifier.call(null))){
if((!((fn_48074 == null)))){
return fn_48074.call((call_info_48075[(0)]));
} else {
return null;
}
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48077);
}} else {
var config__25856__auto__ = self__.config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"chrome-port-disconnect-called-on-disconnected-port","chrome-port-disconnect-called-on-disconnected-port",-1526797777);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,this$__$1);
}
}));

(chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$on_disconnect_BANG_$arity$2 = (function (this$,callback){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
var target_obj_48079 = self__.native_chrome_port;
var _STAR_runtime_state_STAR__orig_val__48085 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48086 = oops.state.prepare_state.call(null,target_obj_48079,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48086);

try{var call_info_48081 = (function (){var target_obj_48082 = (function (){var next_obj_48083 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48079,(0),"onDisconnect",true,true,false))?(target_obj_48079["onDisconnect"]):null);
return next_obj_48083;
})();
return [target_obj_48082,(function (){var next_obj_48084 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48082,(0),"addListener",true,true,false))?(target_obj_48082["addListener"]):null);
return next_obj_48084;
})()];
})();
var fn_48080 = (call_info_48081[(1)]);
if(oops.core.validate_fn_call_dynamically.call(null,fn_48080,oops.state.get_last_access_modifier.call(null))){
if((!((fn_48080 == null)))){
return fn_48080.call((call_info_48081[(0)]),callback);
} else {
return null;
}
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48085);
}} else {
var config__25856__auto__ = self__.config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"chrome-port-on-disconnect-called-on-disconnected-port","chrome-port-on-disconnect-called-on-disconnected-port",-269858172);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,this$__$1);
}
}));

(chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$on_message_BANG_$arity$2 = (function (this$,callback){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
var target_obj_48087 = self__.native_chrome_port;
var _STAR_runtime_state_STAR__orig_val__48093 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__48094 = oops.state.prepare_state.call(null,target_obj_48087,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__48094);

try{var call_info_48089 = (function (){var target_obj_48090 = (function (){var next_obj_48091 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48087,(0),"onMessage",true,true,false))?(target_obj_48087["onMessage"]):null);
return next_obj_48091;
})();
return [target_obj_48090,(function (){var next_obj_48092 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_48090,(0),"addListener",true,true,false))?(target_obj_48090["addListener"]):null);
return next_obj_48092;
})()];
})();
var fn_48088 = (call_info_48089[(1)]);
if(oops.core.validate_fn_call_dynamically.call(null,fn_48088,oops.state.get_last_access_modifier.call(null))){
if((!((fn_48088 == null)))){
return fn_48088.call((call_info_48089[(0)]),callback);
} else {
return null;
}
} else {
return null;
}
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__48093);
}} else {
var config__25856__auto__ = self__.config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"chrome-port-on-message-called-on-disconnected-port","chrome-port-on-message-called-on-disconnected-port",1590595021);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,this$__$1);
}
}));

(chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port_state$IChromePortState$ = cljs.core.PROTOCOL_SENTINEL);

(chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port_state$IChromePortState$set_connected_BANG_$arity$2 = (function (_this,val){
var self__ = this;
var _this__$1 = this;
return (self__.connected_QMARK_ = val);
}));

(chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port_state$IChromePortState$put_message_BANG_$arity$2 = (function (this$,message){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
return cljs.core.async.put_BANG_.call(null,self__.channel,message);
} else {
var config__25856__auto__ = self__.config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"chrome-port-put-message-called-on-disconnected-port","chrome-port-put-message-called-on-disconnected-port",1479634211);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,this$__$1,message);
}
}));

(chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port_state$IChromePortState$close_resources_BANG_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.close_BANG_.call(null,self__.channel);
}));

(chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL);

(chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_this,handler){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.take_BANG_.call(null,self__.channel,handler);
}));

(chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL);

(chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_.call(null,self__.channel);
}));

(chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return chromex.protocols.chrome_port.disconnect_BANG_.call(null,this$__$1);
}));

(chromex.chrome_port.ChromePort.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"config","config",-1659574354,null),new cljs.core.Symbol(null,"native-chrome-port","native-chrome-port",1837388003,null),new cljs.core.Symbol(null,"channel","channel",-1920248077,null),cljs.core.with_meta(new cljs.core.Symbol(null,"connected?","connected?",442980140,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"mutable","mutable",875778266),true], null))], null);
}));

(chromex.chrome_port.ChromePort.cljs$lang$type = true);

(chromex.chrome_port.ChromePort.cljs$lang$ctorStr = "chromex.chrome-port/ChromePort");

(chromex.chrome_port.ChromePort.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write.call(null,writer__4429__auto__,"chromex.chrome-port/ChromePort");
}));

/**
 * Positional factory function for chromex.chrome-port/ChromePort.
 */
chromex.chrome_port.__GT_ChromePort = (function chromex$chrome_port$__GT_ChromePort(config,native_chrome_port,channel,connected_QMARK_){
return (new chromex.chrome_port.ChromePort(config,native_chrome_port,channel,connected_QMARK_));
});

chromex.chrome_port.make_chrome_port = (function chromex$chrome_port$make_chrome_port(config,native_chrome_port){
if(cljs.core.truth_(native_chrome_port)){
} else {
throw (new Error("Assert failed: native-chrome-port"));
}

var channel = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"chrome-port-channel-factory","chrome-port-channel-factory",393485192);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__);
})();
var chrome_port = (new chromex.chrome_port.ChromePort(config,native_chrome_port,channel,true));
var on_message_fn_factory = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"chrome-port-on-message-fn-factory","chrome-port-on-message-fn-factory",1295000398);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,chrome_port);
})();
var on_disconnect_fn_factory = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = new cljs.core.Keyword(null,"chrome-port-on-disconnect-fn-factory","chrome-port-on-disconnect-fn-factory",-501244675);
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_.call(null,handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return handler__25858__auto__.call(null,config__25856__auto__,chrome_port);
})();
chromex.protocols.chrome_port.on_message_BANG_.call(null,chrome_port,on_message_fn_factory);

chromex.protocols.chrome_port.on_disconnect_BANG_.call(null,chrome_port,on_disconnect_fn_factory);

return chrome_port;
});

//# sourceMappingURL=chrome_port.js.map
