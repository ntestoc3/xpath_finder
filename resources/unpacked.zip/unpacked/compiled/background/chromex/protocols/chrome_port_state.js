// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex.protocols.chrome_port_state');
goog.require('cljs.core');

/**
 * @interface
 */
chromex.protocols.chrome_port_state.IChromePortState = function(){};

chromex.protocols.chrome_port_state.set_connected_BANG_ = (function chromex$protocols$chrome_port_state$set_connected_BANG_(this$,val){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_port_state$IChromePortState$set_connected_BANG_$arity$2 == null)))))){
return this$.chromex$protocols$chrome_port_state$IChromePortState$set_connected_BANG_$arity$2(this$,val);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_port_state.set_connected_BANG_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,this$,val);
} else {
var m__4485__auto__ = (chromex.protocols.chrome_port_state.set_connected_BANG_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,this$,val);
} else {
throw cljs.core.missing_protocol.call(null,"IChromePortState.set-connected!",this$);
}
}
}
});

chromex.protocols.chrome_port_state.put_message_BANG_ = (function chromex$protocols$chrome_port_state$put_message_BANG_(this$,message){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_port_state$IChromePortState$put_message_BANG_$arity$2 == null)))))){
return this$.chromex$protocols$chrome_port_state$IChromePortState$put_message_BANG_$arity$2(this$,message);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_port_state.put_message_BANG_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,this$,message);
} else {
var m__4485__auto__ = (chromex.protocols.chrome_port_state.put_message_BANG_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,this$,message);
} else {
throw cljs.core.missing_protocol.call(null,"IChromePortState.put-message!",this$);
}
}
}
});

chromex.protocols.chrome_port_state.close_resources_BANG_ = (function chromex$protocols$chrome_port_state$close_resources_BANG_(this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_port_state$IChromePortState$close_resources_BANG_$arity$1 == null)))))){
return this$.chromex$protocols$chrome_port_state$IChromePortState$close_resources_BANG_$arity$1(this$);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_port_state.close_resources_BANG_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,this$);
} else {
var m__4485__auto__ = (chromex.protocols.chrome_port_state.close_resources_BANG_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,this$);
} else {
throw cljs.core.missing_protocol.call(null,"IChromePortState.close-resources!",this$);
}
}
}
});


//# sourceMappingURL=chrome_port_state.js.map
