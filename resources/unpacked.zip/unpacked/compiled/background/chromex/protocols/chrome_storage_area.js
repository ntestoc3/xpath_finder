// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex.protocols.chrome_storage_area');
goog.require('cljs.core');

/**
 * a wrapper for https://developer.chrome.com/extensions/storage#type-StorageArea
 * @interface
 */
chromex.protocols.chrome_storage_area.IChromeStorageArea = function(){};

chromex.protocols.chrome_storage_area.get_native_storage_area = (function chromex$protocols$chrome_storage_area$get_native_storage_area(this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_native_storage_area$arity$1 == null)))))){
return this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_native_storage_area$arity$1(this$);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_storage_area.get_native_storage_area[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,this$);
} else {
var m__4485__auto__ = (chromex.protocols.chrome_storage_area.get_native_storage_area["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,this$);
} else {
throw cljs.core.missing_protocol.call(null,"IChromeStorageArea.get-native-storage-area",this$);
}
}
}
});

chromex.protocols.chrome_storage_area.get = (function chromex$protocols$chrome_storage_area$get(var_args){
var G__48303 = arguments.length;
switch (G__48303) {
case 1:
return chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$1 = (function (this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$get$arity$1 == null)))))){
return this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$get$arity$1(this$);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_storage_area.get[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,this$);
} else {
var m__4485__auto__ = (chromex.protocols.chrome_storage_area.get["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,this$);
} else {
throw cljs.core.missing_protocol.call(null,"IChromeStorageArea.get",this$);
}
}
}
}));

(chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$2 = (function (this$,keys){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$get$arity$2 == null)))))){
return this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$get$arity$2(this$,keys);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_storage_area.get[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,this$,keys);
} else {
var m__4485__auto__ = (chromex.protocols.chrome_storage_area.get["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,this$,keys);
} else {
throw cljs.core.missing_protocol.call(null,"IChromeStorageArea.get",this$);
}
}
}
}));

(chromex.protocols.chrome_storage_area.get.cljs$lang$maxFixedArity = 2);


chromex.protocols.chrome_storage_area.get_bytes_in_use = (function chromex$protocols$chrome_storage_area$get_bytes_in_use(var_args){
var G__48305 = arguments.length;
switch (G__48305) {
case 1:
return chromex.protocols.chrome_storage_area.get_bytes_in_use.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return chromex.protocols.chrome_storage_area.get_bytes_in_use.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(chromex.protocols.chrome_storage_area.get_bytes_in_use.cljs$core$IFn$_invoke$arity$1 = (function (this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_bytes_in_use$arity$1 == null)))))){
return this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_bytes_in_use$arity$1(this$);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_storage_area.get_bytes_in_use[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,this$);
} else {
var m__4485__auto__ = (chromex.protocols.chrome_storage_area.get_bytes_in_use["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,this$);
} else {
throw cljs.core.missing_protocol.call(null,"IChromeStorageArea.get-bytes-in-use",this$);
}
}
}
}));

(chromex.protocols.chrome_storage_area.get_bytes_in_use.cljs$core$IFn$_invoke$arity$2 = (function (this$,keys){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_bytes_in_use$arity$2 == null)))))){
return this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_bytes_in_use$arity$2(this$,keys);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_storage_area.get_bytes_in_use[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,this$,keys);
} else {
var m__4485__auto__ = (chromex.protocols.chrome_storage_area.get_bytes_in_use["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,this$,keys);
} else {
throw cljs.core.missing_protocol.call(null,"IChromeStorageArea.get-bytes-in-use",this$);
}
}
}
}));

(chromex.protocols.chrome_storage_area.get_bytes_in_use.cljs$lang$maxFixedArity = 2);


chromex.protocols.chrome_storage_area.set = (function chromex$protocols$chrome_storage_area$set(this$,items){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$set$arity$2 == null)))))){
return this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$set$arity$2(this$,items);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_storage_area.set[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,this$,items);
} else {
var m__4485__auto__ = (chromex.protocols.chrome_storage_area.set["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,this$,items);
} else {
throw cljs.core.missing_protocol.call(null,"IChromeStorageArea.set",this$);
}
}
}
});

chromex.protocols.chrome_storage_area.remove = (function chromex$protocols$chrome_storage_area$remove(this$,keys){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$remove$arity$2 == null)))))){
return this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$remove$arity$2(this$,keys);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_storage_area.remove[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,this$,keys);
} else {
var m__4485__auto__ = (chromex.protocols.chrome_storage_area.remove["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,this$,keys);
} else {
throw cljs.core.missing_protocol.call(null,"IChromeStorageArea.remove",this$);
}
}
}
});

chromex.protocols.chrome_storage_area.clear = (function chromex$protocols$chrome_storage_area$clear(this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$clear$arity$1 == null)))))){
return this$.chromex$protocols$chrome_storage_area$IChromeStorageArea$clear$arity$1(this$);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_storage_area.clear[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,this$);
} else {
var m__4485__auto__ = (chromex.protocols.chrome_storage_area.clear["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,this$);
} else {
throw cljs.core.missing_protocol.call(null,"IChromeStorageArea.clear",this$);
}
}
}
});


//# sourceMappingURL=chrome_storage_area.js.map
