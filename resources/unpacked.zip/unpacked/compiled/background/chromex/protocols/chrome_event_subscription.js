// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex.protocols.chrome_event_subscription');
goog.require('cljs.core');

/**
 * @interface
 */
chromex.protocols.chrome_event_subscription.IChromeEventSubscription = function(){};

chromex.protocols.chrome_event_subscription.subscribe_BANG_ = (function chromex$protocols$chrome_event_subscription$subscribe_BANG_(var_args){
var G__48100 = arguments.length;
switch (G__48100) {
case 1:
return chromex.protocols.chrome_event_subscription.subscribe_BANG_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return chromex.protocols.chrome_event_subscription.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(chromex.protocols.chrome_event_subscription.subscribe_BANG_.cljs$core$IFn$_invoke$arity$1 = (function (this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$1 == null)))))){
return this$.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$1(this$);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_event_subscription.subscribe_BANG_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,this$);
} else {
var m__4485__auto__ = (chromex.protocols.chrome_event_subscription.subscribe_BANG_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,this$);
} else {
throw cljs.core.missing_protocol.call(null,"IChromeEventSubscription.subscribe!",this$);
}
}
}
}));

(chromex.protocols.chrome_event_subscription.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (this$,extra_args){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2 == null)))))){
return this$.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(this$,extra_args);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_event_subscription.subscribe_BANG_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,this$,extra_args);
} else {
var m__4485__auto__ = (chromex.protocols.chrome_event_subscription.subscribe_BANG_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,this$,extra_args);
} else {
throw cljs.core.missing_protocol.call(null,"IChromeEventSubscription.subscribe!",this$);
}
}
}
}));

(chromex.protocols.chrome_event_subscription.subscribe_BANG_.cljs$lang$maxFixedArity = 2);


chromex.protocols.chrome_event_subscription.unsubscribe_BANG_ = (function chromex$protocols$chrome_event_subscription$unsubscribe_BANG_(this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$unsubscribe_BANG_$arity$1 == null)))))){
return this$.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$unsubscribe_BANG_$arity$1(this$);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_event_subscription.unsubscribe_BANG_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return m__4488__auto__.call(null,this$);
} else {
var m__4485__auto__ = (chromex.protocols.chrome_event_subscription.unsubscribe_BANG_["_"]);
if((!((m__4485__auto__ == null)))){
return m__4485__auto__.call(null,this$);
} else {
throw cljs.core.missing_protocol.call(null,"IChromeEventSubscription.unsubscribe!",this$);
}
}
}
});


//# sourceMappingURL=chrome_event_subscription.js.map
