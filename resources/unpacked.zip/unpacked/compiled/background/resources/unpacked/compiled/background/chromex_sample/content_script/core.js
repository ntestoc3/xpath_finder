// Compiled by ClojureScript 1.10.597 {}
goog.provide('chromex_sample.content_script.core');
goog.require('cljs.core');
goog.require('cljs.core.async');
goog.require('goog.string');
goog.require('chromex_sample.robula');
goog.require('clojure.string');
goog.require('cljs.pprint');
goog.require('dommy.core');
goog.require('oops.core');
goog.require('chromex.logging');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.ext.runtime');
chromex_sample.content_script.core.server = cljs.core.atom.call(null,null);
chromex_sample.content_script.core.process_message_BANG_ = (function chromex_sample$content_script$core$process_message_BANG_(message){
console.log("CONTENT SCRIPT: got message:",message);

return null;
});
chromex_sample.content_script.core.run_message_loop_BANG_ = (function chromex_sample$content_script$core$run_message_loop_BANG_(message_channel){
console.log("CONTENT SCRIPT: starting message loop...");


var c__24703__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,(function (){
var f__24704__auto__ = (function (){var switch__24634__auto__ = (function (state_37320){
var state_val_37321 = (state_37320[(1)]);
if((state_val_37321 === (1))){
var state_37320__$1 = state_37320;
var statearr_37322_37335 = state_37320__$1;
(statearr_37322_37335[(2)] = null);

(statearr_37322_37335[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_37321 === (2))){
var state_37320__$1 = state_37320;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_37320__$1,(4),message_channel);
} else {
if((state_val_37321 === (3))){
var inst_37318 = (state_37320[(2)]);
var state_37320__$1 = state_37320;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_37320__$1,inst_37318);
} else {
if((state_val_37321 === (4))){
var inst_37308 = (state_37320[(7)]);
var inst_37308__$1 = (state_37320[(2)]);
var inst_37309 = (inst_37308__$1 == null);
var state_37320__$1 = (function (){var statearr_37323 = state_37320;
(statearr_37323[(7)] = inst_37308__$1);

return statearr_37323;
})();
if(cljs.core.truth_(inst_37309)){
var statearr_37324_37336 = state_37320__$1;
(statearr_37324_37336[(1)] = (5));

} else {
var statearr_37325_37337 = state_37320__$1;
(statearr_37325_37337[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_37321 === (5))){
var state_37320__$1 = state_37320;
var statearr_37326_37338 = state_37320__$1;
(statearr_37326_37338[(2)] = null);

(statearr_37326_37338[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_37321 === (6))){
var inst_37308 = (state_37320[(7)]);
var inst_37312 = chromex_sample.content_script.core.process_message_BANG_.call(null,inst_37308);
var state_37320__$1 = (function (){var statearr_37327 = state_37320;
(statearr_37327[(8)] = inst_37312);

return statearr_37327;
})();
var statearr_37328_37339 = state_37320__$1;
(statearr_37328_37339[(2)] = null);

(statearr_37328_37339[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_37321 === (7))){
var inst_37315 = (state_37320[(2)]);
var inst_37316 = console.log("CONTENT SCRIPT: leaving message loop");
var state_37320__$1 = (function (){var statearr_37329 = state_37320;
(statearr_37329[(9)] = inst_37315);

(statearr_37329[(10)] = inst_37316);

return statearr_37329;
})();
var statearr_37330_37340 = state_37320__$1;
(statearr_37330_37340[(2)] = null);

(statearr_37330_37340[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
});
return (function() {
var chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto__ = null;
var chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto____0 = (function (){
var statearr_37331 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_37331[(0)] = chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto__);

(statearr_37331[(1)] = (1));

return statearr_37331;
});
var chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto____1 = (function (state_37320){
while(true){
var ret_value__24636__auto__ = (function (){try{while(true){
var result__24637__auto__ = switch__24634__auto__.call(null,state_37320);
if(cljs.core.keyword_identical_QMARK_.call(null,result__24637__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__24637__auto__;
}
break;
}
}catch (e37332){if((e37332 instanceof Object)){
var ex__24638__auto__ = e37332;
var statearr_37333_37341 = state_37320;
(statearr_37333_37341[(5)] = ex__24638__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_37320);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e37332;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__24636__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__37342 = state_37320;
state_37320 = G__37342;
continue;
} else {
return ret_value__24636__auto__;
}
break;
}
});
chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto__ = function(state_37320){
switch(arguments.length){
case 0:
return chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto____0.call(this);
case 1:
return chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto____1.call(this,state_37320);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto__.cljs$core$IFn$_invoke$arity$0 = chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto____0;
chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto__.cljs$core$IFn$_invoke$arity$1 = chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto____1;
return chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto__;
})()
})();
var state__24705__auto__ = (function (){var statearr_37334 = f__24704__auto__.call(null);
(statearr_37334[(6)] = c__24703__auto__);

return statearr_37334;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__24705__auto__);
}));

return c__24703__auto__;
});
chromex_sample.content_script.core.do_page_analysis_BANG_ = (function chromex_sample$content_script$core$do_page_analysis_BANG_(background_port){
var script_elements = document.getElementsByTagName("a");
var script_count = script_elements.length;
var title = document.title;
var msg = ["CONTENT SCRIPT: document '",cljs.core.str.cljs$core$IFn$_invoke$arity$1(title),"' contains ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(script_count)," a tags."].join('');
console.log(msg);


return chromex.protocols.chrome_port.post_message_BANG_.call(null,background_port,msg);
});
chromex_sample.content_script.core.connect_to_background_page_BANG_ = (function chromex_sample$content_script$core$connect_to_background_page_BANG_(){
var background_port = chromex.ext.runtime.connect_STAR_.call(null,chromex.config.get_active_config.call(null),new cljs.core.Keyword(null,"omit","omit",-1917972325),new cljs.core.Keyword(null,"omit","omit",-1917972325));
chromex.protocols.chrome_port.post_message_BANG_.call(null,background_port,"hello from CONTENT SCRIPT!");

cljs.core.reset_BANG_.call(null,chromex_sample.content_script.core.server,background_port);

chromex_sample.content_script.core.run_message_loop_BANG_.call(null,background_port);

return chromex_sample.content_script.core.do_page_analysis_BANG_.call(null,background_port);
});
chromex_sample.content_script.core.hook_event = (function chromex_sample$content_script$core$hook_event(var_args){
var G__37344 = arguments.length;
switch (G__37344) {
case 3:
return chromex_sample.content_script.core.hook_event.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return chromex_sample.content_script.core.hook_event.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(chromex_sample.content_script.core.hook_event.cljs$core$IFn$_invoke$arity$3 = (function (target,event_name,event_listener){
return chromex_sample.content_script.core.hook_event.call(null,target,event_name,event_listener,true);
}));

(chromex_sample.content_script.core.hook_event.cljs$core$IFn$_invoke$arity$4 = (function (target,event_name,event_listener,use_capture){
return target.addEventListener(cljs.core.name.call(null,event_name),event_listener,use_capture);
}));

(chromex_sample.content_script.core.hook_event.cljs$lang$maxFixedArity = 4);

/**
 * 发送命令消息
 */
chromex_sample.content_script.core.send_command = (function chromex_sample$content_script$core$send_command(data){
return chromex.protocols.chrome_port.post_message_BANG_.call(null,cljs.core.deref.call(null,chromex_sample.content_script.core.server),cljs.core.clj__GT_js.call(null,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"type","type",1174270348),"command",new cljs.core.Keyword(null,"cmd-data","cmd-data",1230377747),data], null)));
});
chromex_sample.content_script.core.trim_http_protocol = (function chromex_sample$content_script$core$trim_http_protocol(url){
return clojure.string.replace.call(null,url,/^https?:/,"");
});
chromex_sample.content_script.core.in_iframe = cljs.core.not_EQ_.call(null,window,top);
chromex_sample.content_script.core.get_parent_frames = (function chromex_sample$content_script$core$get_parent_frames(){
var frames = (function (){var target_obj_37347 = parent;
var _STAR_runtime_state_STAR__orig_val__37349 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37350 = oops.state.prepare_state.call(null,target_obj_37347,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37350);

try{var next_obj_37348 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37347,(0),"frames",true,true,false))?(target_obj_37347["frames"]):null);
return next_obj_37348;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37349);
}})();
var length = (function (){var target_obj_37351 = frames;
var _STAR_runtime_state_STAR__orig_val__37353 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37354 = oops.state.prepare_state.call(null,target_obj_37351,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37354);

try{var next_obj_37352 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37351,(0),"length",true,true,false))?(target_obj_37351["length"]):null);
return next_obj_37352;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37353);
}})();
return cljs.core.map.call(null,(function (p1__37346_SHARP_){
var target_obj_37355 = frames;
var _STAR_runtime_state_STAR__orig_val__37356 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37357 = oops.state.prepare_state.call(null,target_obj_37355,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37357);

try{return oops.core.get_selector_dynamically.call(null,target_obj_37355,cljs.core.str.cljs$core$IFn$_invoke$arity$1(p1__37346_SHARP_));
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37356);
}}),cljs.core.range.call(null,length));
});
chromex_sample.content_script.core.get_frame_info = (function chromex_sample$content_script$core$get_frame_info(){
if(chromex_sample.content_script.core.in_iframe){
var temp__5733__auto__ = (function (){var target_obj_37358 = window;
var _STAR_runtime_state_STAR__orig_val__37360 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37361 = oops.state.prepare_state.call(null,target_obj_37358,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37361);

try{var next_obj_37359 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37358,(0),"frameElement",true,true,false))?(target_obj_37358["frameElement"]):null);
return next_obj_37359;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37360);
}})();
if(cljs.core.truth_(temp__5733__auto__)){
var frame = temp__5733__auto__;
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"type","type",1174270348),"same-orgin",new cljs.core.Keyword(null,"path","path",-188191168),chromex_sample.robula.get_robust_xpath.call(null,(function (){var target_obj_37362 = window;
var _STAR_runtime_state_STAR__orig_val__37365 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37366 = oops.state.prepare_state.call(null,target_obj_37362,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37366);

try{var next_obj_37363 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37362,(0),"parent",true,true,false))?(target_obj_37362["parent"]):null);
var next_obj_37364 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_37363,(0),"document",true,true,false))?(next_obj_37363["document"]):null);
return next_obj_37364;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37365);
}})(),frame)], null);
} else {
var temp__5733__auto____$1 = chromex_sample.content_script.core.get_parent_frames.call(null).indexOf(window);
if(cljs.core.truth_(temp__5733__auto____$1)){
var window_idx = temp__5733__auto____$1;
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"type","type",1174270348),"cross-domain",new cljs.core.Keyword(null,"window-index","window-index",1342180687),window_idx], null);
} else {
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"type","type",1174270348),"cross-domain",new cljs.core.Keyword(null,"location","location",1815599388),chromex_sample.content_script.core.trim_http_protocol.call(null,(function (){var target_obj_37367 = location;
var _STAR_runtime_state_STAR__orig_val__37369 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37370 = oops.state.prepare_state.call(null,target_obj_37367,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37370);

try{var next_obj_37368 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37367,(0),"href",true,true,false))?(target_obj_37367["href"]):null);
return next_obj_37368;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37369);
}})())], null);
}
}
} else {
return null;
}
});
chromex_sample.content_script.core.get_cross_domain_frame_xpath_by_index = (function chromex_sample$content_script$core$get_cross_domain_frame_xpath_by_index(index){
var frame_window = (function (){var target_obj_37372 = window;
var _STAR_runtime_state_STAR__orig_val__37373 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37374 = oops.state.prepare_state.call(null,target_obj_37372,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37374);

try{return oops.core.get_selector_dynamically.call(null,target_obj_37372,["frames",cljs.core.str.cljs$core$IFn$_invoke$arity$1(index)]);
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37373);
}})();
var frame_dom = (function (){var G__37375 = dommy.utils.__GT_Array.call(null,document.getElementsByTagName("iframe"));
var G__37375__$1 = (((G__37375 == null))?null:cljs.core.filter.call(null,(function (p1__37371_SHARP_){
return cljs.core._EQ_.call(null,frame_window,(function (){var target_obj_37376 = p1__37371_SHARP_;
var _STAR_runtime_state_STAR__orig_val__37378 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37379 = oops.state.prepare_state.call(null,target_obj_37376,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37379);

try{var next_obj_37377 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37376,(0),"contentWindow",true,true,false))?(target_obj_37376["contentWindow"]):null);
return next_obj_37377;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37378);
}})());
}),G__37375));
if((G__37375__$1 == null)){
return null;
} else {
return cljs.core.first.call(null,G__37375__$1);
}
})();
console.log("frame-xpath-by-index dom:",frame_dom);


if(cljs.core.truth_(frame_dom)){
return chromex_sample.robula.get_robust_xpath.call(null,document,frame_dom);
} else {
console.error("get-cross-domain-frame-xpath-by-index can't find frame index:",index);

return null;
}
});
chromex_sample.content_script.core.get_cross_domain_frame_xpath_by_location = (function chromex_sample$content_script$core$get_cross_domain_frame_xpath_by_location(frame_location){
var frame_dom = (function (){var G__37380 = dommy.utils.__GT_Array.call(null,document.querySelectorAll("* /deep/ iframe"));
var G__37380__$1 = (((G__37380 == null))?null:cljs.core.filter.call(null,(function (dom){
return cljs.core._EQ_.call(null,chromex_sample.content_script.core.trim_http_protocol.call(null,(function (){var target_obj_37381 = dom;
var _STAR_runtime_state_STAR__orig_val__37383 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37384 = oops.state.prepare_state.call(null,target_obj_37381,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37384);

try{var next_obj_37382 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37381,(0),"src",true,true,false))?(target_obj_37381["src"]):null);
return next_obj_37382;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37383);
}})()),frame_location);
}),G__37380));
if((G__37380__$1 == null)){
return null;
} else {
return cljs.core.first.call(null,G__37380__$1);
}
})();
if(cljs.core.truth_(frame_dom)){
return chromex_sample.robula.get_robust_xpath.call(null,document,frame_dom);
} else {
console.error("get-cross-domain-frame-xpath can't find frame location:",frame_location);

return null;
}
});
chromex_sample.content_script.core.save_command = (function chromex_sample$content_script$core$save_command(cmd,data){
var frame_info = chromex_sample.content_script.core.get_frame_info.call(null);
if(("cross-domain" === new cljs.core.Keyword(null,"type","type",1174270348).cljs$core$IFn$_invoke$arity$1(frame_info))){
console.log("save-command post parent!");


return parent.postMessage(({"type": "ntr-frame-command", "data": cljs.core.clj__GT_js.call(null,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"frame","frame",-1711082588),frame_info,new cljs.core.Keyword(null,"cmd","cmd",-302931143),cmd,new cljs.core.Keyword(null,"data","data",-232669377),data], null))}),"*");
} else {
return chromex_sample.content_script.core.send_command.call(null,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"frame-path","frame-path",1219376077),new cljs.core.Keyword(null,"path","path",-188191168).cljs$core$IFn$_invoke$arity$1(frame_info),new cljs.core.Keyword(null,"cmd","cmd",-302931143),cmd,new cljs.core.Keyword(null,"data","data",-232669377),data], null));
}
});
/**
 * 消息处理函数
 */
chromex_sample.content_script.core.message_proc = (function chromex_sample$content_script$core$message_proc(e){
console.log("message proc!!");


var data = cljs.core.js__GT_clj.call(null,(function (){var target_obj_37385 = e;
var _STAR_runtime_state_STAR__orig_val__37387 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37388 = oops.state.prepare_state.call(null,target_obj_37385,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37388);

try{var next_obj_37386 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37385,(0),"data",true,true,false))?(target_obj_37385["data"]):null);
return next_obj_37386;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37387);
}})(),new cljs.core.Keyword(null,"keywordize-keys","keywordize-keys",1310784252),true);
console.log("message-proc data:",data);


var G__37389 = new cljs.core.Keyword(null,"type","type",1174270348).cljs$core$IFn$_invoke$arity$1(data);
switch (G__37389) {
case "ntr-alert-command":
var cmd_info = new cljs.core.Keyword(null,"cmd-info","cmd-info",-576269435).cljs$core$IFn$_invoke$arity$1(data);
return chromex_sample.content_script.core.save_command.call(null,new cljs.core.Keyword(null,"cmd","cmd",-302931143).cljs$core$IFn$_invoke$arity$1(cmd_info),new cljs.core.Keyword(null,"data","data",-232669377).cljs$core$IFn$_invoke$arity$1(cmd_info));

break;
case "ntr-frame-command":
var data__$1 = new cljs.core.Keyword(null,"data","data",-232669377).cljs$core$IFn$_invoke$arity$1(data);
var frame = new cljs.core.Keyword(null,"frame","frame",-1711082588).cljs$core$IFn$_invoke$arity$1(data__$1);
var frame_path = (cljs.core.truth_(new cljs.core.Keyword(null,"window-index","window-index",1342180687).cljs$core$IFn$_invoke$arity$1(frame))?chromex_sample.content_script.core.get_cross_domain_frame_xpath_by_index.call(null,new cljs.core.Keyword(null,"window-index","window-index",1342180687).cljs$core$IFn$_invoke$arity$1(frame)):(cljs.core.truth_(new cljs.core.Keyword(null,"location","location",1815599388).cljs$core$IFn$_invoke$arity$1(frame))?chromex_sample.content_script.core.get_cross_domain_frame_xpath_by_location.call(null,new cljs.core.Keyword(null,"location","location",1815599388).cljs$core$IFn$_invoke$arity$1(frame)):null));
console.log("ntr-frame-command proc path:",frame_path);


return chromex_sample.content_script.core.send_command.call(null,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"frame-path","frame-path",1219376077),frame_path,new cljs.core.Keyword(null,"cmd","cmd",-302931143),new cljs.core.Keyword(null,"cmd","cmd",-302931143).cljs$core$IFn$_invoke$arity$1(data__$1),new cljs.core.Keyword(null,"data","data",-232669377),new cljs.core.Keyword(null,"data","data",-232669377).cljs$core$IFn$_invoke$arity$1(data__$1)], null));

break;
default:
console.error("message-proc unknown message:",data);

return null;

}
});
chromex_sample.content_script.core.uniq_id_QMARK_ = (function chromex_sample$content_script$core$uniq_id_QMARK_(id){
return cljs.core._EQ_.call(null,cljs.core.count.call(null,dommy.utils.__GT_Array.call(null,document.querySelectorAll(dommy.core.selector.call(null,["#",cljs.core.str.cljs$core$IFn$_invoke$arity$1(id)].join(''))))),(1));
});
chromex_sample.content_script.core.ele_name = (function chromex_sample$content_script$core$ele_name(ele){
return clojure.string.lower_case.call(null,(function (){var target_obj_37391 = ele;
var _STAR_runtime_state_STAR__orig_val__37393 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37394 = oops.state.prepare_state.call(null,target_obj_37391,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37394);

try{var next_obj_37392 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37391,(0),"localName",true,true,false))?(target_obj_37391["localName"]):null);
return next_obj_37392;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37393);
}})());
});
chromex_sample.content_script.core.xpath_ele_id = (function chromex_sample$content_script$core$xpath_ele_id(ele){
return [chromex_sample.content_script.core.ele_name.call(null,ele),"[@id=\"",cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var target_obj_37399 = ele;
var _STAR_runtime_state_STAR__orig_val__37401 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37402 = oops.state.prepare_state.call(null,target_obj_37399,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37402);

try{var next_obj_37400 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37399,(0),"id",true,true,false))?(target_obj_37399["id"]):null);
return next_obj_37400;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37401);
}})()),"\"]"].join('');
});
chromex_sample.content_script.core.xpath_ele_class = (function chromex_sample$content_script$core$xpath_ele_class(ele){
return [chromex_sample.content_script.core.ele_name.call(null,ele),"[@class=\"",cljs.core.str.cljs$core$IFn$_invoke$arity$1(dommy.core.class$.call(null,ele)),"\"]"].join('');
});
chromex_sample.content_script.core.previous_siblings = (function chromex_sample$content_script$core$previous_siblings(ele){
var prev = (function (){var target_obj_37403 = ele;
var _STAR_runtime_state_STAR__orig_val__37405 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37406 = oops.state.prepare_state.call(null,target_obj_37403,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37406);

try{var next_obj_37404 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37403,(0),"previousSibling",true,true,false))?(target_obj_37403["previousSibling"]):null);
return next_obj_37404;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37405);
}})();
if(cljs.core.truth_(prev)){
return cljs.core.cons.call(null,prev,(new cljs.core.LazySeq(null,(function (){
return chromex_sample.content_script.core.previous_siblings.call(null,prev);
}),null,null)));
} else {
return cljs.core.PersistentVector.EMPTY;
}
});
chromex_sample.content_script.core.previous_sibling_elements = (function chromex_sample$content_script$core$previous_sibling_elements(ele){
return cljs.core.filter.call(null,(function (p1__37407_SHARP_){
return cljs.core._EQ_.call(null,(function (){var target_obj_37408 = p1__37407_SHARP_;
var _STAR_runtime_state_STAR__orig_val__37410 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37411 = oops.state.prepare_state.call(null,target_obj_37408,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37411);

try{var next_obj_37409 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37408,(0),"nodeType",true,true,false))?(target_obj_37408["nodeType"]):null);
return next_obj_37409;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37410);
}})(),(1));
}),chromex_sample.content_script.core.previous_siblings.call(null,ele));
});
/**
 * 构造元素的xpath, 比较简单，适应性较差
 */
chromex_sample.content_script.core.make_xpath = (function chromex_sample$content_script$core$make_xpath(element){
var ele = element;
var segs = cljs.core.PersistentVector.EMPTY;
while(true){
if(cljs.core.truth_((function (){var and__4174__auto__ = ele;
if(cljs.core.truth_(and__4174__auto__)){
return cljs.core._EQ_.call(null,(function (){var target_obj_37433 = ele;
var _STAR_runtime_state_STAR__orig_val__37435 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37436 = oops.state.prepare_state.call(null,target_obj_37433,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37436);

try{var next_obj_37434 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37433,(0),"nodeType",true,true,false))?(target_obj_37433["nodeType"]):null);
return next_obj_37434;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37435);
}})(),(1));
} else {
return and__4174__auto__;
}
})())){
var next_ele = (function (){var target_obj_37437 = ele;
var _STAR_runtime_state_STAR__orig_val__37439 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37440 = oops.state.prepare_state.call(null,target_obj_37437,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37440);

try{var next_obj_37438 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37437,(0),"parentNode",true,true,false))?(target_obj_37437["parentNode"]):null);
return next_obj_37438;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37439);
}})();
if(cljs.core.truth_(ele.hasAttribute("id"))){
var id = (function (){var target_obj_37441 = ele;
var _STAR_runtime_state_STAR__orig_val__37443 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37444 = oops.state.prepare_state.call(null,target_obj_37441,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37444);

try{var next_obj_37442 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37441,(0),"id",true,true,false))?(target_obj_37441["id"]):null);
return next_obj_37442;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37443);
}})();
if(chromex_sample.content_script.core.uniq_id_QMARK_.call(null,id)){
return clojure.string.join.call(null,"/",cljs.core.cons.call(null,["id(\"",cljs.core.str.cljs$core$IFn$_invoke$arity$1(id),"\")"].join(''),segs));
} else {
var G__37453 = next_ele;
var G__37454 = cljs.core.cons.call(null,chromex_sample.content_script.core.xpath_ele_id.call(null,ele),segs);
ele = G__37453;
segs = G__37454;
continue;
}
} else {
if(cljs.core.truth_(ele.hasAttribute("class"))){
var G__37455 = next_ele;
var G__37456 = cljs.core.cons.call(null,chromex_sample.content_script.core.xpath_ele_class.call(null,ele),segs);
ele = G__37455;
segs = G__37456;
continue;
} else {
var index = (cljs.core.count.call(null,cljs.core.filter.call(null,((function (ele,segs,next_ele){
return (function (p1__37412_SHARP_){
return cljs.core._EQ_.call(null,(function (){var target_obj_37445 = p1__37412_SHARP_;
var _STAR_runtime_state_STAR__orig_val__37447 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37448 = oops.state.prepare_state.call(null,target_obj_37445,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37448);

try{var next_obj_37446 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37445,(0),"localName",true,true,false))?(target_obj_37445["localName"]):null);
return next_obj_37446;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37447);
}})(),(function (){var target_obj_37449 = ele;
var _STAR_runtime_state_STAR__orig_val__37451 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37452 = oops.state.prepare_state.call(null,target_obj_37449,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37452);

try{var next_obj_37450 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37449,(0),"localName",true,true,false))?(target_obj_37449["localName"]):null);
return next_obj_37450;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37451);
}})());
});})(ele,segs,next_ele))
,chromex_sample.content_script.core.previous_sibling_elements.call(null,ele))) + (1));
var G__37457 = next_ele;
var G__37458 = cljs.core.cons.call(null,[chromex_sample.content_script.core.ele_name.call(null,ele),"[",cljs.core.str.cljs$core$IFn$_invoke$arity$1(index),"]"].join(''),segs);
ele = G__37457;
segs = G__37458;
continue;

}
}
} else {
if(cljs.core.empty_QMARK_.call(null,segs)){
return null;
} else {
return ["/",clojure.string.join.call(null,"/",segs)].join('');
}
}
break;
}
});
chromex_sample.content_script.core.lookup_element_by_xpath = (function chromex_sample$content_script$core$lookup_element_by_xpath(xpath){
var evaluator = (new XPathEvaluator());
var target_obj_37459 = evaluator.evaluate(xpath,(function (){var target_obj_37461 = document;
var _STAR_runtime_state_STAR__orig_val__37463 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37464 = oops.state.prepare_state.call(null,target_obj_37461,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37464);

try{var next_obj_37462 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37461,(0),"documentElement",true,true,false))?(target_obj_37461["documentElement"]):null);
return next_obj_37462;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37463);
}})(),null,(function (){var target_obj_37465 = XPathResult;
var _STAR_runtime_state_STAR__orig_val__37467 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37468 = oops.state.prepare_state.call(null,target_obj_37465,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37468);

try{var next_obj_37466 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37465,(0),"FIRST_ORDERED_NODE_TYPE",true,true,false))?(target_obj_37465["FIRST_ORDERED_NODE_TYPE"]):null);
return next_obj_37466;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37467);
}})(),null);
var _STAR_runtime_state_STAR__orig_val__37469 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37470 = oops.state.prepare_state.call(null,target_obj_37459,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37470);

try{var next_obj_37460 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37459,(0),"singleNodeValue",true,true,false))?(target_obj_37459["singleNodeValue"]):null);
return next_obj_37460;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37469);
}});
chromex_sample.content_script.core.my_eval = (function chromex_sample$content_script$core$my_eval(code){
var head = document.head;
var script = dommy.core.create_element.call(null,"script");
dommy.core.set_html_BANG_.call(null,script,["(",cljs.core.str.cljs$core$IFn$_invoke$arity$1(code),")()"].join(''));

return dommy.core.append_BANG_.call(null,head,script);
});
chromex_sample.content_script.core.last_ele = cljs.core.atom.call(null,null);
chromex_sample.content_script.core.remove_mark = (function chromex_sample$content_script$core$remove_mark(ele){
if(cljs.core.truth_(ele)){
dommy.core.remove_style_BANG_.call(null,ele,new cljs.core.Keyword(null,"box-shadow","box-shadow",1600206755));

return cljs.core.reset_BANG_.call(null,chromex_sample.content_script.core.last_ele,null);
} else {
return null;
}
});
chromex_sample.content_script.core.mark_element = (function chromex_sample$content_script$core$mark_element(ele){
if(cljs.core.truth_(ele)){
dommy.core.set_style_BANG_.call(null,ele,new cljs.core.Keyword(null,"box-shadow","box-shadow",1600206755),"0px 0px 2px 2px blue");

return cljs.core.reset_BANG_.call(null,chromex_sample.content_script.core.last_ele,ele);
} else {
return null;
}
});
chromex_sample.content_script.core.handle_mouse_move = (function chromex_sample$content_script$core$handle_mouse_move(e){
var x = e.clientX;
var y = e.clientY;
console.log("x:",x," y:",y);


var temp__5733__auto__ = document.elementFromPoint(x,y);
if(cljs.core.truth_(temp__5733__auto__)){
var ele = temp__5733__auto__;
var temp__5735__auto___37471 = cljs.core.deref.call(null,chromex_sample.content_script.core.last_ele);
if(cljs.core.truth_(temp__5735__auto___37471)){
var prev_ele_37472 = temp__5735__auto___37471;
if(cljs.core._EQ_.call(null,ele,prev_ele_37472)){
} else {
chromex_sample.content_script.core.remove_mark.call(null,prev_ele_37472);
}
} else {
}

chromex_sample.content_script.core.mark_element.call(null,ele);

chromex_sample.content_script.core.save_command.call(null,"mouse-move",new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"x","x",2099068185),x,new cljs.core.Keyword(null,"y","y",-1757859776),y], null));

console.log("elements xpath:",chromex_sample.robula.get_robust_xpath.call(null,document,ele));

return null;
} else {
return chromex_sample.content_script.core.remove_mark.call(null,cljs.core.deref.call(null,chromex_sample.content_script.core.last_ele));
}
});
chromex_sample.content_script.core.bytes_len = (function chromex_sample$content_script$core$bytes_len(text){
return cljs.core.reduce.call(null,cljs.core._PLUS_,cljs.core.map.call(null,(function (p1__37473_SHARP_){
if((cljs.pprint.char_code.call(null,p1__37473_SHARP_) > (255))){
return (2);
} else {
return (1);
}
}),text));
});
chromex_sample.content_script.core.format_text = (function chromex_sample$content_script$core$format_text(text){
var trimed_text = clojure.string.trim.call(null,clojure.string.replace.call(null,text,/\s*\r?\n\s*/," "));
var pred__37474 = cljs.core._LT_;
var expr__37475 = chromex_sample.content_script.core.bytes_len.call(null,trimed_text);
if(cljs.core.truth_(pred__37474.call(null,(60),expr__37475))){
return "";
} else {
if(cljs.core.truth_(pred__37474.call(null,(20),expr__37475))){
return [cljs.core.subs.call(null,trimed_text,(0),(20)),"..."].join('');
} else {
return trimed_text;
}
}
});
chromex_sample.content_script.core.get_target_text = (function chromex_sample$content_script$core$get_target_text(element){
return chromex_sample.content_script.core.format_text.call(null,(function (){var G__37477 = (function (){var target_obj_37478 = element;
var _STAR_runtime_state_STAR__orig_val__37480 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37481 = oops.state.prepare_state.call(null,target_obj_37478,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37481);

try{var next_obj_37479 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37478,(0),"nodeName",true,true,false))?(target_obj_37478["nodeName"]):null);
return next_obj_37479;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37480);
}})();
switch (G__37477) {
case "INPUT":
if(cljs.core.truth_(new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 3, ["reset",null,"submit",null,"button",null], null), null).call(null,dommy.core.attr.call(null,element,new cljs.core.Keyword(null,"type","type",1174270348))))){
return dommy.core.attr.call(null,element,new cljs.core.Keyword(null,"value","value",305978217));
} else {
var parent_node = dommy.core.parent.call(null,element);
var id = dommy.core.attr.call(null,element,new cljs.core.Keyword(null,"id","id",-1388402092));
if(cljs.core._EQ_.call(null,"LABEL",(function (){var target_obj_37482 = parent_node;
var _STAR_runtime_state_STAR__orig_val__37484 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37485 = oops.state.prepare_state.call(null,target_obj_37482,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37485);

try{var next_obj_37483 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37482,(0),"nodeName",true,true,false))?(target_obj_37482["nodeName"]):null);
return next_obj_37483;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37484);
}})())){
return dommy.core.text.call(null,parent_node);
} else {
if(cljs.core.truth_(id)){
var temp__5733__auto__ = document.querySelector(dommy.core.selector.call(null,goog.string.format("label[for='%s']",id)));
if(cljs.core.truth_(temp__5733__auto__)){
var label_ele = temp__5733__auto__;
return dommy.core.text.call(null,label_ele);
} else {
return dommy.core.attr.call(null,element,new cljs.core.Keyword(null,"name","name",1843675177));
}
} else {
return dommy.core.attr.call(null,element,new cljs.core.Keyword(null,"name","name",1843675177));

}
}
}

break;
case "SELECT":
return dommy.core.attr.call(null,element,new cljs.core.Keyword(null,"name","name",1843675177));

break;
default:
return dommy.core.text.call(null,element);

}
})());
});
/**
 * 获取事件的目标
 */
chromex_sample.content_script.core.event_target = (function chromex_sample$content_script$core$event_target(event){
var target = event.target;
if(cljs.core.truth_(target.shadowRoot)){
return cljs.core.first.call(null,event.path);
} else {
return target;
}
});
/**
 * 获取label指向的目标,不含label指向则返回nil
 */
chromex_sample.content_script.core.get_label_target = (function chromex_sample$content_script$core$get_label_target(target){
if(((function (){var target_obj_37487 = target;
var _STAR_runtime_state_STAR__orig_val__37489 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37490 = oops.state.prepare_state.call(null,target_obj_37487,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37490);

try{var next_obj_37488 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37487,(0),"nodeName",true,true,false))?(target_obj_37487["nodeName"]):null);
return next_obj_37488;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37489);
}})() === "INPUT")){
return null;
} else {
var temp__5735__auto__ = ((((function (){var target_obj_37491 = target;
var _STAR_runtime_state_STAR__orig_val__37493 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37494 = oops.state.prepare_state.call(null,target_obj_37491,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37494);

try{var next_obj_37492 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37491,(0),"nodeName",true,true,false))?(target_obj_37491["nodeName"]):null);
return next_obj_37492;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37493);
}})() === "LABEL"))?target:((((function (){var target_obj_37495 = target;
var _STAR_runtime_state_STAR__orig_val__37498 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37499 = oops.state.prepare_state.call(null,target_obj_37495,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37499);

try{var next_obj_37496 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37495,(0),"parentNode",true,true,false))?(target_obj_37495["parentNode"]):null);
var next_obj_37497 = ((oops.core.validate_object_access_dynamically.call(null,next_obj_37496,(0),"nodeName",true,true,false))?(next_obj_37496["nodeName"]):null);
return next_obj_37497;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37498);
}})() === "LABEL"))?(function (){var target_obj_37500 = target;
var _STAR_runtime_state_STAR__orig_val__37502 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37503 = oops.state.prepare_state.call(null,target_obj_37500,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37503);

try{var next_obj_37501 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37500,(0),"parentNode",true,true,false))?(target_obj_37500["parentNode"]):null);
return next_obj_37501;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37502);
}})():null));
if(cljs.core.truth_(temp__5735__auto__)){
var label = temp__5735__auto__;
var temp__5733__auto__ = dommy.core.attr.call(null,label,"for");
if(cljs.core.truth_(temp__5733__auto__)){
var for_value = temp__5733__auto__;
return document.querySelector(dommy.core.selector.call(null,["#",cljs.core.str.cljs$core$IFn$_invoke$arity$1(for_value)].join('')));
} else {
return (dommy.utils.__GT_Array.call(null,label.getElementsByTagName("input"))[(0)]);
}
} else {
return null;
}
}
});
chromex_sample.content_script.core.mouse_not_in_scroll_QMARK_ = (function chromex_sample$content_script$core$mouse_not_in_scroll_QMARK_(event){
var target = event.target;
return (((!((((target.clientWidth > (0))) && ((event.offsetX >= target.clientWidth)))))) && ((!((((target.clientHeight > (0))) && ((event.offsetY >= target.clientHeight)))))));
});
/**
 * 是否为鼠标可操作的目标
 */
chromex_sample.content_script.core.mouse_opable_target_QMARK_ = (function chromex_sample$content_script$core$mouse_opable_target_QMARK_(target){
return cljs.core.not.call(null,cljs.core.re_matches.call(null,/html|select|optgroup|option/i,(function (){var target_obj_37504 = target;
var _STAR_runtime_state_STAR__orig_val__37506 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37507 = oops.state.prepare_state.call(null,target_obj_37504,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37507);

try{var next_obj_37505 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37504,(0),"tagName",true,true,false))?(target_obj_37504["tagName"]):null);
return next_obj_37505;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37506);
}})()));
});
/**
 * 是否为文件输入
 */
chromex_sample.content_script.core.file_input_QMARK_ = (function chromex_sample$content_script$core$file_input_QMARK_(target){
return ((((function (){var target_obj_37512 = target;
var _STAR_runtime_state_STAR__orig_val__37514 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37515 = oops.state.prepare_state.call(null,target_obj_37512,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37515);

try{var next_obj_37513 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37512,(0),"tagName",true,true,false))?(target_obj_37512["tagName"]):null);
return next_obj_37513;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37514);
}})() === "INPUT")) && ((dommy.core.attr.call(null,target,new cljs.core.Keyword(null,"type","type",1174270348)) === "file")));
});
/**
 * 是否为上传角色
 */
chromex_sample.content_script.core.upload_role_QMARK_ = (function chromex_sample$content_script$core$upload_role_QMARK_(target){
if(cljs.core.truth_(target)){
var role = (function (){var or__4185__auto__ = dommy.core.attr.call(null,target,new cljs.core.Keyword(null,"role","role",-736691072));
if(cljs.core.truth_(or__4185__auto__)){
return or__4185__auto__;
} else {
return dommy.core.attr.call(null,target,new cljs.core.Keyword(null,"data-role","data-role",-1005812940));
}
})();
if(cljs.core.truth_(cljs.core.re_matches.call(null,/upload|file/i,role))){
return true;
} else {
return chromex_sample.content_script.core.upload_role_QMARK_.call(null,(function (){var target_obj_37516 = target;
var _STAR_runtime_state_STAR__orig_val__37518 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__37519 = oops.state.prepare_state.call(null,target_obj_37516,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__37519);

try{var next_obj_37517 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_37516,(0),"parentNode",true,true,false))?(target_obj_37516["parentNode"]):null);
return next_obj_37517;
}finally {(oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__37518);
}})());
}
} else {
return null;
}
});
/**
 * 是否为上传元素
 */
chromex_sample.content_script.core.upload_element_QMARK_ = (function chromex_sample$content_script$core$upload_element_QMARK_(target){
var or__4185__auto__ = chromex_sample.content_script.core.file_input_QMARK_.call(null,target);
if(or__4185__auto__){
return or__4185__auto__;
} else {
return chromex_sample.content_script.core.upload_role_QMARK_.call(null,target);
}
});
chromex_sample.content_script.core.handle_mouse_down = (function chromex_sample$content_script$core$handle_mouse_down(e){
return null;
});
if(chromex_sample.content_script.core.in_iframe){
console.log("CONTENT SCRIPT: in iframe");

} else {
}
chromex_sample.content_script.core.init_BANG_ = (function chromex_sample$content_script$core$init_BANG_(){
console.log("CONTENT SCRIPT: init");


return dommy.core.listen_BANG_.call(null,document,new cljs.core.Keyword(null,"DOMContentLoaded","DOMContentLoaded",88046845),(function (){
console.log("dom content loaded!");


chromex_sample.content_script.core.hook_event.call(null,window,"message",chromex_sample.content_script.core.message_proc);

chromex_sample.content_script.core.hook_event.call(null,document,new cljs.core.Keyword(null,"mousemove","mousemove",-1077794734),chromex_sample.content_script.core.handle_mouse_move);

chromex_sample.content_script.core.connect_to_background_page_BANG_.call(null);

return chromex_sample.content_script.core.my_eval.call(null,"// hook alert, confirm, prompt\nfunction hookAlertFunction(){\n    var rawAlert = window.alert;\n    function sendAlertCmd(cmd, data){\n        var cmdInfo = {\n            cmd: cmd,\n            data: data || {}\n        };\n        window.postMessage({\n            'type': 'ntr-alert-command',\n            'cmd-info': cmdInfo\n        }, '*');\n    }\n    window.alert = function(str){\n        var ret = rawAlert.call(this, str);\n        sendAlertCmd('acceptAlert');\n        return ret;\n    }\n    var rawConfirm = window.confirm;\n    window.confirm = function(str){\n        var ret = rawConfirm.call(this, str);\n        sendAlertCmd(ret?'acceptAlert':'dismissAlert');\n        return ret;\n    }\n    var rawPrompt = window.prompt;\n    window.prompt = function(str){\n        var ret = rawPrompt.call(this, str);\n        if(ret === null){\n            sendAlertCmd('dismissAlert');\n        }\n        else{\n            sendAlertCmd('setAlert', {\n                text: ret\n            });\n            sendAlertCmd('acceptAlert');\n        }\n        return ret;\n    }\n    function wrapBeforeUnloadListener(oldListener){\n        var newListener = function(e){\n            var returnValue = oldListener(e);\n            if(returnValue){\n                sendAlertCmd('acceptAlert');\n            }\n            return returnValue;\n        }\n        return newListener;\n    }\n    var rawAddEventListener = window.addEventListener;\n    window.addEventListener = function(type, listener, useCapture){\n        if(type === 'beforeunload'){\n            listener = wrapBeforeUnloadListener(listener);\n        }\n        return rawAddEventListener.call(window, type, listener, useCapture);\n    };\n    setTimeout(function(){\n        var oldBeforeunload = window.onbeforeunload;\n        if(oldBeforeunload){\n            window.onbeforeunload = wrapBeforeUnloadListener(oldBeforeunload)\n        }\n    }, 1000);\n}\n");
}));
});

//# sourceMappingURL=core.js.map
