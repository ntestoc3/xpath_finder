// Compiled by ClojureScript 1.10.520 {}
goog.provide('chromex_sample.robula');
goog.require('cljs.core');
goog.require('oops.core');
goog.require('clojure.string');
goog.require('goog.string');
goog.require('goog.string.format');
goog.require('clojure.set');
goog.require('dommy.core');
chromex_sample.robula.xpath_length = cljs.core.count;
chromex_sample.robula.xpath_head = cljs.core.first;
chromex_sample.robula.xpath_head_has_predicates_QMARK_ = (function chromex_sample$robula$xpath_head_has_predicates_QMARK_(xpath){
return clojure.string.includes_QMARK_.call(null,chromex_sample.robula.xpath_head.call(null,xpath),"[");
});
chromex_sample.robula.xpath_head_has_position_QMARK_ = (function chromex_sample$robula$xpath_head_has_position_QMARK_(xpath){
var head = chromex_sample.robula.xpath_head.call(null,xpath);
var or__4131__auto__ = clojure.string.includes_QMARK_.call(null,head,"position()");
if(or__4131__auto__){
return or__4131__auto__;
} else {
var or__4131__auto____$1 = clojure.string.includes_QMARK_.call(null,head,"last");
if(or__4131__auto____$1){
return or__4131__auto____$1;
} else {
return cljs.core.re_find.call(null,/\[[0-9]+\]/,head);
}
}
});
chromex_sample.robula.xpath_head_has_text_QMARK_ = (function chromex_sample$robula$xpath_head_has_text_QMARK_(xpath){
return clojure.string.includes_QMARK_.call(null,chromex_sample.robula.xpath_head.call(null,xpath),"text()");
});
chromex_sample.robula.xpath_head_with_all_QMARK_ = (function chromex_sample$robula$xpath_head_with_all_QMARK_(xpath){
return clojure.string.starts_with_QMARK_.call(null,chromex_sample.robula.xpath_head.call(null,xpath),"*");
});
chromex_sample.robula.xpath_add_predicate_to_head = (function chromex_sample$robula$xpath_add_predicate_to_head(xpath,predicate){
var new_head = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.first.call(null,xpath)),cljs.core.str.cljs$core$IFn$_invoke$arity$1(predicate)].join('');
return cljs.core.assoc.call(null,cljs.core.into.call(null,cljs.core.PersistentVector.EMPTY,xpath),(0),new_head);
});
chromex_sample.robula.xpath_replace_head_all = (function chromex_sample$robula$xpath_replace_head_all(xpath,head_tag){
var new_head = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(head_tag),cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.subs.call(null,cljs.core.first.call(null,xpath),(1)))].join('');
return cljs.core.assoc.call(null,cljs.core.into.call(null,cljs.core.PersistentVector.EMPTY,xpath),(0),new_head);
});
chromex_sample.robula.xpath_add_head_all = (function chromex_sample$robula$xpath_add_head_all(xpath){
return cljs.core.cons.call(null,"*",xpath);
});
chromex_sample.robula.xpath_empty = cljs.core.PersistentVector.EMPTY;
chromex_sample.robula.xpath_all = new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, ["*"], null);
chromex_sample.robula.xpath__GT_str = (function chromex_sample$robula$xpath__GT_str(xpath){
return ["//",cljs.core.str.cljs$core$IFn$_invoke$arity$1(clojure.string.join.call(null,"/",xpath))].join('');
});
chromex_sample.robula.get_previous_element_siblings_base = (function chromex_sample$robula$get_previous_element_siblings_base(element){
return cljs.core.take_while.call(null,cljs.core.identity,cljs.core.iterate.call(null,(function (p1__50535_SHARP_){
var target_obj_50536 = p1__50535_SHARP_;
var _STAR_runtime_state_STAR__orig_val__50538 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50539 = oops.state.prepare_state.call(null,target_obj_50536,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50539;

try{var next_obj_50537 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50536,(0),"previousElementSibling",true,true,false))?(target_obj_50536["previousElementSibling"]):null);
return next_obj_50537;
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50538;
}}),element));
});
chromex_sample.robula.get_previous_element_siblings = cljs.core.memoize.call(null,chromex_sample.robula.get_previous_element_siblings_base);
/**
 * 获取所有父级元素，包括自身
 */
chromex_sample.robula.get_all_ancestor_base = (function chromex_sample$robula$get_all_ancestor_base(element){
return cljs.core.take_while.call(null,cljs.core.identity,cljs.core.iterate.call(null,(function (p1__50540_SHARP_){
var target_obj_50541 = p1__50540_SHARP_;
var _STAR_runtime_state_STAR__orig_val__50543 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50544 = oops.state.prepare_state.call(null,target_obj_50541,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50544;

try{var next_obj_50542 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50541,(0),"parentElement",true,true,false))?(target_obj_50541["parentElement"]):null);
return next_obj_50542;
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50543;
}}),element));
});
chromex_sample.robula.get_all_ancestor = cljs.core.memoize.call(null,chromex_sample.robula.get_all_ancestor_base);
chromex_sample.robula.get_ancestor_count = (function chromex_sample$robula$get_ancestor_count(element){
return cljs.core.count.call(null,chromex_sample.robula.get_all_ancestor.call(null,element));
});
chromex_sample.robula.get_ancestor_at = (function chromex_sample$robula$get_ancestor_at(element,index){
return cljs.core.nth.call(null,chromex_sample.robula.get_all_ancestor.call(null,element),index);
});
/**
 * 获取元素的所有属性
 */
chromex_sample.robula.get_attributes = (function chromex_sample$robula$get_attributes(element){
var get_attr_kv = (function (attr){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(function (){var target_obj_50546 = attr;
var _STAR_runtime_state_STAR__orig_val__50548 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50549 = oops.state.prepare_state.call(null,target_obj_50546,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50549;

try{var next_obj_50547 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50546,(0),"name",true,true,false))?(target_obj_50546["name"]):null);
return next_obj_50547;
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50548;
}})(),(function (){var target_obj_50550 = attr;
var _STAR_runtime_state_STAR__orig_val__50552 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50553 = oops.state.prepare_state.call(null,target_obj_50550,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50553;

try{var next_obj_50551 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50550,(0),"value",true,true,false))?(target_obj_50550["value"]):null);
return next_obj_50551;
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50552;
}})()], null);
});
var attrs = (function (){var target_obj_50554 = element;
var _STAR_runtime_state_STAR__orig_val__50556 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50557 = oops.state.prepare_state.call(null,target_obj_50554,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50557;

try{var next_obj_50555 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50554,(0),"attributes",true,true,false))?(target_obj_50554["attributes"]):null);
return next_obj_50555;
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50556;
}})();
return cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.call(null,((function (get_attr_kv,attrs){
return (function (p1__50545_SHARP_){
return get_attr_kv.call(null,(function (){var target_obj_50558 = attrs;
var _STAR_runtime_state_STAR__orig_val__50559 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50560 = oops.state.prepare_state.call(null,target_obj_50558,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50560;

try{return oops.core.get_selector_dynamically.call(null,target_obj_50558,cljs.core.str.cljs$core$IFn$_invoke$arity$1(p1__50545_SHARP_));
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50559;
}})());
});})(get_attr_kv,attrs))
,cljs.core.range.call(null,(function (){var target_obj_50561 = attrs;
var _STAR_runtime_state_STAR__orig_val__50563 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50564 = oops.state.prepare_state.call(null,target_obj_50561,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50564;

try{var next_obj_50562 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50561,(0),"length",true,true,false))?(target_obj_50561["length"]):null);
return next_obj_50562;
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50563;
}})())));
});
chromex_sample.robula.tag_name = (function chromex_sample$robula$tag_name(element){
return clojure.string.lower_case.call(null,(function (){var target_obj_50565 = element;
var _STAR_runtime_state_STAR__orig_val__50567 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50568 = oops.state.prepare_state.call(null,target_obj_50565,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50568;

try{var next_obj_50566 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50565,(0),"tagName",true,true,false))?(target_obj_50565["tagName"]):null);
return next_obj_50566;
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50567;
}})());
});
chromex_sample.robula.attribute_priorization_list = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 5, ["class",null,"name",null,"value",null,"alt",null,"title",null], null), null);
chromex_sample.robula.attribute_black_list = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 10, ["width",null,"height",null,"src",null,"href",null,"style",null,"onclick",null,"onload",null,"maxlength",null,"size",null,"tabindex",null], null), null);
/**
 * 获取xpath头部的祖先元素
 */
chromex_sample.robula.get_xpath_head_ancestor = (function chromex_sample$robula$get_xpath_head_ancestor(xpath,element){
return chromex_sample.robula.get_ancestor_at.call(null,element,(chromex_sample.robula.xpath_length.call(null,xpath) - (1)));
});
/**
 * 转换xpath的*表示
 */
chromex_sample.robula.transf_convert_star = (function chromex_sample$robula$transf_convert_star(xpath,element){
var ancestor = chromex_sample.robula.get_xpath_head_ancestor.call(null,xpath,element);
if(chromex_sample.robula.xpath_head_with_all_QMARK_.call(null,xpath)){
return (new cljs.core.PersistentVector(null,1,(5),cljs.core.PersistentVector.EMPTY_NODE,[chromex_sample.robula.xpath_replace_head_all.call(null,xpath,chromex_sample.robula.tag_name.call(null,ancestor))],null));
} else {
return null;
}
});
chromex_sample.robula.max_text_length = (30);
chromex_sample.robula.xpath_trans = (function chromex_sample$robula$xpath_trans(k,v){
if(clojure.string.includes_QMARK_.call(null,v,"'")){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [goog.string.format("translate(%s,\"'\",\" \")",k),clojure.string.replace.call(null,v,"'"," ")], null);
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [k,v], null);
}
});
chromex_sample.robula.xpath_contains_trans = (function chromex_sample$robula$xpath_contains_trans(k,v){
return cljs.core.apply.call(null,goog.string.format,"contains(%s,'%s')",chromex_sample.robula.xpath_trans.call(null,k,v));
});
/**
 * 构造text表达式
 */
chromex_sample.robula.make_xpath_text_exp = (function chromex_sample$robula$make_xpath_text_exp(s){
var text_fn_name = (((cljs.core.count.call(null,s) > chromex_sample.robula.max_text_length))?goog.string.format("substring(text(),1,%d)",chromex_sample.robula.max_text_length):"text()");
var target_s = cljs.core.subs.call(null,s,(0),chromex_sample.robula.max_text_length);
return goog.string.format("[%s]",chromex_sample.robula.xpath_contains_trans.call(null,text_fn_name,target_s));
});
chromex_sample.robula.make_xpath_attr_predicate = (function chromex_sample$robula$make_xpath_attr_predicate(attr_key,value){
var k = ["@",cljs.core.str.cljs$core$IFn$_invoke$arity$1(attr_key)].join('');
if((cljs.core.count.call(null,value) > chromex_sample.robula.max_text_length)){
return chromex_sample.robula.xpath_contains_trans.call(null,k,cljs.core.subs.call(null,value,(0),chromex_sample.robula.max_text_length));
} else {
return cljs.core.apply.call(null,goog.string.format,"%s='%s'",chromex_sample.robula.xpath_trans.call(null,k,value));
}
});
chromex_sample.robula.make_xpath_attr_exp = (function chromex_sample$robula$make_xpath_attr_exp(attr_key,value){
return goog.string.format("[%s]",chromex_sample.robula.make_xpath_attr_predicate.call(null,attr_key,value));
});
/**
 * 添加id属性
 */
chromex_sample.robula.transf_add_id = (function chromex_sample$robula$transf_add_id(xpath,element){
var ancestor = chromex_sample.robula.get_xpath_head_ancestor.call(null,xpath,element);
var ancestor_id = (function (){var target_obj_50569 = ancestor;
var _STAR_runtime_state_STAR__orig_val__50571 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50572 = oops.state.prepare_state.call(null,target_obj_50569,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50572;

try{var next_obj_50570 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50569,(0),"id",true,true,false))?(target_obj_50569["id"]):null);
return next_obj_50570;
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50571;
}})();
if(((cljs.core.seq.call(null,ancestor_id)) && ((!(chromex_sample.robula.xpath_head_has_predicates_QMARK_.call(null,xpath)))))){
return (new cljs.core.PersistentVector(null,1,(5),cljs.core.PersistentVector.EMPTY_NODE,[chromex_sample.robula.xpath_add_predicate_to_head.call(null,xpath,chromex_sample.robula.make_xpath_attr_exp.call(null,"id",ancestor_id))],null));
} else {
return null;
}
});
/**
 * 添加text属性
 */
chromex_sample.robula.transf_add_text = (function chromex_sample$robula$transf_add_text(xpath,element){
var ancestor = chromex_sample.robula.get_xpath_head_ancestor.call(null,xpath,element);
var ancestor_text = (function (){var target_obj_50573 = ancestor;
var _STAR_runtime_state_STAR__orig_val__50575 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50576 = oops.state.prepare_state.call(null,target_obj_50573,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50576;

try{var next_obj_50574 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50573,(0),"textContent",true,true,false))?(target_obj_50573["textContent"]):null);
return next_obj_50574;
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50575;
}})();
if(((cljs.core.seq.call(null,ancestor_text)) && (cljs.core.not.call(null,chromex_sample.robula.xpath_head_has_position_QMARK_.call(null,xpath))) && ((!(chromex_sample.robula.xpath_head_has_text_QMARK_.call(null,xpath)))))){
return (new cljs.core.PersistentVector(null,1,(5),cljs.core.PersistentVector.EMPTY_NODE,[chromex_sample.robula.xpath_add_predicate_to_head.call(null,xpath,chromex_sample.robula.make_xpath_text_exp.call(null,ancestor_text))],null));
} else {
return null;
}
});
/**
 * 添加其他属性
 */
chromex_sample.robula.transf_add_attribute = (function chromex_sample$robula$transf_add_attribute(xpath,element){
var ancestor = chromex_sample.robula.get_xpath_head_ancestor.call(null,xpath,element);
var ancestor_attrs = chromex_sample.robula.get_attributes.call(null,ancestor);
if((!(chromex_sample.robula.xpath_head_has_predicates_QMARK_.call(null,xpath)))){
var ancestor_priority_attrs = cljs.core.select_keys.call(null,ancestor_attrs,chromex_sample.robula.attribute_priorization_list);
var ancestor_other_attrs = cljs.core.select_keys.call(null,ancestor_attrs,clojure.set.difference.call(null,cljs.core.set.call(null,cljs.core.keys.call(null,ancestor_attrs)),chromex_sample.robula.attribute_priorization_list,chromex_sample.robula.attribute_black_list));
return cljs.core.map.call(null,((function (ancestor_priority_attrs,ancestor_other_attrs,ancestor,ancestor_attrs){
return (function (p__50577){
var vec__50578 = p__50577;
var k = cljs.core.nth.call(null,vec__50578,(0),null);
var v = cljs.core.nth.call(null,vec__50578,(1),null);
return chromex_sample.robula.xpath_add_predicate_to_head.call(null,xpath,chromex_sample.robula.make_xpath_attr_exp.call(null,k,v));
});})(ancestor_priority_attrs,ancestor_other_attrs,ancestor,ancestor_attrs))
,cljs.core.concat.call(null,ancestor_priority_attrs,ancestor_other_attrs));
} else {
return null;
}
});
chromex_sample.robula.powerset = (function chromex_sample$robula$powerset(coll){
return cljs.core.reduce.call(null,(function (a,x){
return cljs.core.into.call(null,a,cljs.core.map.call(null,(function (p1__50581_SHARP_){
return cljs.core.conj.call(null,p1__50581_SHARP_,x);
})),a);
}),cljs.core.PersistentHashSet.createAsIfByAssoc([cljs.core.PersistentHashSet.EMPTY]),coll);
});
/**
 * 优先属性比较
 */
chromex_sample.robula.priorization_attr_compare = (function chromex_sample$robula$priorization_attr_compare(priorization_set,attr1,attr2){
if(cljs.core.truth_(priorization_set.call(null,cljs.core.first.call(null,attr1)))){
return (-1);
} else {
if(cljs.core.truth_(priorization_set.call(null,cljs.core.first.call(null,attr2)))){
return (1);
} else {
return (0);

}
}
});
/**
 * 添加其他属性集合(幂集)
 */
chromex_sample.robula.transf_add_attribute_set = (function chromex_sample$robula$transf_add_attribute_set(xpath,element){
var ancestor_attrs = chromex_sample.robula.get_attributes.call(null,chromex_sample.robula.get_xpath_head_ancestor.call(null,xpath,element));
if((!(chromex_sample.robula.xpath_head_has_predicates_QMARK_.call(null,xpath)))){
var ancestor_useful_attrs = cljs.core.select_keys.call(null,ancestor_attrs,clojure.set.difference.call(null,cljs.core.set.call(null,cljs.core.keys.call(null,ancestor_attrs)),chromex_sample.robula.attribute_black_list));
var attr_power_set = cljs.core.filter.call(null,((function (ancestor_useful_attrs,ancestor_attrs){
return (function (p1__50582_SHARP_){
return (cljs.core.count.call(null,p1__50582_SHARP_) > (1));
});})(ancestor_useful_attrs,ancestor_attrs))
,chromex_sample.robula.powerset.call(null,ancestor_useful_attrs));
var priorization_set_val_cmp = cljs.core.partial.call(null,chromex_sample.robula.priorization_attr_compare,cljs.core.conj.call(null,chromex_sample.robula.attribute_priorization_list,"id"));
var sorted_attr_set = cljs.core.sort.call(null,((function (ancestor_useful_attrs,attr_power_set,priorization_set_val_cmp,ancestor_attrs){
return (function (attr_set1,attr_set2){
var l1 = cljs.core.count.call(null,attr_set1);
var l2 = cljs.core.count.call(null,attr_set2);
if(cljs.core._EQ_.call(null,l1,l2)){
return cljs.core.apply.call(null,priorization_set_val_cmp,cljs.core.first.call(null,cljs.core.drop_while.call(null,((function (l1,l2,ancestor_useful_attrs,attr_power_set,priorization_set_val_cmp,ancestor_attrs){
return (function (p1__50584_SHARP_){
return cljs.core._EQ_.call(null,cljs.core.first.call(null,p1__50584_SHARP_),cljs.core.second.call(null,p1__50584_SHARP_));
});})(l1,l2,ancestor_useful_attrs,attr_power_set,priorization_set_val_cmp,ancestor_attrs))
,cljs.core.zipmap.call(null,attr_set1,attr_set2))));
} else {
return cljs.core.compare.call(null,l1,l2);
}
});})(ancestor_useful_attrs,attr_power_set,priorization_set_val_cmp,ancestor_attrs))
,cljs.core.map.call(null,((function (ancestor_useful_attrs,attr_power_set,priorization_set_val_cmp,ancestor_attrs){
return (function (p1__50583_SHARP_){
return cljs.core.sort.call(null,priorization_set_val_cmp,p1__50583_SHARP_);
});})(ancestor_useful_attrs,attr_power_set,priorization_set_val_cmp,ancestor_attrs))
,attr_power_set));
var gen_attr_set_xpath = ((function (ancestor_useful_attrs,attr_power_set,priorization_set_val_cmp,sorted_attr_set,ancestor_attrs){
return (function (attrs){
return chromex_sample.robula.xpath_add_predicate_to_head.call(null,xpath,goog.string.format("[%s]",clojure.string.join.call(null," and ",cljs.core.map.call(null,((function (ancestor_useful_attrs,attr_power_set,priorization_set_val_cmp,sorted_attr_set,ancestor_attrs){
return (function (p__50585){
var vec__50586 = p__50585;
var k = cljs.core.nth.call(null,vec__50586,(0),null);
var v = cljs.core.nth.call(null,vec__50586,(1),null);
return chromex_sample.robula.make_xpath_attr_predicate.call(null,k,v);
});})(ancestor_useful_attrs,attr_power_set,priorization_set_val_cmp,sorted_attr_set,ancestor_attrs))
,attrs))));
});})(ancestor_useful_attrs,attr_power_set,priorization_set_val_cmp,sorted_attr_set,ancestor_attrs))
;
return cljs.core.map.call(null,gen_attr_set_xpath,sorted_attr_set);
} else {
return null;
}
});
/**
 * 添加位置索引
 */
chromex_sample.robula.transf_add_position = (function chromex_sample$robula$transf_add_position(xpath,element){
var ancestor = chromex_sample.robula.get_xpath_head_ancestor.call(null,xpath,element);
var prev_siblings = chromex_sample.robula.get_previous_element_siblings.call(null,ancestor);
if(cljs.core.not.call(null,chromex_sample.robula.xpath_head_has_position_QMARK_.call(null,xpath))){
var idx = ((chromex_sample.robula.xpath_head_with_all_QMARK_.call(null,xpath))?cljs.core.count.call(null,prev_siblings):cljs.core.count.call(null,cljs.core.filter.call(null,((function (ancestor,prev_siblings){
return (function (p1__50589_SHARP_){
return cljs.core._EQ_.call(null,chromex_sample.robula.tag_name.call(null,ancestor),p1__50589_SHARP_);
});})(ancestor,prev_siblings))
,cljs.core.map.call(null,chromex_sample.robula.tag_name,prev_siblings))));
if((idx > (0))){
return (new cljs.core.PersistentVector(null,1,(5),cljs.core.PersistentVector.EMPTY_NODE,[chromex_sample.robula.xpath_add_predicate_to_head.call(null,xpath,["[",cljs.core.str.cljs$core$IFn$_invoke$arity$1(idx),"]"].join(''))],null));
} else {
return null;
}
} else {
return null;
}
});
/**
 * 添加深度
 */
chromex_sample.robula.transf_add_level = (function chromex_sample$robula$transf_add_level(xpath,element){
if((chromex_sample.robula.xpath_length.call(null,xpath) < (chromex_sample.robula.get_ancestor_count.call(null,element) - (1)))){
return (new cljs.core.PersistentVector(null,1,(5),cljs.core.PersistentVector.EMPTY_NODE,[chromex_sample.robula.xpath_add_head_all.call(null,xpath)],null));
} else {
return null;
}
});
chromex_sample.robula.locate_count = (function chromex_sample$robula$locate_count(document,xpath){
var target_obj_50590 = document.evaluate(xpath,document,null,(function (){var target_obj_50592 = XPathResult;
var _STAR_runtime_state_STAR__orig_val__50594 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50595 = oops.state.prepare_state.call(null,target_obj_50592,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50595;

try{var next_obj_50593 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50592,(0),"ORDERED_NODE_SNAPSHOT_TYPE",true,true,false))?(target_obj_50592["ORDERED_NODE_SNAPSHOT_TYPE"]):null);
return next_obj_50593;
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50594;
}})(),null);
var _STAR_runtime_state_STAR__orig_val__50596 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50597 = oops.state.prepare_state.call(null,target_obj_50590,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50597;

try{var next_obj_50591 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50590,(0),"snapshotLength",true,true,false))?(target_obj_50590["snapshotLength"]):null);
return next_obj_50591;
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50596;
}});
/**
 * 唯一定位？
 */
chromex_sample.robula.unique_locate_QMARK_ = (function chromex_sample$robula$unique_locate_QMARK_(xpath,element,document){
var node_snap = document.evaluate(xpath,document,null,(function (){var target_obj_50598 = XPathResult;
var _STAR_runtime_state_STAR__orig_val__50600 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50601 = oops.state.prepare_state.call(null,target_obj_50598,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50601;

try{var next_obj_50599 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50598,(0),"ORDERED_NODE_SNAPSHOT_TYPE",true,true,false))?(target_obj_50598["ORDERED_NODE_SNAPSHOT_TYPE"]):null);
return next_obj_50599;
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50600;
}})(),null);
return ((cljs.core._EQ_.call(null,(1),(function (){var target_obj_50606 = node_snap;
var _STAR_runtime_state_STAR__orig_val__50608 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50609 = oops.state.prepare_state.call(null,target_obj_50606,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50609;

try{var next_obj_50607 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50606,(0),"snapshotLength",true,true,false))?(target_obj_50606["snapshotLength"]):null);
return next_obj_50607;
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50608;
}})())) && ((element === node_snap.snapshotItem((0)))));
});
chromex_sample.robula.get_element_by_xpath = (function chromex_sample$robula$get_element_by_xpath(document,xpath){
var target_obj_50610 = document.evaluate(xpath,document,null,(function (){var target_obj_50612 = XPathResult;
var _STAR_runtime_state_STAR__orig_val__50614 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50615 = oops.state.prepare_state.call(null,target_obj_50612,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50615;

try{var next_obj_50613 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50612,(0),"FIRST_ORDERED_NODE_TYPE",true,true,false))?(target_obj_50612["FIRST_ORDERED_NODE_TYPE"]):null);
return next_obj_50613;
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50614;
}})(),null);
var _STAR_runtime_state_STAR__orig_val__50616 = oops.state._STAR_runtime_state_STAR_;
var _STAR_runtime_state_STAR__temp_val__50617 = oops.state.prepare_state.call(null,target_obj_50610,(new Error()),function(){arguments[0].apply(console,Array.prototype.slice.call(arguments,1))});
oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__temp_val__50617;

try{var next_obj_50611 = ((oops.core.validate_object_access_dynamically.call(null,target_obj_50610,(0),"singleNodeValue",true,true,false))?(target_obj_50610["singleNodeValue"]):null);
return next_obj_50611;
}finally {oops.state._STAR_runtime_state_STAR_ = _STAR_runtime_state_STAR__orig_val__50616;
}});
chromex_sample.robula.$x = cljs.core.partial.call(null,chromex_sample.robula.get_element_by_xpath,document);
chromex_sample.robula.unique_xpath_QMARK_ = (function chromex_sample$robula$unique_xpath_QMARK_(path,doc,element){
return chromex_sample.robula.unique_locate_QMARK_.call(null,chromex_sample.robula.xpath__GT_str.call(null,path),element,doc);
});
chromex_sample.robula.get_xpath_in_list = (function chromex_sample$robula$get_xpath_in_list(xpath_list,doc,element){
while(true){
if(cljs.core.seq.call(null,xpath_list)){
var xpath = cljs.core.first.call(null,xpath_list);
var new_xpath_list = cljs.core.concat.call(null,(new cljs.core.LazySeq(null,((function (xpath_list,doc,element,xpath){
return (function (){
return chromex_sample.robula.transf_convert_star.call(null,xpath,element);
});})(xpath_list,doc,element,xpath))
,null,null)),(new cljs.core.LazySeq(null,((function (xpath_list,doc,element,xpath){
return (function (){
return chromex_sample.robula.transf_add_id.call(null,xpath,element);
});})(xpath_list,doc,element,xpath))
,null,null)),(new cljs.core.LazySeq(null,((function (xpath_list,doc,element,xpath){
return (function (){
return chromex_sample.robula.transf_add_text.call(null,xpath,element);
});})(xpath_list,doc,element,xpath))
,null,null)),(new cljs.core.LazySeq(null,((function (xpath_list,doc,element,xpath){
return (function (){
return chromex_sample.robula.transf_add_attribute.call(null,xpath,element);
});})(xpath_list,doc,element,xpath))
,null,null)),(new cljs.core.LazySeq(null,((function (xpath_list,doc,element,xpath){
return (function (){
return chromex_sample.robula.transf_add_position.call(null,xpath,element);
});})(xpath_list,doc,element,xpath))
,null,null)),(new cljs.core.LazySeq(null,((function (xpath_list,doc,element,xpath){
return (function (){
return chromex_sample.robula.transf_add_level.call(null,xpath,element);
});})(xpath_list,doc,element,xpath))
,null,null)));
var paths = cljs.core.distinct.call(null,new_xpath_list);
var temp__5733__auto__ = cljs.core.some.call(null,((function (xpath_list,doc,element,xpath,new_xpath_list,paths){
return (function (p1__50618_SHARP_){
if(chromex_sample.robula.unique_xpath_QMARK_.call(null,p1__50618_SHARP_,doc,element)){
return p1__50618_SHARP_;
} else {
return null;
}
});})(xpath_list,doc,element,xpath,new_xpath_list,paths))
,new_xpath_list);
if(cljs.core.truth_(temp__5733__auto__)){
var result = temp__5733__auto__;
return chromex_sample.robula.xpath__GT_str.call(null,result);
} else {
var G__50619 = cljs.core.concat.call(null,cljs.core.rest.call(null,xpath_list),paths);
var G__50620 = doc;
var G__50621 = element;
xpath_list = G__50619;
doc = G__50620;
element = G__50621;
continue;
}
} else {
return null;
}
break;
}
});
chromex_sample.robula.get_robust_xpath_base = (function chromex_sample$robula$get_robust_xpath_base(document,element){
return chromex_sample.robula.get_xpath_in_list.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [chromex_sample.robula.xpath_all], null),document,element);
});
chromex_sample.robula.get_robust_xpath = cljs.core.memoize.call(null,chromex_sample.robula.get_robust_xpath_base);

//# sourceMappingURL=robula.js.map
