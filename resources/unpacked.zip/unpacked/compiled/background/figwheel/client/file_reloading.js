// Compiled by ClojureScript 1.10.520 {}
goog.provide('figwheel.client.file_reloading');
goog.require('cljs.core');
goog.require('figwheel.client.utils');
goog.require('goog.Uri');
goog.require('goog.string');
goog.require('goog.object');
goog.require('goog.net.jsloader');
goog.require('goog.html.legacyconversions');
goog.require('clojure.string');
goog.require('clojure.set');
goog.require('cljs.core.async');
goog.require('goog.async.Deferred');
if((typeof figwheel !== 'undefined') && (typeof figwheel.client !== 'undefined') && (typeof figwheel.client.file_reloading !== 'undefined') && (typeof figwheel.client.file_reloading.figwheel_meta_pragmas !== 'undefined')){
} else {
figwheel.client.file_reloading.figwheel_meta_pragmas = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
}
figwheel.client.file_reloading.on_jsload_custom_event = (function figwheel$client$file_reloading$on_jsload_custom_event(url){
return figwheel.client.utils.dispatch_custom_event.call(null,"figwheel.js-reload",url);
});
figwheel.client.file_reloading.before_jsload_custom_event = (function figwheel$client$file_reloading$before_jsload_custom_event(files){
return figwheel.client.utils.dispatch_custom_event.call(null,"figwheel.before-js-reload",files);
});
figwheel.client.file_reloading.on_cssload_custom_event = (function figwheel$client$file_reloading$on_cssload_custom_event(files){
return figwheel.client.utils.dispatch_custom_event.call(null,"figwheel.css-reload",files);
});
figwheel.client.file_reloading.namespace_file_map_QMARK_ = (function figwheel$client$file_reloading$namespace_file_map_QMARK_(m){
var or__4131__auto__ = ((cljs.core.map_QMARK_.call(null,m)) && (typeof new cljs.core.Keyword(null,"namespace","namespace",-377510372).cljs$core$IFn$_invoke$arity$1(m) === 'string') && ((((new cljs.core.Keyword(null,"file","file",-1269645878).cljs$core$IFn$_invoke$arity$1(m) == null)) || (typeof new cljs.core.Keyword(null,"file","file",-1269645878).cljs$core$IFn$_invoke$arity$1(m) === 'string'))) && (cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"type","type",1174270348).cljs$core$IFn$_invoke$arity$1(m),new cljs.core.Keyword(null,"namespace","namespace",-377510372))));
if(or__4131__auto__){
return or__4131__auto__;
} else {
cljs.core.println.call(null,"Error not namespace-file-map",cljs.core.pr_str.call(null,m));

return false;
}
});
figwheel.client.file_reloading.add_cache_buster = (function figwheel$client$file_reloading$add_cache_buster(url){

return goog.Uri.parse(url).makeUnique();
});
figwheel.client.file_reloading.name__GT_path = (function figwheel$client$file_reloading$name__GT_path(ns){

return goog.object.get(goog.dependencies_.nameToPath,ns);
});
figwheel.client.file_reloading.provided_QMARK_ = (function figwheel$client$file_reloading$provided_QMARK_(ns){
return goog.object.get(goog.dependencies_.written,figwheel.client.file_reloading.name__GT_path.call(null,ns));
});
figwheel.client.file_reloading.immutable_ns_QMARK_ = (function figwheel$client$file_reloading$immutable_ns_QMARK_(name){
var or__4131__auto__ = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 3, ["cljs.nodejs",null,"goog",null,"cljs.core",null], null), null).call(null,name);
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
var or__4131__auto____$1 = goog.string.startsWith("clojure.",name);
if(cljs.core.truth_(or__4131__auto____$1)){
return or__4131__auto____$1;
} else {
return goog.string.startsWith("goog.",name);
}
}
});
figwheel.client.file_reloading.get_requires = (function figwheel$client$file_reloading$get_requires(ns){
return cljs.core.set.call(null,cljs.core.filter.call(null,(function (p1__83161_SHARP_){
return cljs.core.not.call(null,figwheel.client.file_reloading.immutable_ns_QMARK_.call(null,p1__83161_SHARP_));
}),goog.object.getKeys(goog.object.get(goog.dependencies_.requires,figwheel.client.file_reloading.name__GT_path.call(null,ns)))));
});
if((typeof figwheel !== 'undefined') && (typeof figwheel.client !== 'undefined') && (typeof figwheel.client.file_reloading !== 'undefined') && (typeof figwheel.client.file_reloading.dependency_data !== 'undefined')){
} else {
figwheel.client.file_reloading.dependency_data = cljs.core.atom.call(null,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"pathToName","pathToName",-1236616181),cljs.core.PersistentArrayMap.EMPTY,new cljs.core.Keyword(null,"dependents","dependents",136812837),cljs.core.PersistentArrayMap.EMPTY], null));
}
figwheel.client.file_reloading.path_to_name_BANG_ = (function figwheel$client$file_reloading$path_to_name_BANG_(path,name){
return cljs.core.swap_BANG_.call(null,figwheel.client.file_reloading.dependency_data,cljs.core.update_in,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"pathToName","pathToName",-1236616181),path], null),cljs.core.fnil.call(null,clojure.set.union,cljs.core.PersistentHashSet.EMPTY),cljs.core.PersistentHashSet.createAsIfByAssoc([name]));
});
/**
 * Setup a path to name dependencies map.
 * That goes from path -> #{ ns-names }
 */
figwheel.client.file_reloading.setup_path__GT_name_BANG_ = (function figwheel$client$file_reloading$setup_path__GT_name_BANG_(){
var nameToPath = goog.object.filter(goog.dependencies_.nameToPath,(function (v,k,o){
return goog.string.startsWith(v,"../");
}));
return goog.object.forEach(nameToPath,((function (nameToPath){
return (function (v,k,o){
return figwheel.client.file_reloading.path_to_name_BANG_.call(null,v,k);
});})(nameToPath))
);
});
/**
 * returns a set of namespaces defined by a path
 */
figwheel.client.file_reloading.path__GT_name = (function figwheel$client$file_reloading$path__GT_name(path){
return cljs.core.get_in.call(null,cljs.core.deref.call(null,figwheel.client.file_reloading.dependency_data),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"pathToName","pathToName",-1236616181),path], null));
});
figwheel.client.file_reloading.name_to_parent_BANG_ = (function figwheel$client$file_reloading$name_to_parent_BANG_(ns,parent_ns){
return cljs.core.swap_BANG_.call(null,figwheel.client.file_reloading.dependency_data,cljs.core.update_in,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"dependents","dependents",136812837),ns], null),cljs.core.fnil.call(null,clojure.set.union,cljs.core.PersistentHashSet.EMPTY),cljs.core.PersistentHashSet.createAsIfByAssoc([parent_ns]));
});
/**
 * This reverses the goog.dependencies_.requires for looking up ns-dependents.
 */
figwheel.client.file_reloading.setup_ns__GT_dependents_BANG_ = (function figwheel$client$file_reloading$setup_ns__GT_dependents_BANG_(){
var requires = goog.object.filter(goog.dependencies_.requires,(function (v,k,o){
return goog.string.startsWith(k,"../");
}));
return goog.object.forEach(requires,((function (requires){
return (function (v,k,_){
return goog.object.forEach(v,((function (requires){
return (function (v_SINGLEQUOTE_,k_SINGLEQUOTE_,___$1){
var seq__83162 = cljs.core.seq.call(null,figwheel.client.file_reloading.path__GT_name.call(null,k));
var chunk__83163 = null;
var count__83164 = (0);
var i__83165 = (0);
while(true){
if((i__83165 < count__83164)){
var n = cljs.core._nth.call(null,chunk__83163,i__83165);
figwheel.client.file_reloading.name_to_parent_BANG_.call(null,k_SINGLEQUOTE_,n);


var G__83166 = seq__83162;
var G__83167 = chunk__83163;
var G__83168 = count__83164;
var G__83169 = (i__83165 + (1));
seq__83162 = G__83166;
chunk__83163 = G__83167;
count__83164 = G__83168;
i__83165 = G__83169;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq.call(null,seq__83162);
if(temp__5735__auto__){
var seq__83162__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__83162__$1)){
var c__4550__auto__ = cljs.core.chunk_first.call(null,seq__83162__$1);
var G__83170 = cljs.core.chunk_rest.call(null,seq__83162__$1);
var G__83171 = c__4550__auto__;
var G__83172 = cljs.core.count.call(null,c__4550__auto__);
var G__83173 = (0);
seq__83162 = G__83170;
chunk__83163 = G__83171;
count__83164 = G__83172;
i__83165 = G__83173;
continue;
} else {
var n = cljs.core.first.call(null,seq__83162__$1);
figwheel.client.file_reloading.name_to_parent_BANG_.call(null,k_SINGLEQUOTE_,n);


var G__83174 = cljs.core.next.call(null,seq__83162__$1);
var G__83175 = null;
var G__83176 = (0);
var G__83177 = (0);
seq__83162 = G__83174;
chunk__83163 = G__83175;
count__83164 = G__83176;
i__83165 = G__83177;
continue;
}
} else {
return null;
}
}
break;
}
});})(requires))
);
});})(requires))
);
});
figwheel.client.file_reloading.ns__GT_dependents = (function figwheel$client$file_reloading$ns__GT_dependents(ns){
return cljs.core.get_in.call(null,cljs.core.deref.call(null,figwheel.client.file_reloading.dependency_data),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"dependents","dependents",136812837),ns], null));
});
figwheel.client.file_reloading.in_upper_level_QMARK_ = (function figwheel$client$file_reloading$in_upper_level_QMARK_(topo_state,current_depth,dep){
return cljs.core.some.call(null,(function (p__83178){
var vec__83179 = p__83178;
var _ = cljs.core.nth.call(null,vec__83179,(0),null);
var v = cljs.core.nth.call(null,vec__83179,(1),null);
var and__4120__auto__ = v;
if(cljs.core.truth_(and__4120__auto__)){
return v.call(null,dep);
} else {
return and__4120__auto__;
}
}),cljs.core.filter.call(null,(function (p__83182){
var vec__83183 = p__83182;
var k = cljs.core.nth.call(null,vec__83183,(0),null);
var v = cljs.core.nth.call(null,vec__83183,(1),null);
return (k > current_depth);
}),topo_state));
});
figwheel.client.file_reloading.build_topo_sort = (function figwheel$client$file_reloading$build_topo_sort(get_deps){
var get_deps__$1 = cljs.core.memoize.call(null,get_deps);
var topo_sort_helper_STAR_ = ((function (get_deps__$1){
return (function figwheel$client$file_reloading$build_topo_sort_$_topo_sort_helper_STAR_(x,depth,state){
var deps = get_deps__$1.call(null,x);
if(cljs.core.empty_QMARK_.call(null,deps)){
return null;
} else {
return topo_sort_STAR_.call(null,deps,depth,state);
}
});})(get_deps__$1))
;
var topo_sort_STAR_ = ((function (get_deps__$1){
return (function() {
var figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR_ = null;
var figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR___1 = (function (deps){
return figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR_.call(null,deps,(0),cljs.core.atom.call(null,cljs.core.sorted_map.call(null)));
});
var figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR___3 = (function (deps,depth,state){
cljs.core.swap_BANG_.call(null,state,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [depth], null),cljs.core.fnil.call(null,cljs.core.into,cljs.core.PersistentHashSet.EMPTY),deps);

var seq__83195_83203 = cljs.core.seq.call(null,deps);
var chunk__83196_83204 = null;
var count__83197_83205 = (0);
var i__83198_83206 = (0);
while(true){
if((i__83198_83206 < count__83197_83205)){
var dep_83207 = cljs.core._nth.call(null,chunk__83196_83204,i__83198_83206);
if(cljs.core.truth_((function (){var and__4120__auto__ = dep_83207;
if(cljs.core.truth_(and__4120__auto__)){
return cljs.core.not.call(null,figwheel.client.file_reloading.in_upper_level_QMARK_.call(null,cljs.core.deref.call(null,state),depth,dep_83207));
} else {
return and__4120__auto__;
}
})())){
topo_sort_helper_STAR_.call(null,dep_83207,(depth + (1)),state);
} else {
}


var G__83208 = seq__83195_83203;
var G__83209 = chunk__83196_83204;
var G__83210 = count__83197_83205;
var G__83211 = (i__83198_83206 + (1));
seq__83195_83203 = G__83208;
chunk__83196_83204 = G__83209;
count__83197_83205 = G__83210;
i__83198_83206 = G__83211;
continue;
} else {
var temp__5735__auto___83212 = cljs.core.seq.call(null,seq__83195_83203);
if(temp__5735__auto___83212){
var seq__83195_83213__$1 = temp__5735__auto___83212;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__83195_83213__$1)){
var c__4550__auto___83214 = cljs.core.chunk_first.call(null,seq__83195_83213__$1);
var G__83215 = cljs.core.chunk_rest.call(null,seq__83195_83213__$1);
var G__83216 = c__4550__auto___83214;
var G__83217 = cljs.core.count.call(null,c__4550__auto___83214);
var G__83218 = (0);
seq__83195_83203 = G__83215;
chunk__83196_83204 = G__83216;
count__83197_83205 = G__83217;
i__83198_83206 = G__83218;
continue;
} else {
var dep_83219 = cljs.core.first.call(null,seq__83195_83213__$1);
if(cljs.core.truth_((function (){var and__4120__auto__ = dep_83219;
if(cljs.core.truth_(and__4120__auto__)){
return cljs.core.not.call(null,figwheel.client.file_reloading.in_upper_level_QMARK_.call(null,cljs.core.deref.call(null,state),depth,dep_83219));
} else {
return and__4120__auto__;
}
})())){
topo_sort_helper_STAR_.call(null,dep_83219,(depth + (1)),state);
} else {
}


var G__83220 = cljs.core.next.call(null,seq__83195_83213__$1);
var G__83221 = null;
var G__83222 = (0);
var G__83223 = (0);
seq__83195_83203 = G__83220;
chunk__83196_83204 = G__83221;
count__83197_83205 = G__83222;
i__83198_83206 = G__83223;
continue;
}
} else {
}
}
break;
}

if(cljs.core._EQ_.call(null,depth,(0))){
return elim_dups_STAR_.call(null,cljs.core.reverse.call(null,cljs.core.vals.call(null,cljs.core.deref.call(null,state))));
} else {
return null;
}
});
figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR_ = function(deps,depth,state){
switch(arguments.length){
case 1:
return figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR___1.call(this,deps);
case 3:
return figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR___3.call(this,deps,depth,state);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR_.cljs$core$IFn$_invoke$arity$1 = figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR___1;
figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR_.cljs$core$IFn$_invoke$arity$3 = figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR___3;
return figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR_;
})()
;})(get_deps__$1))
;
var elim_dups_STAR_ = ((function (get_deps__$1){
return (function figwheel$client$file_reloading$build_topo_sort_$_elim_dups_STAR_(p__83199){
var vec__83200 = p__83199;
var seq__83201 = cljs.core.seq.call(null,vec__83200);
var first__83202 = cljs.core.first.call(null,seq__83201);
var seq__83201__$1 = cljs.core.next.call(null,seq__83201);
var x = first__83202;
var xs = seq__83201__$1;
if((x == null)){
return cljs.core.List.EMPTY;
} else {
return cljs.core.cons.call(null,x,figwheel$client$file_reloading$build_topo_sort_$_elim_dups_STAR_.call(null,cljs.core.map.call(null,((function (vec__83200,seq__83201,first__83202,seq__83201__$1,x,xs,get_deps__$1){
return (function (p1__83186_SHARP_){
return clojure.set.difference.call(null,p1__83186_SHARP_,x);
});})(vec__83200,seq__83201,first__83202,seq__83201__$1,x,xs,get_deps__$1))
,xs)));
}
});})(get_deps__$1))
;
return topo_sort_STAR_;
});
figwheel.client.file_reloading.get_all_dependencies = (function figwheel$client$file_reloading$get_all_dependencies(ns){
var topo_sort_SINGLEQUOTE_ = figwheel.client.file_reloading.build_topo_sort.call(null,figwheel.client.file_reloading.get_requires);
return cljs.core.apply.call(null,cljs.core.concat,topo_sort_SINGLEQUOTE_.call(null,cljs.core.set.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [ns], null))));
});
figwheel.client.file_reloading.get_all_dependents = (function figwheel$client$file_reloading$get_all_dependents(nss){
var topo_sort_SINGLEQUOTE_ = figwheel.client.file_reloading.build_topo_sort.call(null,figwheel.client.file_reloading.ns__GT_dependents);
return cljs.core.filter.call(null,cljs.core.comp.call(null,cljs.core.not,figwheel.client.file_reloading.immutable_ns_QMARK_),cljs.core.reverse.call(null,cljs.core.apply.call(null,cljs.core.concat,topo_sort_SINGLEQUOTE_.call(null,cljs.core.set.call(null,nss)))));
});
figwheel.client.file_reloading.unprovide_BANG_ = (function figwheel$client$file_reloading$unprovide_BANG_(ns){
var path = figwheel.client.file_reloading.name__GT_path.call(null,ns);
goog.object.remove(goog.dependencies_.visited,path);

goog.object.remove(goog.dependencies_.written,path);

return goog.object.remove(goog.dependencies_.written,[cljs.core.str.cljs$core$IFn$_invoke$arity$1(goog.basePath),cljs.core.str.cljs$core$IFn$_invoke$arity$1(path)].join(''));
});
figwheel.client.file_reloading.resolve_ns = (function figwheel$client$file_reloading$resolve_ns(ns){
return [cljs.core.str.cljs$core$IFn$_invoke$arity$1(goog.basePath),cljs.core.str.cljs$core$IFn$_invoke$arity$1(figwheel.client.file_reloading.name__GT_path.call(null,ns))].join('');
});
figwheel.client.file_reloading.addDependency = (function figwheel$client$file_reloading$addDependency(path,provides,requires){
var seq__83224 = cljs.core.seq.call(null,provides);
var chunk__83225 = null;
var count__83226 = (0);
var i__83227 = (0);
while(true){
if((i__83227 < count__83226)){
var prov = cljs.core._nth.call(null,chunk__83225,i__83227);
figwheel.client.file_reloading.path_to_name_BANG_.call(null,path,prov);

var seq__83236_83244 = cljs.core.seq.call(null,requires);
var chunk__83237_83245 = null;
var count__83238_83246 = (0);
var i__83239_83247 = (0);
while(true){
if((i__83239_83247 < count__83238_83246)){
var req_83248 = cljs.core._nth.call(null,chunk__83237_83245,i__83239_83247);
figwheel.client.file_reloading.name_to_parent_BANG_.call(null,req_83248,prov);


var G__83249 = seq__83236_83244;
var G__83250 = chunk__83237_83245;
var G__83251 = count__83238_83246;
var G__83252 = (i__83239_83247 + (1));
seq__83236_83244 = G__83249;
chunk__83237_83245 = G__83250;
count__83238_83246 = G__83251;
i__83239_83247 = G__83252;
continue;
} else {
var temp__5735__auto___83253 = cljs.core.seq.call(null,seq__83236_83244);
if(temp__5735__auto___83253){
var seq__83236_83254__$1 = temp__5735__auto___83253;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__83236_83254__$1)){
var c__4550__auto___83255 = cljs.core.chunk_first.call(null,seq__83236_83254__$1);
var G__83256 = cljs.core.chunk_rest.call(null,seq__83236_83254__$1);
var G__83257 = c__4550__auto___83255;
var G__83258 = cljs.core.count.call(null,c__4550__auto___83255);
var G__83259 = (0);
seq__83236_83244 = G__83256;
chunk__83237_83245 = G__83257;
count__83238_83246 = G__83258;
i__83239_83247 = G__83259;
continue;
} else {
var req_83260 = cljs.core.first.call(null,seq__83236_83254__$1);
figwheel.client.file_reloading.name_to_parent_BANG_.call(null,req_83260,prov);


var G__83261 = cljs.core.next.call(null,seq__83236_83254__$1);
var G__83262 = null;
var G__83263 = (0);
var G__83264 = (0);
seq__83236_83244 = G__83261;
chunk__83237_83245 = G__83262;
count__83238_83246 = G__83263;
i__83239_83247 = G__83264;
continue;
}
} else {
}
}
break;
}


var G__83265 = seq__83224;
var G__83266 = chunk__83225;
var G__83267 = count__83226;
var G__83268 = (i__83227 + (1));
seq__83224 = G__83265;
chunk__83225 = G__83266;
count__83226 = G__83267;
i__83227 = G__83268;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq.call(null,seq__83224);
if(temp__5735__auto__){
var seq__83224__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__83224__$1)){
var c__4550__auto__ = cljs.core.chunk_first.call(null,seq__83224__$1);
var G__83269 = cljs.core.chunk_rest.call(null,seq__83224__$1);
var G__83270 = c__4550__auto__;
var G__83271 = cljs.core.count.call(null,c__4550__auto__);
var G__83272 = (0);
seq__83224 = G__83269;
chunk__83225 = G__83270;
count__83226 = G__83271;
i__83227 = G__83272;
continue;
} else {
var prov = cljs.core.first.call(null,seq__83224__$1);
figwheel.client.file_reloading.path_to_name_BANG_.call(null,path,prov);

var seq__83240_83273 = cljs.core.seq.call(null,requires);
var chunk__83241_83274 = null;
var count__83242_83275 = (0);
var i__83243_83276 = (0);
while(true){
if((i__83243_83276 < count__83242_83275)){
var req_83277 = cljs.core._nth.call(null,chunk__83241_83274,i__83243_83276);
figwheel.client.file_reloading.name_to_parent_BANG_.call(null,req_83277,prov);


var G__83278 = seq__83240_83273;
var G__83279 = chunk__83241_83274;
var G__83280 = count__83242_83275;
var G__83281 = (i__83243_83276 + (1));
seq__83240_83273 = G__83278;
chunk__83241_83274 = G__83279;
count__83242_83275 = G__83280;
i__83243_83276 = G__83281;
continue;
} else {
var temp__5735__auto___83282__$1 = cljs.core.seq.call(null,seq__83240_83273);
if(temp__5735__auto___83282__$1){
var seq__83240_83283__$1 = temp__5735__auto___83282__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__83240_83283__$1)){
var c__4550__auto___83284 = cljs.core.chunk_first.call(null,seq__83240_83283__$1);
var G__83285 = cljs.core.chunk_rest.call(null,seq__83240_83283__$1);
var G__83286 = c__4550__auto___83284;
var G__83287 = cljs.core.count.call(null,c__4550__auto___83284);
var G__83288 = (0);
seq__83240_83273 = G__83285;
chunk__83241_83274 = G__83286;
count__83242_83275 = G__83287;
i__83243_83276 = G__83288;
continue;
} else {
var req_83289 = cljs.core.first.call(null,seq__83240_83283__$1);
figwheel.client.file_reloading.name_to_parent_BANG_.call(null,req_83289,prov);


var G__83290 = cljs.core.next.call(null,seq__83240_83283__$1);
var G__83291 = null;
var G__83292 = (0);
var G__83293 = (0);
seq__83240_83273 = G__83290;
chunk__83241_83274 = G__83291;
count__83242_83275 = G__83292;
i__83243_83276 = G__83293;
continue;
}
} else {
}
}
break;
}


var G__83294 = cljs.core.next.call(null,seq__83224__$1);
var G__83295 = null;
var G__83296 = (0);
var G__83297 = (0);
seq__83224 = G__83294;
chunk__83225 = G__83295;
count__83226 = G__83296;
i__83227 = G__83297;
continue;
}
} else {
return null;
}
}
break;
}
});
figwheel.client.file_reloading.figwheel_require = (function figwheel$client$file_reloading$figwheel_require(src,reload){
goog.require = figwheel.client.file_reloading.figwheel_require;

if(cljs.core._EQ_.call(null,reload,"reload-all")){
var seq__83298_83302 = cljs.core.seq.call(null,figwheel.client.file_reloading.get_all_dependencies.call(null,src));
var chunk__83299_83303 = null;
var count__83300_83304 = (0);
var i__83301_83305 = (0);
while(true){
if((i__83301_83305 < count__83300_83304)){
var ns_83306 = cljs.core._nth.call(null,chunk__83299_83303,i__83301_83305);
figwheel.client.file_reloading.unprovide_BANG_.call(null,ns_83306);


var G__83307 = seq__83298_83302;
var G__83308 = chunk__83299_83303;
var G__83309 = count__83300_83304;
var G__83310 = (i__83301_83305 + (1));
seq__83298_83302 = G__83307;
chunk__83299_83303 = G__83308;
count__83300_83304 = G__83309;
i__83301_83305 = G__83310;
continue;
} else {
var temp__5735__auto___83311 = cljs.core.seq.call(null,seq__83298_83302);
if(temp__5735__auto___83311){
var seq__83298_83312__$1 = temp__5735__auto___83311;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__83298_83312__$1)){
var c__4550__auto___83313 = cljs.core.chunk_first.call(null,seq__83298_83312__$1);
var G__83314 = cljs.core.chunk_rest.call(null,seq__83298_83312__$1);
var G__83315 = c__4550__auto___83313;
var G__83316 = cljs.core.count.call(null,c__4550__auto___83313);
var G__83317 = (0);
seq__83298_83302 = G__83314;
chunk__83299_83303 = G__83315;
count__83300_83304 = G__83316;
i__83301_83305 = G__83317;
continue;
} else {
var ns_83318 = cljs.core.first.call(null,seq__83298_83312__$1);
figwheel.client.file_reloading.unprovide_BANG_.call(null,ns_83318);


var G__83319 = cljs.core.next.call(null,seq__83298_83312__$1);
var G__83320 = null;
var G__83321 = (0);
var G__83322 = (0);
seq__83298_83302 = G__83319;
chunk__83299_83303 = G__83320;
count__83300_83304 = G__83321;
i__83301_83305 = G__83322;
continue;
}
} else {
}
}
break;
}
} else {
}

if(cljs.core.truth_(reload)){
figwheel.client.file_reloading.unprovide_BANG_.call(null,src);
} else {
}

return goog.require_figwheel_backup_(src);
});
/**
 * Reusable browser REPL bootstrapping. Patches the essential functions
 *   in goog.base to support re-loading of namespaces after page load.
 */
figwheel.client.file_reloading.bootstrap_goog_base = (function figwheel$client$file_reloading$bootstrap_goog_base(){
if(cljs.core.truth_(COMPILED)){
return null;
} else {
goog.require_figwheel_backup_ = (function (){var or__4131__auto__ = goog.require__;
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return goog.require;
}
})();

goog.isProvided_ = (function (name){
return false;
});

figwheel.client.file_reloading.setup_path__GT_name_BANG_.call(null);

figwheel.client.file_reloading.setup_ns__GT_dependents_BANG_.call(null);

goog.addDependency_figwheel_backup_ = goog.addDependency;

goog.addDependency = (function() { 
var G__83323__delegate = function (args){
cljs.core.apply.call(null,figwheel.client.file_reloading.addDependency,args);

return cljs.core.apply.call(null,goog.addDependency_figwheel_backup_,args);
};
var G__83323 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__83324__i = 0, G__83324__a = new Array(arguments.length -  0);
while (G__83324__i < G__83324__a.length) {G__83324__a[G__83324__i] = arguments[G__83324__i + 0]; ++G__83324__i;}
  args = new cljs.core.IndexedSeq(G__83324__a,0,null);
} 
return G__83323__delegate.call(this,args);};
G__83323.cljs$lang$maxFixedArity = 0;
G__83323.cljs$lang$applyTo = (function (arglist__83325){
var args = cljs.core.seq(arglist__83325);
return G__83323__delegate(args);
});
G__83323.cljs$core$IFn$_invoke$arity$variadic = G__83323__delegate;
return G__83323;
})()
;

goog.constructNamespace_("cljs.user");

goog.global.CLOSURE_IMPORT_SCRIPT = figwheel.client.file_reloading.queued_file_reload;

return goog.require = figwheel.client.file_reloading.figwheel_require;
}
});
figwheel.client.file_reloading.patch_goog_base = (function figwheel$client$file_reloading$patch_goog_base(){
if((typeof figwheel !== 'undefined') && (typeof figwheel.client !== 'undefined') && (typeof figwheel.client.file_reloading !== 'undefined') && (typeof figwheel.client.file_reloading.bootstrapped_cljs !== 'undefined')){
return null;
} else {
return (
figwheel.client.file_reloading.bootstrapped_cljs = (function (){
figwheel.client.file_reloading.bootstrap_goog_base.call(null);

return true;
})()
)
;
}
});
figwheel.client.file_reloading.gloader = (((typeof goog !== 'undefined') && (typeof goog.net !== 'undefined') && (typeof goog.net.jsloader !== 'undefined') && (typeof goog.net.jsloader.safeLoad !== 'undefined'))?(function (p1__83326_SHARP_,p2__83327_SHARP_){
return goog.net.jsloader.safeLoad(goog.html.legacyconversions.trustedResourceUrlFromString(cljs.core.str.cljs$core$IFn$_invoke$arity$1(p1__83326_SHARP_)),p2__83327_SHARP_);
}):(((typeof goog !== 'undefined') && (typeof goog.net !== 'undefined') && (typeof goog.net.jsloader !== 'undefined') && (typeof goog.net.jsloader.load !== 'undefined'))?(function (p1__83328_SHARP_,p2__83329_SHARP_){
return goog.net.jsloader.load(cljs.core.str.cljs$core$IFn$_invoke$arity$1(p1__83328_SHARP_),p2__83329_SHARP_);
}):(function(){throw cljs.core.ex_info.call(null,"No remote script loading function found.",cljs.core.PersistentArrayMap.EMPTY)})()
));
figwheel.client.file_reloading.reload_file_in_html_env = (function figwheel$client$file_reloading$reload_file_in_html_env(request_url,callback){

var G__83330 = figwheel.client.file_reloading.gloader.call(null,figwheel.client.file_reloading.add_cache_buster.call(null,request_url),({"cleanupWhenDone": true}));
G__83330.addCallback(((function (G__83330){
return (function (){
return cljs.core.apply.call(null,callback,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [true], null));
});})(G__83330))
);

G__83330.addErrback(((function (G__83330){
return (function (){
return cljs.core.apply.call(null,callback,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [false], null));
});})(G__83330))
);

return G__83330;
});
figwheel.client.file_reloading.write_script_tag_import = figwheel.client.file_reloading.reload_file_in_html_env;
goog.exportSymbol('figwheel.client.file_reloading.write_script_tag_import', figwheel.client.file_reloading.write_script_tag_import);
figwheel.client.file_reloading.worker_import_script = (function figwheel$client$file_reloading$worker_import_script(request_url,callback){

return callback.call(null,(function (){try{self.importScripts(figwheel.client.file_reloading.add_cache_buster.call(null,request_url));

return true;
}catch (e83331){if((e83331 instanceof Error)){
var e = e83331;
figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"error","error",-978969032),["Figwheel: Error loading file ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(request_url)].join(''));

figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"error","error",-978969032),e.stack);

return false;
} else {
throw e83331;

}
}})());
});
goog.exportSymbol('figwheel.client.file_reloading.worker_import_script', figwheel.client.file_reloading.worker_import_script);
figwheel.client.file_reloading.create_node_script_import_fn = (function figwheel$client$file_reloading$create_node_script_import_fn(){
var node_path_lib = require("path");
var util_pattern = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(node_path_lib.sep),cljs.core.str.cljs$core$IFn$_invoke$arity$1(node_path_lib.join("goog","bootstrap","nodejs.js"))].join('');
var util_path = goog.object.findKey(require.cache,((function (node_path_lib,util_pattern){
return (function (v,k,o){
return goog.string.endsWith(k,util_pattern);
});})(node_path_lib,util_pattern))
);
var parts = cljs.core.pop.call(null,cljs.core.pop.call(null,clojure.string.split.call(null,util_path,/[\/\\]/)));
var root_path = clojure.string.join.call(null,node_path_lib.sep,parts);
return ((function (node_path_lib,util_pattern,util_path,parts,root_path){
return (function (request_url,callback){

var cache_path = node_path_lib.resolve(root_path,request_url);
goog.object.remove(require.cache,cache_path);

return callback.call(null,(function (){try{return require(cache_path);
}catch (e83332){if((e83332 instanceof Error)){
var e = e83332;
figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"error","error",-978969032),["Figwheel: Error loading file ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(cache_path)].join(''));

figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"error","error",-978969032),e.stack);

return false;
} else {
throw e83332;

}
}})());
});
;})(node_path_lib,util_pattern,util_path,parts,root_path))
});
goog.exportSymbol('figwheel.client.file_reloading.create_node_script_import_fn', figwheel.client.file_reloading.create_node_script_import_fn);
figwheel.client.file_reloading.reload_file_STAR_ = (function (){var pred__83333 = cljs.core._EQ_;
var expr__83334 = figwheel.client.utils.host_env_QMARK_.call(null);
if(cljs.core.truth_(pred__83333.call(null,new cljs.core.Keyword(null,"node","node",581201198),expr__83334))){
return figwheel.client.file_reloading.create_node_script_import_fn.call(null);
} else {
if(cljs.core.truth_(pred__83333.call(null,new cljs.core.Keyword(null,"html","html",-998796897),expr__83334))){
return figwheel.client.file_reloading.write_script_tag_import;
} else {
if(cljs.core.truth_(pred__83333.call(null,new cljs.core.Keyword(null,"worker","worker",938239996),expr__83334))){
return figwheel.client.file_reloading.worker_import_script;
} else {
return ((function (pred__83333,expr__83334){
return (function (a,b){
throw "Reload not defined for this platform";
});
;})(pred__83333,expr__83334))
}
}
}
})();
figwheel.client.file_reloading.reload_file = (function figwheel$client$file_reloading$reload_file(p__83336,callback){
var map__83337 = p__83336;
var map__83337__$1 = (((((!((map__83337 == null))))?(((((map__83337.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__83337.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__83337):map__83337);
var file_msg = map__83337__$1;
var request_url = cljs.core.get.call(null,map__83337__$1,new cljs.core.Keyword(null,"request-url","request-url",2100346596));

figwheel.client.utils.debug_prn.call(null,["FigWheel: Attempting to load ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(request_url)].join(''));

return (function (){var or__4131__auto__ = goog.object.get(goog.global,"FIGWHEEL_IMPORT_SCRIPT");
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return figwheel.client.file_reloading.reload_file_STAR_;
}
})().call(null,request_url,((function (map__83337,map__83337__$1,file_msg,request_url){
return (function (success_QMARK_){
if(cljs.core.truth_(success_QMARK_)){
figwheel.client.utils.debug_prn.call(null,["FigWheel: Successfully loaded ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(request_url)].join(''));

return cljs.core.apply.call(null,callback,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.assoc.call(null,file_msg,new cljs.core.Keyword(null,"loaded-file","loaded-file",-168399375),true)], null));
} else {
figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"error","error",-978969032),["Figwheel: Error loading file ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(request_url)].join(''));

return cljs.core.apply.call(null,callback,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [file_msg], null));
}
});})(map__83337,map__83337__$1,file_msg,request_url))
);
});
if((typeof figwheel !== 'undefined') && (typeof figwheel.client !== 'undefined') && (typeof figwheel.client.file_reloading !== 'undefined') && (typeof figwheel.client.file_reloading.reload_chan !== 'undefined')){
} else {
figwheel.client.file_reloading.reload_chan = cljs.core.async.chan.call(null);
}
if((typeof figwheel !== 'undefined') && (typeof figwheel.client !== 'undefined') && (typeof figwheel.client.file_reloading !== 'undefined') && (typeof figwheel.client.file_reloading.on_load_callbacks !== 'undefined')){
} else {
figwheel.client.file_reloading.on_load_callbacks = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
}
if((typeof figwheel !== 'undefined') && (typeof figwheel.client !== 'undefined') && (typeof figwheel.client.file_reloading !== 'undefined') && (typeof figwheel.client.file_reloading.dependencies_loaded !== 'undefined')){
} else {
figwheel.client.file_reloading.dependencies_loaded = cljs.core.atom.call(null,cljs.core.PersistentVector.EMPTY);
}
figwheel.client.file_reloading.blocking_load = (function figwheel$client$file_reloading$blocking_load(url){
var out = cljs.core.async.chan.call(null);
figwheel.client.file_reloading.reload_file.call(null,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"request-url","request-url",2100346596),url], null),((function (out){
return (function (file_msg){
cljs.core.async.put_BANG_.call(null,out,file_msg);

return cljs.core.async.close_BANG_.call(null,out);
});})(out))
);

return out;
});
if((typeof figwheel !== 'undefined') && (typeof figwheel.client !== 'undefined') && (typeof figwheel.client.file_reloading !== 'undefined') && (typeof figwheel.client.file_reloading.reloader_loop !== 'undefined')){
} else {
figwheel.client.file_reloading.reloader_loop = (function (){var c__37079__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__37079__auto__){
return (function (){
var f__37080__auto__ = (function (){var switch__36984__auto__ = ((function (c__37079__auto__){
return (function (state_83375){
var state_val_83376 = (state_83375[(1)]);
if((state_val_83376 === (7))){
var inst_83371 = (state_83375[(2)]);
var state_83375__$1 = state_83375;
var statearr_83377_83403 = state_83375__$1;
(statearr_83377_83403[(2)] = inst_83371);

(statearr_83377_83403[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83376 === (1))){
var state_83375__$1 = state_83375;
var statearr_83378_83404 = state_83375__$1;
(statearr_83378_83404[(2)] = null);

(statearr_83378_83404[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83376 === (4))){
var inst_83341 = (state_83375[(7)]);
var inst_83341__$1 = (state_83375[(2)]);
var state_83375__$1 = (function (){var statearr_83379 = state_83375;
(statearr_83379[(7)] = inst_83341__$1);

return statearr_83379;
})();
if(cljs.core.truth_(inst_83341__$1)){
var statearr_83380_83405 = state_83375__$1;
(statearr_83380_83405[(1)] = (5));

} else {
var statearr_83381_83406 = state_83375__$1;
(statearr_83381_83406[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83376 === (15))){
var inst_83356 = (state_83375[(8)]);
var inst_83354 = (state_83375[(9)]);
var inst_83358 = inst_83356.call(null,inst_83354);
var state_83375__$1 = state_83375;
var statearr_83382_83407 = state_83375__$1;
(statearr_83382_83407[(2)] = inst_83358);

(statearr_83382_83407[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83376 === (13))){
var inst_83365 = (state_83375[(2)]);
var state_83375__$1 = state_83375;
var statearr_83383_83408 = state_83375__$1;
(statearr_83383_83408[(2)] = inst_83365);

(statearr_83383_83408[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83376 === (6))){
var state_83375__$1 = state_83375;
var statearr_83384_83409 = state_83375__$1;
(statearr_83384_83409[(2)] = null);

(statearr_83384_83409[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83376 === (17))){
var inst_83362 = (state_83375[(2)]);
var state_83375__$1 = state_83375;
var statearr_83385_83410 = state_83375__$1;
(statearr_83385_83410[(2)] = inst_83362);

(statearr_83385_83410[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83376 === (3))){
var inst_83373 = (state_83375[(2)]);
var state_83375__$1 = state_83375;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_83375__$1,inst_83373);
} else {
if((state_val_83376 === (12))){
var state_83375__$1 = state_83375;
var statearr_83386_83411 = state_83375__$1;
(statearr_83386_83411[(2)] = null);

(statearr_83386_83411[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83376 === (2))){
var state_83375__$1 = state_83375;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_83375__$1,(4),figwheel.client.file_reloading.reload_chan);
} else {
if((state_val_83376 === (11))){
var inst_83346 = (state_83375[(10)]);
var inst_83352 = figwheel.client.file_reloading.blocking_load.call(null,inst_83346);
var state_83375__$1 = state_83375;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_83375__$1,(14),inst_83352);
} else {
if((state_val_83376 === (9))){
var inst_83346 = (state_83375[(10)]);
var state_83375__$1 = state_83375;
if(cljs.core.truth_(inst_83346)){
var statearr_83387_83412 = state_83375__$1;
(statearr_83387_83412[(1)] = (11));

} else {
var statearr_83388_83413 = state_83375__$1;
(statearr_83388_83413[(1)] = (12));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83376 === (5))){
var inst_83341 = (state_83375[(7)]);
var inst_83347 = (state_83375[(11)]);
var inst_83346 = cljs.core.nth.call(null,inst_83341,(0),null);
var inst_83347__$1 = cljs.core.nth.call(null,inst_83341,(1),null);
var state_83375__$1 = (function (){var statearr_83389 = state_83375;
(statearr_83389[(10)] = inst_83346);

(statearr_83389[(11)] = inst_83347__$1);

return statearr_83389;
})();
if(cljs.core.truth_(inst_83347__$1)){
var statearr_83390_83414 = state_83375__$1;
(statearr_83390_83414[(1)] = (8));

} else {
var statearr_83391_83415 = state_83375__$1;
(statearr_83391_83415[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83376 === (14))){
var inst_83346 = (state_83375[(10)]);
var inst_83356 = (state_83375[(8)]);
var inst_83354 = (state_83375[(2)]);
var inst_83355 = cljs.core.deref.call(null,figwheel.client.file_reloading.on_load_callbacks);
var inst_83356__$1 = cljs.core.get.call(null,inst_83355,inst_83346);
var state_83375__$1 = (function (){var statearr_83392 = state_83375;
(statearr_83392[(8)] = inst_83356__$1);

(statearr_83392[(9)] = inst_83354);

return statearr_83392;
})();
if(cljs.core.truth_(inst_83356__$1)){
var statearr_83393_83416 = state_83375__$1;
(statearr_83393_83416[(1)] = (15));

} else {
var statearr_83394_83417 = state_83375__$1;
(statearr_83394_83417[(1)] = (16));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83376 === (16))){
var inst_83354 = (state_83375[(9)]);
var inst_83360 = cljs.core.swap_BANG_.call(null,figwheel.client.file_reloading.dependencies_loaded,cljs.core.conj,inst_83354);
var state_83375__$1 = state_83375;
var statearr_83395_83418 = state_83375__$1;
(statearr_83395_83418[(2)] = inst_83360);

(statearr_83395_83418[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83376 === (10))){
var inst_83367 = (state_83375[(2)]);
var state_83375__$1 = (function (){var statearr_83396 = state_83375;
(statearr_83396[(12)] = inst_83367);

return statearr_83396;
})();
var statearr_83397_83419 = state_83375__$1;
(statearr_83397_83419[(2)] = null);

(statearr_83397_83419[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83376 === (8))){
var inst_83347 = (state_83375[(11)]);
var inst_83349 = eval(inst_83347);
var state_83375__$1 = state_83375;
var statearr_83398_83420 = state_83375__$1;
(statearr_83398_83420[(2)] = inst_83349);

(statearr_83398_83420[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__37079__auto__))
;
return ((function (switch__36984__auto__,c__37079__auto__){
return (function() {
var figwheel$client$file_reloading$state_machine__36985__auto__ = null;
var figwheel$client$file_reloading$state_machine__36985__auto____0 = (function (){
var statearr_83399 = [null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_83399[(0)] = figwheel$client$file_reloading$state_machine__36985__auto__);

(statearr_83399[(1)] = (1));

return statearr_83399;
});
var figwheel$client$file_reloading$state_machine__36985__auto____1 = (function (state_83375){
while(true){
var ret_value__36986__auto__ = (function (){try{while(true){
var result__36987__auto__ = switch__36984__auto__.call(null,state_83375);
if(cljs.core.keyword_identical_QMARK_.call(null,result__36987__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__36987__auto__;
}
break;
}
}catch (e83400){if((e83400 instanceof Object)){
var ex__36988__auto__ = e83400;
var statearr_83401_83421 = state_83375;
(statearr_83401_83421[(5)] = ex__36988__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_83375);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e83400;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__36986__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__83422 = state_83375;
state_83375 = G__83422;
continue;
} else {
return ret_value__36986__auto__;
}
break;
}
});
figwheel$client$file_reloading$state_machine__36985__auto__ = function(state_83375){
switch(arguments.length){
case 0:
return figwheel$client$file_reloading$state_machine__36985__auto____0.call(this);
case 1:
return figwheel$client$file_reloading$state_machine__36985__auto____1.call(this,state_83375);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
figwheel$client$file_reloading$state_machine__36985__auto__.cljs$core$IFn$_invoke$arity$0 = figwheel$client$file_reloading$state_machine__36985__auto____0;
figwheel$client$file_reloading$state_machine__36985__auto__.cljs$core$IFn$_invoke$arity$1 = figwheel$client$file_reloading$state_machine__36985__auto____1;
return figwheel$client$file_reloading$state_machine__36985__auto__;
})()
;})(switch__36984__auto__,c__37079__auto__))
})();
var state__37081__auto__ = (function (){var statearr_83402 = f__37080__auto__.call(null);
(statearr_83402[(6)] = c__37079__auto__);

return statearr_83402;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__37081__auto__);
});})(c__37079__auto__))
);

return c__37079__auto__;
})();
}
figwheel.client.file_reloading.queued_file_reload = (function figwheel$client$file_reloading$queued_file_reload(var_args){
var G__83424 = arguments.length;
switch (G__83424) {
case 1:
return figwheel.client.file_reloading.queued_file_reload.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return figwheel.client.file_reloading.queued_file_reload.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

figwheel.client.file_reloading.queued_file_reload.cljs$core$IFn$_invoke$arity$1 = (function (url){
return figwheel.client.file_reloading.queued_file_reload.call(null,url,null);
});

figwheel.client.file_reloading.queued_file_reload.cljs$core$IFn$_invoke$arity$2 = (function (url,opt_source_text){
return cljs.core.async.put_BANG_.call(null,figwheel.client.file_reloading.reload_chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [url,opt_source_text], null));
});

figwheel.client.file_reloading.queued_file_reload.cljs$lang$maxFixedArity = 2;

figwheel.client.file_reloading.require_with_callback = (function figwheel$client$file_reloading$require_with_callback(p__83426,callback){
var map__83427 = p__83426;
var map__83427__$1 = (((((!((map__83427 == null))))?(((((map__83427.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__83427.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__83427):map__83427);
var file_msg = map__83427__$1;
var namespace = cljs.core.get.call(null,map__83427__$1,new cljs.core.Keyword(null,"namespace","namespace",-377510372));
var request_url = figwheel.client.file_reloading.resolve_ns.call(null,namespace);
cljs.core.swap_BANG_.call(null,figwheel.client.file_reloading.on_load_callbacks,cljs.core.assoc,request_url,((function (request_url,map__83427,map__83427__$1,file_msg,namespace){
return (function (file_msg_SINGLEQUOTE_){
cljs.core.swap_BANG_.call(null,figwheel.client.file_reloading.on_load_callbacks,cljs.core.dissoc,request_url);

return cljs.core.apply.call(null,callback,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.merge.call(null,file_msg,cljs.core.select_keys.call(null,file_msg_SINGLEQUOTE_,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"loaded-file","loaded-file",-168399375)], null)))], null));
});})(request_url,map__83427,map__83427__$1,file_msg,namespace))
);

return figwheel.client.file_reloading.figwheel_require.call(null,cljs.core.name.call(null,namespace),true);
});
figwheel.client.file_reloading.figwheel_no_load_QMARK_ = (function figwheel$client$file_reloading$figwheel_no_load_QMARK_(p__83429){
var map__83430 = p__83429;
var map__83430__$1 = (((((!((map__83430 == null))))?(((((map__83430.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__83430.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__83430):map__83430);
var file_msg = map__83430__$1;
var namespace = cljs.core.get.call(null,map__83430__$1,new cljs.core.Keyword(null,"namespace","namespace",-377510372));
var meta_pragmas = cljs.core.get.call(null,cljs.core.deref.call(null,figwheel.client.file_reloading.figwheel_meta_pragmas),cljs.core.name.call(null,namespace));
return new cljs.core.Keyword(null,"figwheel-no-load","figwheel-no-load",-555840179).cljs$core$IFn$_invoke$arity$1(meta_pragmas);
});
figwheel.client.file_reloading.ns_exists_QMARK_ = (function figwheel$client$file_reloading$ns_exists_QMARK_(namespace){
return (!((cljs.core.reduce.call(null,cljs.core.fnil.call(null,goog.object.get,({})),goog.global,clojure.string.split.call(null,cljs.core.name.call(null,namespace),".")) == null)));
});
figwheel.client.file_reloading.reload_file_QMARK_ = (function figwheel$client$file_reloading$reload_file_QMARK_(p__83432){
var map__83433 = p__83432;
var map__83433__$1 = (((((!((map__83433 == null))))?(((((map__83433.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__83433.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__83433):map__83433);
var file_msg = map__83433__$1;
var namespace = cljs.core.get.call(null,map__83433__$1,new cljs.core.Keyword(null,"namespace","namespace",-377510372));

var meta_pragmas = cljs.core.get.call(null,cljs.core.deref.call(null,figwheel.client.file_reloading.figwheel_meta_pragmas),cljs.core.name.call(null,namespace));
var and__4120__auto__ = cljs.core.not.call(null,figwheel.client.file_reloading.figwheel_no_load_QMARK_.call(null,file_msg));
if(and__4120__auto__){
var or__4131__auto__ = new cljs.core.Keyword(null,"figwheel-always","figwheel-always",799819691).cljs$core$IFn$_invoke$arity$1(meta_pragmas);
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
var or__4131__auto____$1 = new cljs.core.Keyword(null,"figwheel-load","figwheel-load",1316089175).cljs$core$IFn$_invoke$arity$1(meta_pragmas);
if(cljs.core.truth_(or__4131__auto____$1)){
return or__4131__auto____$1;
} else {
var or__4131__auto____$2 = figwheel.client.file_reloading.provided_QMARK_.call(null,cljs.core.name.call(null,namespace));
if(cljs.core.truth_(or__4131__auto____$2)){
return or__4131__auto____$2;
} else {
return figwheel.client.file_reloading.ns_exists_QMARK_.call(null,namespace);
}
}
}
} else {
return and__4120__auto__;
}
});
figwheel.client.file_reloading.js_reload = (function figwheel$client$file_reloading$js_reload(p__83435,callback){
var map__83436 = p__83435;
var map__83436__$1 = (((((!((map__83436 == null))))?(((((map__83436.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__83436.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__83436):map__83436);
var file_msg = map__83436__$1;
var request_url = cljs.core.get.call(null,map__83436__$1,new cljs.core.Keyword(null,"request-url","request-url",2100346596));
var namespace = cljs.core.get.call(null,map__83436__$1,new cljs.core.Keyword(null,"namespace","namespace",-377510372));

if(cljs.core.truth_(figwheel.client.file_reloading.reload_file_QMARK_.call(null,file_msg))){
return figwheel.client.file_reloading.require_with_callback.call(null,file_msg,callback);
} else {
figwheel.client.utils.debug_prn.call(null,["Figwheel: Not trying to load file ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(request_url)].join(''));

return cljs.core.apply.call(null,callback,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [file_msg], null));
}
});
figwheel.client.file_reloading.reload_js_file = (function figwheel$client$file_reloading$reload_js_file(file_msg){
var out = cljs.core.async.chan.call(null);
figwheel.client.file_reloading.js_reload.call(null,file_msg,((function (out){
return (function (url){
cljs.core.async.put_BANG_.call(null,out,url);

return cljs.core.async.close_BANG_.call(null,out);
});})(out))
);

return out;
});
/**
 * Returns a chanel with one collection of loaded filenames on it.
 */
figwheel.client.file_reloading.load_all_js_files = (function figwheel$client$file_reloading$load_all_js_files(files){
var out = cljs.core.async.chan.call(null);
var c__37079__auto___83486 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__37079__auto___83486,out){
return (function (){
var f__37080__auto__ = (function (){var switch__36984__auto__ = ((function (c__37079__auto___83486,out){
return (function (state_83471){
var state_val_83472 = (state_83471[(1)]);
if((state_val_83472 === (1))){
var inst_83445 = cljs.core.seq.call(null,files);
var inst_83446 = cljs.core.first.call(null,inst_83445);
var inst_83447 = cljs.core.next.call(null,inst_83445);
var inst_83448 = files;
var state_83471__$1 = (function (){var statearr_83473 = state_83471;
(statearr_83473[(7)] = inst_83446);

(statearr_83473[(8)] = inst_83448);

(statearr_83473[(9)] = inst_83447);

return statearr_83473;
})();
var statearr_83474_83487 = state_83471__$1;
(statearr_83474_83487[(2)] = null);

(statearr_83474_83487[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83472 === (2))){
var inst_83454 = (state_83471[(10)]);
var inst_83448 = (state_83471[(8)]);
var inst_83453 = cljs.core.seq.call(null,inst_83448);
var inst_83454__$1 = cljs.core.first.call(null,inst_83453);
var inst_83455 = cljs.core.next.call(null,inst_83453);
var inst_83456 = (inst_83454__$1 == null);
var inst_83457 = cljs.core.not.call(null,inst_83456);
var state_83471__$1 = (function (){var statearr_83475 = state_83471;
(statearr_83475[(11)] = inst_83455);

(statearr_83475[(10)] = inst_83454__$1);

return statearr_83475;
})();
if(inst_83457){
var statearr_83476_83488 = state_83471__$1;
(statearr_83476_83488[(1)] = (4));

} else {
var statearr_83477_83489 = state_83471__$1;
(statearr_83477_83489[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83472 === (3))){
var inst_83469 = (state_83471[(2)]);
var state_83471__$1 = state_83471;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_83471__$1,inst_83469);
} else {
if((state_val_83472 === (4))){
var inst_83454 = (state_83471[(10)]);
var inst_83459 = figwheel.client.file_reloading.reload_js_file.call(null,inst_83454);
var state_83471__$1 = state_83471;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_83471__$1,(7),inst_83459);
} else {
if((state_val_83472 === (5))){
var inst_83465 = cljs.core.async.close_BANG_.call(null,out);
var state_83471__$1 = state_83471;
var statearr_83478_83490 = state_83471__$1;
(statearr_83478_83490[(2)] = inst_83465);

(statearr_83478_83490[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83472 === (6))){
var inst_83467 = (state_83471[(2)]);
var state_83471__$1 = state_83471;
var statearr_83479_83491 = state_83471__$1;
(statearr_83479_83491[(2)] = inst_83467);

(statearr_83479_83491[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83472 === (7))){
var inst_83455 = (state_83471[(11)]);
var inst_83461 = (state_83471[(2)]);
var inst_83462 = cljs.core.async.put_BANG_.call(null,out,inst_83461);
var inst_83448 = inst_83455;
var state_83471__$1 = (function (){var statearr_83480 = state_83471;
(statearr_83480[(8)] = inst_83448);

(statearr_83480[(12)] = inst_83462);

return statearr_83480;
})();
var statearr_83481_83492 = state_83471__$1;
(statearr_83481_83492[(2)] = null);

(statearr_83481_83492[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
});})(c__37079__auto___83486,out))
;
return ((function (switch__36984__auto__,c__37079__auto___83486,out){
return (function() {
var figwheel$client$file_reloading$load_all_js_files_$_state_machine__36985__auto__ = null;
var figwheel$client$file_reloading$load_all_js_files_$_state_machine__36985__auto____0 = (function (){
var statearr_83482 = [null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_83482[(0)] = figwheel$client$file_reloading$load_all_js_files_$_state_machine__36985__auto__);

(statearr_83482[(1)] = (1));

return statearr_83482;
});
var figwheel$client$file_reloading$load_all_js_files_$_state_machine__36985__auto____1 = (function (state_83471){
while(true){
var ret_value__36986__auto__ = (function (){try{while(true){
var result__36987__auto__ = switch__36984__auto__.call(null,state_83471);
if(cljs.core.keyword_identical_QMARK_.call(null,result__36987__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__36987__auto__;
}
break;
}
}catch (e83483){if((e83483 instanceof Object)){
var ex__36988__auto__ = e83483;
var statearr_83484_83493 = state_83471;
(statearr_83484_83493[(5)] = ex__36988__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_83471);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e83483;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__36986__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__83494 = state_83471;
state_83471 = G__83494;
continue;
} else {
return ret_value__36986__auto__;
}
break;
}
});
figwheel$client$file_reloading$load_all_js_files_$_state_machine__36985__auto__ = function(state_83471){
switch(arguments.length){
case 0:
return figwheel$client$file_reloading$load_all_js_files_$_state_machine__36985__auto____0.call(this);
case 1:
return figwheel$client$file_reloading$load_all_js_files_$_state_machine__36985__auto____1.call(this,state_83471);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
figwheel$client$file_reloading$load_all_js_files_$_state_machine__36985__auto__.cljs$core$IFn$_invoke$arity$0 = figwheel$client$file_reloading$load_all_js_files_$_state_machine__36985__auto____0;
figwheel$client$file_reloading$load_all_js_files_$_state_machine__36985__auto__.cljs$core$IFn$_invoke$arity$1 = figwheel$client$file_reloading$load_all_js_files_$_state_machine__36985__auto____1;
return figwheel$client$file_reloading$load_all_js_files_$_state_machine__36985__auto__;
})()
;})(switch__36984__auto__,c__37079__auto___83486,out))
})();
var state__37081__auto__ = (function (){var statearr_83485 = f__37080__auto__.call(null);
(statearr_83485[(6)] = c__37079__auto___83486);

return statearr_83485;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__37081__auto__);
});})(c__37079__auto___83486,out))
);


return cljs.core.async.into.call(null,cljs.core.PersistentVector.EMPTY,out);
});
figwheel.client.file_reloading.eval_body = (function figwheel$client$file_reloading$eval_body(p__83495,opts){
var map__83496 = p__83495;
var map__83496__$1 = (((((!((map__83496 == null))))?(((((map__83496.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__83496.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__83496):map__83496);
var eval_body = cljs.core.get.call(null,map__83496__$1,new cljs.core.Keyword(null,"eval-body","eval-body",-907279883));
var file = cljs.core.get.call(null,map__83496__$1,new cljs.core.Keyword(null,"file","file",-1269645878));
if(cljs.core.truth_((function (){var and__4120__auto__ = eval_body;
if(cljs.core.truth_(and__4120__auto__)){
return typeof eval_body === 'string';
} else {
return and__4120__auto__;
}
})())){
var code = eval_body;
try{figwheel.client.utils.debug_prn.call(null,["Evaling file ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(file)].join(''));

return figwheel.client.utils.eval_helper.call(null,code,opts);
}catch (e83498){var e = e83498;
return figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"error","error",-978969032),["Unable to evaluate ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(file)].join(''));
}} else {
return null;
}
});
figwheel.client.file_reloading.expand_files = (function figwheel$client$file_reloading$expand_files(files){
var deps = figwheel.client.file_reloading.get_all_dependents.call(null,cljs.core.map.call(null,new cljs.core.Keyword(null,"namespace","namespace",-377510372),files));
return cljs.core.filter.call(null,cljs.core.comp.call(null,cljs.core.not,cljs.core.partial.call(null,cljs.core.re_matches,/figwheel\.connect.*/),new cljs.core.Keyword(null,"namespace","namespace",-377510372)),cljs.core.map.call(null,((function (deps){
return (function (n){
var temp__5733__auto__ = cljs.core.first.call(null,cljs.core.filter.call(null,((function (deps){
return (function (p1__83499_SHARP_){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"namespace","namespace",-377510372).cljs$core$IFn$_invoke$arity$1(p1__83499_SHARP_),n);
});})(deps))
,files));
if(cljs.core.truth_(temp__5733__auto__)){
var file_msg = temp__5733__auto__;
return file_msg;
} else {
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"namespace","namespace",-377510372),new cljs.core.Keyword(null,"namespace","namespace",-377510372),n], null);
}
});})(deps))
,deps));
});
figwheel.client.file_reloading.sort_files = (function figwheel$client$file_reloading$sort_files(files){
if((cljs.core.count.call(null,files) <= (1))){
return files;
} else {
var keep_files = cljs.core.set.call(null,cljs.core.keep.call(null,new cljs.core.Keyword(null,"namespace","namespace",-377510372),files));
return cljs.core.filter.call(null,cljs.core.comp.call(null,keep_files,new cljs.core.Keyword(null,"namespace","namespace",-377510372)),figwheel.client.file_reloading.expand_files.call(null,files));
}
});
figwheel.client.file_reloading.get_figwheel_always = (function figwheel$client$file_reloading$get_figwheel_always(){
return cljs.core.map.call(null,(function (p__83500){
var vec__83501 = p__83500;
var k = cljs.core.nth.call(null,vec__83501,(0),null);
var v = cljs.core.nth.call(null,vec__83501,(1),null);
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"namespace","namespace",-377510372),k,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"namespace","namespace",-377510372)], null);
}),cljs.core.filter.call(null,(function (p__83504){
var vec__83505 = p__83504;
var k = cljs.core.nth.call(null,vec__83505,(0),null);
var v = cljs.core.nth.call(null,vec__83505,(1),null);
return new cljs.core.Keyword(null,"figwheel-always","figwheel-always",799819691).cljs$core$IFn$_invoke$arity$1(v);
}),cljs.core.deref.call(null,figwheel.client.file_reloading.figwheel_meta_pragmas)));
});
figwheel.client.file_reloading.reload_js_files = (function figwheel$client$file_reloading$reload_js_files(p__83511,p__83512){
var map__83513 = p__83511;
var map__83513__$1 = (((((!((map__83513 == null))))?(((((map__83513.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__83513.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__83513):map__83513);
var opts = map__83513__$1;
var before_jsload = cljs.core.get.call(null,map__83513__$1,new cljs.core.Keyword(null,"before-jsload","before-jsload",-847513128));
var on_jsload = cljs.core.get.call(null,map__83513__$1,new cljs.core.Keyword(null,"on-jsload","on-jsload",-395756602));
var reload_dependents = cljs.core.get.call(null,map__83513__$1,new cljs.core.Keyword(null,"reload-dependents","reload-dependents",-956865430));
var map__83514 = p__83512;
var map__83514__$1 = (((((!((map__83514 == null))))?(((((map__83514.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__83514.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__83514):map__83514);
var msg = map__83514__$1;
var files = cljs.core.get.call(null,map__83514__$1,new cljs.core.Keyword(null,"files","files",-472457450));
var figwheel_meta = cljs.core.get.call(null,map__83514__$1,new cljs.core.Keyword(null,"figwheel-meta","figwheel-meta",-225970237));
var recompile_dependents = cljs.core.get.call(null,map__83514__$1,new cljs.core.Keyword(null,"recompile-dependents","recompile-dependents",523804171));
if(cljs.core.empty_QMARK_.call(null,figwheel_meta)){
} else {
cljs.core.reset_BANG_.call(null,figwheel.client.file_reloading.figwheel_meta_pragmas,figwheel_meta);
}

var c__37079__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (){
var f__37080__auto__ = (function (){var switch__36984__auto__ = ((function (c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (state_83668){
var state_val_83669 = (state_83668[(1)]);
if((state_val_83669 === (7))){
var inst_83531 = (state_83668[(7)]);
var inst_83529 = (state_83668[(8)]);
var inst_83528 = (state_83668[(9)]);
var inst_83530 = (state_83668[(10)]);
var inst_83536 = cljs.core._nth.call(null,inst_83529,inst_83531);
var inst_83537 = figwheel.client.file_reloading.eval_body.call(null,inst_83536,opts);
var inst_83538 = (inst_83531 + (1));
var tmp83670 = inst_83529;
var tmp83671 = inst_83528;
var tmp83672 = inst_83530;
var inst_83528__$1 = tmp83671;
var inst_83529__$1 = tmp83670;
var inst_83530__$1 = tmp83672;
var inst_83531__$1 = inst_83538;
var state_83668__$1 = (function (){var statearr_83673 = state_83668;
(statearr_83673[(7)] = inst_83531__$1);

(statearr_83673[(8)] = inst_83529__$1);

(statearr_83673[(9)] = inst_83528__$1);

(statearr_83673[(11)] = inst_83537);

(statearr_83673[(10)] = inst_83530__$1);

return statearr_83673;
})();
var statearr_83674_83757 = state_83668__$1;
(statearr_83674_83757[(2)] = null);

(statearr_83674_83757[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (20))){
var inst_83571 = (state_83668[(12)]);
var inst_83579 = figwheel.client.file_reloading.sort_files.call(null,inst_83571);
var state_83668__$1 = state_83668;
var statearr_83675_83758 = state_83668__$1;
(statearr_83675_83758[(2)] = inst_83579);

(statearr_83675_83758[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (27))){
var state_83668__$1 = state_83668;
var statearr_83676_83759 = state_83668__$1;
(statearr_83676_83759[(2)] = null);

(statearr_83676_83759[(1)] = (28));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (1))){
var inst_83520 = (state_83668[(13)]);
var inst_83517 = before_jsload.call(null,files);
var inst_83518 = figwheel.client.file_reloading.before_jsload_custom_event.call(null,files);
var inst_83519 = (function (){return ((function (inst_83520,inst_83517,inst_83518,state_val_83669,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (p1__83508_SHARP_){
return new cljs.core.Keyword(null,"eval-body","eval-body",-907279883).cljs$core$IFn$_invoke$arity$1(p1__83508_SHARP_);
});
;})(inst_83520,inst_83517,inst_83518,state_val_83669,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var inst_83520__$1 = cljs.core.filter.call(null,inst_83519,files);
var inst_83521 = cljs.core.not_empty.call(null,inst_83520__$1);
var state_83668__$1 = (function (){var statearr_83677 = state_83668;
(statearr_83677[(14)] = inst_83518);

(statearr_83677[(15)] = inst_83517);

(statearr_83677[(13)] = inst_83520__$1);

return statearr_83677;
})();
if(cljs.core.truth_(inst_83521)){
var statearr_83678_83760 = state_83668__$1;
(statearr_83678_83760[(1)] = (2));

} else {
var statearr_83679_83761 = state_83668__$1;
(statearr_83679_83761[(1)] = (3));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (24))){
var state_83668__$1 = state_83668;
var statearr_83680_83762 = state_83668__$1;
(statearr_83680_83762[(2)] = null);

(statearr_83680_83762[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (39))){
var inst_83621 = (state_83668[(16)]);
var state_83668__$1 = state_83668;
var statearr_83681_83763 = state_83668__$1;
(statearr_83681_83763[(2)] = inst_83621);

(statearr_83681_83763[(1)] = (40));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (46))){
var inst_83663 = (state_83668[(2)]);
var state_83668__$1 = state_83668;
var statearr_83682_83764 = state_83668__$1;
(statearr_83682_83764[(2)] = inst_83663);

(statearr_83682_83764[(1)] = (31));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (4))){
var inst_83565 = (state_83668[(2)]);
var inst_83566 = cljs.core.List.EMPTY;
var inst_83567 = cljs.core.reset_BANG_.call(null,figwheel.client.file_reloading.dependencies_loaded,inst_83566);
var inst_83568 = (function (){return ((function (inst_83565,inst_83566,inst_83567,state_val_83669,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (p1__83509_SHARP_){
var and__4120__auto__ = new cljs.core.Keyword(null,"namespace","namespace",-377510372).cljs$core$IFn$_invoke$arity$1(p1__83509_SHARP_);
if(cljs.core.truth_(and__4120__auto__)){
return ((cljs.core.not.call(null,new cljs.core.Keyword(null,"eval-body","eval-body",-907279883).cljs$core$IFn$_invoke$arity$1(p1__83509_SHARP_))) && (cljs.core.not.call(null,figwheel.client.file_reloading.figwheel_no_load_QMARK_.call(null,p1__83509_SHARP_))));
} else {
return and__4120__auto__;
}
});
;})(inst_83565,inst_83566,inst_83567,state_val_83669,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var inst_83569 = cljs.core.filter.call(null,inst_83568,files);
var inst_83570 = figwheel.client.file_reloading.get_figwheel_always.call(null);
var inst_83571 = cljs.core.concat.call(null,inst_83569,inst_83570);
var state_83668__$1 = (function (){var statearr_83683 = state_83668;
(statearr_83683[(12)] = inst_83571);

(statearr_83683[(17)] = inst_83567);

(statearr_83683[(18)] = inst_83565);

return statearr_83683;
})();
if(cljs.core.truth_(reload_dependents)){
var statearr_83684_83765 = state_83668__$1;
(statearr_83684_83765[(1)] = (16));

} else {
var statearr_83685_83766 = state_83668__$1;
(statearr_83685_83766[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (15))){
var inst_83555 = (state_83668[(2)]);
var state_83668__$1 = state_83668;
var statearr_83686_83767 = state_83668__$1;
(statearr_83686_83767[(2)] = inst_83555);

(statearr_83686_83767[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (21))){
var inst_83581 = (state_83668[(19)]);
var inst_83581__$1 = (state_83668[(2)]);
var inst_83582 = figwheel.client.file_reloading.load_all_js_files.call(null,inst_83581__$1);
var state_83668__$1 = (function (){var statearr_83687 = state_83668;
(statearr_83687[(19)] = inst_83581__$1);

return statearr_83687;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_83668__$1,(22),inst_83582);
} else {
if((state_val_83669 === (31))){
var inst_83666 = (state_83668[(2)]);
var state_83668__$1 = state_83668;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_83668__$1,inst_83666);
} else {
if((state_val_83669 === (32))){
var inst_83621 = (state_83668[(16)]);
var inst_83626 = inst_83621.cljs$lang$protocol_mask$partition0$;
var inst_83627 = (inst_83626 & (64));
var inst_83628 = inst_83621.cljs$core$ISeq$;
var inst_83629 = (cljs.core.PROTOCOL_SENTINEL === inst_83628);
var inst_83630 = ((inst_83627) || (inst_83629));
var state_83668__$1 = state_83668;
if(cljs.core.truth_(inst_83630)){
var statearr_83688_83768 = state_83668__$1;
(statearr_83688_83768[(1)] = (35));

} else {
var statearr_83689_83769 = state_83668__$1;
(statearr_83689_83769[(1)] = (36));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (40))){
var inst_83643 = (state_83668[(20)]);
var inst_83642 = (state_83668[(2)]);
var inst_83643__$1 = cljs.core.get.call(null,inst_83642,new cljs.core.Keyword(null,"figwheel-no-load","figwheel-no-load",-555840179));
var inst_83644 = cljs.core.get.call(null,inst_83642,new cljs.core.Keyword(null,"not-required","not-required",-950359114));
var inst_83645 = cljs.core.not_empty.call(null,inst_83643__$1);
var state_83668__$1 = (function (){var statearr_83690 = state_83668;
(statearr_83690[(20)] = inst_83643__$1);

(statearr_83690[(21)] = inst_83644);

return statearr_83690;
})();
if(cljs.core.truth_(inst_83645)){
var statearr_83691_83770 = state_83668__$1;
(statearr_83691_83770[(1)] = (41));

} else {
var statearr_83692_83771 = state_83668__$1;
(statearr_83692_83771[(1)] = (42));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (33))){
var state_83668__$1 = state_83668;
var statearr_83693_83772 = state_83668__$1;
(statearr_83693_83772[(2)] = false);

(statearr_83693_83772[(1)] = (34));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (13))){
var inst_83541 = (state_83668[(22)]);
var inst_83545 = cljs.core.chunk_first.call(null,inst_83541);
var inst_83546 = cljs.core.chunk_rest.call(null,inst_83541);
var inst_83547 = cljs.core.count.call(null,inst_83545);
var inst_83528 = inst_83546;
var inst_83529 = inst_83545;
var inst_83530 = inst_83547;
var inst_83531 = (0);
var state_83668__$1 = (function (){var statearr_83694 = state_83668;
(statearr_83694[(7)] = inst_83531);

(statearr_83694[(8)] = inst_83529);

(statearr_83694[(9)] = inst_83528);

(statearr_83694[(10)] = inst_83530);

return statearr_83694;
})();
var statearr_83695_83773 = state_83668__$1;
(statearr_83695_83773[(2)] = null);

(statearr_83695_83773[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (22))){
var inst_83589 = (state_83668[(23)]);
var inst_83581 = (state_83668[(19)]);
var inst_83585 = (state_83668[(24)]);
var inst_83584 = (state_83668[(25)]);
var inst_83584__$1 = (state_83668[(2)]);
var inst_83585__$1 = cljs.core.filter.call(null,new cljs.core.Keyword(null,"loaded-file","loaded-file",-168399375),inst_83584__$1);
var inst_83586 = (function (){var all_files = inst_83581;
var res_SINGLEQUOTE_ = inst_83584__$1;
var res = inst_83585__$1;
return ((function (all_files,res_SINGLEQUOTE_,res,inst_83589,inst_83581,inst_83585,inst_83584,inst_83584__$1,inst_83585__$1,state_val_83669,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (p1__83510_SHARP_){
return cljs.core.not.call(null,new cljs.core.Keyword(null,"loaded-file","loaded-file",-168399375).cljs$core$IFn$_invoke$arity$1(p1__83510_SHARP_));
});
;})(all_files,res_SINGLEQUOTE_,res,inst_83589,inst_83581,inst_83585,inst_83584,inst_83584__$1,inst_83585__$1,state_val_83669,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var inst_83587 = cljs.core.filter.call(null,inst_83586,inst_83584__$1);
var inst_83588 = cljs.core.deref.call(null,figwheel.client.file_reloading.dependencies_loaded);
var inst_83589__$1 = cljs.core.filter.call(null,new cljs.core.Keyword(null,"loaded-file","loaded-file",-168399375),inst_83588);
var inst_83590 = cljs.core.not_empty.call(null,inst_83589__$1);
var state_83668__$1 = (function (){var statearr_83696 = state_83668;
(statearr_83696[(23)] = inst_83589__$1);

(statearr_83696[(26)] = inst_83587);

(statearr_83696[(24)] = inst_83585__$1);

(statearr_83696[(25)] = inst_83584__$1);

return statearr_83696;
})();
if(cljs.core.truth_(inst_83590)){
var statearr_83697_83774 = state_83668__$1;
(statearr_83697_83774[(1)] = (23));

} else {
var statearr_83698_83775 = state_83668__$1;
(statearr_83698_83775[(1)] = (24));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (36))){
var state_83668__$1 = state_83668;
var statearr_83699_83776 = state_83668__$1;
(statearr_83699_83776[(2)] = false);

(statearr_83699_83776[(1)] = (37));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (41))){
var inst_83643 = (state_83668[(20)]);
var inst_83647 = cljs.core.comp.call(null,figwheel.client.file_reloading.name__GT_path,new cljs.core.Keyword(null,"namespace","namespace",-377510372));
var inst_83648 = cljs.core.map.call(null,inst_83647,inst_83643);
var inst_83649 = cljs.core.pr_str.call(null,inst_83648);
var inst_83650 = ["figwheel-no-load meta-data: ",inst_83649].join('');
var inst_83651 = figwheel.client.utils.log.call(null,inst_83650);
var state_83668__$1 = state_83668;
var statearr_83700_83777 = state_83668__$1;
(statearr_83700_83777[(2)] = inst_83651);

(statearr_83700_83777[(1)] = (43));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (43))){
var inst_83644 = (state_83668[(21)]);
var inst_83654 = (state_83668[(2)]);
var inst_83655 = cljs.core.not_empty.call(null,inst_83644);
var state_83668__$1 = (function (){var statearr_83701 = state_83668;
(statearr_83701[(27)] = inst_83654);

return statearr_83701;
})();
if(cljs.core.truth_(inst_83655)){
var statearr_83702_83778 = state_83668__$1;
(statearr_83702_83778[(1)] = (44));

} else {
var statearr_83703_83779 = state_83668__$1;
(statearr_83703_83779[(1)] = (45));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (29))){
var inst_83589 = (state_83668[(23)]);
var inst_83587 = (state_83668[(26)]);
var inst_83581 = (state_83668[(19)]);
var inst_83585 = (state_83668[(24)]);
var inst_83584 = (state_83668[(25)]);
var inst_83621 = (state_83668[(16)]);
var inst_83617 = figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"debug","debug",-1608172596),"Figwheel: NOT loading these files ");
var inst_83620 = (function (){var all_files = inst_83581;
var res_SINGLEQUOTE_ = inst_83584;
var res = inst_83585;
var files_not_loaded = inst_83587;
var dependencies_that_loaded = inst_83589;
return ((function (all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_83589,inst_83587,inst_83581,inst_83585,inst_83584,inst_83621,inst_83617,state_val_83669,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (p__83619){
var map__83704 = p__83619;
var map__83704__$1 = (((((!((map__83704 == null))))?(((((map__83704.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__83704.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__83704):map__83704);
var namespace = cljs.core.get.call(null,map__83704__$1,new cljs.core.Keyword(null,"namespace","namespace",-377510372));
var meta_data = cljs.core.get.call(null,cljs.core.deref.call(null,figwheel.client.file_reloading.figwheel_meta_pragmas),cljs.core.name.call(null,namespace));
if((meta_data == null)){
return new cljs.core.Keyword(null,"not-required","not-required",-950359114);
} else {
if(cljs.core.truth_(meta_data.call(null,new cljs.core.Keyword(null,"figwheel-no-load","figwheel-no-load",-555840179)))){
return new cljs.core.Keyword(null,"figwheel-no-load","figwheel-no-load",-555840179);
} else {
return new cljs.core.Keyword(null,"not-required","not-required",-950359114);

}
}
});
;})(all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_83589,inst_83587,inst_83581,inst_83585,inst_83584,inst_83621,inst_83617,state_val_83669,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var inst_83621__$1 = cljs.core.group_by.call(null,inst_83620,inst_83587);
var inst_83623 = (inst_83621__$1 == null);
var inst_83624 = cljs.core.not.call(null,inst_83623);
var state_83668__$1 = (function (){var statearr_83706 = state_83668;
(statearr_83706[(16)] = inst_83621__$1);

(statearr_83706[(28)] = inst_83617);

return statearr_83706;
})();
if(inst_83624){
var statearr_83707_83780 = state_83668__$1;
(statearr_83707_83780[(1)] = (32));

} else {
var statearr_83708_83781 = state_83668__$1;
(statearr_83708_83781[(1)] = (33));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (44))){
var inst_83644 = (state_83668[(21)]);
var inst_83657 = cljs.core.map.call(null,new cljs.core.Keyword(null,"file","file",-1269645878),inst_83644);
var inst_83658 = cljs.core.pr_str.call(null,inst_83657);
var inst_83659 = ["not required: ",inst_83658].join('');
var inst_83660 = figwheel.client.utils.log.call(null,inst_83659);
var state_83668__$1 = state_83668;
var statearr_83709_83782 = state_83668__$1;
(statearr_83709_83782[(2)] = inst_83660);

(statearr_83709_83782[(1)] = (46));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (6))){
var inst_83562 = (state_83668[(2)]);
var state_83668__$1 = state_83668;
var statearr_83710_83783 = state_83668__$1;
(statearr_83710_83783[(2)] = inst_83562);

(statearr_83710_83783[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (28))){
var inst_83587 = (state_83668[(26)]);
var inst_83614 = (state_83668[(2)]);
var inst_83615 = cljs.core.not_empty.call(null,inst_83587);
var state_83668__$1 = (function (){var statearr_83711 = state_83668;
(statearr_83711[(29)] = inst_83614);

return statearr_83711;
})();
if(cljs.core.truth_(inst_83615)){
var statearr_83712_83784 = state_83668__$1;
(statearr_83712_83784[(1)] = (29));

} else {
var statearr_83713_83785 = state_83668__$1;
(statearr_83713_83785[(1)] = (30));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (25))){
var inst_83585 = (state_83668[(24)]);
var inst_83601 = (state_83668[(2)]);
var inst_83602 = cljs.core.not_empty.call(null,inst_83585);
var state_83668__$1 = (function (){var statearr_83714 = state_83668;
(statearr_83714[(30)] = inst_83601);

return statearr_83714;
})();
if(cljs.core.truth_(inst_83602)){
var statearr_83715_83786 = state_83668__$1;
(statearr_83715_83786[(1)] = (26));

} else {
var statearr_83716_83787 = state_83668__$1;
(statearr_83716_83787[(1)] = (27));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (34))){
var inst_83637 = (state_83668[(2)]);
var state_83668__$1 = state_83668;
if(cljs.core.truth_(inst_83637)){
var statearr_83717_83788 = state_83668__$1;
(statearr_83717_83788[(1)] = (38));

} else {
var statearr_83718_83789 = state_83668__$1;
(statearr_83718_83789[(1)] = (39));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (17))){
var state_83668__$1 = state_83668;
var statearr_83719_83790 = state_83668__$1;
(statearr_83719_83790[(2)] = recompile_dependents);

(statearr_83719_83790[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (3))){
var state_83668__$1 = state_83668;
var statearr_83720_83791 = state_83668__$1;
(statearr_83720_83791[(2)] = null);

(statearr_83720_83791[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (12))){
var inst_83558 = (state_83668[(2)]);
var state_83668__$1 = state_83668;
var statearr_83721_83792 = state_83668__$1;
(statearr_83721_83792[(2)] = inst_83558);

(statearr_83721_83792[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (2))){
var inst_83520 = (state_83668[(13)]);
var inst_83527 = cljs.core.seq.call(null,inst_83520);
var inst_83528 = inst_83527;
var inst_83529 = null;
var inst_83530 = (0);
var inst_83531 = (0);
var state_83668__$1 = (function (){var statearr_83722 = state_83668;
(statearr_83722[(7)] = inst_83531);

(statearr_83722[(8)] = inst_83529);

(statearr_83722[(9)] = inst_83528);

(statearr_83722[(10)] = inst_83530);

return statearr_83722;
})();
var statearr_83723_83793 = state_83668__$1;
(statearr_83723_83793[(2)] = null);

(statearr_83723_83793[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (23))){
var inst_83589 = (state_83668[(23)]);
var inst_83587 = (state_83668[(26)]);
var inst_83581 = (state_83668[(19)]);
var inst_83585 = (state_83668[(24)]);
var inst_83584 = (state_83668[(25)]);
var inst_83592 = figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"debug","debug",-1608172596),"Figwheel: loaded these dependencies");
var inst_83594 = (function (){var all_files = inst_83581;
var res_SINGLEQUOTE_ = inst_83584;
var res = inst_83585;
var files_not_loaded = inst_83587;
var dependencies_that_loaded = inst_83589;
return ((function (all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_83589,inst_83587,inst_83581,inst_83585,inst_83584,inst_83592,state_val_83669,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (p__83593){
var map__83724 = p__83593;
var map__83724__$1 = (((((!((map__83724 == null))))?(((((map__83724.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__83724.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__83724):map__83724);
var request_url = cljs.core.get.call(null,map__83724__$1,new cljs.core.Keyword(null,"request-url","request-url",2100346596));
return clojure.string.replace.call(null,request_url,goog.basePath,"");
});
;})(all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_83589,inst_83587,inst_83581,inst_83585,inst_83584,inst_83592,state_val_83669,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var inst_83595 = cljs.core.reverse.call(null,inst_83589);
var inst_83596 = cljs.core.map.call(null,inst_83594,inst_83595);
var inst_83597 = cljs.core.pr_str.call(null,inst_83596);
var inst_83598 = figwheel.client.utils.log.call(null,inst_83597);
var state_83668__$1 = (function (){var statearr_83726 = state_83668;
(statearr_83726[(31)] = inst_83592);

return statearr_83726;
})();
var statearr_83727_83794 = state_83668__$1;
(statearr_83727_83794[(2)] = inst_83598);

(statearr_83727_83794[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (35))){
var state_83668__$1 = state_83668;
var statearr_83728_83795 = state_83668__$1;
(statearr_83728_83795[(2)] = true);

(statearr_83728_83795[(1)] = (37));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (19))){
var inst_83571 = (state_83668[(12)]);
var inst_83577 = figwheel.client.file_reloading.expand_files.call(null,inst_83571);
var state_83668__$1 = state_83668;
var statearr_83729_83796 = state_83668__$1;
(statearr_83729_83796[(2)] = inst_83577);

(statearr_83729_83796[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (11))){
var state_83668__$1 = state_83668;
var statearr_83730_83797 = state_83668__$1;
(statearr_83730_83797[(2)] = null);

(statearr_83730_83797[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (9))){
var inst_83560 = (state_83668[(2)]);
var state_83668__$1 = state_83668;
var statearr_83731_83798 = state_83668__$1;
(statearr_83731_83798[(2)] = inst_83560);

(statearr_83731_83798[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (5))){
var inst_83531 = (state_83668[(7)]);
var inst_83530 = (state_83668[(10)]);
var inst_83533 = (inst_83531 < inst_83530);
var inst_83534 = inst_83533;
var state_83668__$1 = state_83668;
if(cljs.core.truth_(inst_83534)){
var statearr_83732_83799 = state_83668__$1;
(statearr_83732_83799[(1)] = (7));

} else {
var statearr_83733_83800 = state_83668__$1;
(statearr_83733_83800[(1)] = (8));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (14))){
var inst_83541 = (state_83668[(22)]);
var inst_83550 = cljs.core.first.call(null,inst_83541);
var inst_83551 = figwheel.client.file_reloading.eval_body.call(null,inst_83550,opts);
var inst_83552 = cljs.core.next.call(null,inst_83541);
var inst_83528 = inst_83552;
var inst_83529 = null;
var inst_83530 = (0);
var inst_83531 = (0);
var state_83668__$1 = (function (){var statearr_83734 = state_83668;
(statearr_83734[(7)] = inst_83531);

(statearr_83734[(32)] = inst_83551);

(statearr_83734[(8)] = inst_83529);

(statearr_83734[(9)] = inst_83528);

(statearr_83734[(10)] = inst_83530);

return statearr_83734;
})();
var statearr_83735_83801 = state_83668__$1;
(statearr_83735_83801[(2)] = null);

(statearr_83735_83801[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (45))){
var state_83668__$1 = state_83668;
var statearr_83736_83802 = state_83668__$1;
(statearr_83736_83802[(2)] = null);

(statearr_83736_83802[(1)] = (46));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (26))){
var inst_83589 = (state_83668[(23)]);
var inst_83587 = (state_83668[(26)]);
var inst_83581 = (state_83668[(19)]);
var inst_83585 = (state_83668[(24)]);
var inst_83584 = (state_83668[(25)]);
var inst_83604 = figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"debug","debug",-1608172596),"Figwheel: loaded these files");
var inst_83606 = (function (){var all_files = inst_83581;
var res_SINGLEQUOTE_ = inst_83584;
var res = inst_83585;
var files_not_loaded = inst_83587;
var dependencies_that_loaded = inst_83589;
return ((function (all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_83589,inst_83587,inst_83581,inst_83585,inst_83584,inst_83604,state_val_83669,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (p__83605){
var map__83737 = p__83605;
var map__83737__$1 = (((((!((map__83737 == null))))?(((((map__83737.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__83737.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__83737):map__83737);
var namespace = cljs.core.get.call(null,map__83737__$1,new cljs.core.Keyword(null,"namespace","namespace",-377510372));
var file = cljs.core.get.call(null,map__83737__$1,new cljs.core.Keyword(null,"file","file",-1269645878));
if(cljs.core.truth_(namespace)){
return figwheel.client.file_reloading.name__GT_path.call(null,cljs.core.name.call(null,namespace));
} else {
return file;
}
});
;})(all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_83589,inst_83587,inst_83581,inst_83585,inst_83584,inst_83604,state_val_83669,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var inst_83607 = cljs.core.map.call(null,inst_83606,inst_83585);
var inst_83608 = cljs.core.pr_str.call(null,inst_83607);
var inst_83609 = figwheel.client.utils.log.call(null,inst_83608);
var inst_83610 = (function (){var all_files = inst_83581;
var res_SINGLEQUOTE_ = inst_83584;
var res = inst_83585;
var files_not_loaded = inst_83587;
var dependencies_that_loaded = inst_83589;
return ((function (all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_83589,inst_83587,inst_83581,inst_83585,inst_83584,inst_83604,inst_83606,inst_83607,inst_83608,inst_83609,state_val_83669,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (){
figwheel.client.file_reloading.on_jsload_custom_event.call(null,res);

return cljs.core.apply.call(null,on_jsload,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [res], null));
});
;})(all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_83589,inst_83587,inst_83581,inst_83585,inst_83584,inst_83604,inst_83606,inst_83607,inst_83608,inst_83609,state_val_83669,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var inst_83611 = setTimeout(inst_83610,(10));
var state_83668__$1 = (function (){var statearr_83739 = state_83668;
(statearr_83739[(33)] = inst_83609);

(statearr_83739[(34)] = inst_83604);

return statearr_83739;
})();
var statearr_83740_83803 = state_83668__$1;
(statearr_83740_83803[(2)] = inst_83611);

(statearr_83740_83803[(1)] = (28));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (16))){
var state_83668__$1 = state_83668;
var statearr_83741_83804 = state_83668__$1;
(statearr_83741_83804[(2)] = reload_dependents);

(statearr_83741_83804[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (38))){
var inst_83621 = (state_83668[(16)]);
var inst_83639 = cljs.core.apply.call(null,cljs.core.hash_map,inst_83621);
var state_83668__$1 = state_83668;
var statearr_83742_83805 = state_83668__$1;
(statearr_83742_83805[(2)] = inst_83639);

(statearr_83742_83805[(1)] = (40));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (30))){
var state_83668__$1 = state_83668;
var statearr_83743_83806 = state_83668__$1;
(statearr_83743_83806[(2)] = null);

(statearr_83743_83806[(1)] = (31));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (10))){
var inst_83541 = (state_83668[(22)]);
var inst_83543 = cljs.core.chunked_seq_QMARK_.call(null,inst_83541);
var state_83668__$1 = state_83668;
if(inst_83543){
var statearr_83744_83807 = state_83668__$1;
(statearr_83744_83807[(1)] = (13));

} else {
var statearr_83745_83808 = state_83668__$1;
(statearr_83745_83808[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (18))){
var inst_83575 = (state_83668[(2)]);
var state_83668__$1 = state_83668;
if(cljs.core.truth_(inst_83575)){
var statearr_83746_83809 = state_83668__$1;
(statearr_83746_83809[(1)] = (19));

} else {
var statearr_83747_83810 = state_83668__$1;
(statearr_83747_83810[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (42))){
var state_83668__$1 = state_83668;
var statearr_83748_83811 = state_83668__$1;
(statearr_83748_83811[(2)] = null);

(statearr_83748_83811[(1)] = (43));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (37))){
var inst_83634 = (state_83668[(2)]);
var state_83668__$1 = state_83668;
var statearr_83749_83812 = state_83668__$1;
(statearr_83749_83812[(2)] = inst_83634);

(statearr_83749_83812[(1)] = (34));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_83669 === (8))){
var inst_83541 = (state_83668[(22)]);
var inst_83528 = (state_83668[(9)]);
var inst_83541__$1 = cljs.core.seq.call(null,inst_83528);
var state_83668__$1 = (function (){var statearr_83750 = state_83668;
(statearr_83750[(22)] = inst_83541__$1);

return statearr_83750;
})();
if(inst_83541__$1){
var statearr_83751_83813 = state_83668__$1;
(statearr_83751_83813[(1)] = (10));

} else {
var statearr_83752_83814 = state_83668__$1;
(statearr_83752_83814[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents))
;
return ((function (switch__36984__auto__,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents){
return (function() {
var figwheel$client$file_reloading$reload_js_files_$_state_machine__36985__auto__ = null;
var figwheel$client$file_reloading$reload_js_files_$_state_machine__36985__auto____0 = (function (){
var statearr_83753 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_83753[(0)] = figwheel$client$file_reloading$reload_js_files_$_state_machine__36985__auto__);

(statearr_83753[(1)] = (1));

return statearr_83753;
});
var figwheel$client$file_reloading$reload_js_files_$_state_machine__36985__auto____1 = (function (state_83668){
while(true){
var ret_value__36986__auto__ = (function (){try{while(true){
var result__36987__auto__ = switch__36984__auto__.call(null,state_83668);
if(cljs.core.keyword_identical_QMARK_.call(null,result__36987__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__36987__auto__;
}
break;
}
}catch (e83754){if((e83754 instanceof Object)){
var ex__36988__auto__ = e83754;
var statearr_83755_83815 = state_83668;
(statearr_83755_83815[(5)] = ex__36988__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_83668);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e83754;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__36986__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__83816 = state_83668;
state_83668 = G__83816;
continue;
} else {
return ret_value__36986__auto__;
}
break;
}
});
figwheel$client$file_reloading$reload_js_files_$_state_machine__36985__auto__ = function(state_83668){
switch(arguments.length){
case 0:
return figwheel$client$file_reloading$reload_js_files_$_state_machine__36985__auto____0.call(this);
case 1:
return figwheel$client$file_reloading$reload_js_files_$_state_machine__36985__auto____1.call(this,state_83668);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
figwheel$client$file_reloading$reload_js_files_$_state_machine__36985__auto__.cljs$core$IFn$_invoke$arity$0 = figwheel$client$file_reloading$reload_js_files_$_state_machine__36985__auto____0;
figwheel$client$file_reloading$reload_js_files_$_state_machine__36985__auto__.cljs$core$IFn$_invoke$arity$1 = figwheel$client$file_reloading$reload_js_files_$_state_machine__36985__auto____1;
return figwheel$client$file_reloading$reload_js_files_$_state_machine__36985__auto__;
})()
;})(switch__36984__auto__,c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var state__37081__auto__ = (function (){var statearr_83756 = f__37080__auto__.call(null);
(statearr_83756[(6)] = c__37079__auto__);

return statearr_83756;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__37081__auto__);
});})(c__37079__auto__,map__83513,map__83513__$1,opts,before_jsload,on_jsload,reload_dependents,map__83514,map__83514__$1,msg,files,figwheel_meta,recompile_dependents))
);

return c__37079__auto__;
});
figwheel.client.file_reloading.current_links = (function figwheel$client$file_reloading$current_links(){
return Array.prototype.slice.call(document.getElementsByTagName("link"));
});
figwheel.client.file_reloading.truncate_url = (function figwheel$client$file_reloading$truncate_url(url){
return clojure.string.replace_first.call(null,clojure.string.replace_first.call(null,clojure.string.replace_first.call(null,clojure.string.replace_first.call(null,cljs.core.first.call(null,clojure.string.split.call(null,url,/\?/)),[cljs.core.str.cljs$core$IFn$_invoke$arity$1(location.protocol),"//"].join(''),""),".*://",""),/^\/\//,""),/[^\\/]*/,"");
});
figwheel.client.file_reloading.matches_file_QMARK_ = (function figwheel$client$file_reloading$matches_file_QMARK_(p__83819,link){
var map__83820 = p__83819;
var map__83820__$1 = (((((!((map__83820 == null))))?(((((map__83820.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__83820.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__83820):map__83820);
var file = cljs.core.get.call(null,map__83820__$1,new cljs.core.Keyword(null,"file","file",-1269645878));
var temp__5735__auto__ = link.href;
if(cljs.core.truth_(temp__5735__auto__)){
var link_href = temp__5735__auto__;
var match = clojure.string.join.call(null,"/",cljs.core.take_while.call(null,cljs.core.identity,cljs.core.map.call(null,((function (link_href,temp__5735__auto__,map__83820,map__83820__$1,file){
return (function (p1__83817_SHARP_,p2__83818_SHARP_){
if(cljs.core._EQ_.call(null,p1__83817_SHARP_,p2__83818_SHARP_)){
return p1__83817_SHARP_;
} else {
return false;
}
});})(link_href,temp__5735__auto__,map__83820,map__83820__$1,file))
,cljs.core.reverse.call(null,clojure.string.split.call(null,file,"/")),cljs.core.reverse.call(null,clojure.string.split.call(null,figwheel.client.file_reloading.truncate_url.call(null,link_href),"/")))));
var match_length = cljs.core.count.call(null,match);
var file_name_length = cljs.core.count.call(null,cljs.core.last.call(null,clojure.string.split.call(null,file,"/")));
if((match_length >= file_name_length)){
return new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"link","link",-1769163468),link,new cljs.core.Keyword(null,"link-href","link-href",-250644450),link_href,new cljs.core.Keyword(null,"match-length","match-length",1101537310),match_length,new cljs.core.Keyword(null,"current-url-length","current-url-length",380404083),cljs.core.count.call(null,figwheel.client.file_reloading.truncate_url.call(null,link_href))], null);
} else {
return null;
}
} else {
return null;
}
});
figwheel.client.file_reloading.get_correct_link = (function figwheel$client$file_reloading$get_correct_link(f_data){
var temp__5735__auto__ = cljs.core.first.call(null,cljs.core.sort_by.call(null,(function (p__83823){
var map__83824 = p__83823;
var map__83824__$1 = (((((!((map__83824 == null))))?(((((map__83824.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__83824.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__83824):map__83824);
var match_length = cljs.core.get.call(null,map__83824__$1,new cljs.core.Keyword(null,"match-length","match-length",1101537310));
var current_url_length = cljs.core.get.call(null,map__83824__$1,new cljs.core.Keyword(null,"current-url-length","current-url-length",380404083));
return (current_url_length - match_length);
}),cljs.core.keep.call(null,(function (p1__83822_SHARP_){
return figwheel.client.file_reloading.matches_file_QMARK_.call(null,f_data,p1__83822_SHARP_);
}),figwheel.client.file_reloading.current_links.call(null))));
if(cljs.core.truth_(temp__5735__auto__)){
var res = temp__5735__auto__;
return new cljs.core.Keyword(null,"link","link",-1769163468).cljs$core$IFn$_invoke$arity$1(res);
} else {
return null;
}
});
figwheel.client.file_reloading.clone_link = (function figwheel$client$file_reloading$clone_link(link,url){
var clone = document.createElement("link");
clone.rel = "stylesheet";

clone.media = link.media;

clone.disabled = link.disabled;

clone.href = figwheel.client.file_reloading.add_cache_buster.call(null,url);

return clone;
});
figwheel.client.file_reloading.create_link = (function figwheel$client$file_reloading$create_link(url){
var link = document.createElement("link");
link.rel = "stylesheet";

link.href = figwheel.client.file_reloading.add_cache_buster.call(null,url);

return link;
});
figwheel.client.file_reloading.distinctify = (function figwheel$client$file_reloading$distinctify(key,seqq){
return cljs.core.vals.call(null,cljs.core.reduce.call(null,(function (p1__83826_SHARP_,p2__83827_SHARP_){
return cljs.core.assoc.call(null,p1__83826_SHARP_,cljs.core.get.call(null,p2__83827_SHARP_,key),p2__83827_SHARP_);
}),cljs.core.PersistentArrayMap.EMPTY,seqq));
});
figwheel.client.file_reloading.add_link_to_document = (function figwheel$client$file_reloading$add_link_to_document(orig_link,klone,finished_fn){
var parent = orig_link.parentNode;
if(cljs.core._EQ_.call(null,orig_link,parent.lastChild)){
parent.appendChild(klone);
} else {
parent.insertBefore(klone,orig_link.nextSibling);
}

return setTimeout(((function (parent){
return (function (){
parent.removeChild(orig_link);

return finished_fn.call(null);
});})(parent))
,(300));
});
if((typeof figwheel !== 'undefined') && (typeof figwheel.client !== 'undefined') && (typeof figwheel.client.file_reloading !== 'undefined') && (typeof figwheel.client.file_reloading.reload_css_deferred_chain !== 'undefined')){
} else {
figwheel.client.file_reloading.reload_css_deferred_chain = cljs.core.atom.call(null,goog.async.Deferred.succeed());
}
figwheel.client.file_reloading.reload_css_file = (function figwheel$client$file_reloading$reload_css_file(f_data,fin){
var temp__5733__auto__ = figwheel.client.file_reloading.get_correct_link.call(null,f_data);
if(cljs.core.truth_(temp__5733__auto__)){
var link = temp__5733__auto__;
return figwheel.client.file_reloading.add_link_to_document.call(null,link,figwheel.client.file_reloading.clone_link.call(null,link,link.href),((function (link,temp__5733__auto__){
return (function (){
return fin.call(null,cljs.core.assoc.call(null,f_data,new cljs.core.Keyword(null,"loaded","loaded",-1246482293),true));
});})(link,temp__5733__auto__))
);
} else {
return fin.call(null,f_data);
}
});
figwheel.client.file_reloading.reload_css_files_STAR_ = (function figwheel$client$file_reloading$reload_css_files_STAR_(deferred,f_datas,on_cssload){
return figwheel.client.utils.liftContD.call(null,figwheel.client.utils.mapConcatD.call(null,deferred,figwheel.client.file_reloading.reload_css_file,f_datas),(function (f_datas_SINGLEQUOTE_,fin){
var loaded_f_datas_83828 = cljs.core.filter.call(null,new cljs.core.Keyword(null,"loaded","loaded",-1246482293),f_datas_SINGLEQUOTE_);
figwheel.client.file_reloading.on_cssload_custom_event.call(null,loaded_f_datas_83828);

if(cljs.core.fn_QMARK_.call(null,on_cssload)){
on_cssload.call(null,loaded_f_datas_83828);
} else {
}

return fin.call(null);
}));
});
figwheel.client.file_reloading.reload_css_files = (function figwheel$client$file_reloading$reload_css_files(p__83829,p__83830){
var map__83831 = p__83829;
var map__83831__$1 = (((((!((map__83831 == null))))?(((((map__83831.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__83831.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__83831):map__83831);
var on_cssload = cljs.core.get.call(null,map__83831__$1,new cljs.core.Keyword(null,"on-cssload","on-cssload",1825432318));
var map__83832 = p__83830;
var map__83832__$1 = (((((!((map__83832 == null))))?(((((map__83832.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__83832.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__83832):map__83832);
var files_msg = map__83832__$1;
var files = cljs.core.get.call(null,map__83832__$1,new cljs.core.Keyword(null,"files","files",-472457450));
if(figwheel.client.utils.html_env_QMARK_.call(null)){
var temp__5735__auto__ = cljs.core.not_empty.call(null,figwheel.client.file_reloading.distinctify.call(null,new cljs.core.Keyword(null,"file","file",-1269645878),files));
if(cljs.core.truth_(temp__5735__auto__)){
var f_datas = temp__5735__auto__;
return cljs.core.swap_BANG_.call(null,figwheel.client.file_reloading.reload_css_deferred_chain,figwheel.client.file_reloading.reload_css_files_STAR_,f_datas,on_cssload);
} else {
return null;
}
} else {
return null;
}
});

//# sourceMappingURL=file_reloading.js.map?rel=1576314332588
