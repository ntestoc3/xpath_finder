// Compiled by ClojureScript 1.10.597 {}
goog.provide('figwheel.main');
goog.require('cljs.core');

//# sourceMappingURL=main.js.map
