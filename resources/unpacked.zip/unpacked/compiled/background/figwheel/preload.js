// Compiled by ClojureScript 1.10.520 {}
goog.provide('figwheel.preload');
goog.require('cljs.core');
goog.require('figwheel.connect');
figwheel.connect.start.call(null);

//# sourceMappingURL=preload.js.map?rel=1576314333193
