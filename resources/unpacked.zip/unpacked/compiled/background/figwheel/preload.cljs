(ns figwheel.preload
  (:require [figwheel.connect]))

(figwheel.connect/start)
