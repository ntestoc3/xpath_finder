// Compiled by ClojureScript 1.10.597 {}
goog.provide('process.env');
goog.require('cljs.core');

/** @define {string} */
goog.define("process.env.NODE_ENV","development");

//# sourceMappingURL=env.js.map
