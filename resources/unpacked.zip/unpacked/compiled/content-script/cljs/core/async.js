// Compiled by ClojureScript 1.10.597 {:static-fns true, :optimize-constants true}
goog.provide('cljs.core.async');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async.impl.protocols');
goog.require('cljs.core.async.impl.channels');
goog.require('cljs.core.async.impl.buffers');
goog.require('cljs.core.async.impl.timers');
goog.require('cljs.core.async.impl.dispatch');
goog.require('cljs.core.async.impl.ioc_helpers');
goog.require('goog.array');
cljs.core.async.fn_handler = (function cljs$core$async$fn_handler(var_args){
var G__29638 = arguments.length;
switch (G__29638) {
case 1:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1 = (function (f){
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(f,true);
}));

(cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2 = (function (f,blockable){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async29639 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async29639 = (function (f,blockable,meta29640){
this.f = f;
this.blockable = blockable;
this.meta29640 = meta29640;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async29639.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_29641,meta29640__$1){
var self__ = this;
var _29641__$1 = this;
return (new cljs.core.async.t_cljs$core$async29639(self__.f,self__.blockable,meta29640__$1));
}));

(cljs.core.async.t_cljs$core$async29639.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_29641){
var self__ = this;
var _29641__$1 = this;
return self__.meta29640;
}));

(cljs.core.async.t_cljs$core$async29639.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async29639.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
}));

(cljs.core.async.t_cljs$core$async29639.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.blockable;
}));

(cljs.core.async.t_cljs$core$async29639.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.f;
}));

(cljs.core.async.t_cljs$core$async29639.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$blockable,cljs.core.cst$sym$meta29640], null);
}));

(cljs.core.async.t_cljs$core$async29639.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async29639.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async29639");

(cljs.core.async.t_cljs$core$async29639.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write(writer__4429__auto__,"cljs.core.async/t_cljs$core$async29639");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async29639.
 */
cljs.core.async.__GT_t_cljs$core$async29639 = (function cljs$core$async$__GT_t_cljs$core$async29639(f__$1,blockable__$1,meta29640){
return (new cljs.core.async.t_cljs$core$async29639(f__$1,blockable__$1,meta29640));
});

}

return (new cljs.core.async.t_cljs$core$async29639(f,blockable,cljs.core.PersistentArrayMap.EMPTY));
}));

(cljs.core.async.fn_handler.cljs$lang$maxFixedArity = 2);

/**
 * Returns a fixed buffer of size n. When full, puts will block/park.
 */
cljs.core.async.buffer = (function cljs$core$async$buffer(n){
return cljs.core.async.impl.buffers.fixed_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete but
 *   val will be dropped (no transfer).
 */
cljs.core.async.dropping_buffer = (function cljs$core$async$dropping_buffer(n){
return cljs.core.async.impl.buffers.dropping_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete, and be
 *   buffered, but oldest elements in buffer will be dropped (not
 *   transferred).
 */
cljs.core.async.sliding_buffer = (function cljs$core$async$sliding_buffer(n){
return cljs.core.async.impl.buffers.sliding_buffer(n);
});
/**
 * Returns true if a channel created with buff will never block. That is to say,
 * puts into this buffer will never cause the buffer to be full. 
 */
cljs.core.async.unblocking_buffer_QMARK_ = (function cljs$core$async$unblocking_buffer_QMARK_(buff){
if((!((buff == null)))){
if(((false) || ((cljs.core.PROTOCOL_SENTINEL === buff.cljs$core$async$impl$protocols$UnblockingBuffer$)))){
return true;
} else {
if((!buff.cljs$lang$protocol_mask$partition$)){
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
} else {
return false;
}
}
} else {
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
}
});
/**
 * Creates a channel with an optional buffer, an optional transducer (like (map f),
 *   (filter p) etc or a composition thereof), and an optional exception handler.
 *   If buf-or-n is a number, will create and use a fixed buffer of that size. If a
 *   transducer is supplied a buffer must be specified. ex-handler must be a
 *   fn of one argument - if an exception occurs during transformation it will be called
 *   with the thrown value as an argument, and any non-nil return value will be placed
 *   in the channel.
 */
cljs.core.async.chan = (function cljs$core$async$chan(var_args){
var G__29645 = arguments.length;
switch (G__29645) {
case 0:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(null);
}));

(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1 = (function (buf_or_n){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,null,null);
}));

(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2 = (function (buf_or_n,xform){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,xform,null);
}));

(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3 = (function (buf_or_n,xform,ex_handler){
var buf_or_n__$1 = ((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(buf_or_n,(0)))?null:buf_or_n);
if(cljs.core.truth_(xform)){
if(cljs.core.truth_(buf_or_n__$1)){
} else {
throw (new Error(["Assert failed: ","buffer must be supplied when transducer is","\n","buf-or-n"].join('')));
}
} else {
}

return cljs.core.async.impl.channels.chan.cljs$core$IFn$_invoke$arity$3(((typeof buf_or_n__$1 === 'number')?cljs.core.async.buffer(buf_or_n__$1):buf_or_n__$1),xform,ex_handler);
}));

(cljs.core.async.chan.cljs$lang$maxFixedArity = 3);

/**
 * Creates a promise channel with an optional transducer, and an optional
 *   exception-handler. A promise channel can take exactly one value that consumers
 *   will receive. Once full, puts complete but val is dropped (no transfer).
 *   Consumers will block until either a value is placed in the channel or the
 *   channel is closed. See chan for the semantics of xform and ex-handler.
 */
cljs.core.async.promise_chan = (function cljs$core$async$promise_chan(var_args){
var G__29648 = arguments.length;
switch (G__29648) {
case 0:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1(null);
}));

(cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1 = (function (xform){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2(xform,null);
}));

(cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2 = (function (xform,ex_handler){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(cljs.core.async.impl.buffers.promise_buffer(),xform,ex_handler);
}));

(cljs.core.async.promise_chan.cljs$lang$maxFixedArity = 2);

/**
 * Returns a channel that will close after msecs
 */
cljs.core.async.timeout = (function cljs$core$async$timeout(msecs){
return cljs.core.async.impl.timers.timeout(msecs);
});
/**
 * takes a val from port. Must be called inside a (go ...) block. Will
 *   return nil if closed. Will park if nothing is available.
 *   Returns true unless port is already closed
 */
cljs.core.async._LT__BANG_ = (function cljs$core$async$_LT__BANG_(port){
throw (new Error("<! used not in (go ...) block"));
});
/**
 * Asynchronously takes a val from port, passing to fn1. Will pass nil
 * if closed. If on-caller? (default true) is true, and value is
 * immediately available, will call fn1 on calling thread.
 * Returns nil.
 */
cljs.core.async.take_BANG_ = (function cljs$core$async$take_BANG_(var_args){
var G__29651 = arguments.length;
switch (G__29651) {
case 2:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,fn1){
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3(port,fn1,true);
}));

(cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,fn1,on_caller_QMARK_){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(ret)){
var val_29653 = cljs.core.deref(ret);
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_29653) : fn1.call(null,val_29653));
} else {
cljs.core.async.impl.dispatch.run((function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_29653) : fn1.call(null,val_29653));
}));
}
} else {
}

return null;
}));

(cljs.core.async.take_BANG_.cljs$lang$maxFixedArity = 3);

cljs.core.async.nop = (function cljs$core$async$nop(_){
return null;
});
cljs.core.async.fhnop = cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(cljs.core.async.nop);
/**
 * puts a val into port. nil values are not allowed. Must be called
 *   inside a (go ...) block. Will park if no buffer space is available.
 *   Returns true unless port is already closed.
 */
cljs.core.async._GT__BANG_ = (function cljs$core$async$_GT__BANG_(port,val){
throw (new Error(">! used not in (go ...) block"));
});
/**
 * Asynchronously puts a val into port, calling fn1 (if supplied) when
 * complete. nil values are not allowed. Will throw if closed. If
 * on-caller? (default true) is true, and the put is immediately
 * accepted, will call fn1 on calling thread.  Returns nil.
 */
cljs.core.async.put_BANG_ = (function cljs$core$async$put_BANG_(var_args){
var G__29655 = arguments.length;
switch (G__29655) {
case 2:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,val){
var temp__5733__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fhnop);
if(cljs.core.truth_(temp__5733__auto__)){
var ret = temp__5733__auto__;
return cljs.core.deref(ret);
} else {
return true;
}
}));

(cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,val,fn1){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4(port,val,fn1,true);
}));

(cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4 = (function (port,val,fn1,on_caller_QMARK_){
var temp__5733__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(temp__5733__auto__)){
var retb = temp__5733__auto__;
var ret = cljs.core.deref(retb);
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
} else {
cljs.core.async.impl.dispatch.run((function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
}));
}

return ret;
} else {
return true;
}
}));

(cljs.core.async.put_BANG_.cljs$lang$maxFixedArity = 4);

cljs.core.async.close_BANG_ = (function cljs$core$async$close_BANG_(port){
return cljs.core.async.impl.protocols.close_BANG_(port);
});
cljs.core.async.random_array = (function cljs$core$async$random_array(n){
var a = (new Array(n));
var n__4666__auto___29657 = n;
var x_29658 = (0);
while(true){
if((x_29658 < n__4666__auto___29657)){
(a[x_29658] = x_29658);

var G__29659 = (x_29658 + (1));
x_29658 = G__29659;
continue;
} else {
}
break;
}

goog.array.shuffle(a);

return a;
});
cljs.core.async.alt_flag = (function cljs$core$async$alt_flag(){
var flag = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(true);
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async29660 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async29660 = (function (flag,meta29661){
this.flag = flag;
this.meta29661 = meta29661;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async29660.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_29662,meta29661__$1){
var self__ = this;
var _29662__$1 = this;
return (new cljs.core.async.t_cljs$core$async29660(self__.flag,meta29661__$1));
}));

(cljs.core.async.t_cljs$core$async29660.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_29662){
var self__ = this;
var _29662__$1 = this;
return self__.meta29661;
}));

(cljs.core.async.t_cljs$core$async29660.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async29660.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.deref(self__.flag);
}));

(cljs.core.async.t_cljs$core$async29660.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
}));

(cljs.core.async.t_cljs$core$async29660.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.flag,null);

return true;
}));

(cljs.core.async.t_cljs$core$async29660.getBasis = (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$flag,cljs.core.cst$sym$meta29661], null);
}));

(cljs.core.async.t_cljs$core$async29660.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async29660.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async29660");

(cljs.core.async.t_cljs$core$async29660.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write(writer__4429__auto__,"cljs.core.async/t_cljs$core$async29660");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async29660.
 */
cljs.core.async.__GT_t_cljs$core$async29660 = (function cljs$core$async$alt_flag_$___GT_t_cljs$core$async29660(flag__$1,meta29661){
return (new cljs.core.async.t_cljs$core$async29660(flag__$1,meta29661));
});

}

return (new cljs.core.async.t_cljs$core$async29660(flag,cljs.core.PersistentArrayMap.EMPTY));
});
cljs.core.async.alt_handler = (function cljs$core$async$alt_handler(flag,cb){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async29663 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async29663 = (function (flag,cb,meta29664){
this.flag = flag;
this.cb = cb;
this.meta29664 = meta29664;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async29663.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_29665,meta29664__$1){
var self__ = this;
var _29665__$1 = this;
return (new cljs.core.async.t_cljs$core$async29663(self__.flag,self__.cb,meta29664__$1));
}));

(cljs.core.async.t_cljs$core$async29663.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_29665){
var self__ = this;
var _29665__$1 = this;
return self__.meta29664;
}));

(cljs.core.async.t_cljs$core$async29663.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async29663.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.flag);
}));

(cljs.core.async.t_cljs$core$async29663.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
}));

(cljs.core.async.t_cljs$core$async29663.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.async.impl.protocols.commit(self__.flag);

return self__.cb;
}));

(cljs.core.async.t_cljs$core$async29663.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$flag,cljs.core.cst$sym$cb,cljs.core.cst$sym$meta29664], null);
}));

(cljs.core.async.t_cljs$core$async29663.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async29663.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async29663");

(cljs.core.async.t_cljs$core$async29663.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write(writer__4429__auto__,"cljs.core.async/t_cljs$core$async29663");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async29663.
 */
cljs.core.async.__GT_t_cljs$core$async29663 = (function cljs$core$async$alt_handler_$___GT_t_cljs$core$async29663(flag__$1,cb__$1,meta29664){
return (new cljs.core.async.t_cljs$core$async29663(flag__$1,cb__$1,meta29664));
});

}

return (new cljs.core.async.t_cljs$core$async29663(flag,cb,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * returns derefable [val port] if immediate, nil if enqueued
 */
cljs.core.async.do_alts = (function cljs$core$async$do_alts(fret,ports,opts){
if((cljs.core.count(ports) > (0))){
} else {
throw (new Error(["Assert failed: ","alts must have at least one channel operation","\n","(pos? (count ports))"].join('')));
}

var flag = cljs.core.async.alt_flag();
var n = cljs.core.count(ports);
var idxs = cljs.core.async.random_array(n);
var priority = cljs.core.cst$kw$priority.cljs$core$IFn$_invoke$arity$1(opts);
var ret = (function (){var i = (0);
while(true){
if((i < n)){
var idx = (cljs.core.truth_(priority)?i:(idxs[i]));
var port = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(ports,idx);
var wport = ((cljs.core.vector_QMARK_(port))?(port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((0)) : port.call(null,(0))):null);
var vbox = (cljs.core.truth_(wport)?(function (){var val = (port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((1)) : port.call(null,(1)));
return cljs.core.async.impl.protocols.put_BANG_(wport,val,cljs.core.async.alt_handler(flag,((function (i,val,idx,port,wport,flag,n,idxs,priority){
return (function (p1__29666_SHARP_){
var G__29668 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__29666_SHARP_,wport], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__29668) : fret.call(null,G__29668));
});})(i,val,idx,port,wport,flag,n,idxs,priority))
));
})():cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.alt_handler(flag,((function (i,idx,port,wport,flag,n,idxs,priority){
return (function (p1__29667_SHARP_){
var G__29669 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__29667_SHARP_,port], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__29669) : fret.call(null,G__29669));
});})(i,idx,port,wport,flag,n,idxs,priority))
)));
if(cljs.core.truth_(vbox)){
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.deref(vbox),(function (){var or__4185__auto__ = wport;
if(cljs.core.truth_(or__4185__auto__)){
return or__4185__auto__;
} else {
return port;
}
})()], null));
} else {
var G__29670 = (i + (1));
i = G__29670;
continue;
}
} else {
return null;
}
break;
}
})();
var or__4185__auto__ = ret;
if(cljs.core.truth_(or__4185__auto__)){
return or__4185__auto__;
} else {
if(cljs.core.contains_QMARK_(opts,cljs.core.cst$kw$default)){
var temp__5735__auto__ = (function (){var and__4174__auto__ = flag.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1(null);
if(cljs.core.truth_(and__4174__auto__)){
return flag.cljs$core$async$impl$protocols$Handler$commit$arity$1(null);
} else {
return and__4174__auto__;
}
})();
if(cljs.core.truth_(temp__5735__auto__)){
var got = temp__5735__auto__;
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$default.cljs$core$IFn$_invoke$arity$1(opts),cljs.core.cst$kw$default], null));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Completes at most one of several channel operations. Must be called
 * inside a (go ...) block. ports is a vector of channel endpoints,
 * which can be either a channel to take from or a vector of
 *   [channel-to-put-to val-to-put], in any combination. Takes will be
 *   made as if by <!, and puts will be made as if by >!. Unless
 *   the :priority option is true, if more than one port operation is
 *   ready a non-deterministic choice will be made. If no operation is
 *   ready and a :default value is supplied, [default-val :default] will
 *   be returned, otherwise alts! will park until the first operation to
 *   become ready completes. Returns [val port] of the completed
 *   operation, where val is the value taken for takes, and a
 *   boolean (true unless already closed, as per put!) for puts.
 * 
 *   opts are passed as :key val ... Supported options:
 * 
 *   :default val - the value to use if none of the operations are immediately ready
 *   :priority true - (default nil) when true, the operations will be tried in order.
 * 
 *   Note: there is no guarantee that the port exps or val exprs will be
 *   used, nor in what order should they be, so they should not be
 *   depended upon for side effects.
 */
cljs.core.async.alts_BANG_ = (function cljs$core$async$alts_BANG_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___29676 = arguments.length;
var i__4790__auto___29677 = (0);
while(true){
if((i__4790__auto___29677 < len__4789__auto___29676)){
args__4795__auto__.push((arguments[i__4790__auto___29677]));

var G__29678 = (i__4790__auto___29677 + (1));
i__4790__auto___29677 = G__29678;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((1) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((1)),(0),null)):null);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4796__auto__);
});

(cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (ports,p__29673){
var map__29674 = p__29673;
var map__29674__$1 = (((((!((map__29674 == null))))?(((((map__29674.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__29674.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__29674):map__29674);
var opts = map__29674__$1;
throw (new Error("alts! used not in (go ...) block"));
}));

(cljs.core.async.alts_BANG_.cljs$lang$maxFixedArity = (1));

/** @this {Function} */
(cljs.core.async.alts_BANG_.cljs$lang$applyTo = (function (seq29671){
var G__29672 = cljs.core.first(seq29671);
var seq29671__$1 = cljs.core.next(seq29671);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__29672,seq29671__$1);
}));

/**
 * Puts a val into port if it's possible to do so immediately.
 *   nil values are not allowed. Never blocks. Returns true if offer succeeds.
 */
cljs.core.async.offer_BANG_ = (function cljs$core$async$offer_BANG_(port,val){
var ret = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref(ret);
} else {
return null;
}
});
/**
 * Takes a val from port if it's possible to do so immediately.
 *   Never blocks. Returns value if successful, nil otherwise.
 */
cljs.core.async.poll_BANG_ = (function cljs$core$async$poll_BANG_(port){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref(ret);
} else {
return null;
}
});
/**
 * Takes elements from the from channel and supplies them to the to
 * channel. By default, the to channel will be closed when the from
 * channel closes, but can be determined by the close?  parameter. Will
 * stop consuming the from channel if the to channel closes
 */
cljs.core.async.pipe = (function cljs$core$async$pipe(var_args){
var G__29680 = arguments.length;
switch (G__29680) {
case 2:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2 = (function (from,to){
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3(from,to,true);
}));

(cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3 = (function (from,to,close_QMARK_){
var c__27715__auto___29726 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_29704){
var state_val_29705 = (state_29704[(1)]);
if((state_val_29705 === (7))){
var inst_29700 = (state_29704[(2)]);
var state_29704__$1 = state_29704;
var statearr_29706_29727 = state_29704__$1;
(statearr_29706_29727[(2)] = inst_29700);

(statearr_29706_29727[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29705 === (1))){
var state_29704__$1 = state_29704;
var statearr_29707_29728 = state_29704__$1;
(statearr_29707_29728[(2)] = null);

(statearr_29707_29728[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29705 === (4))){
var inst_29683 = (state_29704[(7)]);
var inst_29683__$1 = (state_29704[(2)]);
var inst_29684 = (inst_29683__$1 == null);
var state_29704__$1 = (function (){var statearr_29708 = state_29704;
(statearr_29708[(7)] = inst_29683__$1);

return statearr_29708;
})();
if(cljs.core.truth_(inst_29684)){
var statearr_29709_29729 = state_29704__$1;
(statearr_29709_29729[(1)] = (5));

} else {
var statearr_29710_29730 = state_29704__$1;
(statearr_29710_29730[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29705 === (13))){
var state_29704__$1 = state_29704;
var statearr_29711_29731 = state_29704__$1;
(statearr_29711_29731[(2)] = null);

(statearr_29711_29731[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29705 === (6))){
var inst_29683 = (state_29704[(7)]);
var state_29704__$1 = state_29704;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29704__$1,(11),to,inst_29683);
} else {
if((state_val_29705 === (3))){
var inst_29702 = (state_29704[(2)]);
var state_29704__$1 = state_29704;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29704__$1,inst_29702);
} else {
if((state_val_29705 === (12))){
var state_29704__$1 = state_29704;
var statearr_29712_29732 = state_29704__$1;
(statearr_29712_29732[(2)] = null);

(statearr_29712_29732[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29705 === (2))){
var state_29704__$1 = state_29704;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29704__$1,(4),from);
} else {
if((state_val_29705 === (11))){
var inst_29693 = (state_29704[(2)]);
var state_29704__$1 = state_29704;
if(cljs.core.truth_(inst_29693)){
var statearr_29713_29733 = state_29704__$1;
(statearr_29713_29733[(1)] = (12));

} else {
var statearr_29714_29734 = state_29704__$1;
(statearr_29714_29734[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29705 === (9))){
var state_29704__$1 = state_29704;
var statearr_29715_29735 = state_29704__$1;
(statearr_29715_29735[(2)] = null);

(statearr_29715_29735[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29705 === (5))){
var state_29704__$1 = state_29704;
if(cljs.core.truth_(close_QMARK_)){
var statearr_29716_29736 = state_29704__$1;
(statearr_29716_29736[(1)] = (8));

} else {
var statearr_29717_29737 = state_29704__$1;
(statearr_29717_29737[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29705 === (14))){
var inst_29698 = (state_29704[(2)]);
var state_29704__$1 = state_29704;
var statearr_29718_29738 = state_29704__$1;
(statearr_29718_29738[(2)] = inst_29698);

(statearr_29718_29738[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29705 === (10))){
var inst_29690 = (state_29704[(2)]);
var state_29704__$1 = state_29704;
var statearr_29719_29739 = state_29704__$1;
(statearr_29719_29739[(2)] = inst_29690);

(statearr_29719_29739[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29705 === (8))){
var inst_29687 = cljs.core.async.close_BANG_(to);
var state_29704__$1 = state_29704;
var statearr_29720_29740 = state_29704__$1;
(statearr_29720_29740[(2)] = inst_29687);

(statearr_29720_29740[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_29721 = [null,null,null,null,null,null,null,null];
(statearr_29721[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_29721[(1)] = (1));

return statearr_29721;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_29704){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_29704);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e29722){if((e29722 instanceof Object)){
var ex__27528__auto__ = e29722;
var statearr_29723_29741 = state_29704;
(statearr_29723_29741[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29704);

return cljs.core.cst$kw$recur;
} else {
throw e29722;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__29742 = state_29704;
state_29704 = G__29742;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_29704){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_29704);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_29724 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_29724[(6)] = c__27715__auto___29726);

return statearr_29724;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));


return to;
}));

(cljs.core.async.pipe.cljs$lang$maxFixedArity = 3);

cljs.core.async.pipeline_STAR_ = (function cljs$core$async$pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,type){
if((n > (0))){
} else {
throw (new Error("Assert failed: (pos? n)"));
}

var jobs = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var results = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var process = (function (p__29743){
var vec__29744 = p__29743;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29744,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29744,(1),null);
var job = vec__29744;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((1),xf,ex_handler);
var c__27715__auto___29915 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_29751){
var state_val_29752 = (state_29751[(1)]);
if((state_val_29752 === (1))){
var state_29751__$1 = state_29751;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29751__$1,(2),res,v);
} else {
if((state_val_29752 === (2))){
var inst_29748 = (state_29751[(2)]);
var inst_29749 = cljs.core.async.close_BANG_(res);
var state_29751__$1 = (function (){var statearr_29753 = state_29751;
(statearr_29753[(7)] = inst_29748);

return statearr_29753;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_29751__$1,inst_29749);
} else {
return null;
}
}
});
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0 = (function (){
var statearr_29754 = [null,null,null,null,null,null,null,null];
(statearr_29754[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__);

(statearr_29754[(1)] = (1));

return statearr_29754;
});
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1 = (function (state_29751){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_29751);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e29755){if((e29755 instanceof Object)){
var ex__27528__auto__ = e29755;
var statearr_29756_29916 = state_29751;
(statearr_29756_29916[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29751);

return cljs.core.cst$kw$recur;
} else {
throw e29755;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__29917 = state_29751;
state_29751 = G__29917;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = function(state_29751){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1.call(this,state_29751);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_29757 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_29757[(6)] = c__27715__auto___29915);

return statearr_29757;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));


cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});
var async = (function (p__29758){
var vec__29759 = p__29758;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29759,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29759,(1),null);
var job = vec__29759;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
(xf.cljs$core$IFn$_invoke$arity$2 ? xf.cljs$core$IFn$_invoke$arity$2(v,res) : xf.call(null,v,res));

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});
var n__4666__auto___29918 = n;
var __29919 = (0);
while(true){
if((__29919 < n__4666__auto___29918)){
var G__29762_29920 = type;
var G__29762_29921__$1 = (((G__29762_29920 instanceof cljs.core.Keyword))?G__29762_29920.fqn:null);
switch (G__29762_29921__$1) {
case "compute":
var c__27715__auto___29923 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__29919,c__27715__auto___29923,G__29762_29920,G__29762_29921__$1,n__4666__auto___29918,jobs,results,process,async){
return (function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = ((function (__29919,c__27715__auto___29923,G__29762_29920,G__29762_29921__$1,n__4666__auto___29918,jobs,results,process,async){
return (function (state_29775){
var state_val_29776 = (state_29775[(1)]);
if((state_val_29776 === (1))){
var state_29775__$1 = state_29775;
var statearr_29777_29924 = state_29775__$1;
(statearr_29777_29924[(2)] = null);

(statearr_29777_29924[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29776 === (2))){
var state_29775__$1 = state_29775;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29775__$1,(4),jobs);
} else {
if((state_val_29776 === (3))){
var inst_29773 = (state_29775[(2)]);
var state_29775__$1 = state_29775;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29775__$1,inst_29773);
} else {
if((state_val_29776 === (4))){
var inst_29765 = (state_29775[(2)]);
var inst_29766 = process(inst_29765);
var state_29775__$1 = state_29775;
if(cljs.core.truth_(inst_29766)){
var statearr_29778_29925 = state_29775__$1;
(statearr_29778_29925[(1)] = (5));

} else {
var statearr_29779_29926 = state_29775__$1;
(statearr_29779_29926[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29776 === (5))){
var state_29775__$1 = state_29775;
var statearr_29780_29927 = state_29775__$1;
(statearr_29780_29927[(2)] = null);

(statearr_29780_29927[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29776 === (6))){
var state_29775__$1 = state_29775;
var statearr_29781_29928 = state_29775__$1;
(statearr_29781_29928[(2)] = null);

(statearr_29781_29928[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29776 === (7))){
var inst_29771 = (state_29775[(2)]);
var state_29775__$1 = state_29775;
var statearr_29782_29929 = state_29775__$1;
(statearr_29782_29929[(2)] = inst_29771);

(statearr_29782_29929[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__29919,c__27715__auto___29923,G__29762_29920,G__29762_29921__$1,n__4666__auto___29918,jobs,results,process,async))
;
return ((function (__29919,switch__27524__auto__,c__27715__auto___29923,G__29762_29920,G__29762_29921__$1,n__4666__auto___29918,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0 = (function (){
var statearr_29783 = [null,null,null,null,null,null,null];
(statearr_29783[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__);

(statearr_29783[(1)] = (1));

return statearr_29783;
});
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1 = (function (state_29775){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_29775);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e29784){if((e29784 instanceof Object)){
var ex__27528__auto__ = e29784;
var statearr_29785_29930 = state_29775;
(statearr_29785_29930[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29775);

return cljs.core.cst$kw$recur;
} else {
throw e29784;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__29931 = state_29775;
state_29775 = G__29931;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = function(state_29775){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1.call(this,state_29775);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__;
})()
;})(__29919,switch__27524__auto__,c__27715__auto___29923,G__29762_29920,G__29762_29921__$1,n__4666__auto___29918,jobs,results,process,async))
})();
var state__27717__auto__ = (function (){var statearr_29786 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_29786[(6)] = c__27715__auto___29923);

return statearr_29786;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
});})(__29919,c__27715__auto___29923,G__29762_29920,G__29762_29921__$1,n__4666__auto___29918,jobs,results,process,async))
);


break;
case "async":
var c__27715__auto___29932 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__29919,c__27715__auto___29932,G__29762_29920,G__29762_29921__$1,n__4666__auto___29918,jobs,results,process,async){
return (function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = ((function (__29919,c__27715__auto___29932,G__29762_29920,G__29762_29921__$1,n__4666__auto___29918,jobs,results,process,async){
return (function (state_29799){
var state_val_29800 = (state_29799[(1)]);
if((state_val_29800 === (1))){
var state_29799__$1 = state_29799;
var statearr_29801_29933 = state_29799__$1;
(statearr_29801_29933[(2)] = null);

(statearr_29801_29933[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29800 === (2))){
var state_29799__$1 = state_29799;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29799__$1,(4),jobs);
} else {
if((state_val_29800 === (3))){
var inst_29797 = (state_29799[(2)]);
var state_29799__$1 = state_29799;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29799__$1,inst_29797);
} else {
if((state_val_29800 === (4))){
var inst_29789 = (state_29799[(2)]);
var inst_29790 = async(inst_29789);
var state_29799__$1 = state_29799;
if(cljs.core.truth_(inst_29790)){
var statearr_29802_29934 = state_29799__$1;
(statearr_29802_29934[(1)] = (5));

} else {
var statearr_29803_29935 = state_29799__$1;
(statearr_29803_29935[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29800 === (5))){
var state_29799__$1 = state_29799;
var statearr_29804_29936 = state_29799__$1;
(statearr_29804_29936[(2)] = null);

(statearr_29804_29936[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29800 === (6))){
var state_29799__$1 = state_29799;
var statearr_29805_29937 = state_29799__$1;
(statearr_29805_29937[(2)] = null);

(statearr_29805_29937[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29800 === (7))){
var inst_29795 = (state_29799[(2)]);
var state_29799__$1 = state_29799;
var statearr_29806_29938 = state_29799__$1;
(statearr_29806_29938[(2)] = inst_29795);

(statearr_29806_29938[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__29919,c__27715__auto___29932,G__29762_29920,G__29762_29921__$1,n__4666__auto___29918,jobs,results,process,async))
;
return ((function (__29919,switch__27524__auto__,c__27715__auto___29932,G__29762_29920,G__29762_29921__$1,n__4666__auto___29918,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0 = (function (){
var statearr_29807 = [null,null,null,null,null,null,null];
(statearr_29807[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__);

(statearr_29807[(1)] = (1));

return statearr_29807;
});
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1 = (function (state_29799){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_29799);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e29808){if((e29808 instanceof Object)){
var ex__27528__auto__ = e29808;
var statearr_29809_29939 = state_29799;
(statearr_29809_29939[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29799);

return cljs.core.cst$kw$recur;
} else {
throw e29808;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__29940 = state_29799;
state_29799 = G__29940;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = function(state_29799){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1.call(this,state_29799);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__;
})()
;})(__29919,switch__27524__auto__,c__27715__auto___29932,G__29762_29920,G__29762_29921__$1,n__4666__auto___29918,jobs,results,process,async))
})();
var state__27717__auto__ = (function (){var statearr_29810 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_29810[(6)] = c__27715__auto___29932);

return statearr_29810;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
});})(__29919,c__27715__auto___29932,G__29762_29920,G__29762_29921__$1,n__4666__auto___29918,jobs,results,process,async))
);


break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__29762_29921__$1)].join('')));

}

var G__29941 = (__29919 + (1));
__29919 = G__29941;
continue;
} else {
}
break;
}

var c__27715__auto___29942 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_29832){
var state_val_29833 = (state_29832[(1)]);
if((state_val_29833 === (7))){
var inst_29828 = (state_29832[(2)]);
var state_29832__$1 = state_29832;
var statearr_29834_29943 = state_29832__$1;
(statearr_29834_29943[(2)] = inst_29828);

(statearr_29834_29943[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29833 === (1))){
var state_29832__$1 = state_29832;
var statearr_29835_29944 = state_29832__$1;
(statearr_29835_29944[(2)] = null);

(statearr_29835_29944[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29833 === (4))){
var inst_29813 = (state_29832[(7)]);
var inst_29813__$1 = (state_29832[(2)]);
var inst_29814 = (inst_29813__$1 == null);
var state_29832__$1 = (function (){var statearr_29836 = state_29832;
(statearr_29836[(7)] = inst_29813__$1);

return statearr_29836;
})();
if(cljs.core.truth_(inst_29814)){
var statearr_29837_29945 = state_29832__$1;
(statearr_29837_29945[(1)] = (5));

} else {
var statearr_29838_29946 = state_29832__$1;
(statearr_29838_29946[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29833 === (6))){
var inst_29813 = (state_29832[(7)]);
var inst_29818 = (state_29832[(8)]);
var inst_29818__$1 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var inst_29819 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_29820 = [inst_29813,inst_29818__$1];
var inst_29821 = (new cljs.core.PersistentVector(null,2,(5),inst_29819,inst_29820,null));
var state_29832__$1 = (function (){var statearr_29839 = state_29832;
(statearr_29839[(8)] = inst_29818__$1);

return statearr_29839;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29832__$1,(8),jobs,inst_29821);
} else {
if((state_val_29833 === (3))){
var inst_29830 = (state_29832[(2)]);
var state_29832__$1 = state_29832;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29832__$1,inst_29830);
} else {
if((state_val_29833 === (2))){
var state_29832__$1 = state_29832;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29832__$1,(4),from);
} else {
if((state_val_29833 === (9))){
var inst_29825 = (state_29832[(2)]);
var state_29832__$1 = (function (){var statearr_29840 = state_29832;
(statearr_29840[(9)] = inst_29825);

return statearr_29840;
})();
var statearr_29841_29947 = state_29832__$1;
(statearr_29841_29947[(2)] = null);

(statearr_29841_29947[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29833 === (5))){
var inst_29816 = cljs.core.async.close_BANG_(jobs);
var state_29832__$1 = state_29832;
var statearr_29842_29948 = state_29832__$1;
(statearr_29842_29948[(2)] = inst_29816);

(statearr_29842_29948[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29833 === (8))){
var inst_29818 = (state_29832[(8)]);
var inst_29823 = (state_29832[(2)]);
var state_29832__$1 = (function (){var statearr_29843 = state_29832;
(statearr_29843[(10)] = inst_29823);

return statearr_29843;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29832__$1,(9),results,inst_29818);
} else {
return null;
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0 = (function (){
var statearr_29844 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_29844[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__);

(statearr_29844[(1)] = (1));

return statearr_29844;
});
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1 = (function (state_29832){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_29832);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e29845){if((e29845 instanceof Object)){
var ex__27528__auto__ = e29845;
var statearr_29846_29949 = state_29832;
(statearr_29846_29949[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29832);

return cljs.core.cst$kw$recur;
} else {
throw e29845;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__29950 = state_29832;
state_29832 = G__29950;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = function(state_29832){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1.call(this,state_29832);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_29847 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_29847[(6)] = c__27715__auto___29942);

return statearr_29847;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));


var c__27715__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_29885){
var state_val_29886 = (state_29885[(1)]);
if((state_val_29886 === (7))){
var inst_29881 = (state_29885[(2)]);
var state_29885__$1 = state_29885;
var statearr_29887_29951 = state_29885__$1;
(statearr_29887_29951[(2)] = inst_29881);

(statearr_29887_29951[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (20))){
var state_29885__$1 = state_29885;
var statearr_29888_29952 = state_29885__$1;
(statearr_29888_29952[(2)] = null);

(statearr_29888_29952[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (1))){
var state_29885__$1 = state_29885;
var statearr_29889_29953 = state_29885__$1;
(statearr_29889_29953[(2)] = null);

(statearr_29889_29953[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (4))){
var inst_29850 = (state_29885[(7)]);
var inst_29850__$1 = (state_29885[(2)]);
var inst_29851 = (inst_29850__$1 == null);
var state_29885__$1 = (function (){var statearr_29890 = state_29885;
(statearr_29890[(7)] = inst_29850__$1);

return statearr_29890;
})();
if(cljs.core.truth_(inst_29851)){
var statearr_29891_29954 = state_29885__$1;
(statearr_29891_29954[(1)] = (5));

} else {
var statearr_29892_29955 = state_29885__$1;
(statearr_29892_29955[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (15))){
var inst_29863 = (state_29885[(8)]);
var state_29885__$1 = state_29885;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29885__$1,(18),to,inst_29863);
} else {
if((state_val_29886 === (21))){
var inst_29876 = (state_29885[(2)]);
var state_29885__$1 = state_29885;
var statearr_29893_29956 = state_29885__$1;
(statearr_29893_29956[(2)] = inst_29876);

(statearr_29893_29956[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (13))){
var inst_29878 = (state_29885[(2)]);
var state_29885__$1 = (function (){var statearr_29894 = state_29885;
(statearr_29894[(9)] = inst_29878);

return statearr_29894;
})();
var statearr_29895_29957 = state_29885__$1;
(statearr_29895_29957[(2)] = null);

(statearr_29895_29957[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (6))){
var inst_29850 = (state_29885[(7)]);
var state_29885__$1 = state_29885;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29885__$1,(11),inst_29850);
} else {
if((state_val_29886 === (17))){
var inst_29871 = (state_29885[(2)]);
var state_29885__$1 = state_29885;
if(cljs.core.truth_(inst_29871)){
var statearr_29896_29958 = state_29885__$1;
(statearr_29896_29958[(1)] = (19));

} else {
var statearr_29897_29959 = state_29885__$1;
(statearr_29897_29959[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (3))){
var inst_29883 = (state_29885[(2)]);
var state_29885__$1 = state_29885;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29885__$1,inst_29883);
} else {
if((state_val_29886 === (12))){
var inst_29860 = (state_29885[(10)]);
var state_29885__$1 = state_29885;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29885__$1,(14),inst_29860);
} else {
if((state_val_29886 === (2))){
var state_29885__$1 = state_29885;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29885__$1,(4),results);
} else {
if((state_val_29886 === (19))){
var state_29885__$1 = state_29885;
var statearr_29898_29960 = state_29885__$1;
(statearr_29898_29960[(2)] = null);

(statearr_29898_29960[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (11))){
var inst_29860 = (state_29885[(2)]);
var state_29885__$1 = (function (){var statearr_29899 = state_29885;
(statearr_29899[(10)] = inst_29860);

return statearr_29899;
})();
var statearr_29900_29961 = state_29885__$1;
(statearr_29900_29961[(2)] = null);

(statearr_29900_29961[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (9))){
var state_29885__$1 = state_29885;
var statearr_29901_29962 = state_29885__$1;
(statearr_29901_29962[(2)] = null);

(statearr_29901_29962[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (5))){
var state_29885__$1 = state_29885;
if(cljs.core.truth_(close_QMARK_)){
var statearr_29902_29963 = state_29885__$1;
(statearr_29902_29963[(1)] = (8));

} else {
var statearr_29903_29964 = state_29885__$1;
(statearr_29903_29964[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (14))){
var inst_29863 = (state_29885[(8)]);
var inst_29863__$1 = (state_29885[(2)]);
var inst_29864 = (inst_29863__$1 == null);
var inst_29865 = cljs.core.not(inst_29864);
var state_29885__$1 = (function (){var statearr_29904 = state_29885;
(statearr_29904[(8)] = inst_29863__$1);

return statearr_29904;
})();
if(inst_29865){
var statearr_29905_29965 = state_29885__$1;
(statearr_29905_29965[(1)] = (15));

} else {
var statearr_29906_29966 = state_29885__$1;
(statearr_29906_29966[(1)] = (16));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (16))){
var state_29885__$1 = state_29885;
var statearr_29907_29967 = state_29885__$1;
(statearr_29907_29967[(2)] = false);

(statearr_29907_29967[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (10))){
var inst_29857 = (state_29885[(2)]);
var state_29885__$1 = state_29885;
var statearr_29908_29968 = state_29885__$1;
(statearr_29908_29968[(2)] = inst_29857);

(statearr_29908_29968[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (18))){
var inst_29868 = (state_29885[(2)]);
var state_29885__$1 = state_29885;
var statearr_29909_29969 = state_29885__$1;
(statearr_29909_29969[(2)] = inst_29868);

(statearr_29909_29969[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (8))){
var inst_29854 = cljs.core.async.close_BANG_(to);
var state_29885__$1 = state_29885;
var statearr_29910_29970 = state_29885__$1;
(statearr_29910_29970[(2)] = inst_29854);

(statearr_29910_29970[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0 = (function (){
var statearr_29911 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_29911[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__);

(statearr_29911[(1)] = (1));

return statearr_29911;
});
var cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1 = (function (state_29885){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_29885);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e29912){if((e29912 instanceof Object)){
var ex__27528__auto__ = e29912;
var statearr_29913_29971 = state_29885;
(statearr_29913_29971[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29885);

return cljs.core.cst$kw$recur;
} else {
throw e29912;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__29972 = state_29885;
state_29885 = G__29972;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__ = function(state_29885){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1.call(this,state_29885);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__27525__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_29914 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_29914[(6)] = c__27715__auto__);

return statearr_29914;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));

return c__27715__auto__;
});
/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the async function af, with parallelism n. af
 *   must be a function of two arguments, the first an input value and
 *   the second a channel on which to place the result(s). af must close!
 *   the channel before returning.  The presumption is that af will
 *   return immediately, having launched some asynchronous operation
 *   whose completion/callback will manipulate the result channel. Outputs
 *   will be returned in order relative to  the inputs. By default, the to
 *   channel will be closed when the from channel closes, but can be
 *   determined by the close?  parameter. Will stop consuming the from
 *   channel if the to channel closes.
 */
cljs.core.async.pipeline_async = (function cljs$core$async$pipeline_async(var_args){
var G__29974 = arguments.length;
switch (G__29974) {
case 4:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4 = (function (n,to,af,from){
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5(n,to,af,from,true);
}));

(cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5 = (function (n,to,af,from,close_QMARK_){
return cljs.core.async.pipeline_STAR_(n,to,af,from,close_QMARK_,null,cljs.core.cst$kw$async);
}));

(cljs.core.async.pipeline_async.cljs$lang$maxFixedArity = 5);

/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the transducer xf, with parallelism n. Because
 *   it is parallel, the transducer will be applied independently to each
 *   element, not across elements, and may produce zero or more outputs
 *   per input.  Outputs will be returned in order relative to the
 *   inputs. By default, the to channel will be closed when the from
 *   channel closes, but can be determined by the close?  parameter. Will
 *   stop consuming the from channel if the to channel closes.
 * 
 *   Note this is supplied for API compatibility with the Clojure version.
 *   Values of N > 1 will not result in actual concurrency in a
 *   single-threaded runtime.
 */
cljs.core.async.pipeline = (function cljs$core$async$pipeline(var_args){
var G__29977 = arguments.length;
switch (G__29977) {
case 4:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
case 6:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),(arguments[(5)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4 = (function (n,to,xf,from){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5(n,to,xf,from,true);
}));

(cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5 = (function (n,to,xf,from,close_QMARK_){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6(n,to,xf,from,close_QMARK_,null);
}));

(cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6 = (function (n,to,xf,from,close_QMARK_,ex_handler){
return cljs.core.async.pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,cljs.core.cst$kw$compute);
}));

(cljs.core.async.pipeline.cljs$lang$maxFixedArity = 6);

/**
 * Takes a predicate and a source channel and returns a vector of two
 *   channels, the first of which will contain the values for which the
 *   predicate returned true, the second those for which it returned
 *   false.
 * 
 *   The out channels will be unbuffered by default, or two buf-or-ns can
 *   be supplied. The channels will close after the source channel has
 *   closed.
 */
cljs.core.async.split = (function cljs$core$async$split(var_args){
var G__29980 = arguments.length;
switch (G__29980) {
case 2:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 4:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.split.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4(p,ch,null,null);
}));

(cljs.core.async.split.cljs$core$IFn$_invoke$arity$4 = (function (p,ch,t_buf_or_n,f_buf_or_n){
var tc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(t_buf_or_n);
var fc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(f_buf_or_n);
var c__27715__auto___30029 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_30006){
var state_val_30007 = (state_30006[(1)]);
if((state_val_30007 === (7))){
var inst_30002 = (state_30006[(2)]);
var state_30006__$1 = state_30006;
var statearr_30008_30030 = state_30006__$1;
(statearr_30008_30030[(2)] = inst_30002);

(statearr_30008_30030[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30007 === (1))){
var state_30006__$1 = state_30006;
var statearr_30009_30031 = state_30006__$1;
(statearr_30009_30031[(2)] = null);

(statearr_30009_30031[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30007 === (4))){
var inst_29983 = (state_30006[(7)]);
var inst_29983__$1 = (state_30006[(2)]);
var inst_29984 = (inst_29983__$1 == null);
var state_30006__$1 = (function (){var statearr_30010 = state_30006;
(statearr_30010[(7)] = inst_29983__$1);

return statearr_30010;
})();
if(cljs.core.truth_(inst_29984)){
var statearr_30011_30032 = state_30006__$1;
(statearr_30011_30032[(1)] = (5));

} else {
var statearr_30012_30033 = state_30006__$1;
(statearr_30012_30033[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30007 === (13))){
var state_30006__$1 = state_30006;
var statearr_30013_30034 = state_30006__$1;
(statearr_30013_30034[(2)] = null);

(statearr_30013_30034[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30007 === (6))){
var inst_29983 = (state_30006[(7)]);
var inst_29989 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_29983) : p.call(null,inst_29983));
var state_30006__$1 = state_30006;
if(cljs.core.truth_(inst_29989)){
var statearr_30014_30035 = state_30006__$1;
(statearr_30014_30035[(1)] = (9));

} else {
var statearr_30015_30036 = state_30006__$1;
(statearr_30015_30036[(1)] = (10));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30007 === (3))){
var inst_30004 = (state_30006[(2)]);
var state_30006__$1 = state_30006;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30006__$1,inst_30004);
} else {
if((state_val_30007 === (12))){
var state_30006__$1 = state_30006;
var statearr_30016_30037 = state_30006__$1;
(statearr_30016_30037[(2)] = null);

(statearr_30016_30037[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30007 === (2))){
var state_30006__$1 = state_30006;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_30006__$1,(4),ch);
} else {
if((state_val_30007 === (11))){
var inst_29983 = (state_30006[(7)]);
var inst_29993 = (state_30006[(2)]);
var state_30006__$1 = state_30006;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30006__$1,(8),inst_29993,inst_29983);
} else {
if((state_val_30007 === (9))){
var state_30006__$1 = state_30006;
var statearr_30017_30038 = state_30006__$1;
(statearr_30017_30038[(2)] = tc);

(statearr_30017_30038[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30007 === (5))){
var inst_29986 = cljs.core.async.close_BANG_(tc);
var inst_29987 = cljs.core.async.close_BANG_(fc);
var state_30006__$1 = (function (){var statearr_30018 = state_30006;
(statearr_30018[(8)] = inst_29986);

return statearr_30018;
})();
var statearr_30019_30039 = state_30006__$1;
(statearr_30019_30039[(2)] = inst_29987);

(statearr_30019_30039[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30007 === (14))){
var inst_30000 = (state_30006[(2)]);
var state_30006__$1 = state_30006;
var statearr_30020_30040 = state_30006__$1;
(statearr_30020_30040[(2)] = inst_30000);

(statearr_30020_30040[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30007 === (10))){
var state_30006__$1 = state_30006;
var statearr_30021_30041 = state_30006__$1;
(statearr_30021_30041[(2)] = fc);

(statearr_30021_30041[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30007 === (8))){
var inst_29995 = (state_30006[(2)]);
var state_30006__$1 = state_30006;
if(cljs.core.truth_(inst_29995)){
var statearr_30022_30042 = state_30006__$1;
(statearr_30022_30042[(1)] = (12));

} else {
var statearr_30023_30043 = state_30006__$1;
(statearr_30023_30043[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_30024 = [null,null,null,null,null,null,null,null,null];
(statearr_30024[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_30024[(1)] = (1));

return statearr_30024;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_30006){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_30006);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e30025){if((e30025 instanceof Object)){
var ex__27528__auto__ = e30025;
var statearr_30026_30044 = state_30006;
(statearr_30026_30044[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30006);

return cljs.core.cst$kw$recur;
} else {
throw e30025;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__30045 = state_30006;
state_30006 = G__30045;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_30006){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_30006);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_30027 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_30027[(6)] = c__27715__auto___30029);

return statearr_30027;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));


return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [tc,fc], null);
}));

(cljs.core.async.split.cljs$lang$maxFixedArity = 4);

/**
 * f should be a function of 2 arguments. Returns a channel containing
 *   the single result of applying f to init and the first item from the
 *   channel, then applying f to that result and the 2nd item, etc. If
 *   the channel closes without yielding items, returns init and f is not
 *   called. ch must close before reduce produces a result.
 */
cljs.core.async.reduce = (function cljs$core$async$reduce(f,init,ch){
var c__27715__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_30066){
var state_val_30067 = (state_30066[(1)]);
if((state_val_30067 === (7))){
var inst_30062 = (state_30066[(2)]);
var state_30066__$1 = state_30066;
var statearr_30068_30086 = state_30066__$1;
(statearr_30068_30086[(2)] = inst_30062);

(statearr_30068_30086[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30067 === (1))){
var inst_30046 = init;
var state_30066__$1 = (function (){var statearr_30069 = state_30066;
(statearr_30069[(7)] = inst_30046);

return statearr_30069;
})();
var statearr_30070_30087 = state_30066__$1;
(statearr_30070_30087[(2)] = null);

(statearr_30070_30087[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30067 === (4))){
var inst_30049 = (state_30066[(8)]);
var inst_30049__$1 = (state_30066[(2)]);
var inst_30050 = (inst_30049__$1 == null);
var state_30066__$1 = (function (){var statearr_30071 = state_30066;
(statearr_30071[(8)] = inst_30049__$1);

return statearr_30071;
})();
if(cljs.core.truth_(inst_30050)){
var statearr_30072_30088 = state_30066__$1;
(statearr_30072_30088[(1)] = (5));

} else {
var statearr_30073_30089 = state_30066__$1;
(statearr_30073_30089[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30067 === (6))){
var inst_30053 = (state_30066[(9)]);
var inst_30046 = (state_30066[(7)]);
var inst_30049 = (state_30066[(8)]);
var inst_30053__$1 = (f.cljs$core$IFn$_invoke$arity$2 ? f.cljs$core$IFn$_invoke$arity$2(inst_30046,inst_30049) : f.call(null,inst_30046,inst_30049));
var inst_30054 = cljs.core.reduced_QMARK_(inst_30053__$1);
var state_30066__$1 = (function (){var statearr_30074 = state_30066;
(statearr_30074[(9)] = inst_30053__$1);

return statearr_30074;
})();
if(inst_30054){
var statearr_30075_30090 = state_30066__$1;
(statearr_30075_30090[(1)] = (8));

} else {
var statearr_30076_30091 = state_30066__$1;
(statearr_30076_30091[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30067 === (3))){
var inst_30064 = (state_30066[(2)]);
var state_30066__$1 = state_30066;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30066__$1,inst_30064);
} else {
if((state_val_30067 === (2))){
var state_30066__$1 = state_30066;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_30066__$1,(4),ch);
} else {
if((state_val_30067 === (9))){
var inst_30053 = (state_30066[(9)]);
var inst_30046 = inst_30053;
var state_30066__$1 = (function (){var statearr_30077 = state_30066;
(statearr_30077[(7)] = inst_30046);

return statearr_30077;
})();
var statearr_30078_30092 = state_30066__$1;
(statearr_30078_30092[(2)] = null);

(statearr_30078_30092[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30067 === (5))){
var inst_30046 = (state_30066[(7)]);
var state_30066__$1 = state_30066;
var statearr_30079_30093 = state_30066__$1;
(statearr_30079_30093[(2)] = inst_30046);

(statearr_30079_30093[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30067 === (10))){
var inst_30060 = (state_30066[(2)]);
var state_30066__$1 = state_30066;
var statearr_30080_30094 = state_30066__$1;
(statearr_30080_30094[(2)] = inst_30060);

(statearr_30080_30094[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30067 === (8))){
var inst_30053 = (state_30066[(9)]);
var inst_30056 = cljs.core.deref(inst_30053);
var state_30066__$1 = state_30066;
var statearr_30081_30095 = state_30066__$1;
(statearr_30081_30095[(2)] = inst_30056);

(statearr_30081_30095[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$reduce_$_state_machine__27525__auto__ = null;
var cljs$core$async$reduce_$_state_machine__27525__auto____0 = (function (){
var statearr_30082 = [null,null,null,null,null,null,null,null,null,null];
(statearr_30082[(0)] = cljs$core$async$reduce_$_state_machine__27525__auto__);

(statearr_30082[(1)] = (1));

return statearr_30082;
});
var cljs$core$async$reduce_$_state_machine__27525__auto____1 = (function (state_30066){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_30066);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e30083){if((e30083 instanceof Object)){
var ex__27528__auto__ = e30083;
var statearr_30084_30096 = state_30066;
(statearr_30084_30096[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30066);

return cljs.core.cst$kw$recur;
} else {
throw e30083;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__30097 = state_30066;
state_30066 = G__30097;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$reduce_$_state_machine__27525__auto__ = function(state_30066){
switch(arguments.length){
case 0:
return cljs$core$async$reduce_$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$reduce_$_state_machine__27525__auto____1.call(this,state_30066);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$reduce_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$reduce_$_state_machine__27525__auto____0;
cljs$core$async$reduce_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$reduce_$_state_machine__27525__auto____1;
return cljs$core$async$reduce_$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_30085 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_30085[(6)] = c__27715__auto__);

return statearr_30085;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));

return c__27715__auto__;
});
/**
 * async/reduces a channel with a transformation (xform f).
 *   Returns a channel containing the result.  ch must close before
 *   transduce produces a result.
 */
cljs.core.async.transduce = (function cljs$core$async$transduce(xform,f,init,ch){
var f__$1 = (xform.cljs$core$IFn$_invoke$arity$1 ? xform.cljs$core$IFn$_invoke$arity$1(f) : xform.call(null,f));
var c__27715__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_30103){
var state_val_30104 = (state_30103[(1)]);
if((state_val_30104 === (1))){
var inst_30098 = cljs.core.async.reduce(f__$1,init,ch);
var state_30103__$1 = state_30103;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_30103__$1,(2),inst_30098);
} else {
if((state_val_30104 === (2))){
var inst_30100 = (state_30103[(2)]);
var inst_30101 = (f__$1.cljs$core$IFn$_invoke$arity$1 ? f__$1.cljs$core$IFn$_invoke$arity$1(inst_30100) : f__$1.call(null,inst_30100));
var state_30103__$1 = state_30103;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30103__$1,inst_30101);
} else {
return null;
}
}
});
return (function() {
var cljs$core$async$transduce_$_state_machine__27525__auto__ = null;
var cljs$core$async$transduce_$_state_machine__27525__auto____0 = (function (){
var statearr_30105 = [null,null,null,null,null,null,null];
(statearr_30105[(0)] = cljs$core$async$transduce_$_state_machine__27525__auto__);

(statearr_30105[(1)] = (1));

return statearr_30105;
});
var cljs$core$async$transduce_$_state_machine__27525__auto____1 = (function (state_30103){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_30103);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e30106){if((e30106 instanceof Object)){
var ex__27528__auto__ = e30106;
var statearr_30107_30109 = state_30103;
(statearr_30107_30109[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30103);

return cljs.core.cst$kw$recur;
} else {
throw e30106;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__30110 = state_30103;
state_30103 = G__30110;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$transduce_$_state_machine__27525__auto__ = function(state_30103){
switch(arguments.length){
case 0:
return cljs$core$async$transduce_$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$transduce_$_state_machine__27525__auto____1.call(this,state_30103);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$transduce_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$transduce_$_state_machine__27525__auto____0;
cljs$core$async$transduce_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$transduce_$_state_machine__27525__auto____1;
return cljs$core$async$transduce_$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_30108 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_30108[(6)] = c__27715__auto__);

return statearr_30108;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));

return c__27715__auto__;
});
/**
 * Puts the contents of coll into the supplied channel.
 * 
 *   By default the channel will be closed after the items are copied,
 *   but can be determined by the close? parameter.
 * 
 *   Returns a channel which will close after the items are copied.
 */
cljs.core.async.onto_chan = (function cljs$core$async$onto_chan(var_args){
var G__30112 = arguments.length;
switch (G__30112) {
case 2:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2 = (function (ch,coll){
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3(ch,coll,true);
}));

(cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3 = (function (ch,coll,close_QMARK_){
var c__27715__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_30137){
var state_val_30138 = (state_30137[(1)]);
if((state_val_30138 === (7))){
var inst_30119 = (state_30137[(2)]);
var state_30137__$1 = state_30137;
var statearr_30139_30160 = state_30137__$1;
(statearr_30139_30160[(2)] = inst_30119);

(statearr_30139_30160[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30138 === (1))){
var inst_30113 = cljs.core.seq(coll);
var inst_30114 = inst_30113;
var state_30137__$1 = (function (){var statearr_30140 = state_30137;
(statearr_30140[(7)] = inst_30114);

return statearr_30140;
})();
var statearr_30141_30161 = state_30137__$1;
(statearr_30141_30161[(2)] = null);

(statearr_30141_30161[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30138 === (4))){
var inst_30114 = (state_30137[(7)]);
var inst_30117 = cljs.core.first(inst_30114);
var state_30137__$1 = state_30137;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30137__$1,(7),ch,inst_30117);
} else {
if((state_val_30138 === (13))){
var inst_30131 = (state_30137[(2)]);
var state_30137__$1 = state_30137;
var statearr_30142_30162 = state_30137__$1;
(statearr_30142_30162[(2)] = inst_30131);

(statearr_30142_30162[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30138 === (6))){
var inst_30122 = (state_30137[(2)]);
var state_30137__$1 = state_30137;
if(cljs.core.truth_(inst_30122)){
var statearr_30143_30163 = state_30137__$1;
(statearr_30143_30163[(1)] = (8));

} else {
var statearr_30144_30164 = state_30137__$1;
(statearr_30144_30164[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30138 === (3))){
var inst_30135 = (state_30137[(2)]);
var state_30137__$1 = state_30137;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30137__$1,inst_30135);
} else {
if((state_val_30138 === (12))){
var state_30137__$1 = state_30137;
var statearr_30145_30165 = state_30137__$1;
(statearr_30145_30165[(2)] = null);

(statearr_30145_30165[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30138 === (2))){
var inst_30114 = (state_30137[(7)]);
var state_30137__$1 = state_30137;
if(cljs.core.truth_(inst_30114)){
var statearr_30146_30166 = state_30137__$1;
(statearr_30146_30166[(1)] = (4));

} else {
var statearr_30147_30167 = state_30137__$1;
(statearr_30147_30167[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30138 === (11))){
var inst_30128 = cljs.core.async.close_BANG_(ch);
var state_30137__$1 = state_30137;
var statearr_30148_30168 = state_30137__$1;
(statearr_30148_30168[(2)] = inst_30128);

(statearr_30148_30168[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30138 === (9))){
var state_30137__$1 = state_30137;
if(cljs.core.truth_(close_QMARK_)){
var statearr_30149_30169 = state_30137__$1;
(statearr_30149_30169[(1)] = (11));

} else {
var statearr_30150_30170 = state_30137__$1;
(statearr_30150_30170[(1)] = (12));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30138 === (5))){
var inst_30114 = (state_30137[(7)]);
var state_30137__$1 = state_30137;
var statearr_30151_30171 = state_30137__$1;
(statearr_30151_30171[(2)] = inst_30114);

(statearr_30151_30171[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30138 === (10))){
var inst_30133 = (state_30137[(2)]);
var state_30137__$1 = state_30137;
var statearr_30152_30172 = state_30137__$1;
(statearr_30152_30172[(2)] = inst_30133);

(statearr_30152_30172[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30138 === (8))){
var inst_30114 = (state_30137[(7)]);
var inst_30124 = cljs.core.next(inst_30114);
var inst_30114__$1 = inst_30124;
var state_30137__$1 = (function (){var statearr_30153 = state_30137;
(statearr_30153[(7)] = inst_30114__$1);

return statearr_30153;
})();
var statearr_30154_30173 = state_30137__$1;
(statearr_30154_30173[(2)] = null);

(statearr_30154_30173[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_30155 = [null,null,null,null,null,null,null,null];
(statearr_30155[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_30155[(1)] = (1));

return statearr_30155;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_30137){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_30137);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e30156){if((e30156 instanceof Object)){
var ex__27528__auto__ = e30156;
var statearr_30157_30174 = state_30137;
(statearr_30157_30174[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30137);

return cljs.core.cst$kw$recur;
} else {
throw e30156;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__30175 = state_30137;
state_30137 = G__30175;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_30137){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_30137);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_30158 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_30158[(6)] = c__27715__auto__);

return statearr_30158;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));

return c__27715__auto__;
}));

(cljs.core.async.onto_chan.cljs$lang$maxFixedArity = 3);

/**
 * Creates and returns a channel which contains the contents of coll,
 *   closing when exhausted.
 */
cljs.core.async.to_chan = (function cljs$core$async$to_chan(coll){
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(cljs.core.bounded_count((100),coll));
cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2(ch,coll);

return ch;
});

/**
 * @interface
 */
cljs.core.async.Mux = function(){};

cljs.core.async.muxch_STAR_ = (function cljs$core$async$muxch_STAR_(_){
if((((!((_ == null)))) && ((!((_.cljs$core$async$Mux$muxch_STAR_$arity$1 == null)))))){
return _.cljs$core$async$Mux$muxch_STAR_$arity$1(_);
} else {
var x__4487__auto__ = (((_ == null))?null:_);
var m__4488__auto__ = (cljs.core.async.muxch_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$1(_) : m__4488__auto__.call(null,_));
} else {
var m__4485__auto__ = (cljs.core.async.muxch_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$1(_) : m__4485__auto__.call(null,_));
} else {
throw cljs.core.missing_protocol("Mux.muxch*",_);
}
}
}
});


/**
 * @interface
 */
cljs.core.async.Mult = function(){};

cljs.core.async.tap_STAR_ = (function cljs$core$async$tap_STAR_(m,ch,close_QMARK_){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$tap_STAR_$arity$3 == null)))))){
return m.cljs$core$async$Mult$tap_STAR_$arity$3(m,ch,close_QMARK_);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.tap_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__4488__auto__.call(null,m,ch,close_QMARK_));
} else {
var m__4485__auto__ = (cljs.core.async.tap_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__4485__auto__.call(null,m,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Mult.tap*",m);
}
}
}
});

cljs.core.async.untap_STAR_ = (function cljs$core$async$untap_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mult$untap_STAR_$arity$2(m,ch);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.untap_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4488__auto__.call(null,m,ch));
} else {
var m__4485__auto__ = (cljs.core.async.untap_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4485__auto__.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mult.untap*",m);
}
}
}
});

cljs.core.async.untap_all_STAR_ = (function cljs$core$async$untap_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mult$untap_all_STAR_$arity$1(m);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.untap_all_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4488__auto__.call(null,m));
} else {
var m__4485__auto__ = (cljs.core.async.untap_all_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4485__auto__.call(null,m));
} else {
throw cljs.core.missing_protocol("Mult.untap-all*",m);
}
}
}
});

/**
 * Creates and returns a mult(iple) of the supplied channel. Channels
 *   containing copies of the channel can be created with 'tap', and
 *   detached with 'untap'.
 * 
 *   Each item is distributed to all taps in parallel and synchronously,
 *   i.e. each tap must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow taps from holding up the mult.
 * 
 *   Items received when there are no taps get dropped.
 * 
 *   If a tap puts to a closed channel, it will be removed from the mult.
 */
cljs.core.async.mult = (function cljs$core$async$mult(ch){
var cs = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async30176 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Mult}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async30176 = (function (ch,cs,meta30177){
this.ch = ch;
this.cs = cs;
this.meta30177 = meta30177;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async30176.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_30178,meta30177__$1){
var self__ = this;
var _30178__$1 = this;
return (new cljs.core.async.t_cljs$core$async30176(self__.ch,self__.cs,meta30177__$1));
}));

(cljs.core.async.t_cljs$core$async30176.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_30178){
var self__ = this;
var _30178__$1 = this;
return self__.meta30177;
}));

(cljs.core.async.t_cljs$core$async30176.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async30176.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
}));

(cljs.core.async.t_cljs$core$async30176.prototype.cljs$core$async$Mult$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async30176.prototype.cljs$core$async$Mult$tap_STAR_$arity$3 = (function (_,ch__$1,close_QMARK_){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch__$1,close_QMARK_);

return null;
}));

(cljs.core.async.t_cljs$core$async30176.prototype.cljs$core$async$Mult$untap_STAR_$arity$2 = (function (_,ch__$1){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch__$1);

return null;
}));

(cljs.core.async.t_cljs$core$async30176.prototype.cljs$core$async$Mult$untap_all_STAR_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return null;
}));

(cljs.core.async.t_cljs$core$async30176.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch,cljs.core.cst$sym$cs,cljs.core.cst$sym$meta30177], null);
}));

(cljs.core.async.t_cljs$core$async30176.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async30176.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async30176");

(cljs.core.async.t_cljs$core$async30176.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write(writer__4429__auto__,"cljs.core.async/t_cljs$core$async30176");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async30176.
 */
cljs.core.async.__GT_t_cljs$core$async30176 = (function cljs$core$async$mult_$___GT_t_cljs$core$async30176(ch__$1,cs__$1,meta30177){
return (new cljs.core.async.t_cljs$core$async30176(ch__$1,cs__$1,meta30177));
});

}

return (new cljs.core.async.t_cljs$core$async30176(ch,cs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
var done = (function (_){
if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,true);
} else {
return null;
}
});
var c__27715__auto___30394 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_30311){
var state_val_30312 = (state_30311[(1)]);
if((state_val_30312 === (7))){
var inst_30307 = (state_30311[(2)]);
var state_30311__$1 = state_30311;
var statearr_30313_30395 = state_30311__$1;
(statearr_30313_30395[(2)] = inst_30307);

(statearr_30313_30395[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (20))){
var inst_30212 = (state_30311[(7)]);
var inst_30224 = cljs.core.first(inst_30212);
var inst_30225 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_30224,(0),null);
var inst_30226 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_30224,(1),null);
var state_30311__$1 = (function (){var statearr_30314 = state_30311;
(statearr_30314[(8)] = inst_30225);

return statearr_30314;
})();
if(cljs.core.truth_(inst_30226)){
var statearr_30315_30396 = state_30311__$1;
(statearr_30315_30396[(1)] = (22));

} else {
var statearr_30316_30397 = state_30311__$1;
(statearr_30316_30397[(1)] = (23));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (27))){
var inst_30256 = (state_30311[(9)]);
var inst_30181 = (state_30311[(10)]);
var inst_30254 = (state_30311[(11)]);
var inst_30261 = (state_30311[(12)]);
var inst_30261__$1 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_30254,inst_30256);
var inst_30262 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_30261__$1,inst_30181,done);
var state_30311__$1 = (function (){var statearr_30317 = state_30311;
(statearr_30317[(12)] = inst_30261__$1);

return statearr_30317;
})();
if(cljs.core.truth_(inst_30262)){
var statearr_30318_30398 = state_30311__$1;
(statearr_30318_30398[(1)] = (30));

} else {
var statearr_30319_30399 = state_30311__$1;
(statearr_30319_30399[(1)] = (31));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (1))){
var state_30311__$1 = state_30311;
var statearr_30320_30400 = state_30311__$1;
(statearr_30320_30400[(2)] = null);

(statearr_30320_30400[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (24))){
var inst_30212 = (state_30311[(7)]);
var inst_30231 = (state_30311[(2)]);
var inst_30232 = cljs.core.next(inst_30212);
var inst_30190 = inst_30232;
var inst_30191 = null;
var inst_30192 = (0);
var inst_30193 = (0);
var state_30311__$1 = (function (){var statearr_30321 = state_30311;
(statearr_30321[(13)] = inst_30193);

(statearr_30321[(14)] = inst_30192);

(statearr_30321[(15)] = inst_30191);

(statearr_30321[(16)] = inst_30190);

(statearr_30321[(17)] = inst_30231);

return statearr_30321;
})();
var statearr_30322_30401 = state_30311__$1;
(statearr_30322_30401[(2)] = null);

(statearr_30322_30401[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (39))){
var state_30311__$1 = state_30311;
var statearr_30326_30402 = state_30311__$1;
(statearr_30326_30402[(2)] = null);

(statearr_30326_30402[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (4))){
var inst_30181 = (state_30311[(10)]);
var inst_30181__$1 = (state_30311[(2)]);
var inst_30182 = (inst_30181__$1 == null);
var state_30311__$1 = (function (){var statearr_30327 = state_30311;
(statearr_30327[(10)] = inst_30181__$1);

return statearr_30327;
})();
if(cljs.core.truth_(inst_30182)){
var statearr_30328_30403 = state_30311__$1;
(statearr_30328_30403[(1)] = (5));

} else {
var statearr_30329_30404 = state_30311__$1;
(statearr_30329_30404[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (15))){
var inst_30193 = (state_30311[(13)]);
var inst_30192 = (state_30311[(14)]);
var inst_30191 = (state_30311[(15)]);
var inst_30190 = (state_30311[(16)]);
var inst_30208 = (state_30311[(2)]);
var inst_30209 = (inst_30193 + (1));
var tmp30323 = inst_30192;
var tmp30324 = inst_30191;
var tmp30325 = inst_30190;
var inst_30190__$1 = tmp30325;
var inst_30191__$1 = tmp30324;
var inst_30192__$1 = tmp30323;
var inst_30193__$1 = inst_30209;
var state_30311__$1 = (function (){var statearr_30330 = state_30311;
(statearr_30330[(13)] = inst_30193__$1);

(statearr_30330[(14)] = inst_30192__$1);

(statearr_30330[(15)] = inst_30191__$1);

(statearr_30330[(18)] = inst_30208);

(statearr_30330[(16)] = inst_30190__$1);

return statearr_30330;
})();
var statearr_30331_30405 = state_30311__$1;
(statearr_30331_30405[(2)] = null);

(statearr_30331_30405[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (21))){
var inst_30235 = (state_30311[(2)]);
var state_30311__$1 = state_30311;
var statearr_30335_30406 = state_30311__$1;
(statearr_30335_30406[(2)] = inst_30235);

(statearr_30335_30406[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (31))){
var inst_30261 = (state_30311[(12)]);
var inst_30265 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_30261);
var state_30311__$1 = state_30311;
var statearr_30336_30407 = state_30311__$1;
(statearr_30336_30407[(2)] = inst_30265);

(statearr_30336_30407[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (32))){
var inst_30253 = (state_30311[(19)]);
var inst_30255 = (state_30311[(20)]);
var inst_30256 = (state_30311[(9)]);
var inst_30254 = (state_30311[(11)]);
var inst_30267 = (state_30311[(2)]);
var inst_30268 = (inst_30256 + (1));
var tmp30332 = inst_30253;
var tmp30333 = inst_30255;
var tmp30334 = inst_30254;
var inst_30253__$1 = tmp30332;
var inst_30254__$1 = tmp30334;
var inst_30255__$1 = tmp30333;
var inst_30256__$1 = inst_30268;
var state_30311__$1 = (function (){var statearr_30337 = state_30311;
(statearr_30337[(19)] = inst_30253__$1);

(statearr_30337[(20)] = inst_30255__$1);

(statearr_30337[(9)] = inst_30256__$1);

(statearr_30337[(11)] = inst_30254__$1);

(statearr_30337[(21)] = inst_30267);

return statearr_30337;
})();
var statearr_30338_30408 = state_30311__$1;
(statearr_30338_30408[(2)] = null);

(statearr_30338_30408[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (40))){
var inst_30280 = (state_30311[(22)]);
var inst_30284 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_30280);
var state_30311__$1 = state_30311;
var statearr_30339_30409 = state_30311__$1;
(statearr_30339_30409[(2)] = inst_30284);

(statearr_30339_30409[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (33))){
var inst_30271 = (state_30311[(23)]);
var inst_30273 = cljs.core.chunked_seq_QMARK_(inst_30271);
var state_30311__$1 = state_30311;
if(inst_30273){
var statearr_30340_30410 = state_30311__$1;
(statearr_30340_30410[(1)] = (36));

} else {
var statearr_30341_30411 = state_30311__$1;
(statearr_30341_30411[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (13))){
var inst_30202 = (state_30311[(24)]);
var inst_30205 = cljs.core.async.close_BANG_(inst_30202);
var state_30311__$1 = state_30311;
var statearr_30342_30412 = state_30311__$1;
(statearr_30342_30412[(2)] = inst_30205);

(statearr_30342_30412[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (22))){
var inst_30225 = (state_30311[(8)]);
var inst_30228 = cljs.core.async.close_BANG_(inst_30225);
var state_30311__$1 = state_30311;
var statearr_30343_30413 = state_30311__$1;
(statearr_30343_30413[(2)] = inst_30228);

(statearr_30343_30413[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (36))){
var inst_30271 = (state_30311[(23)]);
var inst_30275 = cljs.core.chunk_first(inst_30271);
var inst_30276 = cljs.core.chunk_rest(inst_30271);
var inst_30277 = cljs.core.count(inst_30275);
var inst_30253 = inst_30276;
var inst_30254 = inst_30275;
var inst_30255 = inst_30277;
var inst_30256 = (0);
var state_30311__$1 = (function (){var statearr_30344 = state_30311;
(statearr_30344[(19)] = inst_30253);

(statearr_30344[(20)] = inst_30255);

(statearr_30344[(9)] = inst_30256);

(statearr_30344[(11)] = inst_30254);

return statearr_30344;
})();
var statearr_30345_30414 = state_30311__$1;
(statearr_30345_30414[(2)] = null);

(statearr_30345_30414[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (41))){
var inst_30271 = (state_30311[(23)]);
var inst_30286 = (state_30311[(2)]);
var inst_30287 = cljs.core.next(inst_30271);
var inst_30253 = inst_30287;
var inst_30254 = null;
var inst_30255 = (0);
var inst_30256 = (0);
var state_30311__$1 = (function (){var statearr_30346 = state_30311;
(statearr_30346[(19)] = inst_30253);

(statearr_30346[(20)] = inst_30255);

(statearr_30346[(9)] = inst_30256);

(statearr_30346[(25)] = inst_30286);

(statearr_30346[(11)] = inst_30254);

return statearr_30346;
})();
var statearr_30347_30415 = state_30311__$1;
(statearr_30347_30415[(2)] = null);

(statearr_30347_30415[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (43))){
var state_30311__$1 = state_30311;
var statearr_30348_30416 = state_30311__$1;
(statearr_30348_30416[(2)] = null);

(statearr_30348_30416[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (29))){
var inst_30295 = (state_30311[(2)]);
var state_30311__$1 = state_30311;
var statearr_30349_30417 = state_30311__$1;
(statearr_30349_30417[(2)] = inst_30295);

(statearr_30349_30417[(1)] = (26));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (44))){
var inst_30304 = (state_30311[(2)]);
var state_30311__$1 = (function (){var statearr_30350 = state_30311;
(statearr_30350[(26)] = inst_30304);

return statearr_30350;
})();
var statearr_30351_30418 = state_30311__$1;
(statearr_30351_30418[(2)] = null);

(statearr_30351_30418[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (6))){
var inst_30245 = (state_30311[(27)]);
var inst_30244 = cljs.core.deref(cs);
var inst_30245__$1 = cljs.core.keys(inst_30244);
var inst_30246 = cljs.core.count(inst_30245__$1);
var inst_30247 = cljs.core.reset_BANG_(dctr,inst_30246);
var inst_30252 = cljs.core.seq(inst_30245__$1);
var inst_30253 = inst_30252;
var inst_30254 = null;
var inst_30255 = (0);
var inst_30256 = (0);
var state_30311__$1 = (function (){var statearr_30352 = state_30311;
(statearr_30352[(27)] = inst_30245__$1);

(statearr_30352[(19)] = inst_30253);

(statearr_30352[(20)] = inst_30255);

(statearr_30352[(28)] = inst_30247);

(statearr_30352[(9)] = inst_30256);

(statearr_30352[(11)] = inst_30254);

return statearr_30352;
})();
var statearr_30353_30419 = state_30311__$1;
(statearr_30353_30419[(2)] = null);

(statearr_30353_30419[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (28))){
var inst_30253 = (state_30311[(19)]);
var inst_30271 = (state_30311[(23)]);
var inst_30271__$1 = cljs.core.seq(inst_30253);
var state_30311__$1 = (function (){var statearr_30354 = state_30311;
(statearr_30354[(23)] = inst_30271__$1);

return statearr_30354;
})();
if(inst_30271__$1){
var statearr_30355_30420 = state_30311__$1;
(statearr_30355_30420[(1)] = (33));

} else {
var statearr_30356_30421 = state_30311__$1;
(statearr_30356_30421[(1)] = (34));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (25))){
var inst_30255 = (state_30311[(20)]);
var inst_30256 = (state_30311[(9)]);
var inst_30258 = (inst_30256 < inst_30255);
var inst_30259 = inst_30258;
var state_30311__$1 = state_30311;
if(cljs.core.truth_(inst_30259)){
var statearr_30357_30422 = state_30311__$1;
(statearr_30357_30422[(1)] = (27));

} else {
var statearr_30358_30423 = state_30311__$1;
(statearr_30358_30423[(1)] = (28));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (34))){
var state_30311__$1 = state_30311;
var statearr_30359_30424 = state_30311__$1;
(statearr_30359_30424[(2)] = null);

(statearr_30359_30424[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (17))){
var state_30311__$1 = state_30311;
var statearr_30360_30425 = state_30311__$1;
(statearr_30360_30425[(2)] = null);

(statearr_30360_30425[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (3))){
var inst_30309 = (state_30311[(2)]);
var state_30311__$1 = state_30311;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30311__$1,inst_30309);
} else {
if((state_val_30312 === (12))){
var inst_30240 = (state_30311[(2)]);
var state_30311__$1 = state_30311;
var statearr_30361_30426 = state_30311__$1;
(statearr_30361_30426[(2)] = inst_30240);

(statearr_30361_30426[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (2))){
var state_30311__$1 = state_30311;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_30311__$1,(4),ch);
} else {
if((state_val_30312 === (23))){
var state_30311__$1 = state_30311;
var statearr_30362_30427 = state_30311__$1;
(statearr_30362_30427[(2)] = null);

(statearr_30362_30427[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (35))){
var inst_30293 = (state_30311[(2)]);
var state_30311__$1 = state_30311;
var statearr_30363_30428 = state_30311__$1;
(statearr_30363_30428[(2)] = inst_30293);

(statearr_30363_30428[(1)] = (29));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (19))){
var inst_30212 = (state_30311[(7)]);
var inst_30216 = cljs.core.chunk_first(inst_30212);
var inst_30217 = cljs.core.chunk_rest(inst_30212);
var inst_30218 = cljs.core.count(inst_30216);
var inst_30190 = inst_30217;
var inst_30191 = inst_30216;
var inst_30192 = inst_30218;
var inst_30193 = (0);
var state_30311__$1 = (function (){var statearr_30364 = state_30311;
(statearr_30364[(13)] = inst_30193);

(statearr_30364[(14)] = inst_30192);

(statearr_30364[(15)] = inst_30191);

(statearr_30364[(16)] = inst_30190);

return statearr_30364;
})();
var statearr_30365_30429 = state_30311__$1;
(statearr_30365_30429[(2)] = null);

(statearr_30365_30429[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (11))){
var inst_30212 = (state_30311[(7)]);
var inst_30190 = (state_30311[(16)]);
var inst_30212__$1 = cljs.core.seq(inst_30190);
var state_30311__$1 = (function (){var statearr_30366 = state_30311;
(statearr_30366[(7)] = inst_30212__$1);

return statearr_30366;
})();
if(inst_30212__$1){
var statearr_30367_30430 = state_30311__$1;
(statearr_30367_30430[(1)] = (16));

} else {
var statearr_30368_30431 = state_30311__$1;
(statearr_30368_30431[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (9))){
var inst_30242 = (state_30311[(2)]);
var state_30311__$1 = state_30311;
var statearr_30369_30432 = state_30311__$1;
(statearr_30369_30432[(2)] = inst_30242);

(statearr_30369_30432[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (5))){
var inst_30188 = cljs.core.deref(cs);
var inst_30189 = cljs.core.seq(inst_30188);
var inst_30190 = inst_30189;
var inst_30191 = null;
var inst_30192 = (0);
var inst_30193 = (0);
var state_30311__$1 = (function (){var statearr_30370 = state_30311;
(statearr_30370[(13)] = inst_30193);

(statearr_30370[(14)] = inst_30192);

(statearr_30370[(15)] = inst_30191);

(statearr_30370[(16)] = inst_30190);

return statearr_30370;
})();
var statearr_30371_30433 = state_30311__$1;
(statearr_30371_30433[(2)] = null);

(statearr_30371_30433[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (14))){
var state_30311__$1 = state_30311;
var statearr_30372_30434 = state_30311__$1;
(statearr_30372_30434[(2)] = null);

(statearr_30372_30434[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (45))){
var inst_30301 = (state_30311[(2)]);
var state_30311__$1 = state_30311;
var statearr_30373_30435 = state_30311__$1;
(statearr_30373_30435[(2)] = inst_30301);

(statearr_30373_30435[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (26))){
var inst_30245 = (state_30311[(27)]);
var inst_30297 = (state_30311[(2)]);
var inst_30298 = cljs.core.seq(inst_30245);
var state_30311__$1 = (function (){var statearr_30374 = state_30311;
(statearr_30374[(29)] = inst_30297);

return statearr_30374;
})();
if(inst_30298){
var statearr_30375_30436 = state_30311__$1;
(statearr_30375_30436[(1)] = (42));

} else {
var statearr_30376_30437 = state_30311__$1;
(statearr_30376_30437[(1)] = (43));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (16))){
var inst_30212 = (state_30311[(7)]);
var inst_30214 = cljs.core.chunked_seq_QMARK_(inst_30212);
var state_30311__$1 = state_30311;
if(inst_30214){
var statearr_30377_30438 = state_30311__$1;
(statearr_30377_30438[(1)] = (19));

} else {
var statearr_30378_30439 = state_30311__$1;
(statearr_30378_30439[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (38))){
var inst_30290 = (state_30311[(2)]);
var state_30311__$1 = state_30311;
var statearr_30379_30440 = state_30311__$1;
(statearr_30379_30440[(2)] = inst_30290);

(statearr_30379_30440[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (30))){
var state_30311__$1 = state_30311;
var statearr_30380_30441 = state_30311__$1;
(statearr_30380_30441[(2)] = null);

(statearr_30380_30441[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (10))){
var inst_30193 = (state_30311[(13)]);
var inst_30191 = (state_30311[(15)]);
var inst_30201 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_30191,inst_30193);
var inst_30202 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_30201,(0),null);
var inst_30203 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_30201,(1),null);
var state_30311__$1 = (function (){var statearr_30381 = state_30311;
(statearr_30381[(24)] = inst_30202);

return statearr_30381;
})();
if(cljs.core.truth_(inst_30203)){
var statearr_30382_30442 = state_30311__$1;
(statearr_30382_30442[(1)] = (13));

} else {
var statearr_30383_30443 = state_30311__$1;
(statearr_30383_30443[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (18))){
var inst_30238 = (state_30311[(2)]);
var state_30311__$1 = state_30311;
var statearr_30384_30444 = state_30311__$1;
(statearr_30384_30444[(2)] = inst_30238);

(statearr_30384_30444[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (42))){
var state_30311__$1 = state_30311;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_30311__$1,(45),dchan);
} else {
if((state_val_30312 === (37))){
var inst_30271 = (state_30311[(23)]);
var inst_30280 = (state_30311[(22)]);
var inst_30181 = (state_30311[(10)]);
var inst_30280__$1 = cljs.core.first(inst_30271);
var inst_30281 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_30280__$1,inst_30181,done);
var state_30311__$1 = (function (){var statearr_30385 = state_30311;
(statearr_30385[(22)] = inst_30280__$1);

return statearr_30385;
})();
if(cljs.core.truth_(inst_30281)){
var statearr_30386_30445 = state_30311__$1;
(statearr_30386_30445[(1)] = (39));

} else {
var statearr_30387_30446 = state_30311__$1;
(statearr_30387_30446[(1)] = (40));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30312 === (8))){
var inst_30193 = (state_30311[(13)]);
var inst_30192 = (state_30311[(14)]);
var inst_30195 = (inst_30193 < inst_30192);
var inst_30196 = inst_30195;
var state_30311__$1 = state_30311;
if(cljs.core.truth_(inst_30196)){
var statearr_30388_30447 = state_30311__$1;
(statearr_30388_30447[(1)] = (10));

} else {
var statearr_30389_30448 = state_30311__$1;
(statearr_30389_30448[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$mult_$_state_machine__27525__auto__ = null;
var cljs$core$async$mult_$_state_machine__27525__auto____0 = (function (){
var statearr_30390 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_30390[(0)] = cljs$core$async$mult_$_state_machine__27525__auto__);

(statearr_30390[(1)] = (1));

return statearr_30390;
});
var cljs$core$async$mult_$_state_machine__27525__auto____1 = (function (state_30311){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_30311);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e30391){if((e30391 instanceof Object)){
var ex__27528__auto__ = e30391;
var statearr_30392_30449 = state_30311;
(statearr_30392_30449[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30311);

return cljs.core.cst$kw$recur;
} else {
throw e30391;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__30450 = state_30311;
state_30311 = G__30450;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$mult_$_state_machine__27525__auto__ = function(state_30311){
switch(arguments.length){
case 0:
return cljs$core$async$mult_$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$mult_$_state_machine__27525__auto____1.call(this,state_30311);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mult_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mult_$_state_machine__27525__auto____0;
cljs$core$async$mult_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mult_$_state_machine__27525__auto____1;
return cljs$core$async$mult_$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_30393 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_30393[(6)] = c__27715__auto___30394);

return statearr_30393;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));


return m;
});
/**
 * Copies the mult source onto the supplied channel.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.tap = (function cljs$core$async$tap(var_args){
var G__30452 = arguments.length;
switch (G__30452) {
case 2:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2 = (function (mult,ch){
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(mult,ch,true);
}));

(cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3 = (function (mult,ch,close_QMARK_){
cljs.core.async.tap_STAR_(mult,ch,close_QMARK_);

return ch;
}));

(cljs.core.async.tap.cljs$lang$maxFixedArity = 3);

/**
 * Disconnects a target channel from a mult
 */
cljs.core.async.untap = (function cljs$core$async$untap(mult,ch){
return cljs.core.async.untap_STAR_(mult,ch);
});
/**
 * Disconnects all target channels from a mult
 */
cljs.core.async.untap_all = (function cljs$core$async$untap_all(mult){
return cljs.core.async.untap_all_STAR_(mult);
});

/**
 * @interface
 */
cljs.core.async.Mix = function(){};

cljs.core.async.admix_STAR_ = (function cljs$core$async$admix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$admix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$admix_STAR_$arity$2(m,ch);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.admix_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4488__auto__.call(null,m,ch));
} else {
var m__4485__auto__ = (cljs.core.async.admix_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4485__auto__.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.admix*",m);
}
}
}
});

cljs.core.async.unmix_STAR_ = (function cljs$core$async$unmix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$unmix_STAR_$arity$2(m,ch);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.unmix_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4488__auto__.call(null,m,ch));
} else {
var m__4485__auto__ = (cljs.core.async.unmix_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4485__auto__.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.unmix*",m);
}
}
}
});

cljs.core.async.unmix_all_STAR_ = (function cljs$core$async$unmix_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mix$unmix_all_STAR_$arity$1(m);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.unmix_all_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4488__auto__.call(null,m));
} else {
var m__4485__auto__ = (cljs.core.async.unmix_all_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4485__auto__.call(null,m));
} else {
throw cljs.core.missing_protocol("Mix.unmix-all*",m);
}
}
}
});

cljs.core.async.toggle_STAR_ = (function cljs$core$async$toggle_STAR_(m,state_map){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$toggle_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$toggle_STAR_$arity$2(m,state_map);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.toggle_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__4488__auto__.call(null,m,state_map));
} else {
var m__4485__auto__ = (cljs.core.async.toggle_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__4485__auto__.call(null,m,state_map));
} else {
throw cljs.core.missing_protocol("Mix.toggle*",m);
}
}
}
});

cljs.core.async.solo_mode_STAR_ = (function cljs$core$async$solo_mode_STAR_(m,mode){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$solo_mode_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$solo_mode_STAR_$arity$2(m,mode);
} else {
var x__4487__auto__ = (((m == null))?null:m);
var m__4488__auto__ = (cljs.core.async.solo_mode_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$2(m,mode) : m__4488__auto__.call(null,m,mode));
} else {
var m__4485__auto__ = (cljs.core.async.solo_mode_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$2(m,mode) : m__4485__auto__.call(null,m,mode));
} else {
throw cljs.core.missing_protocol("Mix.solo-mode*",m);
}
}
}
});

cljs.core.async.ioc_alts_BANG_ = (function cljs$core$async$ioc_alts_BANG_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___30464 = arguments.length;
var i__4790__auto___30465 = (0);
while(true){
if((i__4790__auto___30465 < len__4789__auto___30464)){
args__4795__auto__.push((arguments[i__4790__auto___30465]));

var G__30466 = (i__4790__auto___30465 + (1));
i__4790__auto___30465 = G__30466;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((3) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((3)),(0),null)):null);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__4796__auto__);
});

(cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (state,cont_block,ports,p__30458){
var map__30459 = p__30458;
var map__30459__$1 = (((((!((map__30459 == null))))?(((((map__30459.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__30459.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__30459):map__30459);
var opts = map__30459__$1;
var statearr_30461_30467 = state;
(statearr_30461_30467[(1)] = cont_block);


var temp__5735__auto__ = cljs.core.async.do_alts((function (val){
var statearr_30462_30468 = state;
(statearr_30462_30468[(2)] = val);


return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state);
}),ports,opts);
if(cljs.core.truth_(temp__5735__auto__)){
var cb = temp__5735__auto__;
var statearr_30463_30469 = state;
(statearr_30463_30469[(2)] = cljs.core.deref(cb));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}));

(cljs.core.async.ioc_alts_BANG_.cljs$lang$maxFixedArity = (3));

/** @this {Function} */
(cljs.core.async.ioc_alts_BANG_.cljs$lang$applyTo = (function (seq30454){
var G__30455 = cljs.core.first(seq30454);
var seq30454__$1 = cljs.core.next(seq30454);
var G__30456 = cljs.core.first(seq30454__$1);
var seq30454__$2 = cljs.core.next(seq30454__$1);
var G__30457 = cljs.core.first(seq30454__$2);
var seq30454__$3 = cljs.core.next(seq30454__$2);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__30455,G__30456,G__30457,seq30454__$3);
}));

/**
 * Creates and returns a mix of one or more input channels which will
 *   be put on the supplied out channel. Input sources can be added to
 *   the mix with 'admix', and removed with 'unmix'. A mix supports
 *   soloing, muting and pausing multiple inputs atomically using
 *   'toggle', and can solo using either muting or pausing as determined
 *   by 'solo-mode'.
 * 
 *   Each channel can have zero or more boolean modes set via 'toggle':
 * 
 *   :solo - when true, only this (ond other soloed) channel(s) will appear
 *        in the mix output channel. :mute and :pause states of soloed
 *        channels are ignored. If solo-mode is :mute, non-soloed
 *        channels are muted, if :pause, non-soloed channels are
 *        paused.
 * 
 *   :mute - muted channels will have their contents consumed but not included in the mix
 *   :pause - paused channels will not have their contents consumed (and thus also not included in the mix)
 */
cljs.core.async.mix = (function cljs$core$async$mix(out){
var cs = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var solo_modes = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$pause,null,cljs.core.cst$kw$mute,null], null), null);
var attrs = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(solo_modes,cljs.core.cst$kw$solo);
var solo_mode = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.cst$kw$mute);
var change = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(cljs.core.async.sliding_buffer((1)));
var changed = (function (){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(change,true);
});
var pick = (function (attr,chs){
return cljs.core.reduce_kv((function (ret,c,v){
if(cljs.core.truth_((attr.cljs$core$IFn$_invoke$arity$1 ? attr.cljs$core$IFn$_invoke$arity$1(v) : attr.call(null,v)))){
return cljs.core.conj.cljs$core$IFn$_invoke$arity$2(ret,c);
} else {
return ret;
}
}),cljs.core.PersistentHashSet.EMPTY,chs);
});
var calc_state = (function (){
var chs = cljs.core.deref(cs);
var mode = cljs.core.deref(solo_mode);
var solos = pick(cljs.core.cst$kw$solo,chs);
var pauses = pick(cljs.core.cst$kw$pause,chs);
return new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$solos,solos,cljs.core.cst$kw$mutes,pick(cljs.core.cst$kw$mute,chs),cljs.core.cst$kw$reads,cljs.core.conj.cljs$core$IFn$_invoke$arity$2(((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,cljs.core.cst$kw$pause)) && ((!(cljs.core.empty_QMARK_(solos))))))?cljs.core.vec(solos):cljs.core.vec(cljs.core.remove.cljs$core$IFn$_invoke$arity$2(pauses,cljs.core.keys(chs)))),change)], null);
});
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async30470 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mix}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async30470 = (function (change,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,meta30471){
this.change = change;
this.solo_mode = solo_mode;
this.pick = pick;
this.cs = cs;
this.calc_state = calc_state;
this.out = out;
this.changed = changed;
this.solo_modes = solo_modes;
this.attrs = attrs;
this.meta30471 = meta30471;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async30470.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_30472,meta30471__$1){
var self__ = this;
var _30472__$1 = this;
return (new cljs.core.async.t_cljs$core$async30470(self__.change,self__.solo_mode,self__.pick,self__.cs,self__.calc_state,self__.out,self__.changed,self__.solo_modes,self__.attrs,meta30471__$1));
}));

(cljs.core.async.t_cljs$core$async30470.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_30472){
var self__ = this;
var _30472__$1 = this;
return self__.meta30471;
}));

(cljs.core.async.t_cljs$core$async30470.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async30470.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.out;
}));

(cljs.core.async.t_cljs$core$async30470.prototype.cljs$core$async$Mix$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async30470.prototype.cljs$core$async$Mix$admix_STAR_$arity$2 = (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
}));

(cljs.core.async.t_cljs$core$async30470.prototype.cljs$core$async$Mix$unmix_STAR_$arity$2 = (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
}));

(cljs.core.async.t_cljs$core$async30470.prototype.cljs$core$async$Mix$unmix_all_STAR_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
}));

(cljs.core.async.t_cljs$core$async30470.prototype.cljs$core$async$Mix$toggle_STAR_$arity$2 = (function (_,state_map){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.partial.cljs$core$IFn$_invoke$arity$2(cljs.core.merge_with,cljs.core.merge),state_map);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
}));

(cljs.core.async.t_cljs$core$async30470.prototype.cljs$core$async$Mix$solo_mode_STAR_$arity$2 = (function (_,mode){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_((self__.solo_modes.cljs$core$IFn$_invoke$arity$1 ? self__.solo_modes.cljs$core$IFn$_invoke$arity$1(mode) : self__.solo_modes.call(null,mode)))){
} else {
throw (new Error(["Assert failed: ",["mode must be one of: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(self__.solo_modes)].join(''),"\n","(solo-modes mode)"].join('')));
}

cljs.core.reset_BANG_(self__.solo_mode,mode);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
}));

(cljs.core.async.t_cljs$core$async30470.getBasis = (function (){
return new cljs.core.PersistentVector(null, 10, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$change,cljs.core.cst$sym$solo_DASH_mode,cljs.core.cst$sym$pick,cljs.core.cst$sym$cs,cljs.core.cst$sym$calc_DASH_state,cljs.core.cst$sym$out,cljs.core.cst$sym$changed,cljs.core.cst$sym$solo_DASH_modes,cljs.core.cst$sym$attrs,cljs.core.cst$sym$meta30471], null);
}));

(cljs.core.async.t_cljs$core$async30470.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async30470.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async30470");

(cljs.core.async.t_cljs$core$async30470.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write(writer__4429__auto__,"cljs.core.async/t_cljs$core$async30470");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async30470.
 */
cljs.core.async.__GT_t_cljs$core$async30470 = (function cljs$core$async$mix_$___GT_t_cljs$core$async30470(change__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta30471){
return (new cljs.core.async.t_cljs$core$async30470(change__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta30471));
});

}

return (new cljs.core.async.t_cljs$core$async30470(change,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__27715__auto___30634 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_30574){
var state_val_30575 = (state_30574[(1)]);
if((state_val_30575 === (7))){
var inst_30489 = (state_30574[(2)]);
var state_30574__$1 = state_30574;
var statearr_30576_30635 = state_30574__$1;
(statearr_30576_30635[(2)] = inst_30489);

(statearr_30576_30635[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (20))){
var inst_30501 = (state_30574[(7)]);
var state_30574__$1 = state_30574;
var statearr_30577_30636 = state_30574__$1;
(statearr_30577_30636[(2)] = inst_30501);

(statearr_30577_30636[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (27))){
var state_30574__$1 = state_30574;
var statearr_30578_30637 = state_30574__$1;
(statearr_30578_30637[(2)] = null);

(statearr_30578_30637[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (1))){
var inst_30476 = (state_30574[(8)]);
var inst_30476__$1 = calc_state();
var inst_30478 = (inst_30476__$1 == null);
var inst_30479 = cljs.core.not(inst_30478);
var state_30574__$1 = (function (){var statearr_30579 = state_30574;
(statearr_30579[(8)] = inst_30476__$1);

return statearr_30579;
})();
if(inst_30479){
var statearr_30580_30638 = state_30574__$1;
(statearr_30580_30638[(1)] = (2));

} else {
var statearr_30581_30639 = state_30574__$1;
(statearr_30581_30639[(1)] = (3));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (24))){
var inst_30534 = (state_30574[(9)]);
var inst_30548 = (state_30574[(10)]);
var inst_30525 = (state_30574[(11)]);
var inst_30548__$1 = (inst_30525.cljs$core$IFn$_invoke$arity$1 ? inst_30525.cljs$core$IFn$_invoke$arity$1(inst_30534) : inst_30525.call(null,inst_30534));
var state_30574__$1 = (function (){var statearr_30582 = state_30574;
(statearr_30582[(10)] = inst_30548__$1);

return statearr_30582;
})();
if(cljs.core.truth_(inst_30548__$1)){
var statearr_30583_30640 = state_30574__$1;
(statearr_30583_30640[(1)] = (29));

} else {
var statearr_30584_30641 = state_30574__$1;
(statearr_30584_30641[(1)] = (30));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (4))){
var inst_30492 = (state_30574[(2)]);
var state_30574__$1 = state_30574;
if(cljs.core.truth_(inst_30492)){
var statearr_30585_30642 = state_30574__$1;
(statearr_30585_30642[(1)] = (8));

} else {
var statearr_30586_30643 = state_30574__$1;
(statearr_30586_30643[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (15))){
var inst_30519 = (state_30574[(2)]);
var state_30574__$1 = state_30574;
if(cljs.core.truth_(inst_30519)){
var statearr_30587_30644 = state_30574__$1;
(statearr_30587_30644[(1)] = (19));

} else {
var statearr_30588_30645 = state_30574__$1;
(statearr_30588_30645[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (21))){
var inst_30524 = (state_30574[(12)]);
var inst_30524__$1 = (state_30574[(2)]);
var inst_30525 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_30524__$1,cljs.core.cst$kw$solos);
var inst_30526 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_30524__$1,cljs.core.cst$kw$mutes);
var inst_30527 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_30524__$1,cljs.core.cst$kw$reads);
var state_30574__$1 = (function (){var statearr_30589 = state_30574;
(statearr_30589[(13)] = inst_30526);

(statearr_30589[(12)] = inst_30524__$1);

(statearr_30589[(11)] = inst_30525);

return statearr_30589;
})();
return cljs.core.async.ioc_alts_BANG_(state_30574__$1,(22),inst_30527);
} else {
if((state_val_30575 === (31))){
var inst_30556 = (state_30574[(2)]);
var state_30574__$1 = state_30574;
if(cljs.core.truth_(inst_30556)){
var statearr_30590_30646 = state_30574__$1;
(statearr_30590_30646[(1)] = (32));

} else {
var statearr_30591_30647 = state_30574__$1;
(statearr_30591_30647[(1)] = (33));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (32))){
var inst_30533 = (state_30574[(14)]);
var state_30574__$1 = state_30574;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30574__$1,(35),out,inst_30533);
} else {
if((state_val_30575 === (33))){
var inst_30524 = (state_30574[(12)]);
var inst_30501 = inst_30524;
var state_30574__$1 = (function (){var statearr_30592 = state_30574;
(statearr_30592[(7)] = inst_30501);

return statearr_30592;
})();
var statearr_30593_30648 = state_30574__$1;
(statearr_30593_30648[(2)] = null);

(statearr_30593_30648[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (13))){
var inst_30501 = (state_30574[(7)]);
var inst_30508 = inst_30501.cljs$lang$protocol_mask$partition0$;
var inst_30509 = (inst_30508 & (64));
var inst_30510 = inst_30501.cljs$core$ISeq$;
var inst_30511 = (cljs.core.PROTOCOL_SENTINEL === inst_30510);
var inst_30512 = ((inst_30509) || (inst_30511));
var state_30574__$1 = state_30574;
if(cljs.core.truth_(inst_30512)){
var statearr_30594_30649 = state_30574__$1;
(statearr_30594_30649[(1)] = (16));

} else {
var statearr_30595_30650 = state_30574__$1;
(statearr_30595_30650[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (22))){
var inst_30534 = (state_30574[(9)]);
var inst_30533 = (state_30574[(14)]);
var inst_30532 = (state_30574[(2)]);
var inst_30533__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_30532,(0),null);
var inst_30534__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_30532,(1),null);
var inst_30535 = (inst_30533__$1 == null);
var inst_30536 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_30534__$1,change);
var inst_30537 = ((inst_30535) || (inst_30536));
var state_30574__$1 = (function (){var statearr_30596 = state_30574;
(statearr_30596[(9)] = inst_30534__$1);

(statearr_30596[(14)] = inst_30533__$1);

return statearr_30596;
})();
if(cljs.core.truth_(inst_30537)){
var statearr_30597_30651 = state_30574__$1;
(statearr_30597_30651[(1)] = (23));

} else {
var statearr_30598_30652 = state_30574__$1;
(statearr_30598_30652[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (36))){
var inst_30524 = (state_30574[(12)]);
var inst_30501 = inst_30524;
var state_30574__$1 = (function (){var statearr_30599 = state_30574;
(statearr_30599[(7)] = inst_30501);

return statearr_30599;
})();
var statearr_30600_30653 = state_30574__$1;
(statearr_30600_30653[(2)] = null);

(statearr_30600_30653[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (29))){
var inst_30548 = (state_30574[(10)]);
var state_30574__$1 = state_30574;
var statearr_30601_30654 = state_30574__$1;
(statearr_30601_30654[(2)] = inst_30548);

(statearr_30601_30654[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (6))){
var state_30574__$1 = state_30574;
var statearr_30602_30655 = state_30574__$1;
(statearr_30602_30655[(2)] = false);

(statearr_30602_30655[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (28))){
var inst_30544 = (state_30574[(2)]);
var inst_30545 = calc_state();
var inst_30501 = inst_30545;
var state_30574__$1 = (function (){var statearr_30603 = state_30574;
(statearr_30603[(15)] = inst_30544);

(statearr_30603[(7)] = inst_30501);

return statearr_30603;
})();
var statearr_30604_30656 = state_30574__$1;
(statearr_30604_30656[(2)] = null);

(statearr_30604_30656[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (25))){
var inst_30570 = (state_30574[(2)]);
var state_30574__$1 = state_30574;
var statearr_30605_30657 = state_30574__$1;
(statearr_30605_30657[(2)] = inst_30570);

(statearr_30605_30657[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (34))){
var inst_30568 = (state_30574[(2)]);
var state_30574__$1 = state_30574;
var statearr_30606_30658 = state_30574__$1;
(statearr_30606_30658[(2)] = inst_30568);

(statearr_30606_30658[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (17))){
var state_30574__$1 = state_30574;
var statearr_30607_30659 = state_30574__$1;
(statearr_30607_30659[(2)] = false);

(statearr_30607_30659[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (3))){
var state_30574__$1 = state_30574;
var statearr_30608_30660 = state_30574__$1;
(statearr_30608_30660[(2)] = false);

(statearr_30608_30660[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (12))){
var inst_30572 = (state_30574[(2)]);
var state_30574__$1 = state_30574;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30574__$1,inst_30572);
} else {
if((state_val_30575 === (2))){
var inst_30476 = (state_30574[(8)]);
var inst_30481 = inst_30476.cljs$lang$protocol_mask$partition0$;
var inst_30482 = (inst_30481 & (64));
var inst_30483 = inst_30476.cljs$core$ISeq$;
var inst_30484 = (cljs.core.PROTOCOL_SENTINEL === inst_30483);
var inst_30485 = ((inst_30482) || (inst_30484));
var state_30574__$1 = state_30574;
if(cljs.core.truth_(inst_30485)){
var statearr_30609_30661 = state_30574__$1;
(statearr_30609_30661[(1)] = (5));

} else {
var statearr_30610_30662 = state_30574__$1;
(statearr_30610_30662[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (23))){
var inst_30533 = (state_30574[(14)]);
var inst_30539 = (inst_30533 == null);
var state_30574__$1 = state_30574;
if(cljs.core.truth_(inst_30539)){
var statearr_30611_30663 = state_30574__$1;
(statearr_30611_30663[(1)] = (26));

} else {
var statearr_30612_30664 = state_30574__$1;
(statearr_30612_30664[(1)] = (27));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (35))){
var inst_30559 = (state_30574[(2)]);
var state_30574__$1 = state_30574;
if(cljs.core.truth_(inst_30559)){
var statearr_30613_30665 = state_30574__$1;
(statearr_30613_30665[(1)] = (36));

} else {
var statearr_30614_30666 = state_30574__$1;
(statearr_30614_30666[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (19))){
var inst_30501 = (state_30574[(7)]);
var inst_30521 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_30501);
var state_30574__$1 = state_30574;
var statearr_30615_30667 = state_30574__$1;
(statearr_30615_30667[(2)] = inst_30521);

(statearr_30615_30667[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (11))){
var inst_30501 = (state_30574[(7)]);
var inst_30505 = (inst_30501 == null);
var inst_30506 = cljs.core.not(inst_30505);
var state_30574__$1 = state_30574;
if(inst_30506){
var statearr_30616_30668 = state_30574__$1;
(statearr_30616_30668[(1)] = (13));

} else {
var statearr_30617_30669 = state_30574__$1;
(statearr_30617_30669[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (9))){
var inst_30476 = (state_30574[(8)]);
var state_30574__$1 = state_30574;
var statearr_30618_30670 = state_30574__$1;
(statearr_30618_30670[(2)] = inst_30476);

(statearr_30618_30670[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (5))){
var state_30574__$1 = state_30574;
var statearr_30619_30671 = state_30574__$1;
(statearr_30619_30671[(2)] = true);

(statearr_30619_30671[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (14))){
var state_30574__$1 = state_30574;
var statearr_30620_30672 = state_30574__$1;
(statearr_30620_30672[(2)] = false);

(statearr_30620_30672[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (26))){
var inst_30534 = (state_30574[(9)]);
var inst_30541 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(cs,cljs.core.dissoc,inst_30534);
var state_30574__$1 = state_30574;
var statearr_30621_30673 = state_30574__$1;
(statearr_30621_30673[(2)] = inst_30541);

(statearr_30621_30673[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (16))){
var state_30574__$1 = state_30574;
var statearr_30622_30674 = state_30574__$1;
(statearr_30622_30674[(2)] = true);

(statearr_30622_30674[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (38))){
var inst_30564 = (state_30574[(2)]);
var state_30574__$1 = state_30574;
var statearr_30623_30675 = state_30574__$1;
(statearr_30623_30675[(2)] = inst_30564);

(statearr_30623_30675[(1)] = (34));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (30))){
var inst_30534 = (state_30574[(9)]);
var inst_30526 = (state_30574[(13)]);
var inst_30525 = (state_30574[(11)]);
var inst_30551 = cljs.core.empty_QMARK_(inst_30525);
var inst_30552 = (inst_30526.cljs$core$IFn$_invoke$arity$1 ? inst_30526.cljs$core$IFn$_invoke$arity$1(inst_30534) : inst_30526.call(null,inst_30534));
var inst_30553 = cljs.core.not(inst_30552);
var inst_30554 = ((inst_30551) && (inst_30553));
var state_30574__$1 = state_30574;
var statearr_30624_30676 = state_30574__$1;
(statearr_30624_30676[(2)] = inst_30554);

(statearr_30624_30676[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (10))){
var inst_30476 = (state_30574[(8)]);
var inst_30497 = (state_30574[(2)]);
var inst_30498 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_30497,cljs.core.cst$kw$solos);
var inst_30499 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_30497,cljs.core.cst$kw$mutes);
var inst_30500 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_30497,cljs.core.cst$kw$reads);
var inst_30501 = inst_30476;
var state_30574__$1 = (function (){var statearr_30625 = state_30574;
(statearr_30625[(16)] = inst_30499);

(statearr_30625[(17)] = inst_30498);

(statearr_30625[(18)] = inst_30500);

(statearr_30625[(7)] = inst_30501);

return statearr_30625;
})();
var statearr_30626_30677 = state_30574__$1;
(statearr_30626_30677[(2)] = null);

(statearr_30626_30677[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (18))){
var inst_30516 = (state_30574[(2)]);
var state_30574__$1 = state_30574;
var statearr_30627_30678 = state_30574__$1;
(statearr_30627_30678[(2)] = inst_30516);

(statearr_30627_30678[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (37))){
var state_30574__$1 = state_30574;
var statearr_30628_30679 = state_30574__$1;
(statearr_30628_30679[(2)] = null);

(statearr_30628_30679[(1)] = (38));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30575 === (8))){
var inst_30476 = (state_30574[(8)]);
var inst_30494 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_30476);
var state_30574__$1 = state_30574;
var statearr_30629_30680 = state_30574__$1;
(statearr_30629_30680[(2)] = inst_30494);

(statearr_30629_30680[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$mix_$_state_machine__27525__auto__ = null;
var cljs$core$async$mix_$_state_machine__27525__auto____0 = (function (){
var statearr_30630 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_30630[(0)] = cljs$core$async$mix_$_state_machine__27525__auto__);

(statearr_30630[(1)] = (1));

return statearr_30630;
});
var cljs$core$async$mix_$_state_machine__27525__auto____1 = (function (state_30574){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_30574);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e30631){if((e30631 instanceof Object)){
var ex__27528__auto__ = e30631;
var statearr_30632_30681 = state_30574;
(statearr_30632_30681[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30574);

return cljs.core.cst$kw$recur;
} else {
throw e30631;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__30682 = state_30574;
state_30574 = G__30682;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$mix_$_state_machine__27525__auto__ = function(state_30574){
switch(arguments.length){
case 0:
return cljs$core$async$mix_$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$mix_$_state_machine__27525__auto____1.call(this,state_30574);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mix_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mix_$_state_machine__27525__auto____0;
cljs$core$async$mix_$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mix_$_state_machine__27525__auto____1;
return cljs$core$async$mix_$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_30633 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_30633[(6)] = c__27715__auto___30634);

return statearr_30633;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));


return m;
});
/**
 * Adds ch as an input to the mix
 */
cljs.core.async.admix = (function cljs$core$async$admix(mix,ch){
return cljs.core.async.admix_STAR_(mix,ch);
});
/**
 * Removes ch as an input to the mix
 */
cljs.core.async.unmix = (function cljs$core$async$unmix(mix,ch){
return cljs.core.async.unmix_STAR_(mix,ch);
});
/**
 * removes all inputs from the mix
 */
cljs.core.async.unmix_all = (function cljs$core$async$unmix_all(mix){
return cljs.core.async.unmix_all_STAR_(mix);
});
/**
 * Atomically sets the state(s) of one or more channels in a mix. The
 *   state map is a map of channels -> channel-state-map. A
 *   channel-state-map is a map of attrs -> boolean, where attr is one or
 *   more of :mute, :pause or :solo. Any states supplied are merged with
 *   the current state.
 * 
 *   Note that channels can be added to a mix via toggle, which can be
 *   used to add channels in a particular (e.g. paused) state.
 */
cljs.core.async.toggle = (function cljs$core$async$toggle(mix,state_map){
return cljs.core.async.toggle_STAR_(mix,state_map);
});
/**
 * Sets the solo mode of the mix. mode must be one of :mute or :pause
 */
cljs.core.async.solo_mode = (function cljs$core$async$solo_mode(mix,mode){
return cljs.core.async.solo_mode_STAR_(mix,mode);
});

/**
 * @interface
 */
cljs.core.async.Pub = function(){};

cljs.core.async.sub_STAR_ = (function cljs$core$async$sub_STAR_(p,v,ch,close_QMARK_){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$sub_STAR_$arity$4 == null)))))){
return p.cljs$core$async$Pub$sub_STAR_$arity$4(p,v,ch,close_QMARK_);
} else {
var x__4487__auto__ = (((p == null))?null:p);
var m__4488__auto__ = (cljs.core.async.sub_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$4 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__4488__auto__.call(null,p,v,ch,close_QMARK_));
} else {
var m__4485__auto__ = (cljs.core.async.sub_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$4 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__4485__auto__.call(null,p,v,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Pub.sub*",p);
}
}
}
});

cljs.core.async.unsub_STAR_ = (function cljs$core$async$unsub_STAR_(p,v,ch){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_STAR_$arity$3 == null)))))){
return p.cljs$core$async$Pub$unsub_STAR_$arity$3(p,v,ch);
} else {
var x__4487__auto__ = (((p == null))?null:p);
var m__4488__auto__ = (cljs.core.async.unsub_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__4488__auto__.call(null,p,v,ch));
} else {
var m__4485__auto__ = (cljs.core.async.unsub_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__4485__auto__.call(null,p,v,ch));
} else {
throw cljs.core.missing_protocol("Pub.unsub*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_ = (function cljs$core$async$unsub_all_STAR_(var_args){
var G__30684 = arguments.length;
switch (G__30684) {
case 1:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1 = (function (p){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$1 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$1(p);
} else {
var x__4487__auto__ = (((p == null))?null:p);
var m__4488__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$1(p) : m__4488__auto__.call(null,p));
} else {
var m__4485__auto__ = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$1(p) : m__4485__auto__.call(null,p));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
}));

(cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2 = (function (p,v){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$2 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$2(p,v);
} else {
var x__4487__auto__ = (((p == null))?null:p);
var m__4488__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$2(p,v) : m__4488__auto__.call(null,p,v));
} else {
var m__4485__auto__ = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$2(p,v) : m__4485__auto__.call(null,p,v));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
}));

(cljs.core.async.unsub_all_STAR_.cljs$lang$maxFixedArity = 2);


/**
 * Creates and returns a pub(lication) of the supplied channel,
 *   partitioned into topics by the topic-fn. topic-fn will be applied to
 *   each value on the channel and the result will determine the 'topic'
 *   on which that value will be put. Channels can be subscribed to
 *   receive copies of topics using 'sub', and unsubscribed using
 *   'unsub'. Each topic will be handled by an internal mult on a
 *   dedicated channel. By default these internal channels are
 *   unbuffered, but a buf-fn can be supplied which, given a topic,
 *   creates a buffer with desired properties.
 * 
 *   Each item is distributed to all subs in parallel and synchronously,
 *   i.e. each sub must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow subs from holding up the pub.
 * 
 *   Items received when there are no matching subs get dropped.
 * 
 *   Note that if buf-fns are used then each topic is handled
 *   asynchronously, i.e. if a channel is subscribed to more than one
 *   topic it should not expect them to be interleaved identically with
 *   the source.
 */
cljs.core.async.pub = (function cljs$core$async$pub(var_args){
var G__30688 = arguments.length;
switch (G__30688) {
case 2:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2 = (function (ch,topic_fn){
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3(ch,topic_fn,cljs.core.constantly(null));
}));

(cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3 = (function (ch,topic_fn,buf_fn){
var mults = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var ensure_mult = (function (topic){
var or__4185__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(mults),topic);
if(cljs.core.truth_(or__4185__auto__)){
return or__4185__auto__;
} else {
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(mults,(function (p1__30686_SHARP_){
if(cljs.core.truth_((p1__30686_SHARP_.cljs$core$IFn$_invoke$arity$1 ? p1__30686_SHARP_.cljs$core$IFn$_invoke$arity$1(topic) : p1__30686_SHARP_.call(null,topic)))){
return p1__30686_SHARP_;
} else {
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(p1__30686_SHARP_,topic,cljs.core.async.mult(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((buf_fn.cljs$core$IFn$_invoke$arity$1 ? buf_fn.cljs$core$IFn$_invoke$arity$1(topic) : buf_fn.call(null,topic)))));
}
})),topic);
}
});
var p = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async30689 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Pub}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async30689 = (function (ch,topic_fn,buf_fn,mults,ensure_mult,meta30690){
this.ch = ch;
this.topic_fn = topic_fn;
this.buf_fn = buf_fn;
this.mults = mults;
this.ensure_mult = ensure_mult;
this.meta30690 = meta30690;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async30689.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_30691,meta30690__$1){
var self__ = this;
var _30691__$1 = this;
return (new cljs.core.async.t_cljs$core$async30689(self__.ch,self__.topic_fn,self__.buf_fn,self__.mults,self__.ensure_mult,meta30690__$1));
}));

(cljs.core.async.t_cljs$core$async30689.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_30691){
var self__ = this;
var _30691__$1 = this;
return self__.meta30690;
}));

(cljs.core.async.t_cljs$core$async30689.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async30689.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
}));

(cljs.core.async.t_cljs$core$async30689.prototype.cljs$core$async$Pub$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async30689.prototype.cljs$core$async$Pub$sub_STAR_$arity$4 = (function (p,topic,ch__$1,close_QMARK_){
var self__ = this;
var p__$1 = this;
var m = (self__.ensure_mult.cljs$core$IFn$_invoke$arity$1 ? self__.ensure_mult.cljs$core$IFn$_invoke$arity$1(topic) : self__.ensure_mult.call(null,topic));
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(m,ch__$1,close_QMARK_);
}));

(cljs.core.async.t_cljs$core$async30689.prototype.cljs$core$async$Pub$unsub_STAR_$arity$3 = (function (p,topic,ch__$1){
var self__ = this;
var p__$1 = this;
var temp__5735__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(self__.mults),topic);
if(cljs.core.truth_(temp__5735__auto__)){
var m = temp__5735__auto__;
return cljs.core.async.untap(m,ch__$1);
} else {
return null;
}
}));

(cljs.core.async.t_cljs$core$async30689.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.reset_BANG_(self__.mults,cljs.core.PersistentArrayMap.EMPTY);
}));

(cljs.core.async.t_cljs$core$async30689.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$2 = (function (_,topic){
var self__ = this;
var ___$1 = this;
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.mults,cljs.core.dissoc,topic);
}));

(cljs.core.async.t_cljs$core$async30689.getBasis = (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch,cljs.core.cst$sym$topic_DASH_fn,cljs.core.cst$sym$buf_DASH_fn,cljs.core.cst$sym$mults,cljs.core.cst$sym$ensure_DASH_mult,cljs.core.cst$sym$meta30690], null);
}));

(cljs.core.async.t_cljs$core$async30689.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async30689.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async30689");

(cljs.core.async.t_cljs$core$async30689.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write(writer__4429__auto__,"cljs.core.async/t_cljs$core$async30689");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async30689.
 */
cljs.core.async.__GT_t_cljs$core$async30689 = (function cljs$core$async$__GT_t_cljs$core$async30689(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta30690){
return (new cljs.core.async.t_cljs$core$async30689(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta30690));
});

}

return (new cljs.core.async.t_cljs$core$async30689(ch,topic_fn,buf_fn,mults,ensure_mult,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__27715__auto___30809 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_30763){
var state_val_30764 = (state_30763[(1)]);
if((state_val_30764 === (7))){
var inst_30759 = (state_30763[(2)]);
var state_30763__$1 = state_30763;
var statearr_30765_30810 = state_30763__$1;
(statearr_30765_30810[(2)] = inst_30759);

(statearr_30765_30810[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (20))){
var state_30763__$1 = state_30763;
var statearr_30766_30811 = state_30763__$1;
(statearr_30766_30811[(2)] = null);

(statearr_30766_30811[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (1))){
var state_30763__$1 = state_30763;
var statearr_30767_30812 = state_30763__$1;
(statearr_30767_30812[(2)] = null);

(statearr_30767_30812[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (24))){
var inst_30742 = (state_30763[(7)]);
var inst_30751 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(mults,cljs.core.dissoc,inst_30742);
var state_30763__$1 = state_30763;
var statearr_30768_30813 = state_30763__$1;
(statearr_30768_30813[(2)] = inst_30751);

(statearr_30768_30813[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (4))){
var inst_30694 = (state_30763[(8)]);
var inst_30694__$1 = (state_30763[(2)]);
var inst_30695 = (inst_30694__$1 == null);
var state_30763__$1 = (function (){var statearr_30769 = state_30763;
(statearr_30769[(8)] = inst_30694__$1);

return statearr_30769;
})();
if(cljs.core.truth_(inst_30695)){
var statearr_30770_30814 = state_30763__$1;
(statearr_30770_30814[(1)] = (5));

} else {
var statearr_30771_30815 = state_30763__$1;
(statearr_30771_30815[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (15))){
var inst_30736 = (state_30763[(2)]);
var state_30763__$1 = state_30763;
var statearr_30772_30816 = state_30763__$1;
(statearr_30772_30816[(2)] = inst_30736);

(statearr_30772_30816[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (21))){
var inst_30756 = (state_30763[(2)]);
var state_30763__$1 = (function (){var statearr_30773 = state_30763;
(statearr_30773[(9)] = inst_30756);

return statearr_30773;
})();
var statearr_30774_30817 = state_30763__$1;
(statearr_30774_30817[(2)] = null);

(statearr_30774_30817[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (13))){
var inst_30718 = (state_30763[(10)]);
var inst_30720 = cljs.core.chunked_seq_QMARK_(inst_30718);
var state_30763__$1 = state_30763;
if(inst_30720){
var statearr_30775_30818 = state_30763__$1;
(statearr_30775_30818[(1)] = (16));

} else {
var statearr_30776_30819 = state_30763__$1;
(statearr_30776_30819[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (22))){
var inst_30748 = (state_30763[(2)]);
var state_30763__$1 = state_30763;
if(cljs.core.truth_(inst_30748)){
var statearr_30777_30820 = state_30763__$1;
(statearr_30777_30820[(1)] = (23));

} else {
var statearr_30778_30821 = state_30763__$1;
(statearr_30778_30821[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (6))){
var inst_30694 = (state_30763[(8)]);
var inst_30742 = (state_30763[(7)]);
var inst_30744 = (state_30763[(11)]);
var inst_30742__$1 = (topic_fn.cljs$core$IFn$_invoke$arity$1 ? topic_fn.cljs$core$IFn$_invoke$arity$1(inst_30694) : topic_fn.call(null,inst_30694));
var inst_30743 = cljs.core.deref(mults);
var inst_30744__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_30743,inst_30742__$1);
var state_30763__$1 = (function (){var statearr_30779 = state_30763;
(statearr_30779[(7)] = inst_30742__$1);

(statearr_30779[(11)] = inst_30744__$1);

return statearr_30779;
})();
if(cljs.core.truth_(inst_30744__$1)){
var statearr_30780_30822 = state_30763__$1;
(statearr_30780_30822[(1)] = (19));

} else {
var statearr_30781_30823 = state_30763__$1;
(statearr_30781_30823[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (25))){
var inst_30753 = (state_30763[(2)]);
var state_30763__$1 = state_30763;
var statearr_30782_30824 = state_30763__$1;
(statearr_30782_30824[(2)] = inst_30753);

(statearr_30782_30824[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (17))){
var inst_30718 = (state_30763[(10)]);
var inst_30727 = cljs.core.first(inst_30718);
var inst_30728 = cljs.core.async.muxch_STAR_(inst_30727);
var inst_30729 = cljs.core.async.close_BANG_(inst_30728);
var inst_30730 = cljs.core.next(inst_30718);
var inst_30704 = inst_30730;
var inst_30705 = null;
var inst_30706 = (0);
var inst_30707 = (0);
var state_30763__$1 = (function (){var statearr_30783 = state_30763;
(statearr_30783[(12)] = inst_30707);

(statearr_30783[(13)] = inst_30706);

(statearr_30783[(14)] = inst_30704);

(statearr_30783[(15)] = inst_30729);

(statearr_30783[(16)] = inst_30705);

return statearr_30783;
})();
var statearr_30784_30825 = state_30763__$1;
(statearr_30784_30825[(2)] = null);

(statearr_30784_30825[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (3))){
var inst_30761 = (state_30763[(2)]);
var state_30763__$1 = state_30763;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30763__$1,inst_30761);
} else {
if((state_val_30764 === (12))){
var inst_30738 = (state_30763[(2)]);
var state_30763__$1 = state_30763;
var statearr_30785_30826 = state_30763__$1;
(statearr_30785_30826[(2)] = inst_30738);

(statearr_30785_30826[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (2))){
var state_30763__$1 = state_30763;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_30763__$1,(4),ch);
} else {
if((state_val_30764 === (23))){
var state_30763__$1 = state_30763;
var statearr_30786_30827 = state_30763__$1;
(statearr_30786_30827[(2)] = null);

(statearr_30786_30827[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (19))){
var inst_30694 = (state_30763[(8)]);
var inst_30744 = (state_30763[(11)]);
var inst_30746 = cljs.core.async.muxch_STAR_(inst_30744);
var state_30763__$1 = state_30763;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30763__$1,(22),inst_30746,inst_30694);
} else {
if((state_val_30764 === (11))){
var inst_30718 = (state_30763[(10)]);
var inst_30704 = (state_30763[(14)]);
var inst_30718__$1 = cljs.core.seq(inst_30704);
var state_30763__$1 = (function (){var statearr_30787 = state_30763;
(statearr_30787[(10)] = inst_30718__$1);

return statearr_30787;
})();
if(inst_30718__$1){
var statearr_30788_30828 = state_30763__$1;
(statearr_30788_30828[(1)] = (13));

} else {
var statearr_30789_30829 = state_30763__$1;
(statearr_30789_30829[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (9))){
var inst_30740 = (state_30763[(2)]);
var state_30763__$1 = state_30763;
var statearr_30790_30830 = state_30763__$1;
(statearr_30790_30830[(2)] = inst_30740);

(statearr_30790_30830[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (5))){
var inst_30701 = cljs.core.deref(mults);
var inst_30702 = cljs.core.vals(inst_30701);
var inst_30703 = cljs.core.seq(inst_30702);
var inst_30704 = inst_30703;
var inst_30705 = null;
var inst_30706 = (0);
var inst_30707 = (0);
var state_30763__$1 = (function (){var statearr_30791 = state_30763;
(statearr_30791[(12)] = inst_30707);

(statearr_30791[(13)] = inst_30706);

(statearr_30791[(14)] = inst_30704);

(statearr_30791[(16)] = inst_30705);

return statearr_30791;
})();
var statearr_30792_30831 = state_30763__$1;
(statearr_30792_30831[(2)] = null);

(statearr_30792_30831[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (14))){
var state_30763__$1 = state_30763;
var statearr_30796_30832 = state_30763__$1;
(statearr_30796_30832[(2)] = null);

(statearr_30796_30832[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (16))){
var inst_30718 = (state_30763[(10)]);
var inst_30722 = cljs.core.chunk_first(inst_30718);
var inst_30723 = cljs.core.chunk_rest(inst_30718);
var inst_30724 = cljs.core.count(inst_30722);
var inst_30704 = inst_30723;
var inst_30705 = inst_30722;
var inst_30706 = inst_30724;
var inst_30707 = (0);
var state_30763__$1 = (function (){var statearr_30797 = state_30763;
(statearr_30797[(12)] = inst_30707);

(statearr_30797[(13)] = inst_30706);

(statearr_30797[(14)] = inst_30704);

(statearr_30797[(16)] = inst_30705);

return statearr_30797;
})();
var statearr_30798_30833 = state_30763__$1;
(statearr_30798_30833[(2)] = null);

(statearr_30798_30833[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (10))){
var inst_30707 = (state_30763[(12)]);
var inst_30706 = (state_30763[(13)]);
var inst_30704 = (state_30763[(14)]);
var inst_30705 = (state_30763[(16)]);
var inst_30712 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_30705,inst_30707);
var inst_30713 = cljs.core.async.muxch_STAR_(inst_30712);
var inst_30714 = cljs.core.async.close_BANG_(inst_30713);
var inst_30715 = (inst_30707 + (1));
var tmp30793 = inst_30706;
var tmp30794 = inst_30704;
var tmp30795 = inst_30705;
var inst_30704__$1 = tmp30794;
var inst_30705__$1 = tmp30795;
var inst_30706__$1 = tmp30793;
var inst_30707__$1 = inst_30715;
var state_30763__$1 = (function (){var statearr_30799 = state_30763;
(statearr_30799[(12)] = inst_30707__$1);

(statearr_30799[(13)] = inst_30706__$1);

(statearr_30799[(14)] = inst_30704__$1);

(statearr_30799[(17)] = inst_30714);

(statearr_30799[(16)] = inst_30705__$1);

return statearr_30799;
})();
var statearr_30800_30834 = state_30763__$1;
(statearr_30800_30834[(2)] = null);

(statearr_30800_30834[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (18))){
var inst_30733 = (state_30763[(2)]);
var state_30763__$1 = state_30763;
var statearr_30801_30835 = state_30763__$1;
(statearr_30801_30835[(2)] = inst_30733);

(statearr_30801_30835[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30764 === (8))){
var inst_30707 = (state_30763[(12)]);
var inst_30706 = (state_30763[(13)]);
var inst_30709 = (inst_30707 < inst_30706);
var inst_30710 = inst_30709;
var state_30763__$1 = state_30763;
if(cljs.core.truth_(inst_30710)){
var statearr_30802_30836 = state_30763__$1;
(statearr_30802_30836[(1)] = (10));

} else {
var statearr_30803_30837 = state_30763__$1;
(statearr_30803_30837[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_30804 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_30804[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_30804[(1)] = (1));

return statearr_30804;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_30763){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_30763);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e30805){if((e30805 instanceof Object)){
var ex__27528__auto__ = e30805;
var statearr_30806_30838 = state_30763;
(statearr_30806_30838[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30763);

return cljs.core.cst$kw$recur;
} else {
throw e30805;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__30839 = state_30763;
state_30763 = G__30839;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_30763){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_30763);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_30807 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_30807[(6)] = c__27715__auto___30809);

return statearr_30807;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));


return p;
}));

(cljs.core.async.pub.cljs$lang$maxFixedArity = 3);

/**
 * Subscribes a channel to a topic of a pub.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.sub = (function cljs$core$async$sub(var_args){
var G__30841 = arguments.length;
switch (G__30841) {
case 3:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3 = (function (p,topic,ch){
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4(p,topic,ch,true);
}));

(cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4 = (function (p,topic,ch,close_QMARK_){
return cljs.core.async.sub_STAR_(p,topic,ch,close_QMARK_);
}));

(cljs.core.async.sub.cljs$lang$maxFixedArity = 4);

/**
 * Unsubscribes a channel from a topic of a pub
 */
cljs.core.async.unsub = (function cljs$core$async$unsub(p,topic,ch){
return cljs.core.async.unsub_STAR_(p,topic,ch);
});
/**
 * Unsubscribes all channels from a pub, or a topic of a pub
 */
cljs.core.async.unsub_all = (function cljs$core$async$unsub_all(var_args){
var G__30844 = arguments.length;
switch (G__30844) {
case 1:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1 = (function (p){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1(p);
}));

(cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2 = (function (p,topic){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2(p,topic);
}));

(cljs.core.async.unsub_all.cljs$lang$maxFixedArity = 2);

/**
 * Takes a function and a collection of source channels, and returns a
 *   channel which contains the values produced by applying f to the set
 *   of first items taken from each source channel, followed by applying
 *   f to the set of second items from each channel, until any one of the
 *   channels is closed, at which point the output channel will be
 *   closed. The returned channel will be unbuffered by default, or a
 *   buf-or-n can be supplied
 */
cljs.core.async.map = (function cljs$core$async$map(var_args){
var G__30847 = arguments.length;
switch (G__30847) {
case 2:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.map.cljs$core$IFn$_invoke$arity$2 = (function (f,chs){
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3(f,chs,null);
}));

(cljs.core.async.map.cljs$core$IFn$_invoke$arity$3 = (function (f,chs,buf_or_n){
var chs__$1 = cljs.core.vec(chs);
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var cnt = cljs.core.count(chs__$1);
var rets = cljs.core.object_array.cljs$core$IFn$_invoke$arity$1(cnt);
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
var done = cljs.core.mapv.cljs$core$IFn$_invoke$arity$2((function (i){
return (function (ret){
(rets[i] = ret);

if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,rets.slice((0)));
} else {
return null;
}
});
}),cljs.core.range.cljs$core$IFn$_invoke$arity$1(cnt));
var c__27715__auto___30914 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_30886){
var state_val_30887 = (state_30886[(1)]);
if((state_val_30887 === (7))){
var state_30886__$1 = state_30886;
var statearr_30888_30915 = state_30886__$1;
(statearr_30888_30915[(2)] = null);

(statearr_30888_30915[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30887 === (1))){
var state_30886__$1 = state_30886;
var statearr_30889_30916 = state_30886__$1;
(statearr_30889_30916[(2)] = null);

(statearr_30889_30916[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30887 === (4))){
var inst_30850 = (state_30886[(7)]);
var inst_30852 = (inst_30850 < cnt);
var state_30886__$1 = state_30886;
if(cljs.core.truth_(inst_30852)){
var statearr_30890_30917 = state_30886__$1;
(statearr_30890_30917[(1)] = (6));

} else {
var statearr_30891_30918 = state_30886__$1;
(statearr_30891_30918[(1)] = (7));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30887 === (15))){
var inst_30882 = (state_30886[(2)]);
var state_30886__$1 = state_30886;
var statearr_30892_30919 = state_30886__$1;
(statearr_30892_30919[(2)] = inst_30882);

(statearr_30892_30919[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30887 === (13))){
var inst_30875 = cljs.core.async.close_BANG_(out);
var state_30886__$1 = state_30886;
var statearr_30893_30920 = state_30886__$1;
(statearr_30893_30920[(2)] = inst_30875);

(statearr_30893_30920[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30887 === (6))){
var state_30886__$1 = state_30886;
var statearr_30894_30921 = state_30886__$1;
(statearr_30894_30921[(2)] = null);

(statearr_30894_30921[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30887 === (3))){
var inst_30884 = (state_30886[(2)]);
var state_30886__$1 = state_30886;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30886__$1,inst_30884);
} else {
if((state_val_30887 === (12))){
var inst_30872 = (state_30886[(8)]);
var inst_30872__$1 = (state_30886[(2)]);
var inst_30873 = cljs.core.some(cljs.core.nil_QMARK_,inst_30872__$1);
var state_30886__$1 = (function (){var statearr_30895 = state_30886;
(statearr_30895[(8)] = inst_30872__$1);

return statearr_30895;
})();
if(cljs.core.truth_(inst_30873)){
var statearr_30896_30922 = state_30886__$1;
(statearr_30896_30922[(1)] = (13));

} else {
var statearr_30897_30923 = state_30886__$1;
(statearr_30897_30923[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30887 === (2))){
var inst_30849 = cljs.core.reset_BANG_(dctr,cnt);
var inst_30850 = (0);
var state_30886__$1 = (function (){var statearr_30898 = state_30886;
(statearr_30898[(7)] = inst_30850);

(statearr_30898[(9)] = inst_30849);

return statearr_30898;
})();
var statearr_30899_30924 = state_30886__$1;
(statearr_30899_30924[(2)] = null);

(statearr_30899_30924[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30887 === (11))){
var inst_30850 = (state_30886[(7)]);
var _ = cljs.core.async.impl.ioc_helpers.add_exception_frame(state_30886,(10),Object,null,(9));
var inst_30859 = (chs__$1.cljs$core$IFn$_invoke$arity$1 ? chs__$1.cljs$core$IFn$_invoke$arity$1(inst_30850) : chs__$1.call(null,inst_30850));
var inst_30860 = (done.cljs$core$IFn$_invoke$arity$1 ? done.cljs$core$IFn$_invoke$arity$1(inst_30850) : done.call(null,inst_30850));
var inst_30861 = cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2(inst_30859,inst_30860);
var state_30886__$1 = state_30886;
var statearr_30900_30925 = state_30886__$1;
(statearr_30900_30925[(2)] = inst_30861);


cljs.core.async.impl.ioc_helpers.process_exception(state_30886__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_30887 === (9))){
var inst_30850 = (state_30886[(7)]);
var inst_30863 = (state_30886[(2)]);
var inst_30864 = (inst_30850 + (1));
var inst_30850__$1 = inst_30864;
var state_30886__$1 = (function (){var statearr_30901 = state_30886;
(statearr_30901[(7)] = inst_30850__$1);

(statearr_30901[(10)] = inst_30863);

return statearr_30901;
})();
var statearr_30902_30926 = state_30886__$1;
(statearr_30902_30926[(2)] = null);

(statearr_30902_30926[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30887 === (5))){
var inst_30870 = (state_30886[(2)]);
var state_30886__$1 = (function (){var statearr_30903 = state_30886;
(statearr_30903[(11)] = inst_30870);

return statearr_30903;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_30886__$1,(12),dchan);
} else {
if((state_val_30887 === (14))){
var inst_30872 = (state_30886[(8)]);
var inst_30877 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(f,inst_30872);
var state_30886__$1 = state_30886;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30886__$1,(16),out,inst_30877);
} else {
if((state_val_30887 === (16))){
var inst_30879 = (state_30886[(2)]);
var state_30886__$1 = (function (){var statearr_30904 = state_30886;
(statearr_30904[(12)] = inst_30879);

return statearr_30904;
})();
var statearr_30905_30927 = state_30886__$1;
(statearr_30905_30927[(2)] = null);

(statearr_30905_30927[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30887 === (10))){
var inst_30854 = (state_30886[(2)]);
var inst_30855 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec);
var state_30886__$1 = (function (){var statearr_30906 = state_30886;
(statearr_30906[(13)] = inst_30854);

return statearr_30906;
})();
var statearr_30907_30928 = state_30886__$1;
(statearr_30907_30928[(2)] = inst_30855);


cljs.core.async.impl.ioc_helpers.process_exception(state_30886__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_30887 === (8))){
var inst_30868 = (state_30886[(2)]);
var state_30886__$1 = state_30886;
var statearr_30908_30929 = state_30886__$1;
(statearr_30908_30929[(2)] = inst_30868);

(statearr_30908_30929[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_30909 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_30909[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_30909[(1)] = (1));

return statearr_30909;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_30886){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_30886);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e30910){if((e30910 instanceof Object)){
var ex__27528__auto__ = e30910;
var statearr_30911_30930 = state_30886;
(statearr_30911_30930[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30886);

return cljs.core.cst$kw$recur;
} else {
throw e30910;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__30931 = state_30886;
state_30886 = G__30931;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_30886){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_30886);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_30912 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_30912[(6)] = c__27715__auto___30914);

return statearr_30912;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));


return out;
}));

(cljs.core.async.map.cljs$lang$maxFixedArity = 3);

/**
 * Takes a collection of source channels and returns a channel which
 *   contains all values taken from them. The returned channel will be
 *   unbuffered by default, or a buf-or-n can be supplied. The channel
 *   will close after all the source channels have closed.
 */
cljs.core.async.merge = (function cljs$core$async$merge(var_args){
var G__30934 = arguments.length;
switch (G__30934) {
case 1:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1 = (function (chs){
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2(chs,null);
}));

(cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2 = (function (chs,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__27715__auto___30988 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_30966){
var state_val_30967 = (state_30966[(1)]);
if((state_val_30967 === (7))){
var inst_30945 = (state_30966[(7)]);
var inst_30946 = (state_30966[(8)]);
var inst_30945__$1 = (state_30966[(2)]);
var inst_30946__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_30945__$1,(0),null);
var inst_30947 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_30945__$1,(1),null);
var inst_30948 = (inst_30946__$1 == null);
var state_30966__$1 = (function (){var statearr_30968 = state_30966;
(statearr_30968[(7)] = inst_30945__$1);

(statearr_30968[(9)] = inst_30947);

(statearr_30968[(8)] = inst_30946__$1);

return statearr_30968;
})();
if(cljs.core.truth_(inst_30948)){
var statearr_30969_30989 = state_30966__$1;
(statearr_30969_30989[(1)] = (8));

} else {
var statearr_30970_30990 = state_30966__$1;
(statearr_30970_30990[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30967 === (1))){
var inst_30935 = cljs.core.vec(chs);
var inst_30936 = inst_30935;
var state_30966__$1 = (function (){var statearr_30971 = state_30966;
(statearr_30971[(10)] = inst_30936);

return statearr_30971;
})();
var statearr_30972_30991 = state_30966__$1;
(statearr_30972_30991[(2)] = null);

(statearr_30972_30991[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30967 === (4))){
var inst_30936 = (state_30966[(10)]);
var state_30966__$1 = state_30966;
return cljs.core.async.ioc_alts_BANG_(state_30966__$1,(7),inst_30936);
} else {
if((state_val_30967 === (6))){
var inst_30962 = (state_30966[(2)]);
var state_30966__$1 = state_30966;
var statearr_30973_30992 = state_30966__$1;
(statearr_30973_30992[(2)] = inst_30962);

(statearr_30973_30992[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30967 === (3))){
var inst_30964 = (state_30966[(2)]);
var state_30966__$1 = state_30966;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30966__$1,inst_30964);
} else {
if((state_val_30967 === (2))){
var inst_30936 = (state_30966[(10)]);
var inst_30938 = cljs.core.count(inst_30936);
var inst_30939 = (inst_30938 > (0));
var state_30966__$1 = state_30966;
if(cljs.core.truth_(inst_30939)){
var statearr_30975_30993 = state_30966__$1;
(statearr_30975_30993[(1)] = (4));

} else {
var statearr_30976_30994 = state_30966__$1;
(statearr_30976_30994[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30967 === (11))){
var inst_30936 = (state_30966[(10)]);
var inst_30955 = (state_30966[(2)]);
var tmp30974 = inst_30936;
var inst_30936__$1 = tmp30974;
var state_30966__$1 = (function (){var statearr_30977 = state_30966;
(statearr_30977[(10)] = inst_30936__$1);

(statearr_30977[(11)] = inst_30955);

return statearr_30977;
})();
var statearr_30978_30995 = state_30966__$1;
(statearr_30978_30995[(2)] = null);

(statearr_30978_30995[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30967 === (9))){
var inst_30946 = (state_30966[(8)]);
var state_30966__$1 = state_30966;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30966__$1,(11),out,inst_30946);
} else {
if((state_val_30967 === (5))){
var inst_30960 = cljs.core.async.close_BANG_(out);
var state_30966__$1 = state_30966;
var statearr_30979_30996 = state_30966__$1;
(statearr_30979_30996[(2)] = inst_30960);

(statearr_30979_30996[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30967 === (10))){
var inst_30958 = (state_30966[(2)]);
var state_30966__$1 = state_30966;
var statearr_30980_30997 = state_30966__$1;
(statearr_30980_30997[(2)] = inst_30958);

(statearr_30980_30997[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30967 === (8))){
var inst_30936 = (state_30966[(10)]);
var inst_30945 = (state_30966[(7)]);
var inst_30947 = (state_30966[(9)]);
var inst_30946 = (state_30966[(8)]);
var inst_30950 = (function (){var cs = inst_30936;
var vec__30941 = inst_30945;
var v = inst_30946;
var c = inst_30947;
return (function (p1__30932_SHARP_){
return cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(c,p1__30932_SHARP_);
});
})();
var inst_30951 = cljs.core.filterv(inst_30950,inst_30936);
var inst_30936__$1 = inst_30951;
var state_30966__$1 = (function (){var statearr_30981 = state_30966;
(statearr_30981[(10)] = inst_30936__$1);

return statearr_30981;
})();
var statearr_30982_30998 = state_30966__$1;
(statearr_30982_30998[(2)] = null);

(statearr_30982_30998[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_30983 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_30983[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_30983[(1)] = (1));

return statearr_30983;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_30966){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_30966);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e30984){if((e30984 instanceof Object)){
var ex__27528__auto__ = e30984;
var statearr_30985_30999 = state_30966;
(statearr_30985_30999[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30966);

return cljs.core.cst$kw$recur;
} else {
throw e30984;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__31000 = state_30966;
state_30966 = G__31000;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_30966){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_30966);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_30986 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_30986[(6)] = c__27715__auto___30988);

return statearr_30986;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));


return out;
}));

(cljs.core.async.merge.cljs$lang$maxFixedArity = 2);

/**
 * Returns a channel containing the single (collection) result of the
 *   items taken from the channel conjoined to the supplied
 *   collection. ch must close before into produces a result.
 */
cljs.core.async.into = (function cljs$core$async$into(coll,ch){
return cljs.core.async.reduce(cljs.core.conj,coll,ch);
});
/**
 * Returns a channel that will return, at most, n items from ch. After n items
 * have been returned, or ch has been closed, the return chanel will close.
 * 
 *   The output channel is unbuffered by default, unless buf-or-n is given.
 */
cljs.core.async.take = (function cljs$core$async$take(var_args){
var G__31002 = arguments.length;
switch (G__31002) {
case 2:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.take.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3(n,ch,null);
}));

(cljs.core.async.take.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__27715__auto___31047 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_31026){
var state_val_31027 = (state_31026[(1)]);
if((state_val_31027 === (7))){
var inst_31008 = (state_31026[(7)]);
var inst_31008__$1 = (state_31026[(2)]);
var inst_31009 = (inst_31008__$1 == null);
var inst_31010 = cljs.core.not(inst_31009);
var state_31026__$1 = (function (){var statearr_31028 = state_31026;
(statearr_31028[(7)] = inst_31008__$1);

return statearr_31028;
})();
if(inst_31010){
var statearr_31029_31048 = state_31026__$1;
(statearr_31029_31048[(1)] = (8));

} else {
var statearr_31030_31049 = state_31026__$1;
(statearr_31030_31049[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31027 === (1))){
var inst_31003 = (0);
var state_31026__$1 = (function (){var statearr_31031 = state_31026;
(statearr_31031[(8)] = inst_31003);

return statearr_31031;
})();
var statearr_31032_31050 = state_31026__$1;
(statearr_31032_31050[(2)] = null);

(statearr_31032_31050[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31027 === (4))){
var state_31026__$1 = state_31026;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_31026__$1,(7),ch);
} else {
if((state_val_31027 === (6))){
var inst_31021 = (state_31026[(2)]);
var state_31026__$1 = state_31026;
var statearr_31033_31051 = state_31026__$1;
(statearr_31033_31051[(2)] = inst_31021);

(statearr_31033_31051[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31027 === (3))){
var inst_31023 = (state_31026[(2)]);
var inst_31024 = cljs.core.async.close_BANG_(out);
var state_31026__$1 = (function (){var statearr_31034 = state_31026;
(statearr_31034[(9)] = inst_31023);

return statearr_31034;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_31026__$1,inst_31024);
} else {
if((state_val_31027 === (2))){
var inst_31003 = (state_31026[(8)]);
var inst_31005 = (inst_31003 < n);
var state_31026__$1 = state_31026;
if(cljs.core.truth_(inst_31005)){
var statearr_31035_31052 = state_31026__$1;
(statearr_31035_31052[(1)] = (4));

} else {
var statearr_31036_31053 = state_31026__$1;
(statearr_31036_31053[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31027 === (11))){
var inst_31003 = (state_31026[(8)]);
var inst_31013 = (state_31026[(2)]);
var inst_31014 = (inst_31003 + (1));
var inst_31003__$1 = inst_31014;
var state_31026__$1 = (function (){var statearr_31037 = state_31026;
(statearr_31037[(10)] = inst_31013);

(statearr_31037[(8)] = inst_31003__$1);

return statearr_31037;
})();
var statearr_31038_31054 = state_31026__$1;
(statearr_31038_31054[(2)] = null);

(statearr_31038_31054[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31027 === (9))){
var state_31026__$1 = state_31026;
var statearr_31039_31055 = state_31026__$1;
(statearr_31039_31055[(2)] = null);

(statearr_31039_31055[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31027 === (5))){
var state_31026__$1 = state_31026;
var statearr_31040_31056 = state_31026__$1;
(statearr_31040_31056[(2)] = null);

(statearr_31040_31056[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31027 === (10))){
var inst_31018 = (state_31026[(2)]);
var state_31026__$1 = state_31026;
var statearr_31041_31057 = state_31026__$1;
(statearr_31041_31057[(2)] = inst_31018);

(statearr_31041_31057[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31027 === (8))){
var inst_31008 = (state_31026[(7)]);
var state_31026__$1 = state_31026;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_31026__$1,(11),out,inst_31008);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_31042 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_31042[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_31042[(1)] = (1));

return statearr_31042;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_31026){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_31026);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e31043){if((e31043 instanceof Object)){
var ex__27528__auto__ = e31043;
var statearr_31044_31058 = state_31026;
(statearr_31044_31058[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_31026);

return cljs.core.cst$kw$recur;
} else {
throw e31043;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__31059 = state_31026;
state_31026 = G__31059;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_31026){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_31026);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_31045 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_31045[(6)] = c__27715__auto___31047);

return statearr_31045;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));


return out;
}));

(cljs.core.async.take.cljs$lang$maxFixedArity = 3);

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_LT_ = (function cljs$core$async$map_LT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async31061 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async31061 = (function (f,ch,meta31062){
this.f = f;
this.ch = ch;
this.meta31062 = meta31062;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async31061.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_31063,meta31062__$1){
var self__ = this;
var _31063__$1 = this;
return (new cljs.core.async.t_cljs$core$async31061(self__.f,self__.ch,meta31062__$1));
}));

(cljs.core.async.t_cljs$core$async31061.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_31063){
var self__ = this;
var _31063__$1 = this;
return self__.meta31062;
}));

(cljs.core.async.t_cljs$core$async31061.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async31061.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
}));

(cljs.core.async.t_cljs$core$async31061.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
}));

(cljs.core.async.t_cljs$core$async31061.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async31061.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
var ret = cljs.core.async.impl.protocols.take_BANG_(self__.ch,(function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async31064 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async31064 = (function (f,ch,meta31062,_,fn1,meta31065){
this.f = f;
this.ch = ch;
this.meta31062 = meta31062;
this._ = _;
this.fn1 = fn1;
this.meta31065 = meta31065;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async31064.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_31066,meta31065__$1){
var self__ = this;
var _31066__$1 = this;
return (new cljs.core.async.t_cljs$core$async31064(self__.f,self__.ch,self__.meta31062,self__._,self__.fn1,meta31065__$1));
}));

(cljs.core.async.t_cljs$core$async31064.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_31066){
var self__ = this;
var _31066__$1 = this;
return self__.meta31065;
}));

(cljs.core.async.t_cljs$core$async31064.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async31064.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (___$1){
var self__ = this;
var ___$2 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.fn1);
}));

(cljs.core.async.t_cljs$core$async31064.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (___$1){
var self__ = this;
var ___$2 = this;
return true;
}));

(cljs.core.async.t_cljs$core$async31064.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (___$1){
var self__ = this;
var ___$2 = this;
var f1 = cljs.core.async.impl.protocols.commit(self__.fn1);
return (function (p1__31060_SHARP_){
var G__31067 = (((p1__31060_SHARP_ == null))?null:(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(p1__31060_SHARP_) : self__.f.call(null,p1__31060_SHARP_)));
return (f1.cljs$core$IFn$_invoke$arity$1 ? f1.cljs$core$IFn$_invoke$arity$1(G__31067) : f1.call(null,G__31067));
});
}));

(cljs.core.async.t_cljs$core$async31064.getBasis = (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta31062,cljs.core.with_meta(cljs.core.cst$sym$_,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$tag,cljs.core.cst$sym$cljs$core$async_SLASH_t_cljs$core$async31061], null)),cljs.core.cst$sym$fn1,cljs.core.cst$sym$meta31065], null);
}));

(cljs.core.async.t_cljs$core$async31064.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async31064.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async31064");

(cljs.core.async.t_cljs$core$async31064.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write(writer__4429__auto__,"cljs.core.async/t_cljs$core$async31064");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async31064.
 */
cljs.core.async.__GT_t_cljs$core$async31064 = (function cljs$core$async$map_LT__$___GT_t_cljs$core$async31064(f__$1,ch__$1,meta31062__$1,___$2,fn1__$1,meta31065){
return (new cljs.core.async.t_cljs$core$async31064(f__$1,ch__$1,meta31062__$1,___$2,fn1__$1,meta31065));
});

}

return (new cljs.core.async.t_cljs$core$async31064(self__.f,self__.ch,self__.meta31062,___$1,fn1,cljs.core.PersistentArrayMap.EMPTY));
})()
);
if(cljs.core.truth_((function (){var and__4174__auto__ = ret;
if(cljs.core.truth_(and__4174__auto__)){
return (!((cljs.core.deref(ret) == null)));
} else {
return and__4174__auto__;
}
})())){
return cljs.core.async.impl.channels.box((function (){var G__31068 = cljs.core.deref(ret);
return (self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(G__31068) : self__.f.call(null,G__31068));
})());
} else {
return ret;
}
}));

(cljs.core.async.t_cljs$core$async31061.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async31061.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
}));

(cljs.core.async.t_cljs$core$async31061.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta31062], null);
}));

(cljs.core.async.t_cljs$core$async31061.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async31061.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async31061");

(cljs.core.async.t_cljs$core$async31061.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write(writer__4429__auto__,"cljs.core.async/t_cljs$core$async31061");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async31061.
 */
cljs.core.async.__GT_t_cljs$core$async31061 = (function cljs$core$async$map_LT__$___GT_t_cljs$core$async31061(f__$1,ch__$1,meta31062){
return (new cljs.core.async.t_cljs$core$async31061(f__$1,ch__$1,meta31062));
});

}

return (new cljs.core.async.t_cljs$core$async31061(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_GT_ = (function cljs$core$async$map_GT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async31069 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async31069 = (function (f,ch,meta31070){
this.f = f;
this.ch = ch;
this.meta31070 = meta31070;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async31069.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_31071,meta31070__$1){
var self__ = this;
var _31071__$1 = this;
return (new cljs.core.async.t_cljs$core$async31069(self__.f,self__.ch,meta31070__$1));
}));

(cljs.core.async.t_cljs$core$async31069.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_31071){
var self__ = this;
var _31071__$1 = this;
return self__.meta31070;
}));

(cljs.core.async.t_cljs$core$async31069.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async31069.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
}));

(cljs.core.async.t_cljs$core$async31069.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async31069.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
}));

(cljs.core.async.t_cljs$core$async31069.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async31069.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(val) : self__.f.call(null,val)),fn1);
}));

(cljs.core.async.t_cljs$core$async31069.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta31070], null);
}));

(cljs.core.async.t_cljs$core$async31069.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async31069.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async31069");

(cljs.core.async.t_cljs$core$async31069.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write(writer__4429__auto__,"cljs.core.async/t_cljs$core$async31069");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async31069.
 */
cljs.core.async.__GT_t_cljs$core$async31069 = (function cljs$core$async$map_GT__$___GT_t_cljs$core$async31069(f__$1,ch__$1,meta31070){
return (new cljs.core.async.t_cljs$core$async31069(f__$1,ch__$1,meta31070));
});

}

return (new cljs.core.async.t_cljs$core$async31069(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_GT_ = (function cljs$core$async$filter_GT_(p,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async31072 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async31072 = (function (p,ch,meta31073){
this.p = p;
this.ch = ch;
this.meta31073 = meta31073;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(cljs.core.async.t_cljs$core$async31072.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_31074,meta31073__$1){
var self__ = this;
var _31074__$1 = this;
return (new cljs.core.async.t_cljs$core$async31072(self__.p,self__.ch,meta31073__$1));
}));

(cljs.core.async.t_cljs$core$async31072.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_31074){
var self__ = this;
var _31074__$1 = this;
return self__.meta31073;
}));

(cljs.core.async.t_cljs$core$async31072.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async31072.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
}));

(cljs.core.async.t_cljs$core$async31072.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
}));

(cljs.core.async.t_cljs$core$async31072.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async31072.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
}));

(cljs.core.async.t_cljs$core$async31072.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.async.t_cljs$core$async31072.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_((self__.p.cljs$core$IFn$_invoke$arity$1 ? self__.p.cljs$core$IFn$_invoke$arity$1(val) : self__.p.call(null,val)))){
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
} else {
return cljs.core.async.impl.channels.box(cljs.core.not(cljs.core.async.impl.protocols.closed_QMARK_(self__.ch)));
}
}));

(cljs.core.async.t_cljs$core$async31072.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$p,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta31073], null);
}));

(cljs.core.async.t_cljs$core$async31072.cljs$lang$type = true);

(cljs.core.async.t_cljs$core$async31072.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async31072");

(cljs.core.async.t_cljs$core$async31072.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write(writer__4429__auto__,"cljs.core.async/t_cljs$core$async31072");
}));

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async31072.
 */
cljs.core.async.__GT_t_cljs$core$async31072 = (function cljs$core$async$filter_GT__$___GT_t_cljs$core$async31072(p__$1,ch__$1,meta31073){
return (new cljs.core.async.t_cljs$core$async31072(p__$1,ch__$1,meta31073));
});

}

return (new cljs.core.async.t_cljs$core$async31072(p,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_GT_ = (function cljs$core$async$remove_GT_(p,ch){
return cljs.core.async.filter_GT_(cljs.core.complement(p),ch);
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_LT_ = (function cljs$core$async$filter_LT_(var_args){
var G__31076 = arguments.length;
switch (G__31076) {
case 2:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
}));

(cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__27715__auto___31116 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_31097){
var state_val_31098 = (state_31097[(1)]);
if((state_val_31098 === (7))){
var inst_31093 = (state_31097[(2)]);
var state_31097__$1 = state_31097;
var statearr_31099_31117 = state_31097__$1;
(statearr_31099_31117[(2)] = inst_31093);

(statearr_31099_31117[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31098 === (1))){
var state_31097__$1 = state_31097;
var statearr_31100_31118 = state_31097__$1;
(statearr_31100_31118[(2)] = null);

(statearr_31100_31118[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31098 === (4))){
var inst_31079 = (state_31097[(7)]);
var inst_31079__$1 = (state_31097[(2)]);
var inst_31080 = (inst_31079__$1 == null);
var state_31097__$1 = (function (){var statearr_31101 = state_31097;
(statearr_31101[(7)] = inst_31079__$1);

return statearr_31101;
})();
if(cljs.core.truth_(inst_31080)){
var statearr_31102_31119 = state_31097__$1;
(statearr_31102_31119[(1)] = (5));

} else {
var statearr_31103_31120 = state_31097__$1;
(statearr_31103_31120[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31098 === (6))){
var inst_31079 = (state_31097[(7)]);
var inst_31084 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_31079) : p.call(null,inst_31079));
var state_31097__$1 = state_31097;
if(cljs.core.truth_(inst_31084)){
var statearr_31104_31121 = state_31097__$1;
(statearr_31104_31121[(1)] = (8));

} else {
var statearr_31105_31122 = state_31097__$1;
(statearr_31105_31122[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31098 === (3))){
var inst_31095 = (state_31097[(2)]);
var state_31097__$1 = state_31097;
return cljs.core.async.impl.ioc_helpers.return_chan(state_31097__$1,inst_31095);
} else {
if((state_val_31098 === (2))){
var state_31097__$1 = state_31097;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_31097__$1,(4),ch);
} else {
if((state_val_31098 === (11))){
var inst_31087 = (state_31097[(2)]);
var state_31097__$1 = state_31097;
var statearr_31106_31123 = state_31097__$1;
(statearr_31106_31123[(2)] = inst_31087);

(statearr_31106_31123[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31098 === (9))){
var state_31097__$1 = state_31097;
var statearr_31107_31124 = state_31097__$1;
(statearr_31107_31124[(2)] = null);

(statearr_31107_31124[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31098 === (5))){
var inst_31082 = cljs.core.async.close_BANG_(out);
var state_31097__$1 = state_31097;
var statearr_31108_31125 = state_31097__$1;
(statearr_31108_31125[(2)] = inst_31082);

(statearr_31108_31125[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31098 === (10))){
var inst_31090 = (state_31097[(2)]);
var state_31097__$1 = (function (){var statearr_31109 = state_31097;
(statearr_31109[(8)] = inst_31090);

return statearr_31109;
})();
var statearr_31110_31126 = state_31097__$1;
(statearr_31110_31126[(2)] = null);

(statearr_31110_31126[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31098 === (8))){
var inst_31079 = (state_31097[(7)]);
var state_31097__$1 = state_31097;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_31097__$1,(11),out,inst_31079);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_31111 = [null,null,null,null,null,null,null,null,null];
(statearr_31111[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_31111[(1)] = (1));

return statearr_31111;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_31097){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_31097);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e31112){if((e31112 instanceof Object)){
var ex__27528__auto__ = e31112;
var statearr_31113_31127 = state_31097;
(statearr_31113_31127[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_31097);

return cljs.core.cst$kw$recur;
} else {
throw e31112;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__31128 = state_31097;
state_31097 = G__31128;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_31097){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_31097);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_31114 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_31114[(6)] = c__27715__auto___31116);

return statearr_31114;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));


return out;
}));

(cljs.core.async.filter_LT_.cljs$lang$maxFixedArity = 3);

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_LT_ = (function cljs$core$async$remove_LT_(var_args){
var G__31130 = arguments.length;
switch (G__31130) {
case 2:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
}));

(cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(cljs.core.complement(p),ch,buf_or_n);
}));

(cljs.core.async.remove_LT_.cljs$lang$maxFixedArity = 3);

cljs.core.async.mapcat_STAR_ = (function cljs$core$async$mapcat_STAR_(f,in$,out){
var c__27715__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_31193){
var state_val_31194 = (state_31193[(1)]);
if((state_val_31194 === (7))){
var inst_31189 = (state_31193[(2)]);
var state_31193__$1 = state_31193;
var statearr_31195_31233 = state_31193__$1;
(statearr_31195_31233[(2)] = inst_31189);

(statearr_31195_31233[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (20))){
var inst_31159 = (state_31193[(7)]);
var inst_31170 = (state_31193[(2)]);
var inst_31171 = cljs.core.next(inst_31159);
var inst_31145 = inst_31171;
var inst_31146 = null;
var inst_31147 = (0);
var inst_31148 = (0);
var state_31193__$1 = (function (){var statearr_31196 = state_31193;
(statearr_31196[(8)] = inst_31147);

(statearr_31196[(9)] = inst_31146);

(statearr_31196[(10)] = inst_31145);

(statearr_31196[(11)] = inst_31148);

(statearr_31196[(12)] = inst_31170);

return statearr_31196;
})();
var statearr_31197_31234 = state_31193__$1;
(statearr_31197_31234[(2)] = null);

(statearr_31197_31234[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (1))){
var state_31193__$1 = state_31193;
var statearr_31198_31235 = state_31193__$1;
(statearr_31198_31235[(2)] = null);

(statearr_31198_31235[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (4))){
var inst_31134 = (state_31193[(13)]);
var inst_31134__$1 = (state_31193[(2)]);
var inst_31135 = (inst_31134__$1 == null);
var state_31193__$1 = (function (){var statearr_31199 = state_31193;
(statearr_31199[(13)] = inst_31134__$1);

return statearr_31199;
})();
if(cljs.core.truth_(inst_31135)){
var statearr_31200_31236 = state_31193__$1;
(statearr_31200_31236[(1)] = (5));

} else {
var statearr_31201_31237 = state_31193__$1;
(statearr_31201_31237[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (15))){
var state_31193__$1 = state_31193;
var statearr_31205_31238 = state_31193__$1;
(statearr_31205_31238[(2)] = null);

(statearr_31205_31238[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (21))){
var state_31193__$1 = state_31193;
var statearr_31206_31239 = state_31193__$1;
(statearr_31206_31239[(2)] = null);

(statearr_31206_31239[(1)] = (23));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (13))){
var inst_31147 = (state_31193[(8)]);
var inst_31146 = (state_31193[(9)]);
var inst_31145 = (state_31193[(10)]);
var inst_31148 = (state_31193[(11)]);
var inst_31155 = (state_31193[(2)]);
var inst_31156 = (inst_31148 + (1));
var tmp31202 = inst_31147;
var tmp31203 = inst_31146;
var tmp31204 = inst_31145;
var inst_31145__$1 = tmp31204;
var inst_31146__$1 = tmp31203;
var inst_31147__$1 = tmp31202;
var inst_31148__$1 = inst_31156;
var state_31193__$1 = (function (){var statearr_31207 = state_31193;
(statearr_31207[(8)] = inst_31147__$1);

(statearr_31207[(9)] = inst_31146__$1);

(statearr_31207[(10)] = inst_31145__$1);

(statearr_31207[(14)] = inst_31155);

(statearr_31207[(11)] = inst_31148__$1);

return statearr_31207;
})();
var statearr_31208_31240 = state_31193__$1;
(statearr_31208_31240[(2)] = null);

(statearr_31208_31240[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (22))){
var state_31193__$1 = state_31193;
var statearr_31209_31241 = state_31193__$1;
(statearr_31209_31241[(2)] = null);

(statearr_31209_31241[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (6))){
var inst_31134 = (state_31193[(13)]);
var inst_31143 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_31134) : f.call(null,inst_31134));
var inst_31144 = cljs.core.seq(inst_31143);
var inst_31145 = inst_31144;
var inst_31146 = null;
var inst_31147 = (0);
var inst_31148 = (0);
var state_31193__$1 = (function (){var statearr_31210 = state_31193;
(statearr_31210[(8)] = inst_31147);

(statearr_31210[(9)] = inst_31146);

(statearr_31210[(10)] = inst_31145);

(statearr_31210[(11)] = inst_31148);

return statearr_31210;
})();
var statearr_31211_31242 = state_31193__$1;
(statearr_31211_31242[(2)] = null);

(statearr_31211_31242[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (17))){
var inst_31159 = (state_31193[(7)]);
var inst_31163 = cljs.core.chunk_first(inst_31159);
var inst_31164 = cljs.core.chunk_rest(inst_31159);
var inst_31165 = cljs.core.count(inst_31163);
var inst_31145 = inst_31164;
var inst_31146 = inst_31163;
var inst_31147 = inst_31165;
var inst_31148 = (0);
var state_31193__$1 = (function (){var statearr_31212 = state_31193;
(statearr_31212[(8)] = inst_31147);

(statearr_31212[(9)] = inst_31146);

(statearr_31212[(10)] = inst_31145);

(statearr_31212[(11)] = inst_31148);

return statearr_31212;
})();
var statearr_31213_31243 = state_31193__$1;
(statearr_31213_31243[(2)] = null);

(statearr_31213_31243[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (3))){
var inst_31191 = (state_31193[(2)]);
var state_31193__$1 = state_31193;
return cljs.core.async.impl.ioc_helpers.return_chan(state_31193__$1,inst_31191);
} else {
if((state_val_31194 === (12))){
var inst_31179 = (state_31193[(2)]);
var state_31193__$1 = state_31193;
var statearr_31214_31244 = state_31193__$1;
(statearr_31214_31244[(2)] = inst_31179);

(statearr_31214_31244[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (2))){
var state_31193__$1 = state_31193;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_31193__$1,(4),in$);
} else {
if((state_val_31194 === (23))){
var inst_31187 = (state_31193[(2)]);
var state_31193__$1 = state_31193;
var statearr_31215_31245 = state_31193__$1;
(statearr_31215_31245[(2)] = inst_31187);

(statearr_31215_31245[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (19))){
var inst_31174 = (state_31193[(2)]);
var state_31193__$1 = state_31193;
var statearr_31216_31246 = state_31193__$1;
(statearr_31216_31246[(2)] = inst_31174);

(statearr_31216_31246[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (11))){
var inst_31159 = (state_31193[(7)]);
var inst_31145 = (state_31193[(10)]);
var inst_31159__$1 = cljs.core.seq(inst_31145);
var state_31193__$1 = (function (){var statearr_31217 = state_31193;
(statearr_31217[(7)] = inst_31159__$1);

return statearr_31217;
})();
if(inst_31159__$1){
var statearr_31218_31247 = state_31193__$1;
(statearr_31218_31247[(1)] = (14));

} else {
var statearr_31219_31248 = state_31193__$1;
(statearr_31219_31248[(1)] = (15));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (9))){
var inst_31181 = (state_31193[(2)]);
var inst_31182 = cljs.core.async.impl.protocols.closed_QMARK_(out);
var state_31193__$1 = (function (){var statearr_31220 = state_31193;
(statearr_31220[(15)] = inst_31181);

return statearr_31220;
})();
if(cljs.core.truth_(inst_31182)){
var statearr_31221_31249 = state_31193__$1;
(statearr_31221_31249[(1)] = (21));

} else {
var statearr_31222_31250 = state_31193__$1;
(statearr_31222_31250[(1)] = (22));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (5))){
var inst_31137 = cljs.core.async.close_BANG_(out);
var state_31193__$1 = state_31193;
var statearr_31223_31251 = state_31193__$1;
(statearr_31223_31251[(2)] = inst_31137);

(statearr_31223_31251[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (14))){
var inst_31159 = (state_31193[(7)]);
var inst_31161 = cljs.core.chunked_seq_QMARK_(inst_31159);
var state_31193__$1 = state_31193;
if(inst_31161){
var statearr_31224_31252 = state_31193__$1;
(statearr_31224_31252[(1)] = (17));

} else {
var statearr_31225_31253 = state_31193__$1;
(statearr_31225_31253[(1)] = (18));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (16))){
var inst_31177 = (state_31193[(2)]);
var state_31193__$1 = state_31193;
var statearr_31226_31254 = state_31193__$1;
(statearr_31226_31254[(2)] = inst_31177);

(statearr_31226_31254[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31194 === (10))){
var inst_31146 = (state_31193[(9)]);
var inst_31148 = (state_31193[(11)]);
var inst_31153 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_31146,inst_31148);
var state_31193__$1 = state_31193;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_31193__$1,(13),out,inst_31153);
} else {
if((state_val_31194 === (18))){
var inst_31159 = (state_31193[(7)]);
var inst_31168 = cljs.core.first(inst_31159);
var state_31193__$1 = state_31193;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_31193__$1,(20),out,inst_31168);
} else {
if((state_val_31194 === (8))){
var inst_31147 = (state_31193[(8)]);
var inst_31148 = (state_31193[(11)]);
var inst_31150 = (inst_31148 < inst_31147);
var inst_31151 = inst_31150;
var state_31193__$1 = state_31193;
if(cljs.core.truth_(inst_31151)){
var statearr_31227_31255 = state_31193__$1;
(statearr_31227_31255[(1)] = (10));

} else {
var statearr_31228_31256 = state_31193__$1;
(statearr_31228_31256[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$mapcat_STAR__$_state_machine__27525__auto__ = null;
var cljs$core$async$mapcat_STAR__$_state_machine__27525__auto____0 = (function (){
var statearr_31229 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_31229[(0)] = cljs$core$async$mapcat_STAR__$_state_machine__27525__auto__);

(statearr_31229[(1)] = (1));

return statearr_31229;
});
var cljs$core$async$mapcat_STAR__$_state_machine__27525__auto____1 = (function (state_31193){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_31193);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e31230){if((e31230 instanceof Object)){
var ex__27528__auto__ = e31230;
var statearr_31231_31257 = state_31193;
(statearr_31231_31257[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_31193);

return cljs.core.cst$kw$recur;
} else {
throw e31230;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__31258 = state_31193;
state_31193 = G__31258;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$mapcat_STAR__$_state_machine__27525__auto__ = function(state_31193){
switch(arguments.length){
case 0:
return cljs$core$async$mapcat_STAR__$_state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$mapcat_STAR__$_state_machine__27525__auto____1.call(this,state_31193);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mapcat_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mapcat_STAR__$_state_machine__27525__auto____0;
cljs$core$async$mapcat_STAR__$_state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mapcat_STAR__$_state_machine__27525__auto____1;
return cljs$core$async$mapcat_STAR__$_state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_31232 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_31232[(6)] = c__27715__auto__);

return statearr_31232;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));

return c__27715__auto__;
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_LT_ = (function cljs$core$async$mapcat_LT_(var_args){
var G__31260 = arguments.length;
switch (G__31260) {
case 2:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2 = (function (f,in$){
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3(f,in$,null);
}));

(cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3 = (function (f,in$,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return out;
}));

(cljs.core.async.mapcat_LT_.cljs$lang$maxFixedArity = 3);

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_GT_ = (function cljs$core$async$mapcat_GT_(var_args){
var G__31263 = arguments.length;
switch (G__31263) {
case 2:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2 = (function (f,out){
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3(f,out,null);
}));

(cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3 = (function (f,out,buf_or_n){
var in$ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return in$;
}));

(cljs.core.async.mapcat_GT_.cljs$lang$maxFixedArity = 3);

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.unique = (function cljs$core$async$unique(var_args){
var G__31266 = arguments.length;
switch (G__31266) {
case 1:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1 = (function (ch){
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2(ch,null);
}));

(cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2 = (function (ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__27715__auto___31313 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_31290){
var state_val_31291 = (state_31290[(1)]);
if((state_val_31291 === (7))){
var inst_31285 = (state_31290[(2)]);
var state_31290__$1 = state_31290;
var statearr_31292_31314 = state_31290__$1;
(statearr_31292_31314[(2)] = inst_31285);

(statearr_31292_31314[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31291 === (1))){
var inst_31267 = null;
var state_31290__$1 = (function (){var statearr_31293 = state_31290;
(statearr_31293[(7)] = inst_31267);

return statearr_31293;
})();
var statearr_31294_31315 = state_31290__$1;
(statearr_31294_31315[(2)] = null);

(statearr_31294_31315[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31291 === (4))){
var inst_31270 = (state_31290[(8)]);
var inst_31270__$1 = (state_31290[(2)]);
var inst_31271 = (inst_31270__$1 == null);
var inst_31272 = cljs.core.not(inst_31271);
var state_31290__$1 = (function (){var statearr_31295 = state_31290;
(statearr_31295[(8)] = inst_31270__$1);

return statearr_31295;
})();
if(inst_31272){
var statearr_31296_31316 = state_31290__$1;
(statearr_31296_31316[(1)] = (5));

} else {
var statearr_31297_31317 = state_31290__$1;
(statearr_31297_31317[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31291 === (6))){
var state_31290__$1 = state_31290;
var statearr_31298_31318 = state_31290__$1;
(statearr_31298_31318[(2)] = null);

(statearr_31298_31318[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31291 === (3))){
var inst_31287 = (state_31290[(2)]);
var inst_31288 = cljs.core.async.close_BANG_(out);
var state_31290__$1 = (function (){var statearr_31299 = state_31290;
(statearr_31299[(9)] = inst_31287);

return statearr_31299;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_31290__$1,inst_31288);
} else {
if((state_val_31291 === (2))){
var state_31290__$1 = state_31290;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_31290__$1,(4),ch);
} else {
if((state_val_31291 === (11))){
var inst_31270 = (state_31290[(8)]);
var inst_31279 = (state_31290[(2)]);
var inst_31267 = inst_31270;
var state_31290__$1 = (function (){var statearr_31300 = state_31290;
(statearr_31300[(7)] = inst_31267);

(statearr_31300[(10)] = inst_31279);

return statearr_31300;
})();
var statearr_31301_31319 = state_31290__$1;
(statearr_31301_31319[(2)] = null);

(statearr_31301_31319[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31291 === (9))){
var inst_31270 = (state_31290[(8)]);
var state_31290__$1 = state_31290;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_31290__$1,(11),out,inst_31270);
} else {
if((state_val_31291 === (5))){
var inst_31267 = (state_31290[(7)]);
var inst_31270 = (state_31290[(8)]);
var inst_31274 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_31270,inst_31267);
var state_31290__$1 = state_31290;
if(inst_31274){
var statearr_31303_31320 = state_31290__$1;
(statearr_31303_31320[(1)] = (8));

} else {
var statearr_31304_31321 = state_31290__$1;
(statearr_31304_31321[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31291 === (10))){
var inst_31282 = (state_31290[(2)]);
var state_31290__$1 = state_31290;
var statearr_31305_31322 = state_31290__$1;
(statearr_31305_31322[(2)] = inst_31282);

(statearr_31305_31322[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31291 === (8))){
var inst_31267 = (state_31290[(7)]);
var tmp31302 = inst_31267;
var inst_31267__$1 = tmp31302;
var state_31290__$1 = (function (){var statearr_31306 = state_31290;
(statearr_31306[(7)] = inst_31267__$1);

return statearr_31306;
})();
var statearr_31307_31323 = state_31290__$1;
(statearr_31307_31323[(2)] = null);

(statearr_31307_31323[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_31308 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_31308[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_31308[(1)] = (1));

return statearr_31308;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_31290){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_31290);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e31309){if((e31309 instanceof Object)){
var ex__27528__auto__ = e31309;
var statearr_31310_31324 = state_31290;
(statearr_31310_31324[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_31290);

return cljs.core.cst$kw$recur;
} else {
throw e31309;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__31325 = state_31290;
state_31290 = G__31325;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_31290){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_31290);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_31311 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_31311[(6)] = c__27715__auto___31313);

return statearr_31311;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));


return out;
}));

(cljs.core.async.unique.cljs$lang$maxFixedArity = 2);

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition = (function cljs$core$async$partition(var_args){
var G__31327 = arguments.length;
switch (G__31327) {
case 2:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3(n,ch,null);
}));

(cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__27715__auto___31393 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_31365){
var state_val_31366 = (state_31365[(1)]);
if((state_val_31366 === (7))){
var inst_31361 = (state_31365[(2)]);
var state_31365__$1 = state_31365;
var statearr_31367_31394 = state_31365__$1;
(statearr_31367_31394[(2)] = inst_31361);

(statearr_31367_31394[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31366 === (1))){
var inst_31328 = (new Array(n));
var inst_31329 = inst_31328;
var inst_31330 = (0);
var state_31365__$1 = (function (){var statearr_31368 = state_31365;
(statearr_31368[(7)] = inst_31330);

(statearr_31368[(8)] = inst_31329);

return statearr_31368;
})();
var statearr_31369_31395 = state_31365__$1;
(statearr_31369_31395[(2)] = null);

(statearr_31369_31395[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31366 === (4))){
var inst_31333 = (state_31365[(9)]);
var inst_31333__$1 = (state_31365[(2)]);
var inst_31334 = (inst_31333__$1 == null);
var inst_31335 = cljs.core.not(inst_31334);
var state_31365__$1 = (function (){var statearr_31370 = state_31365;
(statearr_31370[(9)] = inst_31333__$1);

return statearr_31370;
})();
if(inst_31335){
var statearr_31371_31396 = state_31365__$1;
(statearr_31371_31396[(1)] = (5));

} else {
var statearr_31372_31397 = state_31365__$1;
(statearr_31372_31397[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31366 === (15))){
var inst_31355 = (state_31365[(2)]);
var state_31365__$1 = state_31365;
var statearr_31373_31398 = state_31365__$1;
(statearr_31373_31398[(2)] = inst_31355);

(statearr_31373_31398[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31366 === (13))){
var state_31365__$1 = state_31365;
var statearr_31374_31399 = state_31365__$1;
(statearr_31374_31399[(2)] = null);

(statearr_31374_31399[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31366 === (6))){
var inst_31330 = (state_31365[(7)]);
var inst_31351 = (inst_31330 > (0));
var state_31365__$1 = state_31365;
if(cljs.core.truth_(inst_31351)){
var statearr_31375_31400 = state_31365__$1;
(statearr_31375_31400[(1)] = (12));

} else {
var statearr_31376_31401 = state_31365__$1;
(statearr_31376_31401[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31366 === (3))){
var inst_31363 = (state_31365[(2)]);
var state_31365__$1 = state_31365;
return cljs.core.async.impl.ioc_helpers.return_chan(state_31365__$1,inst_31363);
} else {
if((state_val_31366 === (12))){
var inst_31329 = (state_31365[(8)]);
var inst_31353 = cljs.core.vec(inst_31329);
var state_31365__$1 = state_31365;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_31365__$1,(15),out,inst_31353);
} else {
if((state_val_31366 === (2))){
var state_31365__$1 = state_31365;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_31365__$1,(4),ch);
} else {
if((state_val_31366 === (11))){
var inst_31345 = (state_31365[(2)]);
var inst_31346 = (new Array(n));
var inst_31329 = inst_31346;
var inst_31330 = (0);
var state_31365__$1 = (function (){var statearr_31377 = state_31365;
(statearr_31377[(7)] = inst_31330);

(statearr_31377[(10)] = inst_31345);

(statearr_31377[(8)] = inst_31329);

return statearr_31377;
})();
var statearr_31378_31402 = state_31365__$1;
(statearr_31378_31402[(2)] = null);

(statearr_31378_31402[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31366 === (9))){
var inst_31329 = (state_31365[(8)]);
var inst_31343 = cljs.core.vec(inst_31329);
var state_31365__$1 = state_31365;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_31365__$1,(11),out,inst_31343);
} else {
if((state_val_31366 === (5))){
var inst_31330 = (state_31365[(7)]);
var inst_31338 = (state_31365[(11)]);
var inst_31329 = (state_31365[(8)]);
var inst_31333 = (state_31365[(9)]);
var inst_31337 = (inst_31329[inst_31330] = inst_31333);
var inst_31338__$1 = (inst_31330 + (1));
var inst_31339 = (inst_31338__$1 < n);
var state_31365__$1 = (function (){var statearr_31379 = state_31365;
(statearr_31379[(11)] = inst_31338__$1);

(statearr_31379[(12)] = inst_31337);

return statearr_31379;
})();
if(cljs.core.truth_(inst_31339)){
var statearr_31380_31403 = state_31365__$1;
(statearr_31380_31403[(1)] = (8));

} else {
var statearr_31381_31404 = state_31365__$1;
(statearr_31381_31404[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31366 === (14))){
var inst_31358 = (state_31365[(2)]);
var inst_31359 = cljs.core.async.close_BANG_(out);
var state_31365__$1 = (function (){var statearr_31383 = state_31365;
(statearr_31383[(13)] = inst_31358);

return statearr_31383;
})();
var statearr_31384_31405 = state_31365__$1;
(statearr_31384_31405[(2)] = inst_31359);

(statearr_31384_31405[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31366 === (10))){
var inst_31349 = (state_31365[(2)]);
var state_31365__$1 = state_31365;
var statearr_31385_31406 = state_31365__$1;
(statearr_31385_31406[(2)] = inst_31349);

(statearr_31385_31406[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31366 === (8))){
var inst_31338 = (state_31365[(11)]);
var inst_31329 = (state_31365[(8)]);
var tmp31382 = inst_31329;
var inst_31329__$1 = tmp31382;
var inst_31330 = inst_31338;
var state_31365__$1 = (function (){var statearr_31386 = state_31365;
(statearr_31386[(7)] = inst_31330);

(statearr_31386[(8)] = inst_31329__$1);

return statearr_31386;
})();
var statearr_31387_31407 = state_31365__$1;
(statearr_31387_31407[(2)] = null);

(statearr_31387_31407[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_31388 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_31388[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_31388[(1)] = (1));

return statearr_31388;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_31365){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_31365);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e31389){if((e31389 instanceof Object)){
var ex__27528__auto__ = e31389;
var statearr_31390_31408 = state_31365;
(statearr_31390_31408[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_31365);

return cljs.core.cst$kw$recur;
} else {
throw e31389;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__31409 = state_31365;
state_31365 = G__31409;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_31365){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_31365);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_31391 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_31391[(6)] = c__27715__auto___31393);

return statearr_31391;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));


return out;
}));

(cljs.core.async.partition.cljs$lang$maxFixedArity = 3);

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition_by = (function cljs$core$async$partition_by(var_args){
var G__31411 = arguments.length;
switch (G__31411) {
case 2:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2 = (function (f,ch){
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3(f,ch,null);
}));

(cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3 = (function (f,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__27715__auto___31481 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__27716__auto__ = (function (){var switch__27524__auto__ = (function (state_31453){
var state_val_31454 = (state_31453[(1)]);
if((state_val_31454 === (7))){
var inst_31449 = (state_31453[(2)]);
var state_31453__$1 = state_31453;
var statearr_31455_31482 = state_31453__$1;
(statearr_31455_31482[(2)] = inst_31449);

(statearr_31455_31482[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31454 === (1))){
var inst_31412 = [];
var inst_31413 = inst_31412;
var inst_31414 = cljs.core.cst$kw$cljs$core$async_SLASH_nothing;
var state_31453__$1 = (function (){var statearr_31456 = state_31453;
(statearr_31456[(7)] = inst_31414);

(statearr_31456[(8)] = inst_31413);

return statearr_31456;
})();
var statearr_31457_31483 = state_31453__$1;
(statearr_31457_31483[(2)] = null);

(statearr_31457_31483[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31454 === (4))){
var inst_31417 = (state_31453[(9)]);
var inst_31417__$1 = (state_31453[(2)]);
var inst_31418 = (inst_31417__$1 == null);
var inst_31419 = cljs.core.not(inst_31418);
var state_31453__$1 = (function (){var statearr_31458 = state_31453;
(statearr_31458[(9)] = inst_31417__$1);

return statearr_31458;
})();
if(inst_31419){
var statearr_31459_31484 = state_31453__$1;
(statearr_31459_31484[(1)] = (5));

} else {
var statearr_31460_31485 = state_31453__$1;
(statearr_31460_31485[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31454 === (15))){
var inst_31443 = (state_31453[(2)]);
var state_31453__$1 = state_31453;
var statearr_31461_31486 = state_31453__$1;
(statearr_31461_31486[(2)] = inst_31443);

(statearr_31461_31486[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31454 === (13))){
var state_31453__$1 = state_31453;
var statearr_31462_31487 = state_31453__$1;
(statearr_31462_31487[(2)] = null);

(statearr_31462_31487[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31454 === (6))){
var inst_31413 = (state_31453[(8)]);
var inst_31438 = inst_31413.length;
var inst_31439 = (inst_31438 > (0));
var state_31453__$1 = state_31453;
if(cljs.core.truth_(inst_31439)){
var statearr_31463_31488 = state_31453__$1;
(statearr_31463_31488[(1)] = (12));

} else {
var statearr_31464_31489 = state_31453__$1;
(statearr_31464_31489[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31454 === (3))){
var inst_31451 = (state_31453[(2)]);
var state_31453__$1 = state_31453;
return cljs.core.async.impl.ioc_helpers.return_chan(state_31453__$1,inst_31451);
} else {
if((state_val_31454 === (12))){
var inst_31413 = (state_31453[(8)]);
var inst_31441 = cljs.core.vec(inst_31413);
var state_31453__$1 = state_31453;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_31453__$1,(15),out,inst_31441);
} else {
if((state_val_31454 === (2))){
var state_31453__$1 = state_31453;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_31453__$1,(4),ch);
} else {
if((state_val_31454 === (11))){
var inst_31417 = (state_31453[(9)]);
var inst_31421 = (state_31453[(10)]);
var inst_31431 = (state_31453[(2)]);
var inst_31432 = [];
var inst_31433 = inst_31432.push(inst_31417);
var inst_31413 = inst_31432;
var inst_31414 = inst_31421;
var state_31453__$1 = (function (){var statearr_31465 = state_31453;
(statearr_31465[(7)] = inst_31414);

(statearr_31465[(11)] = inst_31433);

(statearr_31465[(12)] = inst_31431);

(statearr_31465[(8)] = inst_31413);

return statearr_31465;
})();
var statearr_31466_31490 = state_31453__$1;
(statearr_31466_31490[(2)] = null);

(statearr_31466_31490[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31454 === (9))){
var inst_31413 = (state_31453[(8)]);
var inst_31429 = cljs.core.vec(inst_31413);
var state_31453__$1 = state_31453;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_31453__$1,(11),out,inst_31429);
} else {
if((state_val_31454 === (5))){
var inst_31414 = (state_31453[(7)]);
var inst_31417 = (state_31453[(9)]);
var inst_31421 = (state_31453[(10)]);
var inst_31421__$1 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_31417) : f.call(null,inst_31417));
var inst_31422 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_31421__$1,inst_31414);
var inst_31423 = cljs.core.keyword_identical_QMARK_(inst_31414,cljs.core.cst$kw$cljs$core$async_SLASH_nothing);
var inst_31424 = ((inst_31422) || (inst_31423));
var state_31453__$1 = (function (){var statearr_31467 = state_31453;
(statearr_31467[(10)] = inst_31421__$1);

return statearr_31467;
})();
if(cljs.core.truth_(inst_31424)){
var statearr_31468_31491 = state_31453__$1;
(statearr_31468_31491[(1)] = (8));

} else {
var statearr_31469_31492 = state_31453__$1;
(statearr_31469_31492[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31454 === (14))){
var inst_31446 = (state_31453[(2)]);
var inst_31447 = cljs.core.async.close_BANG_(out);
var state_31453__$1 = (function (){var statearr_31471 = state_31453;
(statearr_31471[(13)] = inst_31446);

return statearr_31471;
})();
var statearr_31472_31493 = state_31453__$1;
(statearr_31472_31493[(2)] = inst_31447);

(statearr_31472_31493[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31454 === (10))){
var inst_31436 = (state_31453[(2)]);
var state_31453__$1 = state_31453;
var statearr_31473_31494 = state_31453__$1;
(statearr_31473_31494[(2)] = inst_31436);

(statearr_31473_31494[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31454 === (8))){
var inst_31417 = (state_31453[(9)]);
var inst_31421 = (state_31453[(10)]);
var inst_31413 = (state_31453[(8)]);
var inst_31426 = inst_31413.push(inst_31417);
var tmp31470 = inst_31413;
var inst_31413__$1 = tmp31470;
var inst_31414 = inst_31421;
var state_31453__$1 = (function (){var statearr_31474 = state_31453;
(statearr_31474[(7)] = inst_31414);

(statearr_31474[(8)] = inst_31413__$1);

(statearr_31474[(14)] = inst_31426);

return statearr_31474;
})();
var statearr_31475_31495 = state_31453__$1;
(statearr_31475_31495[(2)] = null);

(statearr_31475_31495[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var cljs$core$async$state_machine__27525__auto__ = null;
var cljs$core$async$state_machine__27525__auto____0 = (function (){
var statearr_31476 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_31476[(0)] = cljs$core$async$state_machine__27525__auto__);

(statearr_31476[(1)] = (1));

return statearr_31476;
});
var cljs$core$async$state_machine__27525__auto____1 = (function (state_31453){
while(true){
var ret_value__27526__auto__ = (function (){try{while(true){
var result__27527__auto__ = switch__27524__auto__(state_31453);
if(cljs.core.keyword_identical_QMARK_(result__27527__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__27527__auto__;
}
break;
}
}catch (e31477){if((e31477 instanceof Object)){
var ex__27528__auto__ = e31477;
var statearr_31478_31496 = state_31453;
(statearr_31478_31496[(5)] = ex__27528__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_31453);

return cljs.core.cst$kw$recur;
} else {
throw e31477;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__27526__auto__,cljs.core.cst$kw$recur)){
var G__31497 = state_31453;
state_31453 = G__31497;
continue;
} else {
return ret_value__27526__auto__;
}
break;
}
});
cljs$core$async$state_machine__27525__auto__ = function(state_31453){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__27525__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__27525__auto____1.call(this,state_31453);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__27525__auto____0;
cljs$core$async$state_machine__27525__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__27525__auto____1;
return cljs$core$async$state_machine__27525__auto__;
})()
})();
var state__27717__auto__ = (function (){var statearr_31479 = (f__27716__auto__.cljs$core$IFn$_invoke$arity$0 ? f__27716__auto__.cljs$core$IFn$_invoke$arity$0() : f__27716__auto__.call(null));
(statearr_31479[(6)] = c__27715__auto___31481);

return statearr_31479;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__27717__auto__);
}));


return out;
}));

(cljs.core.async.partition_by.cljs$lang$maxFixedArity = 3);

