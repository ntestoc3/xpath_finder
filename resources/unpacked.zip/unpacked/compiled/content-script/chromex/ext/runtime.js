// Compiled by ClojureScript 1.10.597 {:static-fns true, :optimize-constants true}
goog.provide('chromex.ext.runtime');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.core');
chromex.ext.runtime.last_error_STAR_ = (function chromex$ext$runtime$last_error_STAR_(config){
var result_36304 = (function (){var final_args_array_36305 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.lastError");
var ns_36306 = (function (){var target_obj_36309 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36310 = (target_obj_36309["chrome"]);
var next_obj_36311 = (next_obj_36310["runtime"]);
return next_obj_36311;
})();
var missing_api_36307 = null;
if(missing_api_36307 === true){
return null;
} else {
var config__25890__auto___36314 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36314))){
var logger__25891__auto___36315 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36314);
var prefix__25892__auto___36316 = ["accessing:","chrome.runtime.lastError"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36315)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36314)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36315.apply(null,prefix__25892__auto___36316.concat(final_args_array_36305));
} else {
}

var target_36308 = (function (){var target_obj_36312 = ns_36306;
var next_obj_36313 = (target_obj_36312["lastError"]);
if((!((next_obj_36313 == null)))){
return next_obj_36313;
} else {
return null;
}
})();
return target_36308;
}
})();
return result_36304;
});
chromex.ext.runtime.id_STAR_ = (function chromex$ext$runtime$id_STAR_(config){
var result_36317 = (function (){var final_args_array_36318 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.id");
var ns_36319 = (function (){var target_obj_36322 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36323 = (target_obj_36322["chrome"]);
var next_obj_36324 = (next_obj_36323["runtime"]);
return next_obj_36324;
})();
var missing_api_36320 = null;
if(missing_api_36320 === true){
return null;
} else {
var config__25890__auto___36327 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36327))){
var logger__25891__auto___36328 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36327);
var prefix__25892__auto___36329 = ["accessing:","chrome.runtime.id"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36328)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36327)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36328.apply(null,prefix__25892__auto___36329.concat(final_args_array_36318));
} else {
}

var target_36321 = (function (){var target_obj_36325 = ns_36319;
var next_obj_36326 = (target_obj_36325["id"]);
if((!((next_obj_36326 == null)))){
return next_obj_36326;
} else {
return null;
}
})();
return target_36321;
}
})();
return result_36317;
});
chromex.ext.runtime.get_background_page_STAR_ = (function chromex$ext$runtime$get_background_page_STAR_(config){
var callback_chan_36330 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__) : handler__25858__auto__.call(null,config__25856__auto__));
})();
var marshalled_callback_36332_36350 = (function (cb_background_page_36337){
var fexpr__36341 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36342 = config__25856__auto__;
var G__36343 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_background_DASH_page,cljs.core.cst$kw$name,"getBackgroundPage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"background-page",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36344 = callback_chan_36330;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36342,G__36343,G__36344) : handler__25858__auto__.call(null,G__36342,G__36343,G__36344));
})();
return (fexpr__36341.cljs$core$IFn$_invoke$arity$1 ? fexpr__36341.cljs$core$IFn$_invoke$arity$1(cb_background_page_36337) : fexpr__36341.call(null,cb_background_page_36337));
});
var result_36331_36351 = (function (){var final_args_array_36333 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36332_36350,"callback",null], null)], null),"chrome.runtime.getBackgroundPage");
var ns_36334 = (function (){var target_obj_36345 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36346 = (target_obj_36345["chrome"]);
var next_obj_36347 = (next_obj_36346["runtime"]);
return next_obj_36347;
})();
var missing_api_36335 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getBackgroundPage",ns_36334,"getBackgroundPage") : api_check_fn__25895__auto__.call(null,"chrome.runtime.getBackgroundPage",ns_36334,"getBackgroundPage"));
})();
if(missing_api_36335 === true){
return null;
} else {
var config__25890__auto___36352 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36352))){
var logger__25891__auto___36353 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36352);
var prefix__25892__auto___36354 = ["calling:","chrome.runtime.getBackgroundPage"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36353)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36352)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36353.apply(null,prefix__25892__auto___36354.concat(final_args_array_36333));
} else {
}

var target_36336 = (function (){var target_obj_36348 = ns_36334;
var next_obj_36349 = (target_obj_36348["getBackgroundPage"]);
if((!((next_obj_36349 == null)))){
return next_obj_36349;
} else {
return null;
}
})();
return target_36336.apply(ns_36334,final_args_array_36333);
}
})();

return callback_chan_36330;
});
chromex.ext.runtime.open_options_page_STAR_ = (function chromex$ext$runtime$open_options_page_STAR_(config){
var callback_chan_36355 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__) : handler__25858__auto__.call(null,config__25856__auto__));
})();
var marshalled_callback_36357_36370 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36362 = config__25856__auto__;
var G__36363 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_open_DASH_options_DASH_page,cljs.core.cst$kw$name,"openOptionsPage",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36364 = callback_chan_36355;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36362,G__36363,G__36364) : handler__25858__auto__.call(null,G__36362,G__36363,G__36364));
})();
var result_36356_36371 = (function (){var final_args_array_36358 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36357_36370,"callback",true], null)], null),"chrome.runtime.openOptionsPage");
var ns_36359 = (function (){var target_obj_36365 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36366 = (target_obj_36365["chrome"]);
var next_obj_36367 = (next_obj_36366["runtime"]);
return next_obj_36367;
})();
var missing_api_36360 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.openOptionsPage",ns_36359,"openOptionsPage") : api_check_fn__25895__auto__.call(null,"chrome.runtime.openOptionsPage",ns_36359,"openOptionsPage"));
})();
if(missing_api_36360 === true){
return null;
} else {
var config__25890__auto___36372 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36372))){
var logger__25891__auto___36373 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36372);
var prefix__25892__auto___36374 = ["calling:","chrome.runtime.openOptionsPage"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36373)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36372)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36373.apply(null,prefix__25892__auto___36374.concat(final_args_array_36358));
} else {
}

var target_36361 = (function (){var target_obj_36368 = ns_36359;
var next_obj_36369 = (target_obj_36368["openOptionsPage"]);
if((!((next_obj_36369 == null)))){
return next_obj_36369;
} else {
return null;
}
})();
return target_36361.apply(ns_36359,final_args_array_36358);
}
})();

return callback_chan_36355;
});
chromex.ext.runtime.get_manifest_STAR_ = (function chromex$ext$runtime$get_manifest_STAR_(config){
var result_36375 = (function (){var final_args_array_36376 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.getManifest");
var ns_36377 = (function (){var target_obj_36380 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36381 = (target_obj_36380["chrome"]);
var next_obj_36382 = (next_obj_36381["runtime"]);
return next_obj_36382;
})();
var missing_api_36378 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getManifest",ns_36377,"getManifest") : api_check_fn__25895__auto__.call(null,"chrome.runtime.getManifest",ns_36377,"getManifest"));
})();
if(missing_api_36378 === true){
return null;
} else {
var config__25890__auto___36385 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36385))){
var logger__25891__auto___36386 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36385);
var prefix__25892__auto___36387 = ["calling:","chrome.runtime.getManifest"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36386)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36385)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36386.apply(null,prefix__25892__auto___36387.concat(final_args_array_36376));
} else {
}

var target_36379 = (function (){var target_obj_36383 = ns_36377;
var next_obj_36384 = (target_obj_36383["getManifest"]);
if((!((next_obj_36384 == null)))){
return next_obj_36384;
} else {
return null;
}
})();
return target_36379.apply(ns_36377,final_args_array_36376);
}
})();
return result_36375;
});
chromex.ext.runtime.get_url_STAR_ = (function chromex$ext$runtime$get_url_STAR_(config,path){
var marshalled_path_36389 = (function (){var omit_test_36394 = path;
if(cljs.core.keyword_identical_QMARK_(omit_test_36394,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36394;
}
})();
var result_36388 = (function (){var final_args_array_36390 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_path_36389,"path",null], null)], null),"chrome.runtime.getURL");
var ns_36391 = (function (){var target_obj_36395 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36396 = (target_obj_36395["chrome"]);
var next_obj_36397 = (next_obj_36396["runtime"]);
return next_obj_36397;
})();
var missing_api_36392 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getURL",ns_36391,"getURL") : api_check_fn__25895__auto__.call(null,"chrome.runtime.getURL",ns_36391,"getURL"));
})();
if(missing_api_36392 === true){
return null;
} else {
var config__25890__auto___36400 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36400))){
var logger__25891__auto___36401 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36400);
var prefix__25892__auto___36402 = ["calling:","chrome.runtime.getURL"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36401)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36400)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36401.apply(null,prefix__25892__auto___36402.concat(final_args_array_36390));
} else {
}

var target_36393 = (function (){var target_obj_36398 = ns_36391;
var next_obj_36399 = (target_obj_36398["getURL"]);
if((!((next_obj_36399 == null)))){
return next_obj_36399;
} else {
return null;
}
})();
return target_36393.apply(ns_36391,final_args_array_36390);
}
})();
return result_36388;
});
chromex.ext.runtime.set_uninstall_url_STAR_ = (function chromex$ext$runtime$set_uninstall_url_STAR_(config,url){
var callback_chan_36403 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__) : handler__25858__auto__.call(null,config__25856__auto__));
})();
var marshalled_url_36405_36420 = (function (){var omit_test_36411 = url;
if(cljs.core.keyword_identical_QMARK_(omit_test_36411,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36411;
}
})();
var marshalled_callback_36406_36421 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36412 = config__25856__auto__;
var G__36413 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_set_DASH_uninstall_DASH_url,cljs.core.cst$kw$name,"setUninstallURL",cljs.core.cst$kw$since,"41",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"url",cljs.core.cst$kw$since,"34",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36414 = callback_chan_36403;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36412,G__36413,G__36414) : handler__25858__auto__.call(null,G__36412,G__36413,G__36414));
})();
var result_36404_36422 = (function (){var final_args_array_36407 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_url_36405_36420,"url",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36406_36421,"callback",true], null)], null),"chrome.runtime.setUninstallURL");
var ns_36408 = (function (){var target_obj_36415 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36416 = (target_obj_36415["chrome"]);
var next_obj_36417 = (next_obj_36416["runtime"]);
return next_obj_36417;
})();
var missing_api_36409 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.setUninstallURL",ns_36408,"setUninstallURL") : api_check_fn__25895__auto__.call(null,"chrome.runtime.setUninstallURL",ns_36408,"setUninstallURL"));
})();
if(missing_api_36409 === true){
return null;
} else {
var config__25890__auto___36423 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36423))){
var logger__25891__auto___36424 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36423);
var prefix__25892__auto___36425 = ["calling:","chrome.runtime.setUninstallURL"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36424)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36423)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36424.apply(null,prefix__25892__auto___36425.concat(final_args_array_36407));
} else {
}

var target_36410 = (function (){var target_obj_36418 = ns_36408;
var next_obj_36419 = (target_obj_36418["setUninstallURL"]);
if((!((next_obj_36419 == null)))){
return next_obj_36419;
} else {
return null;
}
})();
return target_36410.apply(ns_36408,final_args_array_36407);
}
})();

return callback_chan_36403;
});
chromex.ext.runtime.reload_STAR_ = (function chromex$ext$runtime$reload_STAR_(config){
var result_36426 = (function (){var final_args_array_36427 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.reload");
var ns_36428 = (function (){var target_obj_36431 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36432 = (target_obj_36431["chrome"]);
var next_obj_36433 = (next_obj_36432["runtime"]);
return next_obj_36433;
})();
var missing_api_36429 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.reload",ns_36428,"reload") : api_check_fn__25895__auto__.call(null,"chrome.runtime.reload",ns_36428,"reload"));
})();
if(missing_api_36429 === true){
return null;
} else {
var config__25890__auto___36436 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36436))){
var logger__25891__auto___36437 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36436);
var prefix__25892__auto___36438 = ["calling:","chrome.runtime.reload"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36437)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36436)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36437.apply(null,prefix__25892__auto___36438.concat(final_args_array_36427));
} else {
}

var target_36430 = (function (){var target_obj_36434 = ns_36428;
var next_obj_36435 = (target_obj_36434["reload"]);
if((!((next_obj_36435 == null)))){
return next_obj_36435;
} else {
return null;
}
})();
return target_36430.apply(ns_36428,final_args_array_36427);
}
})();
return result_36426;
});
chromex.ext.runtime.request_update_check_STAR_ = (function chromex$ext$runtime$request_update_check_STAR_(config){
var callback_chan_36439 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__) : handler__25858__auto__.call(null,config__25856__auto__));
})();
var marshalled_callback_36441_36460 = (function (cb_status_36446,cb_details_36447){
var fexpr__36451 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36452 = config__25856__auto__;
var G__36453 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_request_DASH_update_DASH_check,cljs.core.cst$kw$name,"requestUpdateCheck",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"status",cljs.core.cst$kw$type,"runtime.RequestUpdateCheckStatus"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36454 = callback_chan_36439;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36452,G__36453,G__36454) : handler__25858__auto__.call(null,G__36452,G__36453,G__36454));
})();
return (fexpr__36451.cljs$core$IFn$_invoke$arity$2 ? fexpr__36451.cljs$core$IFn$_invoke$arity$2(cb_status_36446,cb_details_36447) : fexpr__36451.call(null,cb_status_36446,cb_details_36447));
});
var result_36440_36461 = (function (){var final_args_array_36442 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36441_36460,"callback",null], null)], null),"chrome.runtime.requestUpdateCheck");
var ns_36443 = (function (){var target_obj_36455 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36456 = (target_obj_36455["chrome"]);
var next_obj_36457 = (next_obj_36456["runtime"]);
return next_obj_36457;
})();
var missing_api_36444 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.requestUpdateCheck",ns_36443,"requestUpdateCheck") : api_check_fn__25895__auto__.call(null,"chrome.runtime.requestUpdateCheck",ns_36443,"requestUpdateCheck"));
})();
if(missing_api_36444 === true){
return null;
} else {
var config__25890__auto___36462 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36462))){
var logger__25891__auto___36463 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36462);
var prefix__25892__auto___36464 = ["calling:","chrome.runtime.requestUpdateCheck"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36463)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36462)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36463.apply(null,prefix__25892__auto___36464.concat(final_args_array_36442));
} else {
}

var target_36445 = (function (){var target_obj_36458 = ns_36443;
var next_obj_36459 = (target_obj_36458["requestUpdateCheck"]);
if((!((next_obj_36459 == null)))){
return next_obj_36459;
} else {
return null;
}
})();
return target_36445.apply(ns_36443,final_args_array_36442);
}
})();

return callback_chan_36439;
});
chromex.ext.runtime.restart_STAR_ = (function chromex$ext$runtime$restart_STAR_(config){
var result_36465 = (function (){var final_args_array_36466 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.restart");
var ns_36467 = (function (){var target_obj_36470 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36471 = (target_obj_36470["chrome"]);
var next_obj_36472 = (next_obj_36471["runtime"]);
return next_obj_36472;
})();
var missing_api_36468 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restart",ns_36467,"restart") : api_check_fn__25895__auto__.call(null,"chrome.runtime.restart",ns_36467,"restart"));
})();
if(missing_api_36468 === true){
return null;
} else {
var config__25890__auto___36475 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36475))){
var logger__25891__auto___36476 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36475);
var prefix__25892__auto___36477 = ["calling:","chrome.runtime.restart"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36476)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36475)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36476.apply(null,prefix__25892__auto___36477.concat(final_args_array_36466));
} else {
}

var target_36469 = (function (){var target_obj_36473 = ns_36467;
var next_obj_36474 = (target_obj_36473["restart"]);
if((!((next_obj_36474 == null)))){
return next_obj_36474;
} else {
return null;
}
})();
return target_36469.apply(ns_36467,final_args_array_36466);
}
})();
return result_36465;
});
chromex.ext.runtime.restart_after_delay_STAR_ = (function chromex$ext$runtime$restart_after_delay_STAR_(config,seconds){
var callback_chan_36478 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__) : handler__25858__auto__.call(null,config__25856__auto__));
})();
var marshalled_seconds_36480_36495 = (function (){var omit_test_36486 = seconds;
if(cljs.core.keyword_identical_QMARK_(omit_test_36486,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36486;
}
})();
var marshalled_callback_36481_36496 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36487 = config__25856__auto__;
var G__36488 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_restart_DASH_after_DASH_delay,cljs.core.cst$kw$name,"restartAfterDelay",cljs.core.cst$kw$since,"53",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"seconds",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36489 = callback_chan_36478;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36487,G__36488,G__36489) : handler__25858__auto__.call(null,G__36487,G__36488,G__36489));
})();
var result_36479_36497 = (function (){var final_args_array_36482 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_seconds_36480_36495,"seconds",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36481_36496,"callback",true], null)], null),"chrome.runtime.restartAfterDelay");
var ns_36483 = (function (){var target_obj_36490 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36491 = (target_obj_36490["chrome"]);
var next_obj_36492 = (next_obj_36491["runtime"]);
return next_obj_36492;
})();
var missing_api_36484 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restartAfterDelay",ns_36483,"restartAfterDelay") : api_check_fn__25895__auto__.call(null,"chrome.runtime.restartAfterDelay",ns_36483,"restartAfterDelay"));
})();
if(missing_api_36484 === true){
return null;
} else {
var config__25890__auto___36498 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36498))){
var logger__25891__auto___36499 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36498);
var prefix__25892__auto___36500 = ["calling:","chrome.runtime.restartAfterDelay"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36499)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36498)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36499.apply(null,prefix__25892__auto___36500.concat(final_args_array_36482));
} else {
}

var target_36485 = (function (){var target_obj_36493 = ns_36483;
var next_obj_36494 = (target_obj_36493["restartAfterDelay"]);
if((!((next_obj_36494 == null)))){
return next_obj_36494;
} else {
return null;
}
})();
return target_36485.apply(ns_36483,final_args_array_36482);
}
})();

return callback_chan_36478;
});
chromex.ext.runtime.connect_STAR_ = (function chromex$ext$runtime$connect_STAR_(config,extension_id,connect_info){
var marshalled_extension_id_36502 = (function (){var omit_test_36508 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_36508,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36508;
}
})();
var marshalled_connect_info_36503 = (function (){var omit_test_36509 = connect_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_36509,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36509;
}
})();
var result_36501 = (function (){var final_args_array_36504 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_36502,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_connect_info_36503,"connect-info",true], null)], null),"chrome.runtime.connect");
var ns_36505 = (function (){var target_obj_36510 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36511 = (target_obj_36510["chrome"]);
var next_obj_36512 = (next_obj_36511["runtime"]);
return next_obj_36512;
})();
var missing_api_36506 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connect",ns_36505,"connect") : api_check_fn__25895__auto__.call(null,"chrome.runtime.connect",ns_36505,"connect"));
})();
if(missing_api_36506 === true){
return null;
} else {
var config__25890__auto___36515 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36515))){
var logger__25891__auto___36516 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36515);
var prefix__25892__auto___36517 = ["calling:","chrome.runtime.connect"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36516)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36515)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36516.apply(null,prefix__25892__auto___36517.concat(final_args_array_36504));
} else {
}

var target_36507 = (function (){var target_obj_36513 = ns_36505;
var next_obj_36514 = (target_obj_36513["connect"]);
if((!((next_obj_36514 == null)))){
return next_obj_36514;
} else {
return null;
}
})();
return target_36507.apply(ns_36505,final_args_array_36504);
}
})();
return chromex.marshalling.from_native_chrome_port(config,result_36501);
});
chromex.ext.runtime.connect_native_STAR_ = (function chromex$ext$runtime$connect_native_STAR_(config,application){
var marshalled_application_36519 = (function (){var omit_test_36524 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_36524,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36524;
}
})();
var result_36518 = (function (){var final_args_array_36520 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_36519,"application",null], null)], null),"chrome.runtime.connectNative");
var ns_36521 = (function (){var target_obj_36525 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36526 = (target_obj_36525["chrome"]);
var next_obj_36527 = (next_obj_36526["runtime"]);
return next_obj_36527;
})();
var missing_api_36522 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connectNative",ns_36521,"connectNative") : api_check_fn__25895__auto__.call(null,"chrome.runtime.connectNative",ns_36521,"connectNative"));
})();
if(missing_api_36522 === true){
return null;
} else {
var config__25890__auto___36530 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36530))){
var logger__25891__auto___36531 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36530);
var prefix__25892__auto___36532 = ["calling:","chrome.runtime.connectNative"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36531)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36530)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36531.apply(null,prefix__25892__auto___36532.concat(final_args_array_36520));
} else {
}

var target_36523 = (function (){var target_obj_36528 = ns_36521;
var next_obj_36529 = (target_obj_36528["connectNative"]);
if((!((next_obj_36529 == null)))){
return next_obj_36529;
} else {
return null;
}
})();
return target_36523.apply(ns_36521,final_args_array_36520);
}
})();
return chromex.marshalling.from_native_chrome_port(config,result_36518);
});
chromex.ext.runtime.send_message_STAR_ = (function chromex$ext$runtime$send_message_STAR_(config,extension_id,message,options){
var callback_chan_36533 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__) : handler__25858__auto__.call(null,config__25856__auto__));
})();
var marshalled_extension_id_36535_36559 = (function (){var omit_test_36543 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_36543,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36543;
}
})();
var marshalled_message_36536_36560 = (function (){var omit_test_36544 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_36544,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36544;
}
})();
var marshalled_options_36537_36561 = (function (){var omit_test_36545 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_36545,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36545;
}
})();
var marshalled_response_callback_36538_36562 = (function (cb_response_36546){
var fexpr__36550 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36551 = config__25856__auto__;
var G__36552 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_message,cljs.core.cst$kw$name,"sendMessage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"extension-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36553 = callback_chan_36533;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36551,G__36552,G__36553) : handler__25858__auto__.call(null,G__36551,G__36552,G__36553));
})();
return (fexpr__36550.cljs$core$IFn$_invoke$arity$1 ? fexpr__36550.cljs$core$IFn$_invoke$arity$1(cb_response_36546) : fexpr__36550.call(null,cb_response_36546));
});
var result_36534_36563 = (function (){var final_args_array_36539 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_36535_36559,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_36536_36560,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_36537_36561,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_36538_36562,"response-callback",true], null)], null),"chrome.runtime.sendMessage");
var ns_36540 = (function (){var target_obj_36554 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36555 = (target_obj_36554["chrome"]);
var next_obj_36556 = (next_obj_36555["runtime"]);
return next_obj_36556;
})();
var missing_api_36541 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendMessage",ns_36540,"sendMessage") : api_check_fn__25895__auto__.call(null,"chrome.runtime.sendMessage",ns_36540,"sendMessage"));
})();
if(missing_api_36541 === true){
return null;
} else {
var config__25890__auto___36564 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36564))){
var logger__25891__auto___36565 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36564);
var prefix__25892__auto___36566 = ["calling:","chrome.runtime.sendMessage"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36565)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36564)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36565.apply(null,prefix__25892__auto___36566.concat(final_args_array_36539));
} else {
}

var target_36542 = (function (){var target_obj_36557 = ns_36540;
var next_obj_36558 = (target_obj_36557["sendMessage"]);
if((!((next_obj_36558 == null)))){
return next_obj_36558;
} else {
return null;
}
})();
return target_36542.apply(ns_36540,final_args_array_36539);
}
})();

return callback_chan_36533;
});
chromex.ext.runtime.send_native_message_STAR_ = (function chromex$ext$runtime$send_native_message_STAR_(config,application,message){
var callback_chan_36567 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__) : handler__25858__auto__.call(null,config__25856__auto__));
})();
var marshalled_application_36569_36591 = (function (){var omit_test_36576 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_36576,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36576;
}
})();
var marshalled_message_36570_36592 = (function (){var omit_test_36577 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_36577,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36577;
}
})();
var marshalled_response_callback_36571_36593 = (function (cb_response_36578){
var fexpr__36582 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36583 = config__25856__auto__;
var G__36584 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_native_DASH_message,cljs.core.cst$kw$name,"sendNativeMessage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"application",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36585 = callback_chan_36567;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36583,G__36584,G__36585) : handler__25858__auto__.call(null,G__36583,G__36584,G__36585));
})();
return (fexpr__36582.cljs$core$IFn$_invoke$arity$1 ? fexpr__36582.cljs$core$IFn$_invoke$arity$1(cb_response_36578) : fexpr__36582.call(null,cb_response_36578));
});
var result_36568_36594 = (function (){var final_args_array_36572 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_36569_36591,"application",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_36570_36592,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_36571_36593,"response-callback",true], null)], null),"chrome.runtime.sendNativeMessage");
var ns_36573 = (function (){var target_obj_36586 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36587 = (target_obj_36586["chrome"]);
var next_obj_36588 = (next_obj_36587["runtime"]);
return next_obj_36588;
})();
var missing_api_36574 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendNativeMessage",ns_36573,"sendNativeMessage") : api_check_fn__25895__auto__.call(null,"chrome.runtime.sendNativeMessage",ns_36573,"sendNativeMessage"));
})();
if(missing_api_36574 === true){
return null;
} else {
var config__25890__auto___36595 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36595))){
var logger__25891__auto___36596 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36595);
var prefix__25892__auto___36597 = ["calling:","chrome.runtime.sendNativeMessage"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36596)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36595)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36596.apply(null,prefix__25892__auto___36597.concat(final_args_array_36572));
} else {
}

var target_36575 = (function (){var target_obj_36589 = ns_36573;
var next_obj_36590 = (target_obj_36589["sendNativeMessage"]);
if((!((next_obj_36590 == null)))){
return next_obj_36590;
} else {
return null;
}
})();
return target_36575.apply(ns_36573,final_args_array_36572);
}
})();

return callback_chan_36567;
});
chromex.ext.runtime.get_platform_info_STAR_ = (function chromex$ext$runtime$get_platform_info_STAR_(config){
var callback_chan_36598 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__) : handler__25858__auto__.call(null,config__25856__auto__));
})();
var marshalled_callback_36600_36618 = (function (cb_platform_info_36605){
var fexpr__36609 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36610 = config__25856__auto__;
var G__36611 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_platform_DASH_info,cljs.core.cst$kw$name,"getPlatformInfo",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"platform-info",cljs.core.cst$kw$type,"runtime.PlatformInfo"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36612 = callback_chan_36598;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36610,G__36611,G__36612) : handler__25858__auto__.call(null,G__36610,G__36611,G__36612));
})();
return (fexpr__36609.cljs$core$IFn$_invoke$arity$1 ? fexpr__36609.cljs$core$IFn$_invoke$arity$1(cb_platform_info_36605) : fexpr__36609.call(null,cb_platform_info_36605));
});
var result_36599_36619 = (function (){var final_args_array_36601 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36600_36618,"callback",null], null)], null),"chrome.runtime.getPlatformInfo");
var ns_36602 = (function (){var target_obj_36613 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36614 = (target_obj_36613["chrome"]);
var next_obj_36615 = (next_obj_36614["runtime"]);
return next_obj_36615;
})();
var missing_api_36603 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPlatformInfo",ns_36602,"getPlatformInfo") : api_check_fn__25895__auto__.call(null,"chrome.runtime.getPlatformInfo",ns_36602,"getPlatformInfo"));
})();
if(missing_api_36603 === true){
return null;
} else {
var config__25890__auto___36620 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36620))){
var logger__25891__auto___36621 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36620);
var prefix__25892__auto___36622 = ["calling:","chrome.runtime.getPlatformInfo"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36621)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36620)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36621.apply(null,prefix__25892__auto___36622.concat(final_args_array_36601));
} else {
}

var target_36604 = (function (){var target_obj_36616 = ns_36602;
var next_obj_36617 = (target_obj_36616["getPlatformInfo"]);
if((!((next_obj_36617 == null)))){
return next_obj_36617;
} else {
return null;
}
})();
return target_36604.apply(ns_36602,final_args_array_36601);
}
})();

return callback_chan_36598;
});
chromex.ext.runtime.get_package_directory_entry_STAR_ = (function chromex$ext$runtime$get_package_directory_entry_STAR_(config){
var callback_chan_36623 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__) : handler__25858__auto__.call(null,config__25856__auto__));
})();
var marshalled_callback_36625_36643 = (function (cb_directory_entry_36630){
var fexpr__36634 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36635 = config__25856__auto__;
var G__36636 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_package_DASH_directory_DASH_entry,cljs.core.cst$kw$name,"getPackageDirectoryEntry",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"directory-entry",cljs.core.cst$kw$type,"DirectoryEntry"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36637 = callback_chan_36623;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36635,G__36636,G__36637) : handler__25858__auto__.call(null,G__36635,G__36636,G__36637));
})();
return (fexpr__36634.cljs$core$IFn$_invoke$arity$1 ? fexpr__36634.cljs$core$IFn$_invoke$arity$1(cb_directory_entry_36630) : fexpr__36634.call(null,cb_directory_entry_36630));
});
var result_36624_36644 = (function (){var final_args_array_36626 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36625_36643,"callback",null], null)], null),"chrome.runtime.getPackageDirectoryEntry");
var ns_36627 = (function (){var target_obj_36638 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36639 = (target_obj_36638["chrome"]);
var next_obj_36640 = (next_obj_36639["runtime"]);
return next_obj_36640;
})();
var missing_api_36628 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPackageDirectoryEntry",ns_36627,"getPackageDirectoryEntry") : api_check_fn__25895__auto__.call(null,"chrome.runtime.getPackageDirectoryEntry",ns_36627,"getPackageDirectoryEntry"));
})();
if(missing_api_36628 === true){
return null;
} else {
var config__25890__auto___36645 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36645))){
var logger__25891__auto___36646 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36645);
var prefix__25892__auto___36647 = ["calling:","chrome.runtime.getPackageDirectoryEntry"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36646)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36645)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36646.apply(null,prefix__25892__auto___36647.concat(final_args_array_36626));
} else {
}

var target_36629 = (function (){var target_obj_36641 = ns_36627;
var next_obj_36642 = (target_obj_36641["getPackageDirectoryEntry"]);
if((!((next_obj_36642 == null)))){
return next_obj_36642;
} else {
return null;
}
})();
return target_36629.apply(ns_36627,final_args_array_36626);
}
})();

return callback_chan_36623;
});
chromex.ext.runtime.on_startup_STAR_ = (function chromex$ext$runtime$on_startup_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___36666 = arguments.length;
var i__4790__auto___36667 = (0);
while(true){
if((i__4790__auto___36667 < len__4789__auto___36666)){
args__4795__auto__.push((arguments[i__4790__auto___36667]));

var G__36668 = (i__4790__auto___36667 + (1));
i__4790__auto___36667 = G__36668;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_36651 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36658 = config__25856__auto__;
var G__36659 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_startup;
var G__36660 = channel;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36658,G__36659,G__36660) : handler__25858__auto__.call(null,G__36658,G__36659,G__36660));
})();
var handler_fn_36652 = event_fn_36651;
var logging_fn_36653 = (function (){
var config__25890__auto___36669 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36669))){
var logger__25891__auto___36670 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36669);
var prefix__25892__auto___36671 = ["event:","chrome.runtime.onStartup"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36670)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36669)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36670.apply(null,prefix__25892__auto___36671.concat(cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentVector.EMPTY)));
} else {
}

return (handler_fn_36652.cljs$core$IFn$_invoke$arity$0 ? handler_fn_36652.cljs$core$IFn$_invoke$arity$0() : handler_fn_36652.call(null));
});
var ns_obj_36656 = (function (){var target_obj_36661 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36662 = (target_obj_36661["chrome"]);
var next_obj_36663 = (next_obj_36662["runtime"]);
return next_obj_36663;
})();
var missing_api_36657 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onStartup",ns_obj_36656,"onStartup") : api_check_fn__25895__auto__.call(null,"chrome.runtime.onStartup",ns_obj_36656,"onStartup"));
})();
if(missing_api_36657 === true){
return null;
} else {
var event_obj_36654 = (function (){var target_obj_36664 = ns_obj_36656;
var next_obj_36665 = (target_obj_36664["onStartup"]);
return next_obj_36665;
})();
var result_36655 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_36654,logging_fn_36653,channel);
result_36655.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_36655;
}
}));

(chromex.ext.runtime.on_startup_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_startup_STAR_.cljs$lang$applyTo = (function (seq36648){
var G__36649 = cljs.core.first(seq36648);
var seq36648__$1 = cljs.core.next(seq36648);
var G__36650 = cljs.core.first(seq36648__$1);
var seq36648__$2 = cljs.core.next(seq36648__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__36649,G__36650,seq36648__$2);
}));

chromex.ext.runtime.on_installed_STAR_ = (function chromex$ext$runtime$on_installed_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___36692 = arguments.length;
var i__4790__auto___36693 = (0);
while(true){
if((i__4790__auto___36693 < len__4789__auto___36692)){
args__4795__auto__.push((arguments[i__4790__auto___36693]));

var G__36694 = (i__4790__auto___36693 + (1));
i__4790__auto___36693 = G__36694;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_36675 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36684 = config__25856__auto__;
var G__36685 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_installed;
var G__36686 = channel;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36684,G__36685,G__36686) : handler__25858__auto__.call(null,G__36684,G__36685,G__36686));
})();
var handler_fn_36676 = (function (cb_details_36682){
return (event_fn_36675.cljs$core$IFn$_invoke$arity$1 ? event_fn_36675.cljs$core$IFn$_invoke$arity$1(cb_details_36682) : event_fn_36675.call(null,cb_details_36682));
});
var logging_fn_36677 = (function (cb_param_details_36683){
var config__25890__auto___36695 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36695))){
var logger__25891__auto___36696 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36695);
var prefix__25892__auto___36697 = ["event:","chrome.runtime.onInstalled"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36696)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36695)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36696.apply(null,prefix__25892__auto___36697.concat(cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_details_36683], null))));
} else {
}

return handler_fn_36676(cb_param_details_36683);
});
var ns_obj_36680 = (function (){var target_obj_36687 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36688 = (target_obj_36687["chrome"]);
var next_obj_36689 = (next_obj_36688["runtime"]);
return next_obj_36689;
})();
var missing_api_36681 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onInstalled",ns_obj_36680,"onInstalled") : api_check_fn__25895__auto__.call(null,"chrome.runtime.onInstalled",ns_obj_36680,"onInstalled"));
})();
if(missing_api_36681 === true){
return null;
} else {
var event_obj_36678 = (function (){var target_obj_36690 = ns_obj_36680;
var next_obj_36691 = (target_obj_36690["onInstalled"]);
return next_obj_36691;
})();
var result_36679 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_36678,logging_fn_36677,channel);
result_36679.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_36679;
}
}));

(chromex.ext.runtime.on_installed_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_installed_STAR_.cljs$lang$applyTo = (function (seq36672){
var G__36673 = cljs.core.first(seq36672);
var seq36672__$1 = cljs.core.next(seq36672);
var G__36674 = cljs.core.first(seq36672__$1);
var seq36672__$2 = cljs.core.next(seq36672__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__36673,G__36674,seq36672__$2);
}));

chromex.ext.runtime.on_suspend_STAR_ = (function chromex$ext$runtime$on_suspend_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___36716 = arguments.length;
var i__4790__auto___36717 = (0);
while(true){
if((i__4790__auto___36717 < len__4789__auto___36716)){
args__4795__auto__.push((arguments[i__4790__auto___36717]));

var G__36718 = (i__4790__auto___36717 + (1));
i__4790__auto___36717 = G__36718;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_36701 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36708 = config__25856__auto__;
var G__36709 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend;
var G__36710 = channel;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36708,G__36709,G__36710) : handler__25858__auto__.call(null,G__36708,G__36709,G__36710));
})();
var handler_fn_36702 = event_fn_36701;
var logging_fn_36703 = (function (){
var config__25890__auto___36719 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36719))){
var logger__25891__auto___36720 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36719);
var prefix__25892__auto___36721 = ["event:","chrome.runtime.onSuspend"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36720)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36719)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36720.apply(null,prefix__25892__auto___36721.concat(cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentVector.EMPTY)));
} else {
}

return (handler_fn_36702.cljs$core$IFn$_invoke$arity$0 ? handler_fn_36702.cljs$core$IFn$_invoke$arity$0() : handler_fn_36702.call(null));
});
var ns_obj_36706 = (function (){var target_obj_36711 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36712 = (target_obj_36711["chrome"]);
var next_obj_36713 = (next_obj_36712["runtime"]);
return next_obj_36713;
})();
var missing_api_36707 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspend",ns_obj_36706,"onSuspend") : api_check_fn__25895__auto__.call(null,"chrome.runtime.onSuspend",ns_obj_36706,"onSuspend"));
})();
if(missing_api_36707 === true){
return null;
} else {
var event_obj_36704 = (function (){var target_obj_36714 = ns_obj_36706;
var next_obj_36715 = (target_obj_36714["onSuspend"]);
return next_obj_36715;
})();
var result_36705 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_36704,logging_fn_36703,channel);
result_36705.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_36705;
}
}));

(chromex.ext.runtime.on_suspend_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_suspend_STAR_.cljs$lang$applyTo = (function (seq36698){
var G__36699 = cljs.core.first(seq36698);
var seq36698__$1 = cljs.core.next(seq36698);
var G__36700 = cljs.core.first(seq36698__$1);
var seq36698__$2 = cljs.core.next(seq36698__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__36699,G__36700,seq36698__$2);
}));

chromex.ext.runtime.on_suspend_canceled_STAR_ = (function chromex$ext$runtime$on_suspend_canceled_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___36740 = arguments.length;
var i__4790__auto___36741 = (0);
while(true){
if((i__4790__auto___36741 < len__4789__auto___36740)){
args__4795__auto__.push((arguments[i__4790__auto___36741]));

var G__36742 = (i__4790__auto___36741 + (1));
i__4790__auto___36741 = G__36742;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_36725 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36732 = config__25856__auto__;
var G__36733 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend_DASH_canceled;
var G__36734 = channel;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36732,G__36733,G__36734) : handler__25858__auto__.call(null,G__36732,G__36733,G__36734));
})();
var handler_fn_36726 = event_fn_36725;
var logging_fn_36727 = (function (){
var config__25890__auto___36743 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36743))){
var logger__25891__auto___36744 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36743);
var prefix__25892__auto___36745 = ["event:","chrome.runtime.onSuspendCanceled"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36744)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36743)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36744.apply(null,prefix__25892__auto___36745.concat(cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentVector.EMPTY)));
} else {
}

return (handler_fn_36726.cljs$core$IFn$_invoke$arity$0 ? handler_fn_36726.cljs$core$IFn$_invoke$arity$0() : handler_fn_36726.call(null));
});
var ns_obj_36730 = (function (){var target_obj_36735 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36736 = (target_obj_36735["chrome"]);
var next_obj_36737 = (next_obj_36736["runtime"]);
return next_obj_36737;
})();
var missing_api_36731 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspendCanceled",ns_obj_36730,"onSuspendCanceled") : api_check_fn__25895__auto__.call(null,"chrome.runtime.onSuspendCanceled",ns_obj_36730,"onSuspendCanceled"));
})();
if(missing_api_36731 === true){
return null;
} else {
var event_obj_36728 = (function (){var target_obj_36738 = ns_obj_36730;
var next_obj_36739 = (target_obj_36738["onSuspendCanceled"]);
return next_obj_36739;
})();
var result_36729 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_36728,logging_fn_36727,channel);
result_36729.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_36729;
}
}));

(chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$applyTo = (function (seq36722){
var G__36723 = cljs.core.first(seq36722);
var seq36722__$1 = cljs.core.next(seq36722);
var G__36724 = cljs.core.first(seq36722__$1);
var seq36722__$2 = cljs.core.next(seq36722__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__36723,G__36724,seq36722__$2);
}));

chromex.ext.runtime.on_update_available_STAR_ = (function chromex$ext$runtime$on_update_available_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___36766 = arguments.length;
var i__4790__auto___36767 = (0);
while(true){
if((i__4790__auto___36767 < len__4789__auto___36766)){
args__4795__auto__.push((arguments[i__4790__auto___36767]));

var G__36768 = (i__4790__auto___36767 + (1));
i__4790__auto___36767 = G__36768;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_36749 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36758 = config__25856__auto__;
var G__36759 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_update_DASH_available;
var G__36760 = channel;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36758,G__36759,G__36760) : handler__25858__auto__.call(null,G__36758,G__36759,G__36760));
})();
var handler_fn_36750 = (function (cb_details_36756){
return (event_fn_36749.cljs$core$IFn$_invoke$arity$1 ? event_fn_36749.cljs$core$IFn$_invoke$arity$1(cb_details_36756) : event_fn_36749.call(null,cb_details_36756));
});
var logging_fn_36751 = (function (cb_param_details_36757){
var config__25890__auto___36769 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36769))){
var logger__25891__auto___36770 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36769);
var prefix__25892__auto___36771 = ["event:","chrome.runtime.onUpdateAvailable"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36770)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36769)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36770.apply(null,prefix__25892__auto___36771.concat(cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_details_36757], null))));
} else {
}

return handler_fn_36750(cb_param_details_36757);
});
var ns_obj_36754 = (function (){var target_obj_36761 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36762 = (target_obj_36761["chrome"]);
var next_obj_36763 = (next_obj_36762["runtime"]);
return next_obj_36763;
})();
var missing_api_36755 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onUpdateAvailable",ns_obj_36754,"onUpdateAvailable") : api_check_fn__25895__auto__.call(null,"chrome.runtime.onUpdateAvailable",ns_obj_36754,"onUpdateAvailable"));
})();
if(missing_api_36755 === true){
return null;
} else {
var event_obj_36752 = (function (){var target_obj_36764 = ns_obj_36754;
var next_obj_36765 = (target_obj_36764["onUpdateAvailable"]);
return next_obj_36765;
})();
var result_36753 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_36752,logging_fn_36751,channel);
result_36753.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_36753;
}
}));

(chromex.ext.runtime.on_update_available_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_update_available_STAR_.cljs$lang$applyTo = (function (seq36746){
var G__36747 = cljs.core.first(seq36746);
var seq36746__$1 = cljs.core.next(seq36746);
var G__36748 = cljs.core.first(seq36746__$1);
var seq36746__$2 = cljs.core.next(seq36746__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__36747,G__36748,seq36746__$2);
}));

chromex.ext.runtime.on_browser_update_available_STAR_ = (function chromex$ext$runtime$on_browser_update_available_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___36790 = arguments.length;
var i__4790__auto___36791 = (0);
while(true){
if((i__4790__auto___36791 < len__4789__auto___36790)){
args__4795__auto__.push((arguments[i__4790__auto___36791]));

var G__36792 = (i__4790__auto___36791 + (1));
i__4790__auto___36791 = G__36792;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_36775 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36782 = config__25856__auto__;
var G__36783 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_browser_DASH_update_DASH_available;
var G__36784 = channel;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36782,G__36783,G__36784) : handler__25858__auto__.call(null,G__36782,G__36783,G__36784));
})();
var handler_fn_36776 = event_fn_36775;
var logging_fn_36777 = (function (){
var config__25890__auto___36793 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36793))){
var logger__25891__auto___36794 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36793);
var prefix__25892__auto___36795 = ["event:","chrome.runtime.onBrowserUpdateAvailable"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36794)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36793)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36794.apply(null,prefix__25892__auto___36795.concat(cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentVector.EMPTY)));
} else {
}

return (handler_fn_36776.cljs$core$IFn$_invoke$arity$0 ? handler_fn_36776.cljs$core$IFn$_invoke$arity$0() : handler_fn_36776.call(null));
});
var ns_obj_36780 = (function (){var target_obj_36785 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36786 = (target_obj_36785["chrome"]);
var next_obj_36787 = (next_obj_36786["runtime"]);
return next_obj_36787;
})();
var missing_api_36781 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onBrowserUpdateAvailable",ns_obj_36780,"onBrowserUpdateAvailable") : api_check_fn__25895__auto__.call(null,"chrome.runtime.onBrowserUpdateAvailable",ns_obj_36780,"onBrowserUpdateAvailable"));
})();
if(missing_api_36781 === true){
return null;
} else {
var event_obj_36778 = (function (){var target_obj_36788 = ns_obj_36780;
var next_obj_36789 = (target_obj_36788["onBrowserUpdateAvailable"]);
return next_obj_36789;
})();
var result_36779 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_36778,logging_fn_36777,channel);
result_36779.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_36779;
}
}));

(chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$applyTo = (function (seq36772){
var G__36773 = cljs.core.first(seq36772);
var seq36772__$1 = cljs.core.next(seq36772);
var G__36774 = cljs.core.first(seq36772__$1);
var seq36772__$2 = cljs.core.next(seq36772__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__36773,G__36774,seq36772__$2);
}));

chromex.ext.runtime.on_connect_STAR_ = (function chromex$ext$runtime$on_connect_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___36817 = arguments.length;
var i__4790__auto___36818 = (0);
while(true){
if((i__4790__auto___36818 < len__4789__auto___36817)){
args__4795__auto__.push((arguments[i__4790__auto___36818]));

var G__36819 = (i__4790__auto___36818 + (1));
i__4790__auto___36818 = G__36819;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_36799 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36808 = config__25856__auto__;
var G__36809 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect;
var G__36810 = channel;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36808,G__36809,G__36810) : handler__25858__auto__.call(null,G__36808,G__36809,G__36810));
})();
var handler_fn_36800 = (function (cb_port_36806){
var G__36811 = chromex.marshalling.from_native_chrome_port(config,cb_port_36806);
return (event_fn_36799.cljs$core$IFn$_invoke$arity$1 ? event_fn_36799.cljs$core$IFn$_invoke$arity$1(G__36811) : event_fn_36799.call(null,G__36811));
});
var logging_fn_36801 = (function (cb_param_port_36807){
var config__25890__auto___36820 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36820))){
var logger__25891__auto___36821 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36820);
var prefix__25892__auto___36822 = ["event:","chrome.runtime.onConnect"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36821)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36820)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36821.apply(null,prefix__25892__auto___36822.concat(cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_port_36807], null))));
} else {
}

return handler_fn_36800(cb_param_port_36807);
});
var ns_obj_36804 = (function (){var target_obj_36812 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36813 = (target_obj_36812["chrome"]);
var next_obj_36814 = (next_obj_36813["runtime"]);
return next_obj_36814;
})();
var missing_api_36805 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnect",ns_obj_36804,"onConnect") : api_check_fn__25895__auto__.call(null,"chrome.runtime.onConnect",ns_obj_36804,"onConnect"));
})();
if(missing_api_36805 === true){
return null;
} else {
var event_obj_36802 = (function (){var target_obj_36815 = ns_obj_36804;
var next_obj_36816 = (target_obj_36815["onConnect"]);
return next_obj_36816;
})();
var result_36803 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_36802,logging_fn_36801,channel);
result_36803.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_36803;
}
}));

(chromex.ext.runtime.on_connect_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_connect_STAR_.cljs$lang$applyTo = (function (seq36796){
var G__36797 = cljs.core.first(seq36796);
var seq36796__$1 = cljs.core.next(seq36796);
var G__36798 = cljs.core.first(seq36796__$1);
var seq36796__$2 = cljs.core.next(seq36796__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__36797,G__36798,seq36796__$2);
}));

chromex.ext.runtime.on_connect_external_STAR_ = (function chromex$ext$runtime$on_connect_external_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___36844 = arguments.length;
var i__4790__auto___36845 = (0);
while(true){
if((i__4790__auto___36845 < len__4789__auto___36844)){
args__4795__auto__.push((arguments[i__4790__auto___36845]));

var G__36846 = (i__4790__auto___36845 + (1));
i__4790__auto___36845 = G__36846;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_36826 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36835 = config__25856__auto__;
var G__36836 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect_DASH_external;
var G__36837 = channel;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36835,G__36836,G__36837) : handler__25858__auto__.call(null,G__36835,G__36836,G__36837));
})();
var handler_fn_36827 = (function (cb_port_36833){
var G__36838 = chromex.marshalling.from_native_chrome_port(config,cb_port_36833);
return (event_fn_36826.cljs$core$IFn$_invoke$arity$1 ? event_fn_36826.cljs$core$IFn$_invoke$arity$1(G__36838) : event_fn_36826.call(null,G__36838));
});
var logging_fn_36828 = (function (cb_param_port_36834){
var config__25890__auto___36847 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36847))){
var logger__25891__auto___36848 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36847);
var prefix__25892__auto___36849 = ["event:","chrome.runtime.onConnectExternal"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36848)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36847)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36848.apply(null,prefix__25892__auto___36849.concat(cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_port_36834], null))));
} else {
}

return handler_fn_36827(cb_param_port_36834);
});
var ns_obj_36831 = (function (){var target_obj_36839 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36840 = (target_obj_36839["chrome"]);
var next_obj_36841 = (next_obj_36840["runtime"]);
return next_obj_36841;
})();
var missing_api_36832 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnectExternal",ns_obj_36831,"onConnectExternal") : api_check_fn__25895__auto__.call(null,"chrome.runtime.onConnectExternal",ns_obj_36831,"onConnectExternal"));
})();
if(missing_api_36832 === true){
return null;
} else {
var event_obj_36829 = (function (){var target_obj_36842 = ns_obj_36831;
var next_obj_36843 = (target_obj_36842["onConnectExternal"]);
return next_obj_36843;
})();
var result_36830 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_36829,logging_fn_36828,channel);
result_36830.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_36830;
}
}));

(chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$applyTo = (function (seq36823){
var G__36824 = cljs.core.first(seq36823);
var seq36823__$1 = cljs.core.next(seq36823);
var G__36825 = cljs.core.first(seq36823__$1);
var seq36823__$2 = cljs.core.next(seq36823__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__36824,G__36825,seq36823__$2);
}));

chromex.ext.runtime.on_connect_native_STAR_ = (function chromex$ext$runtime$on_connect_native_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___36871 = arguments.length;
var i__4790__auto___36872 = (0);
while(true){
if((i__4790__auto___36872 < len__4789__auto___36871)){
args__4795__auto__.push((arguments[i__4790__auto___36872]));

var G__36873 = (i__4790__auto___36872 + (1));
i__4790__auto___36872 = G__36873;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_native_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_connect_native_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_36853 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36862 = config__25856__auto__;
var G__36863 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect_DASH_native;
var G__36864 = channel;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36862,G__36863,G__36864) : handler__25858__auto__.call(null,G__36862,G__36863,G__36864));
})();
var handler_fn_36854 = (function (cb_port_36860){
var G__36865 = chromex.marshalling.from_native_chrome_port(config,cb_port_36860);
return (event_fn_36853.cljs$core$IFn$_invoke$arity$1 ? event_fn_36853.cljs$core$IFn$_invoke$arity$1(G__36865) : event_fn_36853.call(null,G__36865));
});
var logging_fn_36855 = (function (cb_param_port_36861){
var config__25890__auto___36874 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36874))){
var logger__25891__auto___36875 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36874);
var prefix__25892__auto___36876 = ["event:","chrome.runtime.onConnectNative"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36875)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36874)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36875.apply(null,prefix__25892__auto___36876.concat(cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_port_36861], null))));
} else {
}

return handler_fn_36854(cb_param_port_36861);
});
var ns_obj_36858 = (function (){var target_obj_36866 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36867 = (target_obj_36866["chrome"]);
var next_obj_36868 = (next_obj_36867["runtime"]);
return next_obj_36868;
})();
var missing_api_36859 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnectNative",ns_obj_36858,"onConnectNative") : api_check_fn__25895__auto__.call(null,"chrome.runtime.onConnectNative",ns_obj_36858,"onConnectNative"));
})();
if(missing_api_36859 === true){
return null;
} else {
var event_obj_36856 = (function (){var target_obj_36869 = ns_obj_36858;
var next_obj_36870 = (target_obj_36869["onConnectNative"]);
return next_obj_36870;
})();
var result_36857 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_36856,logging_fn_36855,channel);
result_36857.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_36857;
}
}));

(chromex.ext.runtime.on_connect_native_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_connect_native_STAR_.cljs$lang$applyTo = (function (seq36850){
var G__36851 = cljs.core.first(seq36850);
var seq36850__$1 = cljs.core.next(seq36850);
var G__36852 = cljs.core.first(seq36850__$1);
var seq36850__$2 = cljs.core.next(seq36850__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__36851,G__36852,seq36850__$2);
}));

chromex.ext.runtime.on_message_STAR_ = (function chromex$ext$runtime$on_message_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___36901 = arguments.length;
var i__4790__auto___36902 = (0);
while(true){
if((i__4790__auto___36902 < len__4789__auto___36901)){
args__4795__auto__.push((arguments[i__4790__auto___36902]));

var G__36903 = (i__4790__auto___36902 + (1));
i__4790__auto___36902 = G__36903;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_36880 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36893 = config__25856__auto__;
var G__36894 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message;
var G__36895 = channel;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36893,G__36894,G__36895) : handler__25858__auto__.call(null,G__36893,G__36894,G__36895));
})();
var handler_fn_36881 = (function (cb_message_36887,cb_sender_36888,cb_send_response_36889){
return (event_fn_36880.cljs$core$IFn$_invoke$arity$3 ? event_fn_36880.cljs$core$IFn$_invoke$arity$3(cb_message_36887,cb_sender_36888,cb_send_response_36889) : event_fn_36880.call(null,cb_message_36887,cb_sender_36888,cb_send_response_36889));
});
var logging_fn_36882 = (function (cb_param_message_36890,cb_param_sender_36891,cb_param_send_response_36892){
var config__25890__auto___36904 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36904))){
var logger__25891__auto___36905 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36904);
var prefix__25892__auto___36906 = ["event:","chrome.runtime.onMessage"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36905)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36904)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36905.apply(null,prefix__25892__auto___36906.concat(cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_message_36890,cb_param_sender_36891,cb_param_send_response_36892], null))));
} else {
}

return handler_fn_36881(cb_param_message_36890,cb_param_sender_36891,cb_param_send_response_36892);
});
var ns_obj_36885 = (function (){var target_obj_36896 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36897 = (target_obj_36896["chrome"]);
var next_obj_36898 = (next_obj_36897["runtime"]);
return next_obj_36898;
})();
var missing_api_36886 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessage",ns_obj_36885,"onMessage") : api_check_fn__25895__auto__.call(null,"chrome.runtime.onMessage",ns_obj_36885,"onMessage"));
})();
if(missing_api_36886 === true){
return null;
} else {
var event_obj_36883 = (function (){var target_obj_36899 = ns_obj_36885;
var next_obj_36900 = (target_obj_36899["onMessage"]);
return next_obj_36900;
})();
var result_36884 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_36883,logging_fn_36882,channel);
result_36884.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_36884;
}
}));

(chromex.ext.runtime.on_message_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_message_STAR_.cljs$lang$applyTo = (function (seq36877){
var G__36878 = cljs.core.first(seq36877);
var seq36877__$1 = cljs.core.next(seq36877);
var G__36879 = cljs.core.first(seq36877__$1);
var seq36877__$2 = cljs.core.next(seq36877__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__36878,G__36879,seq36877__$2);
}));

chromex.ext.runtime.on_message_external_STAR_ = (function chromex$ext$runtime$on_message_external_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___36931 = arguments.length;
var i__4790__auto___36932 = (0);
while(true){
if((i__4790__auto___36932 < len__4789__auto___36931)){
args__4795__auto__.push((arguments[i__4790__auto___36932]));

var G__36933 = (i__4790__auto___36932 + (1));
i__4790__auto___36932 = G__36933;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_36910 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36923 = config__25856__auto__;
var G__36924 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message_DASH_external;
var G__36925 = channel;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36923,G__36924,G__36925) : handler__25858__auto__.call(null,G__36923,G__36924,G__36925));
})();
var handler_fn_36911 = (function (cb_message_36917,cb_sender_36918,cb_send_response_36919){
return (event_fn_36910.cljs$core$IFn$_invoke$arity$3 ? event_fn_36910.cljs$core$IFn$_invoke$arity$3(cb_message_36917,cb_sender_36918,cb_send_response_36919) : event_fn_36910.call(null,cb_message_36917,cb_sender_36918,cb_send_response_36919));
});
var logging_fn_36912 = (function (cb_param_message_36920,cb_param_sender_36921,cb_param_send_response_36922){
var config__25890__auto___36934 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36934))){
var logger__25891__auto___36935 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36934);
var prefix__25892__auto___36936 = ["event:","chrome.runtime.onMessageExternal"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36935)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36934)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36935.apply(null,prefix__25892__auto___36936.concat(cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_message_36920,cb_param_sender_36921,cb_param_send_response_36922], null))));
} else {
}

return handler_fn_36911(cb_param_message_36920,cb_param_sender_36921,cb_param_send_response_36922);
});
var ns_obj_36915 = (function (){var target_obj_36926 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36927 = (target_obj_36926["chrome"]);
var next_obj_36928 = (next_obj_36927["runtime"]);
return next_obj_36928;
})();
var missing_api_36916 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessageExternal",ns_obj_36915,"onMessageExternal") : api_check_fn__25895__auto__.call(null,"chrome.runtime.onMessageExternal",ns_obj_36915,"onMessageExternal"));
})();
if(missing_api_36916 === true){
return null;
} else {
var event_obj_36913 = (function (){var target_obj_36929 = ns_obj_36915;
var next_obj_36930 = (target_obj_36929["onMessageExternal"]);
return next_obj_36930;
})();
var result_36914 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_36913,logging_fn_36912,channel);
result_36914.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_36914;
}
}));

(chromex.ext.runtime.on_message_external_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_message_external_STAR_.cljs$lang$applyTo = (function (seq36907){
var G__36908 = cljs.core.first(seq36907);
var seq36907__$1 = cljs.core.next(seq36907);
var G__36909 = cljs.core.first(seq36907__$1);
var seq36907__$2 = cljs.core.next(seq36907__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__36908,G__36909,seq36907__$2);
}));

chromex.ext.runtime.on_restart_required_STAR_ = (function chromex$ext$runtime$on_restart_required_STAR_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___36957 = arguments.length;
var i__4790__auto___36958 = (0);
while(true){
if((i__4790__auto___36958 < len__4789__auto___36957)){
args__4795__auto__.push((arguments[i__4790__auto___36958]));

var G__36959 = (i__4790__auto___36958 + (1));
i__4790__auto___36958 = G__36959;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_36940 = (function (){var config__25856__auto__ = config;
var handler_key__25857__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__25858__auto__ = handler_key__25857__auto__.cljs$core$IFn$_invoke$arity$1(config__25856__auto__);
if(cljs.core.fn_QMARK_(handler__25858__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25857__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25856__auto__)].join(''),"\n","(clojure.core/fn? handler__25858__auto__)"].join('')));
}

var G__36949 = config__25856__auto__;
var G__36950 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_restart_DASH_required;
var G__36951 = channel;
return (handler__25858__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__25858__auto__.cljs$core$IFn$_invoke$arity$3(G__36949,G__36950,G__36951) : handler__25858__auto__.call(null,G__36949,G__36950,G__36951));
})();
var handler_fn_36941 = (function (cb_reason_36947){
return (event_fn_36940.cljs$core$IFn$_invoke$arity$1 ? event_fn_36940.cljs$core$IFn$_invoke$arity$1(cb_reason_36947) : event_fn_36940.call(null,cb_reason_36947));
});
var logging_fn_36942 = (function (cb_param_reason_36948){
var config__25890__auto___36960 = config;
if(cljs.core.truth_(cljs.core.cst$kw$verbose_DASH_logging.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36960))){
var logger__25891__auto___36961 = cljs.core.cst$kw$logger.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36960);
var prefix__25892__auto___36962 = ["event:","chrome.runtime.onRestartRequired"];
if(cljs.core.fn_QMARK_(logger__25891__auto___36961)){
} else {
throw (new Error(["Assert failed: ",["invalid :logger in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25890__auto___36960)].join(''),"\n","(clojure.core/fn? logger__25891__auto__)"].join('')));
}

logger__25891__auto___36961.apply(null,prefix__25892__auto___36962.concat(cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cb_param_reason_36948], null))));
} else {
}

return handler_fn_36941(cb_param_reason_36948);
});
var ns_obj_36945 = (function (){var target_obj_36952 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36953 = (target_obj_36952["chrome"]);
var next_obj_36954 = (next_obj_36953["runtime"]);
return next_obj_36954;
})();
var missing_api_36946 = (function (){var config__25894__auto__ = config;
var api_check_fn__25895__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__25894__auto__);
if(cljs.core.fn_QMARK_(api_check_fn__25895__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid :api-check-fn in chromex config\n","config:",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25894__auto__)].join(''),"\n","(clojure.core/fn? api-check-fn__25895__auto__)"].join('')));
}

return (api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__25895__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onRestartRequired",ns_obj_36945,"onRestartRequired") : api_check_fn__25895__auto__.call(null,"chrome.runtime.onRestartRequired",ns_obj_36945,"onRestartRequired"));
})();
if(missing_api_36946 === true){
return null;
} else {
var event_obj_36943 = (function (){var target_obj_36955 = ns_obj_36945;
var next_obj_36956 = (target_obj_36955["onRestartRequired"]);
return next_obj_36956;
})();
var result_36944 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_36943,logging_fn_36942,channel);
result_36944.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_36944;
}
}));

(chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$applyTo = (function (seq36937){
var G__36938 = cljs.core.first(seq36937);
var seq36937__$1 = cljs.core.next(seq36937);
var G__36939 = cljs.core.first(seq36937__$1);
var seq36937__$2 = cljs.core.next(seq36937__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__36938,G__36939,seq36937__$2);
}));

