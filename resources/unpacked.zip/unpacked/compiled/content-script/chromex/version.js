// Compiled by ClojureScript 1.10.597 {:static-fns true, :optimize-constants true}
goog.provide('chromex.version');
goog.require('cljs.core');
goog.require('cljs.core.constants');
chromex.version.current_version = "0.8.5";
chromex.version.get_current_version = (function chromex$version$get_current_version(){
return chromex.version.current_version;
});
