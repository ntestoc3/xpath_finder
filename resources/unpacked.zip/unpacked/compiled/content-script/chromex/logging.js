// Compiled by ClojureScript 1.10.597 {:static-fns true, :optimize-constants true}
goog.provide('chromex.logging');
goog.require('cljs.core');
goog.require('cljs.core.constants');
