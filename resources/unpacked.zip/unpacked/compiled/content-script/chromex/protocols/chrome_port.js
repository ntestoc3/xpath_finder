// Compiled by ClojureScript 1.10.597 {:static-fns true, :optimize-constants true}
goog.provide('chromex.protocols.chrome_port');
goog.require('cljs.core');
goog.require('cljs.core.constants');

/**
 * a wrapper for https://developer.chrome.com/extensions/runtime#type-Port
 * @interface
 */
chromex.protocols.chrome_port.IChromePort = function(){};

chromex.protocols.chrome_port.get_native_port = (function chromex$protocols$chrome_port$get_native_port(this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_port$IChromePort$get_native_port$arity$1 == null)))))){
return this$.chromex$protocols$chrome_port$IChromePort$get_native_port$arity$1(this$);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_port.get_native_port[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4488__auto__.call(null,this$));
} else {
var m__4485__auto__ = (chromex.protocols.chrome_port.get_native_port["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4485__auto__.call(null,this$));
} else {
throw cljs.core.missing_protocol("IChromePort.get-native-port",this$);
}
}
}
});

chromex.protocols.chrome_port.get_name = (function chromex$protocols$chrome_port$get_name(this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_port$IChromePort$get_name$arity$1 == null)))))){
return this$.chromex$protocols$chrome_port$IChromePort$get_name$arity$1(this$);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_port.get_name[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4488__auto__.call(null,this$));
} else {
var m__4485__auto__ = (chromex.protocols.chrome_port.get_name["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4485__auto__.call(null,this$));
} else {
throw cljs.core.missing_protocol("IChromePort.get-name",this$);
}
}
}
});

chromex.protocols.chrome_port.get_sender = (function chromex$protocols$chrome_port$get_sender(this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_port$IChromePort$get_sender$arity$1 == null)))))){
return this$.chromex$protocols$chrome_port$IChromePort$get_sender$arity$1(this$);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_port.get_sender[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4488__auto__.call(null,this$));
} else {
var m__4485__auto__ = (chromex.protocols.chrome_port.get_sender["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4485__auto__.call(null,this$));
} else {
throw cljs.core.missing_protocol("IChromePort.get-sender",this$);
}
}
}
});

chromex.protocols.chrome_port.post_message_BANG_ = (function chromex$protocols$chrome_port$post_message_BANG_(this$,message){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_port$IChromePort$post_message_BANG_$arity$2 == null)))))){
return this$.chromex$protocols$chrome_port$IChromePort$post_message_BANG_$arity$2(this$,message);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_port.post_message_BANG_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$2(this$,message) : m__4488__auto__.call(null,this$,message));
} else {
var m__4485__auto__ = (chromex.protocols.chrome_port.post_message_BANG_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$2(this$,message) : m__4485__auto__.call(null,this$,message));
} else {
throw cljs.core.missing_protocol("IChromePort.post-message!",this$);
}
}
}
});

chromex.protocols.chrome_port.disconnect_BANG_ = (function chromex$protocols$chrome_port$disconnect_BANG_(this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_port$IChromePort$disconnect_BANG_$arity$1 == null)))))){
return this$.chromex$protocols$chrome_port$IChromePort$disconnect_BANG_$arity$1(this$);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_port.disconnect_BANG_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4488__auto__.call(null,this$));
} else {
var m__4485__auto__ = (chromex.protocols.chrome_port.disconnect_BANG_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4485__auto__.call(null,this$));
} else {
throw cljs.core.missing_protocol("IChromePort.disconnect!",this$);
}
}
}
});

chromex.protocols.chrome_port.on_disconnect_BANG_ = (function chromex$protocols$chrome_port$on_disconnect_BANG_(this$,callback){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_port$IChromePort$on_disconnect_BANG_$arity$2 == null)))))){
return this$.chromex$protocols$chrome_port$IChromePort$on_disconnect_BANG_$arity$2(this$,callback);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_port.on_disconnect_BANG_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$2(this$,callback) : m__4488__auto__.call(null,this$,callback));
} else {
var m__4485__auto__ = (chromex.protocols.chrome_port.on_disconnect_BANG_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$2(this$,callback) : m__4485__auto__.call(null,this$,callback));
} else {
throw cljs.core.missing_protocol("IChromePort.on-disconnect!",this$);
}
}
}
});

chromex.protocols.chrome_port.on_message_BANG_ = (function chromex$protocols$chrome_port$on_message_BANG_(this$,callback){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_port$IChromePort$on_message_BANG_$arity$2 == null)))))){
return this$.chromex$protocols$chrome_port$IChromePort$on_message_BANG_$arity$2(this$,callback);
} else {
var x__4487__auto__ = (((this$ == null))?null:this$);
var m__4488__auto__ = (chromex.protocols.chrome_port.on_message_BANG_[goog.typeOf(x__4487__auto__)]);
if((!((m__4488__auto__ == null)))){
return (m__4488__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4488__auto__.cljs$core$IFn$_invoke$arity$2(this$,callback) : m__4488__auto__.call(null,this$,callback));
} else {
var m__4485__auto__ = (chromex.protocols.chrome_port.on_message_BANG_["_"]);
if((!((m__4485__auto__ == null)))){
return (m__4485__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4485__auto__.cljs$core$IFn$_invoke$arity$2(this$,callback) : m__4485__auto__.call(null,this$,callback));
} else {
throw cljs.core.missing_protocol("IChromePort.on-message!",this$);
}
}
}
});

