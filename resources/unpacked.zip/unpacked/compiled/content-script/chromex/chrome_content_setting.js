// Compiled by ClojureScript 1.10.597 {:static-fns true, :optimize-constants true}
goog.provide('chromex.chrome_content_setting');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.protocols.chrome_content_setting');
goog.require('chromex.support');
goog.require('oops.core');

/**
* @constructor
 * @implements {chromex.protocols.chrome_content_setting.IChromeContentSetting}
*/
chromex.chrome_content_setting.ChromeContentSetting = (function (native_chrome_content_setting,channel_factory,callback_factory){
this.native_chrome_content_setting = native_chrome_content_setting;
this.channel_factory = channel_factory;
this.callback_factory = callback_factory;
});
(chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$ = cljs.core.PROTOCOL_SENTINEL);

(chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_native_content_setting$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_content_setting;
}));

(chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_35190_35206 = self__.native_chrome_content_setting;
var call_info_35192_35207 = [target_obj_35190_35206,(function (){var next_obj_35193 = (target_obj_35190_35206["get"]);
return next_obj_35193;
})()];
var fn_35191_35208 = (call_info_35192_35207[(1)]);
if((!((fn_35191_35208 == null)))){
fn_35191_35208.call((call_info_35192_35207[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
}));

(chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$set$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_35194_35209 = self__.native_chrome_content_setting;
var call_info_35196_35210 = [target_obj_35194_35209,(function (){var next_obj_35197 = (target_obj_35194_35209["set"]);
return next_obj_35197;
})()];
var fn_35195_35211 = (call_info_35196_35210[(1)]);
if((!((fn_35195_35211 == null)))){
fn_35195_35211.call((call_info_35196_35210[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
}));

(chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$clear$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_35198_35212 = self__.native_chrome_content_setting;
var call_info_35200_35213 = [target_obj_35198_35212,(function (){var next_obj_35201 = (target_obj_35198_35212["clear"]);
return next_obj_35201;
})()];
var fn_35199_35214 = (call_info_35200_35213[(1)]);
if((!((fn_35199_35214 == null)))){
fn_35199_35214.call((call_info_35200_35213[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
}));

(chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_resource_identifiers$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_35202_35215 = self__.native_chrome_content_setting;
var call_info_35204_35216 = [target_obj_35202_35215,(function (){var next_obj_35205 = (target_obj_35202_35215["getResourceIdentifiers"]);
return next_obj_35205;
})()];
var fn_35203_35217 = (call_info_35204_35216[(1)]);
if((!((fn_35203_35217 == null)))){
fn_35203_35217.call((call_info_35204_35216[(0)]),(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
}));

(chromex.chrome_content_setting.ChromeContentSetting.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$native_DASH_chrome_DASH_content_DASH_setting,cljs.core.cst$sym$channel_DASH_factory,cljs.core.cst$sym$callback_DASH_factory], null);
}));

(chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$type = true);

(chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$ctorStr = "chromex.chrome-content-setting/ChromeContentSetting");

(chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__,opt__4430__auto__){
return cljs.core._write(writer__4429__auto__,"chromex.chrome-content-setting/ChromeContentSetting");
}));

/**
 * Positional factory function for chromex.chrome-content-setting/ChromeContentSetting.
 */
chromex.chrome_content_setting.__GT_ChromeContentSetting = (function chromex$chrome_content_setting$__GT_ChromeContentSetting(native_chrome_content_setting,channel_factory,callback_factory){
return (new chromex.chrome_content_setting.ChromeContentSetting(native_chrome_content_setting,channel_factory,callback_factory));
});

chromex.chrome_content_setting.make_chrome_content_setting = (function chromex$chrome_content_setting$make_chrome_content_setting(config,native_chrome_content_setting){
if(cljs.core.truth_(native_chrome_content_setting)){
} else {
throw (new Error("Assert failed: native-chrome-content-setting"));
}

return (new chromex.chrome_content_setting.ChromeContentSetting(native_chrome_content_setting,(function (){var config__25865__auto__ = config;
var handler_key__25866__auto__ = cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_channel_DASH_factory;
var handler__25867__auto__ = handler_key__25866__auto__.cljs$core$IFn$_invoke$arity$1(config__25865__auto__);
if(cljs.core.fn_QMARK_(handler__25867__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25866__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25865__auto__)].join(''),"\n","(clojure.core/fn? handler__25867__auto__)"].join('')));
}

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__25867__auto__,config__25865__auto__);
})(),(function (){var config__25865__auto__ = config;
var handler_key__25866__auto__ = cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_fn_DASH_factory;
var handler__25867__auto__ = handler_key__25866__auto__.cljs$core$IFn$_invoke$arity$1(config__25865__auto__);
if(cljs.core.fn_QMARK_(handler__25867__auto__)){
} else {
throw (new Error(["Assert failed: ",["invalid ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(handler_key__25866__auto__)," in chromex config\n","config: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(config__25865__auto__)].join(''),"\n","(clojure.core/fn? handler__25867__auto__)"].join('')));
}

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__25867__auto__,config__25865__auto__);
})()));
});
