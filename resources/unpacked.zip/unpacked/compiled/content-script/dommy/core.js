// Compiled by ClojureScript 1.10.597 {:static-fns true, :optimize-constants true}
goog.provide('dommy.core');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('clojure.string');
goog.require('dommy.utils');
/**
 * Returns a selector in string format.
 * Accepts string, keyword, or collection.
 */
dommy.core.selector = (function dommy$core$selector(data){
if(cljs.core.coll_QMARK_(data)){
return clojure.string.join.cljs$core$IFn$_invoke$arity$2(" ",cljs.core.map.cljs$core$IFn$_invoke$arity$2(dommy.core.selector,data));
} else {
if(((typeof data === 'string') || ((data instanceof cljs.core.Keyword)))){
return cljs.core.name(data);
} else {
return null;
}
}
});
dommy.core.text = (function dommy$core$text(elem){
var or__4185__auto__ = elem.textContent;
if(cljs.core.truth_(or__4185__auto__)){
return or__4185__auto__;
} else {
return elem.innerText;
}
});
dommy.core.html = (function dommy$core$html(elem){
return elem.innerHTML;
});
dommy.core.value = (function dommy$core$value(elem){
return elem.value;
});
dommy.core.class$ = (function dommy$core$class(elem){
return elem.className;
});
dommy.core.attr = (function dommy$core$attr(elem,k){
if(cljs.core.truth_(k)){
return elem.getAttribute(dommy.utils.as_str(k));
} else {
return null;
}
});
/**
 * The computed style of `elem`, optionally specifying the key of
 * a particular style to return
 */
dommy.core.style = (function dommy$core$style(var_args){
var G__40816 = arguments.length;
switch (G__40816) {
case 1:
return dommy.core.style.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return dommy.core.style.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(dommy.core.style.cljs$core$IFn$_invoke$arity$1 = (function (elem){
return cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(window.getComputedStyle(elem));
}));

(dommy.core.style.cljs$core$IFn$_invoke$arity$2 = (function (elem,k){
return (window.getComputedStyle(elem)[dommy.utils.as_str(k)]);
}));

(dommy.core.style.cljs$lang$maxFixedArity = 2);

dommy.core.px = (function dommy$core$px(elem,k){

var pixels = dommy.core.style.cljs$core$IFn$_invoke$arity$2(elem,k);
if(cljs.core.seq(pixels)){
return parseInt(pixels);
} else {
return null;
}
});
/**
 * Does `elem` contain `c` in its class list
 */
dommy.core.has_class_QMARK_ = (function dommy$core$has_class_QMARK_(elem,c){
var c__$1 = dommy.utils.as_str(c);
var temp__5733__auto__ = elem.classList;
if(cljs.core.truth_(temp__5733__auto__)){
var class_list = temp__5733__auto__;
return class_list.contains(c__$1);
} else {
var temp__5735__auto__ = dommy.core.class$(elem);
if(cljs.core.truth_(temp__5735__auto__)){
var class_name = temp__5735__auto__;
var temp__5735__auto____$1 = dommy.utils.class_index(class_name,c__$1);
if(cljs.core.truth_(temp__5735__auto____$1)){
var i = temp__5735__auto____$1;
return (i >= (0));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Is `elem` hidden (as associated with hide!/show!/toggle!, using display: none)
 */
dommy.core.hidden_QMARK_ = (function dommy$core$hidden_QMARK_(elem){
return (dommy.core.style.cljs$core$IFn$_invoke$arity$2(elem,cljs.core.cst$kw$display) === "none");
});
/**
 * Returns a map of the bounding client rect of `elem`
 * as a map with [:top :left :right :bottom :width :height]
 */
dommy.core.bounding_client_rect = (function dommy$core$bounding_client_rect(elem){
var r = elem.getBoundingClientRect();
return new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$top,r.top,cljs.core.cst$kw$bottom,r.bottom,cljs.core.cst$kw$left,r.left,cljs.core.cst$kw$right,r.right,cljs.core.cst$kw$width,r.width,cljs.core.cst$kw$height,r.height], null);
});
dommy.core.parent = (function dommy$core$parent(elem){
return elem.parentNode;
});
dommy.core.children = (function dommy$core$children(elem){
return elem.children;
});
/**
 * Lazy seq of the ancestors of `elem`
 */
dommy.core.ancestors = (function dommy$core$ancestors(elem){
return cljs.core.take_while.cljs$core$IFn$_invoke$arity$2(cljs.core.identity,cljs.core.iterate(dommy.core.parent,elem));
});
dommy.core.ancestor_nodes = dommy.core.ancestors;
/**
 * Returns a predicate on nodes that match `selector` at the
 * time of this `matches-pred` call (may return outdated results
 * if you fuck with the DOM)
 */
dommy.core.matches_pred = (function dommy$core$matches_pred(var_args){
var G__40819 = arguments.length;
switch (G__40819) {
case 2:
return dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 1:
return dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$2 = (function (base,selector){
var matches = dommy.utils.__GT_Array(base.querySelectorAll(dommy.core.selector(selector)));
return (function (elem){
return (matches.indexOf(elem) >= (0));
});
}));

(dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$1 = (function (selector){
return dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$2(document,selector);
}));

(dommy.core.matches_pred.cljs$lang$maxFixedArity = 2);

/**
 * Closest ancestor of `elem` (up to `base`, if provided)
 * that matches `selector`
 */
dommy.core.closest = (function dommy$core$closest(var_args){
var G__40823 = arguments.length;
switch (G__40823) {
case 3:
return dommy.core.closest.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 2:
return dommy.core.closest.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(dommy.core.closest.cljs$core$IFn$_invoke$arity$3 = (function (base,elem,selector){
return cljs.core.first(cljs.core.filter.cljs$core$IFn$_invoke$arity$2(dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$2(base,selector),cljs.core.take_while.cljs$core$IFn$_invoke$arity$2((function (p1__40821_SHARP_){
return (!((p1__40821_SHARP_ === base)));
}),dommy.core.ancestors(elem))));
}));

(dommy.core.closest.cljs$core$IFn$_invoke$arity$2 = (function (elem,selector){
return dommy.core.closest.cljs$core$IFn$_invoke$arity$3(document.body,elem,selector);
}));

(dommy.core.closest.cljs$lang$maxFixedArity = 3);

/**
 * Is `descendant` a descendant of `ancestor`?
 * (http://goo.gl/T8pgCX)
 */
dommy.core.descendant_QMARK_ = (function dommy$core$descendant_QMARK_(descendant,ancestor){
if(cljs.core.truth_(ancestor.contains)){
return ancestor.contains(descendant);
} else {
if(cljs.core.truth_(ancestor.compareDocumentPosition)){
return ((ancestor.compareDocumentPosition(descendant) & (1 << (4))) != 0);
} else {
return null;
}
}
});
/**
 * Set the textContent of `elem` to `text`, fall back to innerText
 */
dommy.core.set_text_BANG_ = (function dommy$core$set_text_BANG_(elem,text){
if((!((void 0 === elem.textContent)))){
(elem.textContent = text);
} else {
(elem.innerText = text);
}

return elem;
});
/**
 * Set the innerHTML of `elem` to `html`
 */
dommy.core.set_html_BANG_ = (function dommy$core$set_html_BANG_(elem,html){
(elem.innerHTML = html);

return elem;
});
/**
 * Set the value of `elem` to `value`
 */
dommy.core.set_value_BANG_ = (function dommy$core$set_value_BANG_(elem,value){
(elem.value = value);

return elem;
});
/**
 * Set the css class of `elem` to `elem`
 */
dommy.core.set_class_BANG_ = (function dommy$core$set_class_BANG_(elem,c){
return (elem.className = c);
});
/**
 * Set the style of `elem` using key-value pairs:
 * 
 *    (set-style! elem :display "block" :color "red")
 */
dommy.core.set_style_BANG_ = (function dommy$core$set_style_BANG_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___40843 = arguments.length;
var i__4790__auto___40844 = (0);
while(true){
if((i__4790__auto___40844 < len__4789__auto___40843)){
args__4795__auto__.push((arguments[i__4790__auto___40844]));

var G__40845 = (i__4790__auto___40844 + (1));
i__4790__auto___40844 = G__40845;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((1) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((1)),(0),null)):null);
return dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4796__auto__);
});

(dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,kvs){
if(cljs.core.even_QMARK_(cljs.core.count(kvs))){
} else {
throw (new Error("Assert failed: (even? (count kvs))"));
}

var style = elem.style;
var seq__40827_40846 = cljs.core.seq(cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),kvs));
var chunk__40828_40847 = null;
var count__40829_40848 = (0);
var i__40830_40849 = (0);
while(true){
if((i__40830_40849 < count__40829_40848)){
var vec__40837_40850 = chunk__40828_40847.cljs$core$IIndexed$_nth$arity$2(null,i__40830_40849);
var k_40851 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__40837_40850,(0),null);
var v_40852 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__40837_40850,(1),null);
style.setProperty(dommy.utils.as_str(k_40851),v_40852);


var G__40853 = seq__40827_40846;
var G__40854 = chunk__40828_40847;
var G__40855 = count__40829_40848;
var G__40856 = (i__40830_40849 + (1));
seq__40827_40846 = G__40853;
chunk__40828_40847 = G__40854;
count__40829_40848 = G__40855;
i__40830_40849 = G__40856;
continue;
} else {
var temp__5735__auto___40857 = cljs.core.seq(seq__40827_40846);
if(temp__5735__auto___40857){
var seq__40827_40858__$1 = temp__5735__auto___40857;
if(cljs.core.chunked_seq_QMARK_(seq__40827_40858__$1)){
var c__4609__auto___40859 = cljs.core.chunk_first(seq__40827_40858__$1);
var G__40860 = cljs.core.chunk_rest(seq__40827_40858__$1);
var G__40861 = c__4609__auto___40859;
var G__40862 = cljs.core.count(c__4609__auto___40859);
var G__40863 = (0);
seq__40827_40846 = G__40860;
chunk__40828_40847 = G__40861;
count__40829_40848 = G__40862;
i__40830_40849 = G__40863;
continue;
} else {
var vec__40840_40864 = cljs.core.first(seq__40827_40858__$1);
var k_40865 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__40840_40864,(0),null);
var v_40866 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__40840_40864,(1),null);
style.setProperty(dommy.utils.as_str(k_40865),v_40866);


var G__40867 = cljs.core.next(seq__40827_40858__$1);
var G__40868 = null;
var G__40869 = (0);
var G__40870 = (0);
seq__40827_40846 = G__40867;
chunk__40828_40847 = G__40868;
count__40829_40848 = G__40869;
i__40830_40849 = G__40870;
continue;
}
} else {
}
}
break;
}

return elem;
}));

(dommy.core.set_style_BANG_.cljs$lang$maxFixedArity = (1));

/** @this {Function} */
(dommy.core.set_style_BANG_.cljs$lang$applyTo = (function (seq40825){
var G__40826 = cljs.core.first(seq40825);
var seq40825__$1 = cljs.core.next(seq40825);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__40826,seq40825__$1);
}));

/**
 * Remove the style of `elem` using keywords:
 *   
 *    (remove-style! elem :display :color)
 */
dommy.core.remove_style_BANG_ = (function dommy$core$remove_style_BANG_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___40877 = arguments.length;
var i__4790__auto___40878 = (0);
while(true){
if((i__4790__auto___40878 < len__4789__auto___40877)){
args__4795__auto__.push((arguments[i__4790__auto___40878]));

var G__40879 = (i__4790__auto___40878 + (1));
i__4790__auto___40878 = G__40879;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((1) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((1)),(0),null)):null);
return dommy.core.remove_style_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4796__auto__);
});

(dommy.core.remove_style_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,keywords){
var style = elem.style;
var seq__40873_40880 = cljs.core.seq(keywords);
var chunk__40874_40881 = null;
var count__40875_40882 = (0);
var i__40876_40883 = (0);
while(true){
if((i__40876_40883 < count__40875_40882)){
var kw_40884 = chunk__40874_40881.cljs$core$IIndexed$_nth$arity$2(null,i__40876_40883);
style.removeProperty(dommy.utils.as_str(kw_40884));


var G__40885 = seq__40873_40880;
var G__40886 = chunk__40874_40881;
var G__40887 = count__40875_40882;
var G__40888 = (i__40876_40883 + (1));
seq__40873_40880 = G__40885;
chunk__40874_40881 = G__40886;
count__40875_40882 = G__40887;
i__40876_40883 = G__40888;
continue;
} else {
var temp__5735__auto___40889 = cljs.core.seq(seq__40873_40880);
if(temp__5735__auto___40889){
var seq__40873_40890__$1 = temp__5735__auto___40889;
if(cljs.core.chunked_seq_QMARK_(seq__40873_40890__$1)){
var c__4609__auto___40891 = cljs.core.chunk_first(seq__40873_40890__$1);
var G__40892 = cljs.core.chunk_rest(seq__40873_40890__$1);
var G__40893 = c__4609__auto___40891;
var G__40894 = cljs.core.count(c__4609__auto___40891);
var G__40895 = (0);
seq__40873_40880 = G__40892;
chunk__40874_40881 = G__40893;
count__40875_40882 = G__40894;
i__40876_40883 = G__40895;
continue;
} else {
var kw_40896 = cljs.core.first(seq__40873_40890__$1);
style.removeProperty(dommy.utils.as_str(kw_40896));


var G__40897 = cljs.core.next(seq__40873_40890__$1);
var G__40898 = null;
var G__40899 = (0);
var G__40900 = (0);
seq__40873_40880 = G__40897;
chunk__40874_40881 = G__40898;
count__40875_40882 = G__40899;
i__40876_40883 = G__40900;
continue;
}
} else {
}
}
break;
}

return elem;
}));

(dommy.core.remove_style_BANG_.cljs$lang$maxFixedArity = (1));

/** @this {Function} */
(dommy.core.remove_style_BANG_.cljs$lang$applyTo = (function (seq40871){
var G__40872 = cljs.core.first(seq40871);
var seq40871__$1 = cljs.core.next(seq40871);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__40872,seq40871__$1);
}));

dommy.core.set_px_BANG_ = (function dommy$core$set_px_BANG_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___40919 = arguments.length;
var i__4790__auto___40920 = (0);
while(true){
if((i__4790__auto___40920 < len__4789__auto___40919)){
args__4795__auto__.push((arguments[i__4790__auto___40920]));

var G__40921 = (i__4790__auto___40920 + (1));
i__4790__auto___40920 = G__40921;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((1) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((1)),(0),null)):null);
return dommy.core.set_px_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4796__auto__);
});

(dommy.core.set_px_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,kvs){

if(cljs.core.even_QMARK_(cljs.core.count(kvs))){
} else {
throw (new Error("Assert failed: (even? (count kvs))"));
}

var seq__40903_40922 = cljs.core.seq(cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),kvs));
var chunk__40904_40923 = null;
var count__40905_40924 = (0);
var i__40906_40925 = (0);
while(true){
if((i__40906_40925 < count__40905_40924)){
var vec__40913_40926 = chunk__40904_40923.cljs$core$IIndexed$_nth$arity$2(null,i__40906_40925);
var k_40927 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__40913_40926,(0),null);
var v_40928 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__40913_40926,(1),null);
dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([k_40927,[cljs.core.str.cljs$core$IFn$_invoke$arity$1(v_40928),"px"].join('')], 0));


var G__40929 = seq__40903_40922;
var G__40930 = chunk__40904_40923;
var G__40931 = count__40905_40924;
var G__40932 = (i__40906_40925 + (1));
seq__40903_40922 = G__40929;
chunk__40904_40923 = G__40930;
count__40905_40924 = G__40931;
i__40906_40925 = G__40932;
continue;
} else {
var temp__5735__auto___40933 = cljs.core.seq(seq__40903_40922);
if(temp__5735__auto___40933){
var seq__40903_40934__$1 = temp__5735__auto___40933;
if(cljs.core.chunked_seq_QMARK_(seq__40903_40934__$1)){
var c__4609__auto___40935 = cljs.core.chunk_first(seq__40903_40934__$1);
var G__40936 = cljs.core.chunk_rest(seq__40903_40934__$1);
var G__40937 = c__4609__auto___40935;
var G__40938 = cljs.core.count(c__4609__auto___40935);
var G__40939 = (0);
seq__40903_40922 = G__40936;
chunk__40904_40923 = G__40937;
count__40905_40924 = G__40938;
i__40906_40925 = G__40939;
continue;
} else {
var vec__40916_40940 = cljs.core.first(seq__40903_40934__$1);
var k_40941 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__40916_40940,(0),null);
var v_40942 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__40916_40940,(1),null);
dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([k_40941,[cljs.core.str.cljs$core$IFn$_invoke$arity$1(v_40942),"px"].join('')], 0));


var G__40943 = cljs.core.next(seq__40903_40934__$1);
var G__40944 = null;
var G__40945 = (0);
var G__40946 = (0);
seq__40903_40922 = G__40943;
chunk__40904_40923 = G__40944;
count__40905_40924 = G__40945;
i__40906_40925 = G__40946;
continue;
}
} else {
}
}
break;
}

return elem;
}));

(dommy.core.set_px_BANG_.cljs$lang$maxFixedArity = (1));

/** @this {Function} */
(dommy.core.set_px_BANG_.cljs$lang$applyTo = (function (seq40901){
var G__40902 = cljs.core.first(seq40901);
var seq40901__$1 = cljs.core.next(seq40901);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__40902,seq40901__$1);
}));

/**
 * Sets dom attributes on and returns `elem`.
 * Attributes without values will be set to their name:
 * 
 *     (set-attr! elem :disabled)
 * 
 * With values, the function takes variadic kv pairs:
 * 
 *     (set-attr! elem :id "some-id"
 *                     :name "some-name")
 */
dommy.core.set_attr_BANG_ = (function dommy$core$set_attr_BANG_(var_args){
var G__40952 = arguments.length;
switch (G__40952) {
case 2:
return dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
var args_arr__4810__auto__ = [];
var len__4789__auto___40972 = arguments.length;
var i__4790__auto___40973 = (0);
while(true){
if((i__4790__auto___40973 < len__4789__auto___40972)){
args_arr__4810__auto__.push((arguments[i__4790__auto___40973]));

var G__40974 = (i__4790__auto___40973 + (1));
i__4790__auto___40973 = G__40974;
continue;
} else {
}
break;
}

var argseq__4811__auto__ = (new cljs.core.IndexedSeq(args_arr__4810__auto__.slice((3)),(0),null));
return dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__4811__auto__);

}
});

(dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,k){
return dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$3(elem,k,dommy.utils.as_str(k));
}));

(dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (elem,k,v){
var k__$1 = dommy.utils.as_str(k);
if(cljs.core.truth_(v)){
if(cljs.core.fn_QMARK_(v)){
var G__40953 = elem;
(G__40953[k__$1] = v);

return G__40953;
} else {
var G__40954 = elem;
G__40954.setAttribute(k__$1,v);

return G__40954;
}
} else {
return null;
}
}));

(dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,k,v,kvs){
if(cljs.core.even_QMARK_(cljs.core.count(kvs))){
} else {
throw (new Error("Assert failed: (even? (count kvs))"));
}

var seq__40955_40975 = cljs.core.seq(cljs.core.cons(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [k,v], null),cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),kvs)));
var chunk__40956_40976 = null;
var count__40957_40977 = (0);
var i__40958_40978 = (0);
while(true){
if((i__40958_40978 < count__40957_40977)){
var vec__40965_40979 = chunk__40956_40976.cljs$core$IIndexed$_nth$arity$2(null,i__40958_40978);
var k_40980__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__40965_40979,(0),null);
var v_40981__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__40965_40979,(1),null);
dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$3(elem,k_40980__$1,v_40981__$1);


var G__40982 = seq__40955_40975;
var G__40983 = chunk__40956_40976;
var G__40984 = count__40957_40977;
var G__40985 = (i__40958_40978 + (1));
seq__40955_40975 = G__40982;
chunk__40956_40976 = G__40983;
count__40957_40977 = G__40984;
i__40958_40978 = G__40985;
continue;
} else {
var temp__5735__auto___40986 = cljs.core.seq(seq__40955_40975);
if(temp__5735__auto___40986){
var seq__40955_40987__$1 = temp__5735__auto___40986;
if(cljs.core.chunked_seq_QMARK_(seq__40955_40987__$1)){
var c__4609__auto___40988 = cljs.core.chunk_first(seq__40955_40987__$1);
var G__40989 = cljs.core.chunk_rest(seq__40955_40987__$1);
var G__40990 = c__4609__auto___40988;
var G__40991 = cljs.core.count(c__4609__auto___40988);
var G__40992 = (0);
seq__40955_40975 = G__40989;
chunk__40956_40976 = G__40990;
count__40957_40977 = G__40991;
i__40958_40978 = G__40992;
continue;
} else {
var vec__40968_40993 = cljs.core.first(seq__40955_40987__$1);
var k_40994__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__40968_40993,(0),null);
var v_40995__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__40968_40993,(1),null);
dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$3(elem,k_40994__$1,v_40995__$1);


var G__40996 = cljs.core.next(seq__40955_40987__$1);
var G__40997 = null;
var G__40998 = (0);
var G__40999 = (0);
seq__40955_40975 = G__40996;
chunk__40956_40976 = G__40997;
count__40957_40977 = G__40998;
i__40958_40978 = G__40999;
continue;
}
} else {
}
}
break;
}

return elem;
}));

/** @this {Function} */
(dommy.core.set_attr_BANG_.cljs$lang$applyTo = (function (seq40948){
var G__40949 = cljs.core.first(seq40948);
var seq40948__$1 = cljs.core.next(seq40948);
var G__40950 = cljs.core.first(seq40948__$1);
var seq40948__$2 = cljs.core.next(seq40948__$1);
var G__40951 = cljs.core.first(seq40948__$2);
var seq40948__$3 = cljs.core.next(seq40948__$2);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__40949,G__40950,G__40951,seq40948__$3);
}));

(dommy.core.set_attr_BANG_.cljs$lang$maxFixedArity = (3));

/**
 * Removes dom attributes on and returns `elem`.
 * `class` and `classes` are special cases which clear
 * out the class name on removal.
 */
dommy.core.remove_attr_BANG_ = (function dommy$core$remove_attr_BANG_(var_args){
var G__41004 = arguments.length;
switch (G__41004) {
case 2:
return dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var args_arr__4810__auto__ = [];
var len__4789__auto___41011 = arguments.length;
var i__4790__auto___41012 = (0);
while(true){
if((i__4790__auto___41012 < len__4789__auto___41011)){
args_arr__4810__auto__.push((arguments[i__4790__auto___41012]));

var G__41013 = (i__4790__auto___41012 + (1));
i__4790__auto___41012 = G__41013;
continue;
} else {
}
break;
}

var argseq__4811__auto__ = (new cljs.core.IndexedSeq(args_arr__4810__auto__.slice((2)),(0),null));
return dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4811__auto__);

}
});

(dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,k){
var k_41014__$1 = dommy.utils.as_str(k);
if(cljs.core.truth_((function (){var fexpr__41005 = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, ["class",null,"classes",null], null), null);
return (fexpr__41005.cljs$core$IFn$_invoke$arity$1 ? fexpr__41005.cljs$core$IFn$_invoke$arity$1(k_41014__$1) : fexpr__41005.call(null,k_41014__$1));
})())){
dommy.core.set_class_BANG_(elem,"");
} else {
elem.removeAttribute(k_41014__$1);
}

return elem;
}));

(dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,k,ks){
var seq__41006_41015 = cljs.core.seq(cljs.core.cons(k,ks));
var chunk__41007_41016 = null;
var count__41008_41017 = (0);
var i__41009_41018 = (0);
while(true){
if((i__41009_41018 < count__41008_41017)){
var k_41019__$1 = chunk__41007_41016.cljs$core$IIndexed$_nth$arity$2(null,i__41009_41018);
dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$2(elem,k_41019__$1);


var G__41020 = seq__41006_41015;
var G__41021 = chunk__41007_41016;
var G__41022 = count__41008_41017;
var G__41023 = (i__41009_41018 + (1));
seq__41006_41015 = G__41020;
chunk__41007_41016 = G__41021;
count__41008_41017 = G__41022;
i__41009_41018 = G__41023;
continue;
} else {
var temp__5735__auto___41024 = cljs.core.seq(seq__41006_41015);
if(temp__5735__auto___41024){
var seq__41006_41025__$1 = temp__5735__auto___41024;
if(cljs.core.chunked_seq_QMARK_(seq__41006_41025__$1)){
var c__4609__auto___41026 = cljs.core.chunk_first(seq__41006_41025__$1);
var G__41027 = cljs.core.chunk_rest(seq__41006_41025__$1);
var G__41028 = c__4609__auto___41026;
var G__41029 = cljs.core.count(c__4609__auto___41026);
var G__41030 = (0);
seq__41006_41015 = G__41027;
chunk__41007_41016 = G__41028;
count__41008_41017 = G__41029;
i__41009_41018 = G__41030;
continue;
} else {
var k_41031__$1 = cljs.core.first(seq__41006_41025__$1);
dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$2(elem,k_41031__$1);


var G__41032 = cljs.core.next(seq__41006_41025__$1);
var G__41033 = null;
var G__41034 = (0);
var G__41035 = (0);
seq__41006_41015 = G__41032;
chunk__41007_41016 = G__41033;
count__41008_41017 = G__41034;
i__41009_41018 = G__41035;
continue;
}
} else {
}
}
break;
}

return elem;
}));

/** @this {Function} */
(dommy.core.remove_attr_BANG_.cljs$lang$applyTo = (function (seq41001){
var G__41002 = cljs.core.first(seq41001);
var seq41001__$1 = cljs.core.next(seq41001);
var G__41003 = cljs.core.first(seq41001__$1);
var seq41001__$2 = cljs.core.next(seq41001__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__41002,G__41003,seq41001__$2);
}));

(dommy.core.remove_attr_BANG_.cljs$lang$maxFixedArity = (2));

/**
 * Toggles a dom attribute `k` on `elem`, optionally specifying
 * the boolean value with `add?`
 */
dommy.core.toggle_attr_BANG_ = (function dommy$core$toggle_attr_BANG_(var_args){
var G__41037 = arguments.length;
switch (G__41037) {
case 2:
return dommy.core.toggle_attr_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return dommy.core.toggle_attr_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(dommy.core.toggle_attr_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,k){
return dommy.core.toggle_attr_BANG_.cljs$core$IFn$_invoke$arity$3(elem,k,cljs.core.boolean$(dommy.core.attr(elem,k)));
}));

(dommy.core.toggle_attr_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (elem,k,add_QMARK_){
if(add_QMARK_){
return dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$2(elem,k);
} else {
return dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$2(elem,k);
}
}));

(dommy.core.toggle_attr_BANG_.cljs$lang$maxFixedArity = 3);

/**
 * Add `classes` to `elem`, trying to use Element::classList, and
 * falling back to fast string parsing/manipulation
 */
dommy.core.add_class_BANG_ = (function dommy$core$add_class_BANG_(var_args){
var G__41043 = arguments.length;
switch (G__41043) {
case 2:
return dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var args_arr__4810__auto__ = [];
var len__4789__auto___41057 = arguments.length;
var i__4790__auto___41058 = (0);
while(true){
if((i__4790__auto___41058 < len__4789__auto___41057)){
args_arr__4810__auto__.push((arguments[i__4790__auto___41058]));

var G__41059 = (i__4790__auto___41058 + (1));
i__4790__auto___41058 = G__41059;
continue;
} else {
}
break;
}

var argseq__4811__auto__ = (new cljs.core.IndexedSeq(args_arr__4810__auto__.slice((2)),(0),null));
return dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4811__auto__);

}
});

(dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,classes){
var classes__$1 = clojure.string.trim(dommy.utils.as_str(classes)).split(/\s+/);
if(cljs.core.seq(classes__$1)){
var temp__5733__auto___41060 = elem.classList;
if(cljs.core.truth_(temp__5733__auto___41060)){
var class_list_41061 = temp__5733__auto___41060;
var seq__41044_41062 = cljs.core.seq(classes__$1);
var chunk__41045_41063 = null;
var count__41046_41064 = (0);
var i__41047_41065 = (0);
while(true){
if((i__41047_41065 < count__41046_41064)){
var c_41066 = chunk__41045_41063.cljs$core$IIndexed$_nth$arity$2(null,i__41047_41065);
class_list_41061.add(c_41066);


var G__41067 = seq__41044_41062;
var G__41068 = chunk__41045_41063;
var G__41069 = count__41046_41064;
var G__41070 = (i__41047_41065 + (1));
seq__41044_41062 = G__41067;
chunk__41045_41063 = G__41068;
count__41046_41064 = G__41069;
i__41047_41065 = G__41070;
continue;
} else {
var temp__5735__auto___41071 = cljs.core.seq(seq__41044_41062);
if(temp__5735__auto___41071){
var seq__41044_41072__$1 = temp__5735__auto___41071;
if(cljs.core.chunked_seq_QMARK_(seq__41044_41072__$1)){
var c__4609__auto___41073 = cljs.core.chunk_first(seq__41044_41072__$1);
var G__41074 = cljs.core.chunk_rest(seq__41044_41072__$1);
var G__41075 = c__4609__auto___41073;
var G__41076 = cljs.core.count(c__4609__auto___41073);
var G__41077 = (0);
seq__41044_41062 = G__41074;
chunk__41045_41063 = G__41075;
count__41046_41064 = G__41076;
i__41047_41065 = G__41077;
continue;
} else {
var c_41078 = cljs.core.first(seq__41044_41072__$1);
class_list_41061.add(c_41078);


var G__41079 = cljs.core.next(seq__41044_41072__$1);
var G__41080 = null;
var G__41081 = (0);
var G__41082 = (0);
seq__41044_41062 = G__41079;
chunk__41045_41063 = G__41080;
count__41046_41064 = G__41081;
i__41047_41065 = G__41082;
continue;
}
} else {
}
}
break;
}
} else {
var seq__41048_41083 = cljs.core.seq(classes__$1);
var chunk__41049_41084 = null;
var count__41050_41085 = (0);
var i__41051_41086 = (0);
while(true){
if((i__41051_41086 < count__41050_41085)){
var c_41087 = chunk__41049_41084.cljs$core$IIndexed$_nth$arity$2(null,i__41051_41086);
var class_name_41088 = dommy.core.class$(elem);
if(cljs.core.truth_(dommy.utils.class_index(class_name_41088,c_41087))){
} else {
dommy.core.set_class_BANG_(elem,(((class_name_41088 === ""))?c_41087:[cljs.core.str.cljs$core$IFn$_invoke$arity$1(class_name_41088)," ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(c_41087)].join('')));
}


var G__41089 = seq__41048_41083;
var G__41090 = chunk__41049_41084;
var G__41091 = count__41050_41085;
var G__41092 = (i__41051_41086 + (1));
seq__41048_41083 = G__41089;
chunk__41049_41084 = G__41090;
count__41050_41085 = G__41091;
i__41051_41086 = G__41092;
continue;
} else {
var temp__5735__auto___41093 = cljs.core.seq(seq__41048_41083);
if(temp__5735__auto___41093){
var seq__41048_41094__$1 = temp__5735__auto___41093;
if(cljs.core.chunked_seq_QMARK_(seq__41048_41094__$1)){
var c__4609__auto___41095 = cljs.core.chunk_first(seq__41048_41094__$1);
var G__41096 = cljs.core.chunk_rest(seq__41048_41094__$1);
var G__41097 = c__4609__auto___41095;
var G__41098 = cljs.core.count(c__4609__auto___41095);
var G__41099 = (0);
seq__41048_41083 = G__41096;
chunk__41049_41084 = G__41097;
count__41050_41085 = G__41098;
i__41051_41086 = G__41099;
continue;
} else {
var c_41100 = cljs.core.first(seq__41048_41094__$1);
var class_name_41101 = dommy.core.class$(elem);
if(cljs.core.truth_(dommy.utils.class_index(class_name_41101,c_41100))){
} else {
dommy.core.set_class_BANG_(elem,(((class_name_41101 === ""))?c_41100:[cljs.core.str.cljs$core$IFn$_invoke$arity$1(class_name_41101)," ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(c_41100)].join('')));
}


var G__41102 = cljs.core.next(seq__41048_41094__$1);
var G__41103 = null;
var G__41104 = (0);
var G__41105 = (0);
seq__41048_41083 = G__41102;
chunk__41049_41084 = G__41103;
count__41050_41085 = G__41104;
i__41051_41086 = G__41105;
continue;
}
} else {
}
}
break;
}
}
} else {
}

return elem;
}));

(dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,classes,more_classes){
var seq__41052_41106 = cljs.core.seq(cljs.core.conj.cljs$core$IFn$_invoke$arity$2(more_classes,classes));
var chunk__41053_41107 = null;
var count__41054_41108 = (0);
var i__41055_41109 = (0);
while(true){
if((i__41055_41109 < count__41054_41108)){
var c_41110 = chunk__41053_41107.cljs$core$IIndexed$_nth$arity$2(null,i__41055_41109);
dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,c_41110);


var G__41111 = seq__41052_41106;
var G__41112 = chunk__41053_41107;
var G__41113 = count__41054_41108;
var G__41114 = (i__41055_41109 + (1));
seq__41052_41106 = G__41111;
chunk__41053_41107 = G__41112;
count__41054_41108 = G__41113;
i__41055_41109 = G__41114;
continue;
} else {
var temp__5735__auto___41115 = cljs.core.seq(seq__41052_41106);
if(temp__5735__auto___41115){
var seq__41052_41116__$1 = temp__5735__auto___41115;
if(cljs.core.chunked_seq_QMARK_(seq__41052_41116__$1)){
var c__4609__auto___41117 = cljs.core.chunk_first(seq__41052_41116__$1);
var G__41118 = cljs.core.chunk_rest(seq__41052_41116__$1);
var G__41119 = c__4609__auto___41117;
var G__41120 = cljs.core.count(c__4609__auto___41117);
var G__41121 = (0);
seq__41052_41106 = G__41118;
chunk__41053_41107 = G__41119;
count__41054_41108 = G__41120;
i__41055_41109 = G__41121;
continue;
} else {
var c_41122 = cljs.core.first(seq__41052_41116__$1);
dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,c_41122);


var G__41123 = cljs.core.next(seq__41052_41116__$1);
var G__41124 = null;
var G__41125 = (0);
var G__41126 = (0);
seq__41052_41106 = G__41123;
chunk__41053_41107 = G__41124;
count__41054_41108 = G__41125;
i__41055_41109 = G__41126;
continue;
}
} else {
}
}
break;
}

return elem;
}));

/** @this {Function} */
(dommy.core.add_class_BANG_.cljs$lang$applyTo = (function (seq41040){
var G__41041 = cljs.core.first(seq41040);
var seq41040__$1 = cljs.core.next(seq41040);
var G__41042 = cljs.core.first(seq41040__$1);
var seq41040__$2 = cljs.core.next(seq41040__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__41041,G__41042,seq41040__$2);
}));

(dommy.core.add_class_BANG_.cljs$lang$maxFixedArity = (2));

/**
 * Remove `c` from `elem` class list
 */
dommy.core.remove_class_BANG_ = (function dommy$core$remove_class_BANG_(var_args){
var G__41131 = arguments.length;
switch (G__41131) {
case 2:
return dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var args_arr__4810__auto__ = [];
var len__4789__auto___41137 = arguments.length;
var i__4790__auto___41138 = (0);
while(true){
if((i__4790__auto___41138 < len__4789__auto___41137)){
args_arr__4810__auto__.push((arguments[i__4790__auto___41138]));

var G__41139 = (i__4790__auto___41138 + (1));
i__4790__auto___41138 = G__41139;
continue;
} else {
}
break;
}

var argseq__4811__auto__ = (new cljs.core.IndexedSeq(args_arr__4810__auto__.slice((2)),(0),null));
return dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4811__auto__);

}
});

(dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,c){
var c__$1 = dommy.utils.as_str(c);
var temp__5733__auto___41140 = elem.classList;
if(cljs.core.truth_(temp__5733__auto___41140)){
var class_list_41141 = temp__5733__auto___41140;
class_list_41141.remove(c__$1);
} else {
var class_name_41142 = dommy.core.class$(elem);
var new_class_name_41143 = dommy.utils.remove_class_str(class_name_41142,c__$1);
if((class_name_41142 === new_class_name_41143)){
} else {
dommy.core.set_class_BANG_(elem,new_class_name_41143);
}
}

return elem;
}));

(dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,class$,classes){
var seq__41132 = cljs.core.seq(cljs.core.conj.cljs$core$IFn$_invoke$arity$2(classes,class$));
var chunk__41133 = null;
var count__41134 = (0);
var i__41135 = (0);
while(true){
if((i__41135 < count__41134)){
var c = chunk__41133.cljs$core$IIndexed$_nth$arity$2(null,i__41135);
dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,c);


var G__41144 = seq__41132;
var G__41145 = chunk__41133;
var G__41146 = count__41134;
var G__41147 = (i__41135 + (1));
seq__41132 = G__41144;
chunk__41133 = G__41145;
count__41134 = G__41146;
i__41135 = G__41147;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__41132);
if(temp__5735__auto__){
var seq__41132__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__41132__$1)){
var c__4609__auto__ = cljs.core.chunk_first(seq__41132__$1);
var G__41148 = cljs.core.chunk_rest(seq__41132__$1);
var G__41149 = c__4609__auto__;
var G__41150 = cljs.core.count(c__4609__auto__);
var G__41151 = (0);
seq__41132 = G__41148;
chunk__41133 = G__41149;
count__41134 = G__41150;
i__41135 = G__41151;
continue;
} else {
var c = cljs.core.first(seq__41132__$1);
dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,c);


var G__41152 = cljs.core.next(seq__41132__$1);
var G__41153 = null;
var G__41154 = (0);
var G__41155 = (0);
seq__41132 = G__41152;
chunk__41133 = G__41153;
count__41134 = G__41154;
i__41135 = G__41155;
continue;
}
} else {
return null;
}
}
break;
}
}));

/** @this {Function} */
(dommy.core.remove_class_BANG_.cljs$lang$applyTo = (function (seq41128){
var G__41129 = cljs.core.first(seq41128);
var seq41128__$1 = cljs.core.next(seq41128);
var G__41130 = cljs.core.first(seq41128__$1);
var seq41128__$2 = cljs.core.next(seq41128__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__41129,G__41130,seq41128__$2);
}));

(dommy.core.remove_class_BANG_.cljs$lang$maxFixedArity = (2));

/**
 * (toggle-class! elem class) will add-class! if elem does not have class
 * and remove-class! otherwise.
 * (toggle-class! elem class add?) will add-class! if add? is truthy,
 * otherwise it will remove-class!
 */
dommy.core.toggle_class_BANG_ = (function dommy$core$toggle_class_BANG_(var_args){
var G__41157 = arguments.length;
switch (G__41157) {
case 2:
return dommy.core.toggle_class_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return dommy.core.toggle_class_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(dommy.core.toggle_class_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,c){
var c__$1 = dommy.utils.as_str(c);
var temp__5733__auto___41159 = elem.classList;
if(cljs.core.truth_(temp__5733__auto___41159)){
var class_list_41160 = temp__5733__auto___41159;
class_list_41160.toggle(c__$1);
} else {
dommy.core.toggle_class_BANG_.cljs$core$IFn$_invoke$arity$3(elem,c__$1,(!(dommy.core.has_class_QMARK_(elem,c__$1))));
}

return elem;
}));

(dommy.core.toggle_class_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (elem,class$,add_QMARK_){
if(add_QMARK_){
dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,class$);
} else {
dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,class$);
}

return elem;
}));

(dommy.core.toggle_class_BANG_.cljs$lang$maxFixedArity = 3);

/**
 * Display or hide the given `elem` (using display: none).
 * Takes an optional boolean `show?`
 */
dommy.core.toggle_BANG_ = (function dommy$core$toggle_BANG_(var_args){
var G__41162 = arguments.length;
switch (G__41162) {
case 2:
return dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 1:
return dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,show_QMARK_){
return dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([cljs.core.cst$kw$display,((show_QMARK_)?"":"none")], 0));
}));

(dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$1 = (function (elem){
return dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$2(elem,dommy.core.hidden_QMARK_(elem));
}));

(dommy.core.toggle_BANG_.cljs$lang$maxFixedArity = 2);

dommy.core.hide_BANG_ = (function dommy$core$hide_BANG_(elem){
return dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$2(elem,false);
});
dommy.core.show_BANG_ = (function dommy$core$show_BANG_(elem){
return dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$2(elem,true);
});
dommy.core.scroll_into_view = (function dommy$core$scroll_into_view(elem,align_with_top_QMARK_){
var top = cljs.core.cst$kw$top.cljs$core$IFn$_invoke$arity$1(dommy.core.bounding_client_rect(elem));
if((window.innerHeight < (top + elem.offsetHeight))){
return elem.scrollIntoView(align_with_top_QMARK_);
} else {
return null;
}
});
dommy.core.create_element = (function dommy$core$create_element(var_args){
var G__41165 = arguments.length;
switch (G__41165) {
case 1:
return dommy.core.create_element.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return dommy.core.create_element.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(dommy.core.create_element.cljs$core$IFn$_invoke$arity$1 = (function (tag){
return document.createElement(dommy.utils.as_str(tag));
}));

(dommy.core.create_element.cljs$core$IFn$_invoke$arity$2 = (function (tag_ns,tag){
return document.createElementNS(dommy.utils.as_str(tag_ns),dommy.utils.as_str(tag));
}));

(dommy.core.create_element.cljs$lang$maxFixedArity = 2);

dommy.core.create_text_node = (function dommy$core$create_text_node(text){
return document.createTextNode(text);
});
/**
 * Clears all children from `elem`
 */
dommy.core.clear_BANG_ = (function dommy$core$clear_BANG_(elem){
return dommy.core.set_html_BANG_(elem,"");
});
/**
 * Append `child` to `parent`
 */
dommy.core.append_BANG_ = (function dommy$core$append_BANG_(var_args){
var G__41171 = arguments.length;
switch (G__41171) {
case 2:
return dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var args_arr__4810__auto__ = [];
var len__4789__auto___41178 = arguments.length;
var i__4790__auto___41179 = (0);
while(true){
if((i__4790__auto___41179 < len__4789__auto___41178)){
args_arr__4810__auto__.push((arguments[i__4790__auto___41179]));

var G__41180 = (i__4790__auto___41179 + (1));
i__4790__auto___41179 = G__41180;
continue;
} else {
}
break;
}

var argseq__4811__auto__ = (new cljs.core.IndexedSeq(args_arr__4810__auto__.slice((2)),(0),null));
return dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4811__auto__);

}
});

(dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (parent,child){
var G__41172 = parent;
G__41172.appendChild(child);

return G__41172;
}));

(dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (parent,child,more_children){
var seq__41173_41181 = cljs.core.seq(cljs.core.cons(child,more_children));
var chunk__41174_41182 = null;
var count__41175_41183 = (0);
var i__41176_41184 = (0);
while(true){
if((i__41176_41184 < count__41175_41183)){
var c_41185 = chunk__41174_41182.cljs$core$IIndexed$_nth$arity$2(null,i__41176_41184);
dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2(parent,c_41185);


var G__41186 = seq__41173_41181;
var G__41187 = chunk__41174_41182;
var G__41188 = count__41175_41183;
var G__41189 = (i__41176_41184 + (1));
seq__41173_41181 = G__41186;
chunk__41174_41182 = G__41187;
count__41175_41183 = G__41188;
i__41176_41184 = G__41189;
continue;
} else {
var temp__5735__auto___41190 = cljs.core.seq(seq__41173_41181);
if(temp__5735__auto___41190){
var seq__41173_41191__$1 = temp__5735__auto___41190;
if(cljs.core.chunked_seq_QMARK_(seq__41173_41191__$1)){
var c__4609__auto___41192 = cljs.core.chunk_first(seq__41173_41191__$1);
var G__41193 = cljs.core.chunk_rest(seq__41173_41191__$1);
var G__41194 = c__4609__auto___41192;
var G__41195 = cljs.core.count(c__4609__auto___41192);
var G__41196 = (0);
seq__41173_41181 = G__41193;
chunk__41174_41182 = G__41194;
count__41175_41183 = G__41195;
i__41176_41184 = G__41196;
continue;
} else {
var c_41197 = cljs.core.first(seq__41173_41191__$1);
dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2(parent,c_41197);


var G__41198 = cljs.core.next(seq__41173_41191__$1);
var G__41199 = null;
var G__41200 = (0);
var G__41201 = (0);
seq__41173_41181 = G__41198;
chunk__41174_41182 = G__41199;
count__41175_41183 = G__41200;
i__41176_41184 = G__41201;
continue;
}
} else {
}
}
break;
}

return parent;
}));

/** @this {Function} */
(dommy.core.append_BANG_.cljs$lang$applyTo = (function (seq41168){
var G__41169 = cljs.core.first(seq41168);
var seq41168__$1 = cljs.core.next(seq41168);
var G__41170 = cljs.core.first(seq41168__$1);
var seq41168__$2 = cljs.core.next(seq41168__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__41169,G__41170,seq41168__$2);
}));

(dommy.core.append_BANG_.cljs$lang$maxFixedArity = (2));

/**
 * Prepend `child` to `parent`
 */
dommy.core.prepend_BANG_ = (function dommy$core$prepend_BANG_(var_args){
var G__41206 = arguments.length;
switch (G__41206) {
case 2:
return dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var args_arr__4810__auto__ = [];
var len__4789__auto___41213 = arguments.length;
var i__4790__auto___41214 = (0);
while(true){
if((i__4790__auto___41214 < len__4789__auto___41213)){
args_arr__4810__auto__.push((arguments[i__4790__auto___41214]));

var G__41215 = (i__4790__auto___41214 + (1));
i__4790__auto___41214 = G__41215;
continue;
} else {
}
break;
}

var argseq__4811__auto__ = (new cljs.core.IndexedSeq(args_arr__4810__auto__.slice((2)),(0),null));
return dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4811__auto__);

}
});

(dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (parent,child){
var G__41207 = parent;
G__41207.insertBefore(child,parent.firstChild);

return G__41207;
}));

(dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (parent,child,more_children){
var seq__41208_41216 = cljs.core.seq(cljs.core.cons(child,more_children));
var chunk__41209_41217 = null;
var count__41210_41218 = (0);
var i__41211_41219 = (0);
while(true){
if((i__41211_41219 < count__41210_41218)){
var c_41220 = chunk__41209_41217.cljs$core$IIndexed$_nth$arity$2(null,i__41211_41219);
dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$2(parent,c_41220);


var G__41221 = seq__41208_41216;
var G__41222 = chunk__41209_41217;
var G__41223 = count__41210_41218;
var G__41224 = (i__41211_41219 + (1));
seq__41208_41216 = G__41221;
chunk__41209_41217 = G__41222;
count__41210_41218 = G__41223;
i__41211_41219 = G__41224;
continue;
} else {
var temp__5735__auto___41225 = cljs.core.seq(seq__41208_41216);
if(temp__5735__auto___41225){
var seq__41208_41226__$1 = temp__5735__auto___41225;
if(cljs.core.chunked_seq_QMARK_(seq__41208_41226__$1)){
var c__4609__auto___41227 = cljs.core.chunk_first(seq__41208_41226__$1);
var G__41228 = cljs.core.chunk_rest(seq__41208_41226__$1);
var G__41229 = c__4609__auto___41227;
var G__41230 = cljs.core.count(c__4609__auto___41227);
var G__41231 = (0);
seq__41208_41216 = G__41228;
chunk__41209_41217 = G__41229;
count__41210_41218 = G__41230;
i__41211_41219 = G__41231;
continue;
} else {
var c_41232 = cljs.core.first(seq__41208_41226__$1);
dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$2(parent,c_41232);


var G__41233 = cljs.core.next(seq__41208_41226__$1);
var G__41234 = null;
var G__41235 = (0);
var G__41236 = (0);
seq__41208_41216 = G__41233;
chunk__41209_41217 = G__41234;
count__41210_41218 = G__41235;
i__41211_41219 = G__41236;
continue;
}
} else {
}
}
break;
}

return parent;
}));

/** @this {Function} */
(dommy.core.prepend_BANG_.cljs$lang$applyTo = (function (seq41203){
var G__41204 = cljs.core.first(seq41203);
var seq41203__$1 = cljs.core.next(seq41203);
var G__41205 = cljs.core.first(seq41203__$1);
var seq41203__$2 = cljs.core.next(seq41203__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__41204,G__41205,seq41203__$2);
}));

(dommy.core.prepend_BANG_.cljs$lang$maxFixedArity = (2));

/**
 * Insert `elem` before `other`, `other` must have a parent
 */
dommy.core.insert_before_BANG_ = (function dommy$core$insert_before_BANG_(elem,other){
var p = dommy.core.parent(other);
if(cljs.core.truth_(p)){
} else {
throw (new Error(["Assert failed: ","Target element must have a parent","\n","p"].join('')));
}

p.insertBefore(elem,other);

return elem;
});
/**
 * Insert `elem` after `other`, `other` must have a parent
 */
dommy.core.insert_after_BANG_ = (function dommy$core$insert_after_BANG_(elem,other){
var temp__5733__auto___41237 = other.nextSibling;
if(cljs.core.truth_(temp__5733__auto___41237)){
var next_41238 = temp__5733__auto___41237;
dommy.core.insert_before_BANG_(elem,next_41238);
} else {
dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2(dommy.core.parent(other),elem);
}

return elem;
});
/**
 * Replace `elem` with `new`, return `new`
 */
dommy.core.replace_BANG_ = (function dommy$core$replace_BANG_(elem,new$){
var p = dommy.core.parent(elem);
if(cljs.core.truth_(p)){
} else {
throw (new Error(["Assert failed: ","Target element must have a parent","\n","p"].join('')));
}

p.replaceChild(new$,elem);

return new$;
});
/**
 * Replace children of `elem` with `child`
 */
dommy.core.replace_contents_BANG_ = (function dommy$core$replace_contents_BANG_(p,child){
return dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2(dommy.core.clear_BANG_(p),child);
});
/**
 * Remove `elem` from `parent`, return `parent`
 */
dommy.core.remove_BANG_ = (function dommy$core$remove_BANG_(var_args){
var G__41240 = arguments.length;
switch (G__41240) {
case 1:
return dommy.core.remove_BANG_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return dommy.core.remove_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(dommy.core.remove_BANG_.cljs$core$IFn$_invoke$arity$1 = (function (elem){
var p = dommy.core.parent(elem);
if(cljs.core.truth_(p)){
} else {
throw (new Error(["Assert failed: ","Target element must have a parent","\n","p"].join('')));
}

return dommy.core.remove_BANG_.cljs$core$IFn$_invoke$arity$2(p,elem);
}));

(dommy.core.remove_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (p,elem){
var G__41241 = p;
G__41241.removeChild(elem);

return G__41241;
}));

(dommy.core.remove_BANG_.cljs$lang$maxFixedArity = 2);

dommy.core.special_listener_makers = cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p__41243){
var vec__41244 = p__41243;
var special_mouse_event = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41244,(0),null);
var real_mouse_event = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41244,(1),null);
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [special_mouse_event,cljs.core.PersistentArrayMap.createAsIfByAssoc([real_mouse_event,(function (f){
return (function (event){
var related_target = event.relatedTarget;
var listener_target = (function (){var or__4185__auto__ = event.selectedTarget;
if(cljs.core.truth_(or__4185__auto__)){
return or__4185__auto__;
} else {
return event.currentTarget;
}
})();
if(cljs.core.truth_((function (){var and__4174__auto__ = related_target;
if(cljs.core.truth_(and__4174__auto__)){
return dommy.core.descendant_QMARK_(related_target,listener_target);
} else {
return and__4174__auto__;
}
})())){
return null;
} else {
return (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(event) : f.call(null,event));
}
});
})])], null);
}),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$mouseenter,cljs.core.cst$kw$mouseover,cljs.core.cst$kw$mouseleave,cljs.core.cst$kw$mouseout], null)));
/**
 * fires f if event.target is found with `selector`
 */
dommy.core.live_listener = (function dommy$core$live_listener(elem,selector,f){
return (function (event){
var selected_target = dommy.core.closest.cljs$core$IFn$_invoke$arity$3(elem,event.target,selector);
if(cljs.core.truth_((function (){var and__4174__auto__ = selected_target;
if(cljs.core.truth_(and__4174__auto__)){
return cljs.core.not(dommy.core.attr(selected_target,cljs.core.cst$kw$disabled));
} else {
return and__4174__auto__;
}
})())){
(event.selectedTarget = selected_target);

return (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(event) : f.call(null,event));
} else {
return null;
}
});
});
/**
 * Returns a nested map of event listeners on `elem`
 */
dommy.core.event_listeners = (function dommy$core$event_listeners(elem){
var or__4185__auto__ = elem.dommyEventListeners;
if(cljs.core.truth_(or__4185__auto__)){
return or__4185__auto__;
} else {
return cljs.core.PersistentArrayMap.EMPTY;
}
});
dommy.core.update_event_listeners_BANG_ = (function dommy$core$update_event_listeners_BANG_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___41250 = arguments.length;
var i__4790__auto___41251 = (0);
while(true){
if((i__4790__auto___41251 < len__4789__auto___41250)){
args__4795__auto__.push((arguments[i__4790__auto___41251]));

var G__41252 = (i__4790__auto___41251 + (1));
i__4790__auto___41251 = G__41252;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((2) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((2)),(0),null)):null);
return dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4796__auto__);
});

(dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,f,args){
var elem__$1 = elem;
return (elem__$1.dommyEventListeners = cljs.core.apply.cljs$core$IFn$_invoke$arity$3(f,dommy.core.event_listeners(elem__$1),args));
}));

(dommy.core.update_event_listeners_BANG_.cljs$lang$maxFixedArity = (2));

/** @this {Function} */
(dommy.core.update_event_listeners_BANG_.cljs$lang$applyTo = (function (seq41247){
var G__41248 = cljs.core.first(seq41247);
var seq41247__$1 = cljs.core.next(seq41247);
var G__41249 = cljs.core.first(seq41247__$1);
var seq41247__$2 = cljs.core.next(seq41247__$1);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__41248,G__41249,seq41247__$2);
}));

dommy.core.elem_and_selector = (function dommy$core$elem_and_selector(elem_sel){
if(cljs.core.sequential_QMARK_(elem_sel)){
var fexpr__41253 = cljs.core.juxt.cljs$core$IFn$_invoke$arity$2(cljs.core.first,cljs.core.rest);
return (fexpr__41253.cljs$core$IFn$_invoke$arity$1 ? fexpr__41253.cljs$core$IFn$_invoke$arity$1(elem_sel) : fexpr__41253.call(null,elem_sel));
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [elem_sel,null], null);
}
});
/**
 * Adds `f` as a listener for events of type `event-type` on
 * `elem-sel`, which must either be a DOM node, or a sequence
 * whose first item is a DOM node.
 * 
 * In other words, the call to `listen!` can take two forms:
 * 
 * If `elem-sel` is a DOM node, i.e., you're doing something like:
 * 
 *     (listen! elem :click click-handler)
 * 
 * then `click-handler` will be set as a listener for `click` events
 * on the `elem`.
 * 
 * If `elem-sel` is a sequence:
 * 
 *     (listen! [elem :.selector.for :.some.descendants] :click click-handler)
 * 
 * then `click-handler` will be set as a listener for `click` events
 * on descendants of `elem` that match the selector
 * 
 * Also accepts any number of event-type and handler pairs for setting
 * multiple listeners at once:
 * 
 *     (listen! some-elem :click click-handler :hover hover-handler)
 */
dommy.core.listen_BANG_ = (function dommy$core$listen_BANG_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___41367 = arguments.length;
var i__4790__auto___41368 = (0);
while(true){
if((i__4790__auto___41368 < len__4789__auto___41367)){
args__4795__auto__.push((arguments[i__4790__auto___41368]));

var G__41369 = (i__4790__auto___41368 + (1));
i__4790__auto___41368 = G__41369;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((1) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((1)),(0),null)):null);
return dommy.core.listen_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4796__auto__);
});

(dommy.core.listen_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem_sel,type_fs){
if(cljs.core.even_QMARK_(cljs.core.count(type_fs))){
} else {
throw (new Error("Assert failed: (even? (count type-fs))"));
}

var vec__41256_41370 = dommy.core.elem_and_selector(elem_sel);
var elem_41371 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41256_41370,(0),null);
var selector_41372 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41256_41370,(1),null);
var seq__41259_41373 = cljs.core.seq(cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),type_fs));
var chunk__41266_41374 = null;
var count__41267_41375 = (0);
var i__41268_41376 = (0);
while(true){
if((i__41268_41376 < count__41267_41375)){
var vec__41321_41377 = chunk__41266_41374.cljs$core$IIndexed$_nth$arity$2(null,i__41268_41376);
var orig_type_41378 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41321_41377,(0),null);
var f_41379 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41321_41377,(1),null);
var seq__41269_41380 = cljs.core.seq(cljs.core.get.cljs$core$IFn$_invoke$arity$3(dommy.core.special_listener_makers,orig_type_41378,cljs.core.PersistentArrayMap.createAsIfByAssoc([orig_type_41378,cljs.core.identity])));
var chunk__41271_41381 = null;
var count__41272_41382 = (0);
var i__41273_41383 = (0);
while(true){
if((i__41273_41383 < count__41272_41382)){
var vec__41334_41384 = chunk__41271_41381.cljs$core$IIndexed$_nth$arity$2(null,i__41273_41383);
var actual_type_41385 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41334_41384,(0),null);
var factory_41386 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41334_41384,(1),null);
var canonical_f_41387 = (function (){var G__41338 = (factory_41386.cljs$core$IFn$_invoke$arity$1 ? factory_41386.cljs$core$IFn$_invoke$arity$1(f_41379) : factory_41386.call(null,f_41379));
var fexpr__41337 = (cljs.core.truth_(selector_41372)?cljs.core.partial.cljs$core$IFn$_invoke$arity$3(dommy.core.live_listener,elem_41371,selector_41372):cljs.core.identity);
return (fexpr__41337.cljs$core$IFn$_invoke$arity$1 ? fexpr__41337.cljs$core$IFn$_invoke$arity$1(G__41338) : fexpr__41337.call(null,G__41338));
})();
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_41371,cljs.core.assoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_41372,actual_type_41385,f_41379], null),canonical_f_41387], 0));

if(cljs.core.truth_(elem_41371.addEventListener)){
elem_41371.addEventListener(cljs.core.name(actual_type_41385),canonical_f_41387);
} else {
elem_41371.attachEvent(cljs.core.name(actual_type_41385),canonical_f_41387);
}


var G__41388 = seq__41269_41380;
var G__41389 = chunk__41271_41381;
var G__41390 = count__41272_41382;
var G__41391 = (i__41273_41383 + (1));
seq__41269_41380 = G__41388;
chunk__41271_41381 = G__41389;
count__41272_41382 = G__41390;
i__41273_41383 = G__41391;
continue;
} else {
var temp__5735__auto___41392 = cljs.core.seq(seq__41269_41380);
if(temp__5735__auto___41392){
var seq__41269_41393__$1 = temp__5735__auto___41392;
if(cljs.core.chunked_seq_QMARK_(seq__41269_41393__$1)){
var c__4609__auto___41394 = cljs.core.chunk_first(seq__41269_41393__$1);
var G__41395 = cljs.core.chunk_rest(seq__41269_41393__$1);
var G__41396 = c__4609__auto___41394;
var G__41397 = cljs.core.count(c__4609__auto___41394);
var G__41398 = (0);
seq__41269_41380 = G__41395;
chunk__41271_41381 = G__41396;
count__41272_41382 = G__41397;
i__41273_41383 = G__41398;
continue;
} else {
var vec__41339_41399 = cljs.core.first(seq__41269_41393__$1);
var actual_type_41400 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41339_41399,(0),null);
var factory_41401 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41339_41399,(1),null);
var canonical_f_41402 = (function (){var G__41343 = (factory_41401.cljs$core$IFn$_invoke$arity$1 ? factory_41401.cljs$core$IFn$_invoke$arity$1(f_41379) : factory_41401.call(null,f_41379));
var fexpr__41342 = (cljs.core.truth_(selector_41372)?cljs.core.partial.cljs$core$IFn$_invoke$arity$3(dommy.core.live_listener,elem_41371,selector_41372):cljs.core.identity);
return (fexpr__41342.cljs$core$IFn$_invoke$arity$1 ? fexpr__41342.cljs$core$IFn$_invoke$arity$1(G__41343) : fexpr__41342.call(null,G__41343));
})();
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_41371,cljs.core.assoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_41372,actual_type_41400,f_41379], null),canonical_f_41402], 0));

if(cljs.core.truth_(elem_41371.addEventListener)){
elem_41371.addEventListener(cljs.core.name(actual_type_41400),canonical_f_41402);
} else {
elem_41371.attachEvent(cljs.core.name(actual_type_41400),canonical_f_41402);
}


var G__41403 = cljs.core.next(seq__41269_41393__$1);
var G__41404 = null;
var G__41405 = (0);
var G__41406 = (0);
seq__41269_41380 = G__41403;
chunk__41271_41381 = G__41404;
count__41272_41382 = G__41405;
i__41273_41383 = G__41406;
continue;
}
} else {
}
}
break;
}

var G__41407 = seq__41259_41373;
var G__41408 = chunk__41266_41374;
var G__41409 = count__41267_41375;
var G__41410 = (i__41268_41376 + (1));
seq__41259_41373 = G__41407;
chunk__41266_41374 = G__41408;
count__41267_41375 = G__41409;
i__41268_41376 = G__41410;
continue;
} else {
var temp__5735__auto___41411 = cljs.core.seq(seq__41259_41373);
if(temp__5735__auto___41411){
var seq__41259_41412__$1 = temp__5735__auto___41411;
if(cljs.core.chunked_seq_QMARK_(seq__41259_41412__$1)){
var c__4609__auto___41413 = cljs.core.chunk_first(seq__41259_41412__$1);
var G__41414 = cljs.core.chunk_rest(seq__41259_41412__$1);
var G__41415 = c__4609__auto___41413;
var G__41416 = cljs.core.count(c__4609__auto___41413);
var G__41417 = (0);
seq__41259_41373 = G__41414;
chunk__41266_41374 = G__41415;
count__41267_41375 = G__41416;
i__41268_41376 = G__41417;
continue;
} else {
var vec__41344_41418 = cljs.core.first(seq__41259_41412__$1);
var orig_type_41419 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41344_41418,(0),null);
var f_41420 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41344_41418,(1),null);
var seq__41260_41421 = cljs.core.seq(cljs.core.get.cljs$core$IFn$_invoke$arity$3(dommy.core.special_listener_makers,orig_type_41419,cljs.core.PersistentArrayMap.createAsIfByAssoc([orig_type_41419,cljs.core.identity])));
var chunk__41262_41422 = null;
var count__41263_41423 = (0);
var i__41264_41424 = (0);
while(true){
if((i__41264_41424 < count__41263_41423)){
var vec__41357_41425 = chunk__41262_41422.cljs$core$IIndexed$_nth$arity$2(null,i__41264_41424);
var actual_type_41426 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41357_41425,(0),null);
var factory_41427 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41357_41425,(1),null);
var canonical_f_41428 = (function (){var G__41361 = (factory_41427.cljs$core$IFn$_invoke$arity$1 ? factory_41427.cljs$core$IFn$_invoke$arity$1(f_41420) : factory_41427.call(null,f_41420));
var fexpr__41360 = (cljs.core.truth_(selector_41372)?cljs.core.partial.cljs$core$IFn$_invoke$arity$3(dommy.core.live_listener,elem_41371,selector_41372):cljs.core.identity);
return (fexpr__41360.cljs$core$IFn$_invoke$arity$1 ? fexpr__41360.cljs$core$IFn$_invoke$arity$1(G__41361) : fexpr__41360.call(null,G__41361));
})();
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_41371,cljs.core.assoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_41372,actual_type_41426,f_41420], null),canonical_f_41428], 0));

if(cljs.core.truth_(elem_41371.addEventListener)){
elem_41371.addEventListener(cljs.core.name(actual_type_41426),canonical_f_41428);
} else {
elem_41371.attachEvent(cljs.core.name(actual_type_41426),canonical_f_41428);
}


var G__41429 = seq__41260_41421;
var G__41430 = chunk__41262_41422;
var G__41431 = count__41263_41423;
var G__41432 = (i__41264_41424 + (1));
seq__41260_41421 = G__41429;
chunk__41262_41422 = G__41430;
count__41263_41423 = G__41431;
i__41264_41424 = G__41432;
continue;
} else {
var temp__5735__auto___41433__$1 = cljs.core.seq(seq__41260_41421);
if(temp__5735__auto___41433__$1){
var seq__41260_41434__$1 = temp__5735__auto___41433__$1;
if(cljs.core.chunked_seq_QMARK_(seq__41260_41434__$1)){
var c__4609__auto___41435 = cljs.core.chunk_first(seq__41260_41434__$1);
var G__41436 = cljs.core.chunk_rest(seq__41260_41434__$1);
var G__41437 = c__4609__auto___41435;
var G__41438 = cljs.core.count(c__4609__auto___41435);
var G__41439 = (0);
seq__41260_41421 = G__41436;
chunk__41262_41422 = G__41437;
count__41263_41423 = G__41438;
i__41264_41424 = G__41439;
continue;
} else {
var vec__41362_41440 = cljs.core.first(seq__41260_41434__$1);
var actual_type_41441 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41362_41440,(0),null);
var factory_41442 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41362_41440,(1),null);
var canonical_f_41443 = (function (){var G__41366 = (factory_41442.cljs$core$IFn$_invoke$arity$1 ? factory_41442.cljs$core$IFn$_invoke$arity$1(f_41420) : factory_41442.call(null,f_41420));
var fexpr__41365 = (cljs.core.truth_(selector_41372)?cljs.core.partial.cljs$core$IFn$_invoke$arity$3(dommy.core.live_listener,elem_41371,selector_41372):cljs.core.identity);
return (fexpr__41365.cljs$core$IFn$_invoke$arity$1 ? fexpr__41365.cljs$core$IFn$_invoke$arity$1(G__41366) : fexpr__41365.call(null,G__41366));
})();
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_41371,cljs.core.assoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_41372,actual_type_41441,f_41420], null),canonical_f_41443], 0));

if(cljs.core.truth_(elem_41371.addEventListener)){
elem_41371.addEventListener(cljs.core.name(actual_type_41441),canonical_f_41443);
} else {
elem_41371.attachEvent(cljs.core.name(actual_type_41441),canonical_f_41443);
}


var G__41444 = cljs.core.next(seq__41260_41434__$1);
var G__41445 = null;
var G__41446 = (0);
var G__41447 = (0);
seq__41260_41421 = G__41444;
chunk__41262_41422 = G__41445;
count__41263_41423 = G__41446;
i__41264_41424 = G__41447;
continue;
}
} else {
}
}
break;
}

var G__41448 = cljs.core.next(seq__41259_41412__$1);
var G__41449 = null;
var G__41450 = (0);
var G__41451 = (0);
seq__41259_41373 = G__41448;
chunk__41266_41374 = G__41449;
count__41267_41375 = G__41450;
i__41268_41376 = G__41451;
continue;
}
} else {
}
}
break;
}

return elem_sel;
}));

(dommy.core.listen_BANG_.cljs$lang$maxFixedArity = (1));

/** @this {Function} */
(dommy.core.listen_BANG_.cljs$lang$applyTo = (function (seq41254){
var G__41255 = cljs.core.first(seq41254);
var seq41254__$1 = cljs.core.next(seq41254);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__41255,seq41254__$1);
}));

/**
 * Removes event listener for the element defined in `elem-sel`,
 * which is the same format as listen!.
 * 
 *   The following forms are allowed, and will remove all handlers
 *   that match the parameters passed in:
 * 
 *    (unlisten! [elem :.selector] :click event-listener)
 * 
 *    (unlisten! [elem :.selector]
 *      :click event-listener
 *      :mouseover other-event-listener)
 */
dommy.core.unlisten_BANG_ = (function dommy$core$unlisten_BANG_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___41533 = arguments.length;
var i__4790__auto___41534 = (0);
while(true){
if((i__4790__auto___41534 < len__4789__auto___41533)){
args__4795__auto__.push((arguments[i__4790__auto___41534]));

var G__41535 = (i__4790__auto___41534 + (1));
i__4790__auto___41534 = G__41535;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((1) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((1)),(0),null)):null);
return dommy.core.unlisten_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4796__auto__);
});

(dommy.core.unlisten_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem_sel,type_fs){
if(cljs.core.even_QMARK_(cljs.core.count(type_fs))){
} else {
throw (new Error("Assert failed: (even? (count type-fs))"));
}

var vec__41454_41536 = dommy.core.elem_and_selector(elem_sel);
var elem_41537 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41454_41536,(0),null);
var selector_41538 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41454_41536,(1),null);
var seq__41457_41539 = cljs.core.seq(cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),type_fs));
var chunk__41464_41540 = null;
var count__41465_41541 = (0);
var i__41466_41542 = (0);
while(true){
if((i__41466_41542 < count__41465_41541)){
var vec__41503_41543 = chunk__41464_41540.cljs$core$IIndexed$_nth$arity$2(null,i__41466_41542);
var orig_type_41544 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41503_41543,(0),null);
var f_41545 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41503_41543,(1),null);
var seq__41467_41546 = cljs.core.seq(cljs.core.get.cljs$core$IFn$_invoke$arity$3(dommy.core.special_listener_makers,orig_type_41544,cljs.core.PersistentArrayMap.createAsIfByAssoc([orig_type_41544,cljs.core.identity])));
var chunk__41469_41547 = null;
var count__41470_41548 = (0);
var i__41471_41549 = (0);
while(true){
if((i__41471_41549 < count__41470_41548)){
var vec__41512_41550 = chunk__41469_41547.cljs$core$IIndexed$_nth$arity$2(null,i__41471_41549);
var actual_type_41551 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41512_41550,(0),null);
var __41552 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41512_41550,(1),null);
var keys_41553 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_41538,actual_type_41551,f_41545], null);
var canonical_f_41554 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(dommy.core.event_listeners(elem_41537),keys_41553);
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_41537,dommy.utils.dissoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([keys_41553], 0));

if(cljs.core.truth_(elem_41537.removeEventListener)){
elem_41537.removeEventListener(cljs.core.name(actual_type_41551),canonical_f_41554);
} else {
elem_41537.detachEvent(cljs.core.name(actual_type_41551),canonical_f_41554);
}


var G__41555 = seq__41467_41546;
var G__41556 = chunk__41469_41547;
var G__41557 = count__41470_41548;
var G__41558 = (i__41471_41549 + (1));
seq__41467_41546 = G__41555;
chunk__41469_41547 = G__41556;
count__41470_41548 = G__41557;
i__41471_41549 = G__41558;
continue;
} else {
var temp__5735__auto___41559 = cljs.core.seq(seq__41467_41546);
if(temp__5735__auto___41559){
var seq__41467_41560__$1 = temp__5735__auto___41559;
if(cljs.core.chunked_seq_QMARK_(seq__41467_41560__$1)){
var c__4609__auto___41561 = cljs.core.chunk_first(seq__41467_41560__$1);
var G__41562 = cljs.core.chunk_rest(seq__41467_41560__$1);
var G__41563 = c__4609__auto___41561;
var G__41564 = cljs.core.count(c__4609__auto___41561);
var G__41565 = (0);
seq__41467_41546 = G__41562;
chunk__41469_41547 = G__41563;
count__41470_41548 = G__41564;
i__41471_41549 = G__41565;
continue;
} else {
var vec__41515_41566 = cljs.core.first(seq__41467_41560__$1);
var actual_type_41567 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41515_41566,(0),null);
var __41568 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41515_41566,(1),null);
var keys_41569 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_41538,actual_type_41567,f_41545], null);
var canonical_f_41570 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(dommy.core.event_listeners(elem_41537),keys_41569);
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_41537,dommy.utils.dissoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([keys_41569], 0));

if(cljs.core.truth_(elem_41537.removeEventListener)){
elem_41537.removeEventListener(cljs.core.name(actual_type_41567),canonical_f_41570);
} else {
elem_41537.detachEvent(cljs.core.name(actual_type_41567),canonical_f_41570);
}


var G__41571 = cljs.core.next(seq__41467_41560__$1);
var G__41572 = null;
var G__41573 = (0);
var G__41574 = (0);
seq__41467_41546 = G__41571;
chunk__41469_41547 = G__41572;
count__41470_41548 = G__41573;
i__41471_41549 = G__41574;
continue;
}
} else {
}
}
break;
}

var G__41575 = seq__41457_41539;
var G__41576 = chunk__41464_41540;
var G__41577 = count__41465_41541;
var G__41578 = (i__41466_41542 + (1));
seq__41457_41539 = G__41575;
chunk__41464_41540 = G__41576;
count__41465_41541 = G__41577;
i__41466_41542 = G__41578;
continue;
} else {
var temp__5735__auto___41579 = cljs.core.seq(seq__41457_41539);
if(temp__5735__auto___41579){
var seq__41457_41580__$1 = temp__5735__auto___41579;
if(cljs.core.chunked_seq_QMARK_(seq__41457_41580__$1)){
var c__4609__auto___41581 = cljs.core.chunk_first(seq__41457_41580__$1);
var G__41582 = cljs.core.chunk_rest(seq__41457_41580__$1);
var G__41583 = c__4609__auto___41581;
var G__41584 = cljs.core.count(c__4609__auto___41581);
var G__41585 = (0);
seq__41457_41539 = G__41582;
chunk__41464_41540 = G__41583;
count__41465_41541 = G__41584;
i__41466_41542 = G__41585;
continue;
} else {
var vec__41518_41586 = cljs.core.first(seq__41457_41580__$1);
var orig_type_41587 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41518_41586,(0),null);
var f_41588 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41518_41586,(1),null);
var seq__41458_41589 = cljs.core.seq(cljs.core.get.cljs$core$IFn$_invoke$arity$3(dommy.core.special_listener_makers,orig_type_41587,cljs.core.PersistentArrayMap.createAsIfByAssoc([orig_type_41587,cljs.core.identity])));
var chunk__41460_41590 = null;
var count__41461_41591 = (0);
var i__41462_41592 = (0);
while(true){
if((i__41462_41592 < count__41461_41591)){
var vec__41527_41593 = chunk__41460_41590.cljs$core$IIndexed$_nth$arity$2(null,i__41462_41592);
var actual_type_41594 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41527_41593,(0),null);
var __41595 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41527_41593,(1),null);
var keys_41596 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_41538,actual_type_41594,f_41588], null);
var canonical_f_41597 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(dommy.core.event_listeners(elem_41537),keys_41596);
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_41537,dommy.utils.dissoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([keys_41596], 0));

if(cljs.core.truth_(elem_41537.removeEventListener)){
elem_41537.removeEventListener(cljs.core.name(actual_type_41594),canonical_f_41597);
} else {
elem_41537.detachEvent(cljs.core.name(actual_type_41594),canonical_f_41597);
}


var G__41598 = seq__41458_41589;
var G__41599 = chunk__41460_41590;
var G__41600 = count__41461_41591;
var G__41601 = (i__41462_41592 + (1));
seq__41458_41589 = G__41598;
chunk__41460_41590 = G__41599;
count__41461_41591 = G__41600;
i__41462_41592 = G__41601;
continue;
} else {
var temp__5735__auto___41602__$1 = cljs.core.seq(seq__41458_41589);
if(temp__5735__auto___41602__$1){
var seq__41458_41603__$1 = temp__5735__auto___41602__$1;
if(cljs.core.chunked_seq_QMARK_(seq__41458_41603__$1)){
var c__4609__auto___41604 = cljs.core.chunk_first(seq__41458_41603__$1);
var G__41605 = cljs.core.chunk_rest(seq__41458_41603__$1);
var G__41606 = c__4609__auto___41604;
var G__41607 = cljs.core.count(c__4609__auto___41604);
var G__41608 = (0);
seq__41458_41589 = G__41605;
chunk__41460_41590 = G__41606;
count__41461_41591 = G__41607;
i__41462_41592 = G__41608;
continue;
} else {
var vec__41530_41609 = cljs.core.first(seq__41458_41603__$1);
var actual_type_41610 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41530_41609,(0),null);
var __41611 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41530_41609,(1),null);
var keys_41612 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_41538,actual_type_41610,f_41588], null);
var canonical_f_41613 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(dommy.core.event_listeners(elem_41537),keys_41612);
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_41537,dommy.utils.dissoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([keys_41612], 0));

if(cljs.core.truth_(elem_41537.removeEventListener)){
elem_41537.removeEventListener(cljs.core.name(actual_type_41610),canonical_f_41613);
} else {
elem_41537.detachEvent(cljs.core.name(actual_type_41610),canonical_f_41613);
}


var G__41614 = cljs.core.next(seq__41458_41603__$1);
var G__41615 = null;
var G__41616 = (0);
var G__41617 = (0);
seq__41458_41589 = G__41614;
chunk__41460_41590 = G__41615;
count__41461_41591 = G__41616;
i__41462_41592 = G__41617;
continue;
}
} else {
}
}
break;
}

var G__41618 = cljs.core.next(seq__41457_41580__$1);
var G__41619 = null;
var G__41620 = (0);
var G__41621 = (0);
seq__41457_41539 = G__41618;
chunk__41464_41540 = G__41619;
count__41465_41541 = G__41620;
i__41466_41542 = G__41621;
continue;
}
} else {
}
}
break;
}

return elem_sel;
}));

(dommy.core.unlisten_BANG_.cljs$lang$maxFixedArity = (1));

/** @this {Function} */
(dommy.core.unlisten_BANG_.cljs$lang$applyTo = (function (seq41452){
var G__41453 = cljs.core.first(seq41452);
var seq41452__$1 = cljs.core.next(seq41452);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__41453,seq41452__$1);
}));

/**
 * Behaves like `listen!`, but removes the listener after the first event occurs.
 */
dommy.core.listen_once_BANG_ = (function dommy$core$listen_once_BANG_(var_args){
var args__4795__auto__ = [];
var len__4789__auto___41643 = arguments.length;
var i__4790__auto___41644 = (0);
while(true){
if((i__4790__auto___41644 < len__4789__auto___41643)){
args__4795__auto__.push((arguments[i__4790__auto___41644]));

var G__41645 = (i__4790__auto___41644 + (1));
i__4790__auto___41644 = G__41645;
continue;
} else {
}
break;
}

var argseq__4796__auto__ = ((((1) < args__4795__auto__.length))?(new cljs.core.IndexedSeq(args__4795__auto__.slice((1)),(0),null)):null);
return dommy.core.listen_once_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4796__auto__);
});

(dommy.core.listen_once_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem_sel,type_fs){
if(cljs.core.even_QMARK_(cljs.core.count(type_fs))){
} else {
throw (new Error("Assert failed: (even? (count type-fs))"));
}

var vec__41624_41646 = dommy.core.elem_and_selector(elem_sel);
var elem_41647 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41624_41646,(0),null);
var selector_41648 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41624_41646,(1),null);
var seq__41627_41649 = cljs.core.seq(cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),type_fs));
var chunk__41628_41650 = null;
var count__41629_41651 = (0);
var i__41630_41652 = (0);
while(true){
if((i__41630_41652 < count__41629_41651)){
var vec__41637_41653 = chunk__41628_41650.cljs$core$IIndexed$_nth$arity$2(null,i__41630_41652);
var type_41654 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41637_41653,(0),null);
var f_41655 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41637_41653,(1),null);
dommy.core.listen_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_sel,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([type_41654,((function (seq__41627_41649,chunk__41628_41650,count__41629_41651,i__41630_41652,vec__41637_41653,type_41654,f_41655,vec__41624_41646,elem_41647,selector_41648){
return (function dommy$core$this_fn(e){
dommy.core.unlisten_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_sel,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([type_41654,dommy$core$this_fn], 0));

return (f_41655.cljs$core$IFn$_invoke$arity$1 ? f_41655.cljs$core$IFn$_invoke$arity$1(e) : f_41655.call(null,e));
});})(seq__41627_41649,chunk__41628_41650,count__41629_41651,i__41630_41652,vec__41637_41653,type_41654,f_41655,vec__41624_41646,elem_41647,selector_41648))
], 0));


var G__41656 = seq__41627_41649;
var G__41657 = chunk__41628_41650;
var G__41658 = count__41629_41651;
var G__41659 = (i__41630_41652 + (1));
seq__41627_41649 = G__41656;
chunk__41628_41650 = G__41657;
count__41629_41651 = G__41658;
i__41630_41652 = G__41659;
continue;
} else {
var temp__5735__auto___41660 = cljs.core.seq(seq__41627_41649);
if(temp__5735__auto___41660){
var seq__41627_41661__$1 = temp__5735__auto___41660;
if(cljs.core.chunked_seq_QMARK_(seq__41627_41661__$1)){
var c__4609__auto___41662 = cljs.core.chunk_first(seq__41627_41661__$1);
var G__41663 = cljs.core.chunk_rest(seq__41627_41661__$1);
var G__41664 = c__4609__auto___41662;
var G__41665 = cljs.core.count(c__4609__auto___41662);
var G__41666 = (0);
seq__41627_41649 = G__41663;
chunk__41628_41650 = G__41664;
count__41629_41651 = G__41665;
i__41630_41652 = G__41666;
continue;
} else {
var vec__41640_41667 = cljs.core.first(seq__41627_41661__$1);
var type_41668 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41640_41667,(0),null);
var f_41669 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41640_41667,(1),null);
dommy.core.listen_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_sel,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([type_41668,((function (seq__41627_41649,chunk__41628_41650,count__41629_41651,i__41630_41652,vec__41640_41667,type_41668,f_41669,seq__41627_41661__$1,temp__5735__auto___41660,vec__41624_41646,elem_41647,selector_41648){
return (function dommy$core$this_fn(e){
dommy.core.unlisten_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_sel,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([type_41668,dommy$core$this_fn], 0));

return (f_41669.cljs$core$IFn$_invoke$arity$1 ? f_41669.cljs$core$IFn$_invoke$arity$1(e) : f_41669.call(null,e));
});})(seq__41627_41649,chunk__41628_41650,count__41629_41651,i__41630_41652,vec__41640_41667,type_41668,f_41669,seq__41627_41661__$1,temp__5735__auto___41660,vec__41624_41646,elem_41647,selector_41648))
], 0));


var G__41670 = cljs.core.next(seq__41627_41661__$1);
var G__41671 = null;
var G__41672 = (0);
var G__41673 = (0);
seq__41627_41649 = G__41670;
chunk__41628_41650 = G__41671;
count__41629_41651 = G__41672;
i__41630_41652 = G__41673;
continue;
}
} else {
}
}
break;
}

return elem_sel;
}));

(dommy.core.listen_once_BANG_.cljs$lang$maxFixedArity = (1));

/** @this {Function} */
(dommy.core.listen_once_BANG_.cljs$lang$applyTo = (function (seq41622){
var G__41623 = cljs.core.first(seq41622);
var seq41622__$1 = cljs.core.next(seq41622);
var self__4776__auto__ = this;
return self__4776__auto__.cljs$core$IFn$_invoke$arity$variadic(G__41623,seq41622__$1);
}));

