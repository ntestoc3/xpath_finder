// Compiled by ClojureScript 1.10.597 {:static-fns true, :optimize-constants true}
goog.provide('chromex_sample.content_script');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex_sample.content_script.core');
if((typeof chromex_sample !== 'undefined') && (typeof chromex_sample.content_script !== 'undefined') && (typeof chromex_sample.content_script.runonce_1364499943 !== 'undefined')){
} else {
chromex_sample.content_script.runonce_1364499943 = new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$value,chromex_sample.content_script.core.init_BANG_(),cljs.core.cst$kw$code,"(do (core/init!))"], null);
}
