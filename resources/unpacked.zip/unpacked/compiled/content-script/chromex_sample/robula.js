// Compiled by ClojureScript 1.10.597 {:static-fns true, :optimize-constants true}
goog.provide('chromex_sample.robula');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('oops.core');
goog.require('clojure.string');
goog.require('goog.string');
goog.require('goog.string.format');
goog.require('clojure.set');
goog.require('dommy.core');
chromex_sample.robula.xpath_length = cljs.core.count;
chromex_sample.robula.xpath_head = cljs.core.first;
chromex_sample.robula.xpath_head_has_predicates_QMARK_ = (function chromex_sample$robula$xpath_head_has_predicates_QMARK_(xpath){
return clojure.string.includes_QMARK_((chromex_sample.robula.xpath_head.cljs$core$IFn$_invoke$arity$1 ? chromex_sample.robula.xpath_head.cljs$core$IFn$_invoke$arity$1(xpath) : chromex_sample.robula.xpath_head.call(null,xpath)),"[");
});
chromex_sample.robula.xpath_head_has_position_QMARK_ = (function chromex_sample$robula$xpath_head_has_position_QMARK_(xpath){
var head = (chromex_sample.robula.xpath_head.cljs$core$IFn$_invoke$arity$1 ? chromex_sample.robula.xpath_head.cljs$core$IFn$_invoke$arity$1(xpath) : chromex_sample.robula.xpath_head.call(null,xpath));
var or__4185__auto__ = clojure.string.includes_QMARK_(head,"position()");
if(or__4185__auto__){
return or__4185__auto__;
} else {
var or__4185__auto____$1 = clojure.string.includes_QMARK_(head,"last");
if(or__4185__auto____$1){
return or__4185__auto____$1;
} else {
return cljs.core.re_find(/\[[0-9]+\]/,head);
}
}
});
chromex_sample.robula.xpath_head_has_text_QMARK_ = (function chromex_sample$robula$xpath_head_has_text_QMARK_(xpath){
return clojure.string.includes_QMARK_((chromex_sample.robula.xpath_head.cljs$core$IFn$_invoke$arity$1 ? chromex_sample.robula.xpath_head.cljs$core$IFn$_invoke$arity$1(xpath) : chromex_sample.robula.xpath_head.call(null,xpath)),"text()");
});
chromex_sample.robula.xpath_head_with_all_QMARK_ = (function chromex_sample$robula$xpath_head_with_all_QMARK_(xpath){
return clojure.string.starts_with_QMARK_((chromex_sample.robula.xpath_head.cljs$core$IFn$_invoke$arity$1 ? chromex_sample.robula.xpath_head.cljs$core$IFn$_invoke$arity$1(xpath) : chromex_sample.robula.xpath_head.call(null,xpath)),"*");
});
chromex_sample.robula.xpath_add_predicate_to_head = (function chromex_sample$robula$xpath_add_predicate_to_head(xpath,predicate){
var new_head = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.first(xpath)),cljs.core.str.cljs$core$IFn$_invoke$arity$1(predicate)].join('');
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentVector.EMPTY,xpath),(0),new_head);
});
chromex_sample.robula.xpath_replace_head_all = (function chromex_sample$robula$xpath_replace_head_all(xpath,head_tag){
var new_head = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(head_tag),cljs.core.subs.cljs$core$IFn$_invoke$arity$2(cljs.core.first(xpath),(1))].join('');
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentVector.EMPTY,xpath),(0),new_head);
});
chromex_sample.robula.xpath_add_head_all = (function chromex_sample$robula$xpath_add_head_all(xpath){
return cljs.core.cons("*",xpath);
});
chromex_sample.robula.xpath_empty = cljs.core.PersistentVector.EMPTY;
chromex_sample.robula.xpath_all = new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, ["*"], null);
chromex_sample.robula.xpath__GT_str = (function chromex_sample$robula$xpath__GT_str(xpath){
return ["//",clojure.string.join.cljs$core$IFn$_invoke$arity$2("/",xpath)].join('');
});
chromex_sample.robula.get_previous_element_siblings_base = (function chromex_sample$robula$get_previous_element_siblings_base(element){
return cljs.core.take_while.cljs$core$IFn$_invoke$arity$2(cljs.core.identity,cljs.core.iterate((function (p1__80460_SHARP_){
var target_obj_80461 = p1__80460_SHARP_;
var next_obj_80462 = (target_obj_80461["previousElementSibling"]);
return next_obj_80462;
}),element));
});
chromex_sample.robula.get_previous_element_siblings = cljs.core.memoize(chromex_sample.robula.get_previous_element_siblings_base);
/**
 * 获取所有父级元素，包括自身
 */
chromex_sample.robula.get_all_ancestor_base = (function chromex_sample$robula$get_all_ancestor_base(element){
return cljs.core.take_while.cljs$core$IFn$_invoke$arity$2(cljs.core.identity,cljs.core.iterate((function (p1__80463_SHARP_){
var target_obj_80464 = p1__80463_SHARP_;
var next_obj_80465 = (target_obj_80464["parentElement"]);
return next_obj_80465;
}),element));
});
chromex_sample.robula.get_all_ancestor = cljs.core.memoize(chromex_sample.robula.get_all_ancestor_base);
chromex_sample.robula.get_ancestor_count = (function chromex_sample$robula$get_ancestor_count(element){
return cljs.core.count((chromex_sample.robula.get_all_ancestor.cljs$core$IFn$_invoke$arity$1 ? chromex_sample.robula.get_all_ancestor.cljs$core$IFn$_invoke$arity$1(element) : chromex_sample.robula.get_all_ancestor.call(null,element)));
});
chromex_sample.robula.get_ancestor_at = (function chromex_sample$robula$get_ancestor_at(element,index){
return cljs.core.nth.cljs$core$IFn$_invoke$arity$2((chromex_sample.robula.get_all_ancestor.cljs$core$IFn$_invoke$arity$1 ? chromex_sample.robula.get_all_ancestor.cljs$core$IFn$_invoke$arity$1(element) : chromex_sample.robula.get_all_ancestor.call(null,element)),index);
});
/**
 * 获取元素的所有属性
 */
chromex_sample.robula.get_attributes = (function chromex_sample$robula$get_attributes(element){
var get_attr_kv = (function (attr){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(function (){var target_obj_80467 = attr;
var next_obj_80468 = (target_obj_80467["name"]);
return next_obj_80468;
})(),(function (){var target_obj_80469 = attr;
var next_obj_80470 = (target_obj_80469["value"]);
return next_obj_80470;
})()], null);
});
var attrs = (function (){var target_obj_80471 = element;
var next_obj_80472 = (target_obj_80471["attributes"]);
return next_obj_80472;
})();
return cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p1__80466_SHARP_){
return get_attr_kv((function (){var target_obj_80473 = attrs;
return oops.core.get_selector_dynamically(target_obj_80473,cljs.core.str.cljs$core$IFn$_invoke$arity$1(p1__80466_SHARP_));
})());
}),cljs.core.range.cljs$core$IFn$_invoke$arity$1((function (){var target_obj_80474 = attrs;
var next_obj_80475 = (target_obj_80474["length"]);
return next_obj_80475;
})())));
});
chromex_sample.robula.tag_name = (function chromex_sample$robula$tag_name(element){
return clojure.string.lower_case((function (){var target_obj_80476 = element;
var next_obj_80477 = (target_obj_80476["tagName"]);
return next_obj_80477;
})());
});
chromex_sample.robula.attribute_priorization_list = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 5, ["class",null,"name",null,"value",null,"alt",null,"title",null], null), null);
chromex_sample.robula.attribute_black_list = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 10, ["width",null,"height",null,"src",null,"href",null,"style",null,"onclick",null,"onload",null,"maxlength",null,"size",null,"tabindex",null], null), null);
/**
 * 获取xpath头部的祖先元素
 */
chromex_sample.robula.get_xpath_head_ancestor = (function chromex_sample$robula$get_xpath_head_ancestor(xpath,element){
return chromex_sample.robula.get_ancestor_at(element,((chromex_sample.robula.xpath_length.cljs$core$IFn$_invoke$arity$1 ? chromex_sample.robula.xpath_length.cljs$core$IFn$_invoke$arity$1(xpath) : chromex_sample.robula.xpath_length.call(null,xpath)) - (1)));
});
/**
 * 转换xpath的*表示
 */
chromex_sample.robula.transf_convert_star = (function chromex_sample$robula$transf_convert_star(xpath,element){
var ancestor = chromex_sample.robula.get_xpath_head_ancestor(xpath,element);
if(chromex_sample.robula.xpath_head_with_all_QMARK_(xpath)){
return (new cljs.core.PersistentVector(null,1,(5),cljs.core.PersistentVector.EMPTY_NODE,[chromex_sample.robula.xpath_replace_head_all(xpath,chromex_sample.robula.tag_name(ancestor))],null));
} else {
return null;
}
});
chromex_sample.robula.max_text_length = (30);
chromex_sample.robula.xpath_trans = (function chromex_sample$robula$xpath_trans(k,v){
if(clojure.string.includes_QMARK_(v,"'")){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [goog.string.format("translate(%s,\"'\",\" \")",k),clojure.string.replace(v,"'"," ")], null);
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [k,v], null);
}
});
chromex_sample.robula.xpath_contains_trans = (function chromex_sample$robula$xpath_contains_trans(k,v){
return cljs.core.apply.cljs$core$IFn$_invoke$arity$3(goog.string.format,"contains(%s,'%s')",chromex_sample.robula.xpath_trans(k,v));
});
/**
 * 构造text表达式
 */
chromex_sample.robula.make_xpath_text_exp = (function chromex_sample$robula$make_xpath_text_exp(s){
var text_fn_name = (((cljs.core.count(s) > chromex_sample.robula.max_text_length))?goog.string.format("substring(text(),1,%d)",chromex_sample.robula.max_text_length):"text()");
var target_s = cljs.core.subs.cljs$core$IFn$_invoke$arity$3(s,(0),chromex_sample.robula.max_text_length);
var G__80478 = "[%s]";
var G__80479 = chromex_sample.robula.xpath_contains_trans(text_fn_name,target_s);
return goog.string.format(G__80478,G__80479);
});
chromex_sample.robula.make_xpath_attr_predicate = (function chromex_sample$robula$make_xpath_attr_predicate(attr_key,value){
var k = ["@",cljs.core.str.cljs$core$IFn$_invoke$arity$1(attr_key)].join('');
if((cljs.core.count(value) > chromex_sample.robula.max_text_length)){
return chromex_sample.robula.xpath_contains_trans(k,cljs.core.subs.cljs$core$IFn$_invoke$arity$3(value,(0),chromex_sample.robula.max_text_length));
} else {
return cljs.core.apply.cljs$core$IFn$_invoke$arity$3(goog.string.format,"%s='%s'",chromex_sample.robula.xpath_trans(k,value));
}
});
chromex_sample.robula.make_xpath_attr_exp = (function chromex_sample$robula$make_xpath_attr_exp(attr_key,value){
var G__80480 = "[%s]";
var G__80481 = chromex_sample.robula.make_xpath_attr_predicate(attr_key,value);
return goog.string.format(G__80480,G__80481);
});
/**
 * 添加id属性
 */
chromex_sample.robula.transf_add_id = (function chromex_sample$robula$transf_add_id(xpath,element){
var ancestor = chromex_sample.robula.get_xpath_head_ancestor(xpath,element);
var ancestor_id = (function (){var target_obj_80482 = ancestor;
var next_obj_80483 = (target_obj_80482["id"]);
return next_obj_80483;
})();
if(((cljs.core.seq(ancestor_id)) && ((!(chromex_sample.robula.xpath_head_has_predicates_QMARK_(xpath)))))){
return (new cljs.core.PersistentVector(null,1,(5),cljs.core.PersistentVector.EMPTY_NODE,[chromex_sample.robula.xpath_add_predicate_to_head(xpath,chromex_sample.robula.make_xpath_attr_exp("id",ancestor_id))],null));
} else {
return null;
}
});
/**
 * 添加text属性
 */
chromex_sample.robula.transf_add_text = (function chromex_sample$robula$transf_add_text(xpath,element){
var ancestor = chromex_sample.robula.get_xpath_head_ancestor(xpath,element);
var ancestor_text = (function (){var target_obj_80484 = ancestor;
var next_obj_80485 = (target_obj_80484["textContent"]);
return next_obj_80485;
})();
if(((cljs.core.seq(ancestor_text)) && (cljs.core.not(chromex_sample.robula.xpath_head_has_position_QMARK_(xpath))) && ((!(chromex_sample.robula.xpath_head_has_text_QMARK_(xpath)))))){
return (new cljs.core.PersistentVector(null,1,(5),cljs.core.PersistentVector.EMPTY_NODE,[chromex_sample.robula.xpath_add_predicate_to_head(xpath,chromex_sample.robula.make_xpath_text_exp(ancestor_text))],null));
} else {
return null;
}
});
/**
 * 添加其他属性
 */
chromex_sample.robula.transf_add_attribute = (function chromex_sample$robula$transf_add_attribute(xpath,element){
var ancestor = chromex_sample.robula.get_xpath_head_ancestor(xpath,element);
var ancestor_attrs = chromex_sample.robula.get_attributes(ancestor);
if((!(chromex_sample.robula.xpath_head_has_predicates_QMARK_(xpath)))){
var ancestor_priority_attrs = cljs.core.select_keys(ancestor_attrs,chromex_sample.robula.attribute_priorization_list);
var ancestor_other_attrs = cljs.core.select_keys(ancestor_attrs,clojure.set.difference.cljs$core$IFn$_invoke$arity$variadic(cljs.core.set(cljs.core.keys(ancestor_attrs)),chromex_sample.robula.attribute_priorization_list,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([chromex_sample.robula.attribute_black_list], 0)));
return cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p__80486){
var vec__80487 = p__80486;
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__80487,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__80487,(1),null);
return chromex_sample.robula.xpath_add_predicate_to_head(xpath,chromex_sample.robula.make_xpath_attr_exp(k,v));
}),cljs.core.concat.cljs$core$IFn$_invoke$arity$2(ancestor_priority_attrs,ancestor_other_attrs));
} else {
return null;
}
});
chromex_sample.robula.powerset = (function chromex_sample$robula$powerset(coll){
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3((function (a,x){
return cljs.core.into.cljs$core$IFn$_invoke$arity$3(a,cljs.core.map.cljs$core$IFn$_invoke$arity$1((function (p1__80490_SHARP_){
return cljs.core.conj.cljs$core$IFn$_invoke$arity$2(p1__80490_SHARP_,x);
})),a);
}),cljs.core.PersistentHashSet.createAsIfByAssoc([cljs.core.PersistentHashSet.EMPTY]),coll);
});
/**
 * 优先属性比较
 */
chromex_sample.robula.priorization_attr_compare = (function chromex_sample$robula$priorization_attr_compare(priorization_set,attr1,attr2){
if(cljs.core.truth_((function (){var G__80491 = cljs.core.first(attr1);
return (priorization_set.cljs$core$IFn$_invoke$arity$1 ? priorization_set.cljs$core$IFn$_invoke$arity$1(G__80491) : priorization_set.call(null,G__80491));
})())){
return (-1);
} else {
if(cljs.core.truth_((function (){var G__80492 = cljs.core.first(attr2);
return (priorization_set.cljs$core$IFn$_invoke$arity$1 ? priorization_set.cljs$core$IFn$_invoke$arity$1(G__80492) : priorization_set.call(null,G__80492));
})())){
return (1);
} else {
return (0);

}
}
});
/**
 * 添加其他属性集合(幂集)
 */
chromex_sample.robula.transf_add_attribute_set = (function chromex_sample$robula$transf_add_attribute_set(xpath,element){
var ancestor_attrs = chromex_sample.robula.get_attributes(chromex_sample.robula.get_xpath_head_ancestor(xpath,element));
if((!(chromex_sample.robula.xpath_head_has_predicates_QMARK_(xpath)))){
var ancestor_useful_attrs = cljs.core.select_keys(ancestor_attrs,clojure.set.difference.cljs$core$IFn$_invoke$arity$2(cljs.core.set(cljs.core.keys(ancestor_attrs)),chromex_sample.robula.attribute_black_list));
var attr_power_set = cljs.core.filter.cljs$core$IFn$_invoke$arity$2((function (p1__80493_SHARP_){
return (cljs.core.count(p1__80493_SHARP_) > (1));
}),chromex_sample.robula.powerset(ancestor_useful_attrs));
var priorization_set_val_cmp = cljs.core.partial.cljs$core$IFn$_invoke$arity$2(chromex_sample.robula.priorization_attr_compare,cljs.core.conj.cljs$core$IFn$_invoke$arity$2(chromex_sample.robula.attribute_priorization_list,"id"));
var sorted_attr_set = cljs.core.sort.cljs$core$IFn$_invoke$arity$2((function (attr_set1,attr_set2){
var l1 = cljs.core.count(attr_set1);
var l2 = cljs.core.count(attr_set2);
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(l1,l2)){
return cljs.core.apply.cljs$core$IFn$_invoke$arity$2(priorization_set_val_cmp,cljs.core.first(cljs.core.drop_while.cljs$core$IFn$_invoke$arity$2((function (p1__80495_SHARP_){
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.first(p1__80495_SHARP_),cljs.core.second(p1__80495_SHARP_));
}),cljs.core.zipmap(attr_set1,attr_set2))));
} else {
return cljs.core.compare(l1,l2);
}
}),cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p1__80494_SHARP_){
return cljs.core.sort.cljs$core$IFn$_invoke$arity$2(priorization_set_val_cmp,p1__80494_SHARP_);
}),attr_power_set));
var gen_attr_set_xpath = (function (attrs){
return chromex_sample.robula.xpath_add_predicate_to_head(xpath,(function (){var G__80496 = "[%s]";
var G__80497 = clojure.string.join.cljs$core$IFn$_invoke$arity$2(" and ",cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p__80498){
var vec__80499 = p__80498;
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__80499,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__80499,(1),null);
return chromex_sample.robula.make_xpath_attr_predicate(k,v);
}),attrs));
return goog.string.format(G__80496,G__80497);
})());
});
return cljs.core.map.cljs$core$IFn$_invoke$arity$2(gen_attr_set_xpath,sorted_attr_set);
} else {
return null;
}
});
/**
 * 添加位置索引
 */
chromex_sample.robula.transf_add_position = (function chromex_sample$robula$transf_add_position(xpath,element){
var ancestor = chromex_sample.robula.get_xpath_head_ancestor(xpath,element);
var prev_siblings = (chromex_sample.robula.get_previous_element_siblings.cljs$core$IFn$_invoke$arity$1 ? chromex_sample.robula.get_previous_element_siblings.cljs$core$IFn$_invoke$arity$1(ancestor) : chromex_sample.robula.get_previous_element_siblings.call(null,ancestor));
if(cljs.core.not(chromex_sample.robula.xpath_head_has_position_QMARK_(xpath))){
var idx = ((chromex_sample.robula.xpath_head_with_all_QMARK_(xpath))?cljs.core.count(prev_siblings):cljs.core.count(cljs.core.filter.cljs$core$IFn$_invoke$arity$2((function (p1__80502_SHARP_){
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(chromex_sample.robula.tag_name(ancestor),p1__80502_SHARP_);
}),cljs.core.map.cljs$core$IFn$_invoke$arity$2(chromex_sample.robula.tag_name,prev_siblings))));
if((idx > (0))){
return (new cljs.core.PersistentVector(null,1,(5),cljs.core.PersistentVector.EMPTY_NODE,[chromex_sample.robula.xpath_add_predicate_to_head(xpath,["[",cljs.core.str.cljs$core$IFn$_invoke$arity$1(idx),"]"].join(''))],null));
} else {
return null;
}
} else {
return null;
}
});
/**
 * 添加深度
 */
chromex_sample.robula.transf_add_level = (function chromex_sample$robula$transf_add_level(xpath,element){
if(((chromex_sample.robula.xpath_length.cljs$core$IFn$_invoke$arity$1 ? chromex_sample.robula.xpath_length.cljs$core$IFn$_invoke$arity$1(xpath) : chromex_sample.robula.xpath_length.call(null,xpath)) < (chromex_sample.robula.get_ancestor_count(element) - (1)))){
return (new cljs.core.PersistentVector(null,1,(5),cljs.core.PersistentVector.EMPTY_NODE,[chromex_sample.robula.xpath_add_head_all(xpath)],null));
} else {
return null;
}
});
chromex_sample.robula.locate_count = (function chromex_sample$robula$locate_count(document,xpath){
var target_obj_80503 = document.evaluate(xpath,document,null,(function (){var target_obj_80505 = XPathResult;
var next_obj_80506 = (target_obj_80505["ORDERED_NODE_SNAPSHOT_TYPE"]);
return next_obj_80506;
})(),null);
var next_obj_80504 = (target_obj_80503["snapshotLength"]);
return next_obj_80504;
});
/**
 * 唯一定位？
 */
chromex_sample.robula.unique_locate_QMARK_ = (function chromex_sample$robula$unique_locate_QMARK_(xpath,element,document){
var node_snap = document.evaluate(xpath,document,null,(function (){var target_obj_80507 = XPathResult;
var next_obj_80508 = (target_obj_80507["ORDERED_NODE_SNAPSHOT_TYPE"]);
return next_obj_80508;
})(),null);
return ((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((1),(function (){var target_obj_80511 = node_snap;
var next_obj_80512 = (target_obj_80511["snapshotLength"]);
return next_obj_80512;
})())) && ((element === node_snap.snapshotItem((0)))));
});
chromex_sample.robula.get_element_by_xpath = (function chromex_sample$robula$get_element_by_xpath(document,xpath){
var target_obj_80513 = document.evaluate(xpath,document,null,(function (){var target_obj_80515 = XPathResult;
var next_obj_80516 = (target_obj_80515["FIRST_ORDERED_NODE_TYPE"]);
return next_obj_80516;
})(),null);
var next_obj_80514 = (target_obj_80513["singleNodeValue"]);
return next_obj_80514;
});
chromex_sample.robula.$x = cljs.core.partial.cljs$core$IFn$_invoke$arity$2(chromex_sample.robula.get_element_by_xpath,document);
chromex_sample.robula.unique_xpath_QMARK_ = (function chromex_sample$robula$unique_xpath_QMARK_(path,doc,element){
return chromex_sample.robula.unique_locate_QMARK_(chromex_sample.robula.xpath__GT_str(path),element,doc);
});
chromex_sample.robula.get_xpath_in_list = (function chromex_sample$robula$get_xpath_in_list(xpath_list,doc,element){
while(true){
if(cljs.core.seq(xpath_list)){
var xpath = cljs.core.first(xpath_list);
var new_xpath_list = cljs.core.concat.cljs$core$IFn$_invoke$arity$variadic(chromex_sample.robula.transf_convert_star(xpath,element),chromex_sample.robula.transf_add_id(xpath,element),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([chromex_sample.robula.transf_add_text(xpath,element),chromex_sample.robula.transf_add_attribute(xpath,element),chromex_sample.robula.transf_add_position(xpath,element),chromex_sample.robula.transf_add_level(xpath,element)], 0));
var paths = cljs.core.vec(cljs.core.distinct.cljs$core$IFn$_invoke$arity$1(new_xpath_list));
var temp__5733__auto__ = cljs.core.some(((function (xpath_list,doc,element,xpath,new_xpath_list,paths){
return (function (p1__80517_SHARP_){
if(chromex_sample.robula.unique_xpath_QMARK_(p1__80517_SHARP_,doc,element)){
return p1__80517_SHARP_;
} else {
return null;
}
});})(xpath_list,doc,element,xpath,new_xpath_list,paths))
,paths);
if(cljs.core.truth_(temp__5733__auto__)){
var result = temp__5733__auto__;
return chromex_sample.robula.xpath__GT_str(result);
} else {
var G__80518 = cljs.core.vec(cljs.core.concat.cljs$core$IFn$_invoke$arity$2(cljs.core.rest(xpath_list),paths));
var G__80519 = doc;
var G__80520 = element;
xpath_list = G__80518;
doc = G__80519;
element = G__80520;
continue;
}
} else {
return null;
}
break;
}
});
chromex_sample.robula.get_robust_xpath_base = (function chromex_sample$robula$get_robust_xpath_base(document,element){
return chromex_sample.robula.get_xpath_in_list(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [chromex_sample.robula.xpath_all], null),document,element);
});
chromex_sample.robula.get_robust_xpath = cljs.core.memoize(chromex_sample.robula.get_robust_xpath_base);
