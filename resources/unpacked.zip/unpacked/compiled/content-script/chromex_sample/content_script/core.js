// Compiled by ClojureScript 1.10.597 {:static-fns true, :optimize-constants true}
goog.provide('chromex_sample.content_script.core');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async');
goog.require('goog.string');
goog.require('chromex_sample.robula');
goog.require('clojure.string');
goog.require('cljs.pprint');
goog.require('dommy.core');
goog.require('oops.core');
goog.require('chromex.logging');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.ext.runtime');
chromex_sample.content_script.core.server = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
chromex_sample.content_script.core.process_message_BANG_ = (function chromex_sample$content_script$core$process_message_BANG_(message){
console.log("CONTENT SCRIPT: got message:",message);

return null;
});
chromex_sample.content_script.core.run_message_loop_BANG_ = (function chromex_sample$content_script$core$run_message_loop_BANG_(message_channel){
console.log("CONTENT SCRIPT: starting message loop...");


var c__24703__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__24704__auto__ = (function (){var switch__24634__auto__ = (function (state_36571){
var state_val_36572 = (state_36571[(1)]);
if((state_val_36572 === (1))){
var state_36571__$1 = state_36571;
var statearr_36573_36586 = state_36571__$1;
(statearr_36573_36586[(2)] = null);

(statearr_36573_36586[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_36572 === (2))){
var state_36571__$1 = state_36571;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_36571__$1,(4),message_channel);
} else {
if((state_val_36572 === (3))){
var inst_36569 = (state_36571[(2)]);
var state_36571__$1 = state_36571;
return cljs.core.async.impl.ioc_helpers.return_chan(state_36571__$1,inst_36569);
} else {
if((state_val_36572 === (4))){
var inst_36559 = (state_36571[(7)]);
var inst_36559__$1 = (state_36571[(2)]);
var inst_36560 = (inst_36559__$1 == null);
var state_36571__$1 = (function (){var statearr_36574 = state_36571;
(statearr_36574[(7)] = inst_36559__$1);

return statearr_36574;
})();
if(cljs.core.truth_(inst_36560)){
var statearr_36575_36587 = state_36571__$1;
(statearr_36575_36587[(1)] = (5));

} else {
var statearr_36576_36588 = state_36571__$1;
(statearr_36576_36588[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_36572 === (5))){
var state_36571__$1 = state_36571;
var statearr_36577_36589 = state_36571__$1;
(statearr_36577_36589[(2)] = null);

(statearr_36577_36589[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_36572 === (6))){
var inst_36559 = (state_36571[(7)]);
var inst_36563 = chromex_sample.content_script.core.process_message_BANG_(inst_36559);
var state_36571__$1 = (function (){var statearr_36578 = state_36571;
(statearr_36578[(8)] = inst_36563);

return statearr_36578;
})();
var statearr_36579_36590 = state_36571__$1;
(statearr_36579_36590[(2)] = null);

(statearr_36579_36590[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_36572 === (7))){
var inst_36566 = (state_36571[(2)]);
var inst_36567 = console.log("CONTENT SCRIPT: leaving message loop");
var state_36571__$1 = (function (){var statearr_36580 = state_36571;
(statearr_36580[(9)] = inst_36567);

(statearr_36580[(10)] = inst_36566);

return statearr_36580;
})();
var statearr_36581_36591 = state_36571__$1;
(statearr_36581_36591[(2)] = null);

(statearr_36581_36591[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});
return (function() {
var chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto__ = null;
var chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto____0 = (function (){
var statearr_36582 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_36582[(0)] = chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto__);

(statearr_36582[(1)] = (1));

return statearr_36582;
});
var chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto____1 = (function (state_36571){
while(true){
var ret_value__24636__auto__ = (function (){try{while(true){
var result__24637__auto__ = switch__24634__auto__(state_36571);
if(cljs.core.keyword_identical_QMARK_(result__24637__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__24637__auto__;
}
break;
}
}catch (e36583){if((e36583 instanceof Object)){
var ex__24638__auto__ = e36583;
var statearr_36584_36592 = state_36571;
(statearr_36584_36592[(5)] = ex__24638__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_36571);

return cljs.core.cst$kw$recur;
} else {
throw e36583;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__24636__auto__,cljs.core.cst$kw$recur)){
var G__36593 = state_36571;
state_36571 = G__36593;
continue;
} else {
return ret_value__24636__auto__;
}
break;
}
});
chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto__ = function(state_36571){
switch(arguments.length){
case 0:
return chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto____0.call(this);
case 1:
return chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto____1.call(this,state_36571);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto__.cljs$core$IFn$_invoke$arity$0 = chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto____0;
chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto__.cljs$core$IFn$_invoke$arity$1 = chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto____1;
return chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__24635__auto__;
})()
})();
var state__24705__auto__ = (function (){var statearr_36585 = (f__24704__auto__.cljs$core$IFn$_invoke$arity$0 ? f__24704__auto__.cljs$core$IFn$_invoke$arity$0() : f__24704__auto__.call(null));
(statearr_36585[(6)] = c__24703__auto__);

return statearr_36585;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__24705__auto__);
}));

return c__24703__auto__;
});
chromex_sample.content_script.core.do_page_analysis_BANG_ = (function chromex_sample$content_script$core$do_page_analysis_BANG_(background_port){
var script_elements = document.getElementsByTagName("a");
var script_count = script_elements.length;
var title = document.title;
var msg = ["CONTENT SCRIPT: document '",cljs.core.str.cljs$core$IFn$_invoke$arity$1(title),"' contains ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(script_count)," a tags."].join('');
console.log(msg);


return chromex.protocols.chrome_port.post_message_BANG_(background_port,msg);
});
chromex_sample.content_script.core.connect_to_background_page_BANG_ = (function chromex_sample$content_script$core$connect_to_background_page_BANG_(){
var background_port = chromex.ext.runtime.connect_STAR_(chromex.config.get_active_config(),cljs.core.cst$kw$omit,cljs.core.cst$kw$omit);
chromex.protocols.chrome_port.post_message_BANG_(background_port,"hello from CONTENT SCRIPT!");

cljs.core.reset_BANG_(chromex_sample.content_script.core.server,background_port);

chromex_sample.content_script.core.run_message_loop_BANG_(background_port);

return chromex_sample.content_script.core.do_page_analysis_BANG_(background_port);
});
chromex_sample.content_script.core.hook_event = (function chromex_sample$content_script$core$hook_event(var_args){
var G__36595 = arguments.length;
switch (G__36595) {
case 3:
return chromex_sample.content_script.core.hook_event.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return chromex_sample.content_script.core.hook_event.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(chromex_sample.content_script.core.hook_event.cljs$core$IFn$_invoke$arity$3 = (function (target,event_name,event_listener){
return chromex_sample.content_script.core.hook_event.cljs$core$IFn$_invoke$arity$4(target,event_name,event_listener,true);
}));

(chromex_sample.content_script.core.hook_event.cljs$core$IFn$_invoke$arity$4 = (function (target,event_name,event_listener,use_capture){
return target.addEventListener(cljs.core.name(event_name),event_listener,use_capture);
}));

(chromex_sample.content_script.core.hook_event.cljs$lang$maxFixedArity = 4);

/**
 * 发送命令消息
 */
chromex_sample.content_script.core.send_command = (function chromex_sample$content_script$core$send_command(data){
return chromex.protocols.chrome_port.post_message_BANG_(cljs.core.deref(chromex_sample.content_script.core.server),cljs.core.clj__GT_js(new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$type,"command",cljs.core.cst$kw$cmd_DASH_data,data], null)));
});
chromex_sample.content_script.core.trim_http_protocol = (function chromex_sample$content_script$core$trim_http_protocol(url){
return clojure.string.replace(url,/^https?:/,"");
});
chromex_sample.content_script.core.in_iframe = cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(window,top);
chromex_sample.content_script.core.get_parent_frames = (function chromex_sample$content_script$core$get_parent_frames(){
var frames = (function (){var target_obj_36598 = parent;
var next_obj_36599 = (target_obj_36598["frames"]);
return next_obj_36599;
})();
var length = (function (){var target_obj_36600 = frames;
var next_obj_36601 = (target_obj_36600["length"]);
return next_obj_36601;
})();
return cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p1__36597_SHARP_){
var target_obj_36602 = frames;
return oops.core.get_selector_dynamically(target_obj_36602,cljs.core.str.cljs$core$IFn$_invoke$arity$1(p1__36597_SHARP_));
}),cljs.core.range.cljs$core$IFn$_invoke$arity$1(length));
});
chromex_sample.content_script.core.get_frame_info = (function chromex_sample$content_script$core$get_frame_info(){
if(chromex_sample.content_script.core.in_iframe){
var temp__5733__auto__ = (function (){var target_obj_36603 = window;
var next_obj_36604 = (target_obj_36603["frameElement"]);
return next_obj_36604;
})();
if(cljs.core.truth_(temp__5733__auto__)){
var frame = temp__5733__auto__;
return new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$type,"same-orgin",cljs.core.cst$kw$path,(function (){var G__36605 = (function (){var target_obj_36607 = window;
var next_obj_36608 = (target_obj_36607["parent"]);
var next_obj_36609 = (next_obj_36608["document"]);
return next_obj_36609;
})();
var G__36606 = frame;
return (chromex_sample.robula.get_robust_xpath.cljs$core$IFn$_invoke$arity$2 ? chromex_sample.robula.get_robust_xpath.cljs$core$IFn$_invoke$arity$2(G__36605,G__36606) : chromex_sample.robula.get_robust_xpath.call(null,G__36605,G__36606));
})()], null);
} else {
var temp__5733__auto____$1 = chromex_sample.content_script.core.get_parent_frames().indexOf(window);
if(cljs.core.truth_(temp__5733__auto____$1)){
var window_idx = temp__5733__auto____$1;
return new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$type,"cross-domain",cljs.core.cst$kw$window_DASH_index,window_idx], null);
} else {
return new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$type,"cross-domain",cljs.core.cst$kw$location,chromex_sample.content_script.core.trim_http_protocol((function (){var target_obj_36610 = location;
var next_obj_36611 = (target_obj_36610["href"]);
return next_obj_36611;
})())], null);
}
}
} else {
return null;
}
});
chromex_sample.content_script.core.get_cross_domain_frame_xpath_by_index = (function chromex_sample$content_script$core$get_cross_domain_frame_xpath_by_index(index){
var frame_window = (function (){var target_obj_36613 = window;
return oops.core.get_selector_dynamically(target_obj_36613,["frames",cljs.core.str.cljs$core$IFn$_invoke$arity$1(index)]);
})();
var frame_dom = (function (){var G__36614 = dommy.utils.__GT_Array(document.getElementsByTagName("iframe"));
var G__36614__$1 = (((G__36614 == null))?null:cljs.core.filter.cljs$core$IFn$_invoke$arity$2((function (p1__36612_SHARP_){
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(frame_window,(function (){var target_obj_36615 = p1__36612_SHARP_;
var next_obj_36616 = (target_obj_36615["contentWindow"]);
return next_obj_36616;
})());
}),G__36614));
if((G__36614__$1 == null)){
return null;
} else {
return cljs.core.first(G__36614__$1);
}
})();
console.log("frame-xpath-by-index dom:",frame_dom);


if(cljs.core.truth_(frame_dom)){
return (chromex_sample.robula.get_robust_xpath.cljs$core$IFn$_invoke$arity$2 ? chromex_sample.robula.get_robust_xpath.cljs$core$IFn$_invoke$arity$2(document,frame_dom) : chromex_sample.robula.get_robust_xpath.call(null,document,frame_dom));
} else {
console.error("get-cross-domain-frame-xpath-by-index can't find frame index:",index);

return null;
}
});
chromex_sample.content_script.core.get_cross_domain_frame_xpath_by_location = (function chromex_sample$content_script$core$get_cross_domain_frame_xpath_by_location(frame_location){
var frame_dom = (function (){var G__36617 = dommy.utils.__GT_Array(document.querySelectorAll("* /deep/ iframe"));
var G__36617__$1 = (((G__36617 == null))?null:cljs.core.filter.cljs$core$IFn$_invoke$arity$2((function (dom){
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(chromex_sample.content_script.core.trim_http_protocol((function (){var target_obj_36618 = dom;
var next_obj_36619 = (target_obj_36618["src"]);
return next_obj_36619;
})()),frame_location);
}),G__36617));
if((G__36617__$1 == null)){
return null;
} else {
return cljs.core.first(G__36617__$1);
}
})();
if(cljs.core.truth_(frame_dom)){
return (chromex_sample.robula.get_robust_xpath.cljs$core$IFn$_invoke$arity$2 ? chromex_sample.robula.get_robust_xpath.cljs$core$IFn$_invoke$arity$2(document,frame_dom) : chromex_sample.robula.get_robust_xpath.call(null,document,frame_dom));
} else {
console.error("get-cross-domain-frame-xpath can't find frame location:",frame_location);

return null;
}
});
chromex_sample.content_script.core.save_command = (function chromex_sample$content_script$core$save_command(cmd,data){
var frame_info = chromex_sample.content_script.core.get_frame_info();
if(("cross-domain" === cljs.core.cst$kw$type.cljs$core$IFn$_invoke$arity$1(frame_info))){
console.log("save-command post parent!");


return parent.postMessage(({"type": "ntr-frame-command", "data": cljs.core.clj__GT_js(new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$frame,frame_info,cljs.core.cst$kw$cmd,cmd,cljs.core.cst$kw$data,data], null))}),"*");
} else {
return chromex_sample.content_script.core.send_command(new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$frame_DASH_path,cljs.core.cst$kw$path.cljs$core$IFn$_invoke$arity$1(frame_info),cljs.core.cst$kw$cmd,cmd,cljs.core.cst$kw$data,data], null));
}
});
/**
 * 消息处理函数
 */
chromex_sample.content_script.core.message_proc = (function chromex_sample$content_script$core$message_proc(e){
console.log("message proc!!");


var data = cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$variadic((function (){var target_obj_36620 = e;
var next_obj_36621 = (target_obj_36620["data"]);
return next_obj_36621;
})(),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([cljs.core.cst$kw$keywordize_DASH_keys,true], 0));
console.log("message-proc data:",data);


var G__36622 = cljs.core.cst$kw$type.cljs$core$IFn$_invoke$arity$1(data);
switch (G__36622) {
case "ntr-alert-command":
var cmd_info = cljs.core.cst$kw$cmd_DASH_info.cljs$core$IFn$_invoke$arity$1(data);
return chromex_sample.content_script.core.save_command(cljs.core.cst$kw$cmd.cljs$core$IFn$_invoke$arity$1(cmd_info),cljs.core.cst$kw$data.cljs$core$IFn$_invoke$arity$1(cmd_info));

break;
case "ntr-frame-command":
var data__$1 = cljs.core.cst$kw$data.cljs$core$IFn$_invoke$arity$1(data);
var frame = cljs.core.cst$kw$frame.cljs$core$IFn$_invoke$arity$1(data__$1);
var frame_path = (cljs.core.truth_(cljs.core.cst$kw$window_DASH_index.cljs$core$IFn$_invoke$arity$1(frame))?chromex_sample.content_script.core.get_cross_domain_frame_xpath_by_index(cljs.core.cst$kw$window_DASH_index.cljs$core$IFn$_invoke$arity$1(frame)):(cljs.core.truth_(cljs.core.cst$kw$location.cljs$core$IFn$_invoke$arity$1(frame))?chromex_sample.content_script.core.get_cross_domain_frame_xpath_by_location(cljs.core.cst$kw$location.cljs$core$IFn$_invoke$arity$1(frame)):null));
console.log("ntr-frame-command proc path:",frame_path);


return chromex_sample.content_script.core.send_command(new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$frame_DASH_path,frame_path,cljs.core.cst$kw$cmd,cljs.core.cst$kw$cmd.cljs$core$IFn$_invoke$arity$1(data__$1),cljs.core.cst$kw$data,cljs.core.cst$kw$data.cljs$core$IFn$_invoke$arity$1(data__$1)], null));

break;
default:
console.error("message-proc unknown message:",data);

return null;

}
});
chromex_sample.content_script.core.uniq_id_QMARK_ = (function chromex_sample$content_script$core$uniq_id_QMARK_(id){
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.count(dommy.utils.__GT_Array(document.querySelectorAll(dommy.core.selector(["#",cljs.core.str.cljs$core$IFn$_invoke$arity$1(id)].join(''))))),(1));
});
chromex_sample.content_script.core.ele_name = (function chromex_sample$content_script$core$ele_name(ele){
return clojure.string.lower_case((function (){var target_obj_36624 = ele;
var next_obj_36625 = (target_obj_36624["localName"]);
return next_obj_36625;
})());
});
chromex_sample.content_script.core.xpath_ele_id = (function chromex_sample$content_script$core$xpath_ele_id(ele){
return [chromex_sample.content_script.core.ele_name(ele),"[@id=\"",cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var target_obj_36628 = ele;
var next_obj_36629 = (target_obj_36628["id"]);
return next_obj_36629;
})()),"\"]"].join('');
});
chromex_sample.content_script.core.xpath_ele_class = (function chromex_sample$content_script$core$xpath_ele_class(ele){
return [chromex_sample.content_script.core.ele_name(ele),"[@class=\"",cljs.core.str.cljs$core$IFn$_invoke$arity$1(dommy.core.class$(ele)),"\"]"].join('');
});
chromex_sample.content_script.core.previous_siblings = (function chromex_sample$content_script$core$previous_siblings(ele){
var prev = (function (){var target_obj_36630 = ele;
var next_obj_36631 = (target_obj_36630["previousSibling"]);
return next_obj_36631;
})();
if(cljs.core.truth_(prev)){
return cljs.core.cons(prev,(new cljs.core.LazySeq(null,(function (){
return (chromex_sample.content_script.core.previous_siblings.cljs$core$IFn$_invoke$arity$1 ? chromex_sample.content_script.core.previous_siblings.cljs$core$IFn$_invoke$arity$1(prev) : chromex_sample.content_script.core.previous_siblings.call(null,prev));
}),null,null)));
} else {
return cljs.core.PersistentVector.EMPTY;
}
});
chromex_sample.content_script.core.previous_sibling_elements = (function chromex_sample$content_script$core$previous_sibling_elements(ele){
return cljs.core.filter.cljs$core$IFn$_invoke$arity$2((function (p1__36632_SHARP_){
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((function (){var target_obj_36633 = p1__36632_SHARP_;
var next_obj_36634 = (target_obj_36633["nodeType"]);
return next_obj_36634;
})(),(1));
}),chromex_sample.content_script.core.previous_siblings(ele));
});
/**
 * 构造元素的xpath, 比较简单，适应性较差
 */
chromex_sample.content_script.core.make_xpath = (function chromex_sample$content_script$core$make_xpath(element){
var ele = element;
var segs = cljs.core.PersistentVector.EMPTY;
while(true){
if(cljs.core.truth_((function (){var and__4174__auto__ = ele;
if(cljs.core.truth_(and__4174__auto__)){
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((function (){var target_obj_36646 = ele;
var next_obj_36647 = (target_obj_36646["nodeType"]);
return next_obj_36647;
})(),(1));
} else {
return and__4174__auto__;
}
})())){
var next_ele = (function (){var target_obj_36648 = ele;
var next_obj_36649 = (target_obj_36648["parentNode"]);
return next_obj_36649;
})();
if(cljs.core.truth_(ele.hasAttribute("id"))){
var id = (function (){var target_obj_36650 = ele;
var next_obj_36651 = (target_obj_36650["id"]);
return next_obj_36651;
})();
if(chromex_sample.content_script.core.uniq_id_QMARK_(id)){
return clojure.string.join.cljs$core$IFn$_invoke$arity$2("/",cljs.core.cons(["id(\"",cljs.core.str.cljs$core$IFn$_invoke$arity$1(id),"\")"].join(''),segs));
} else {
var G__36656 = next_ele;
var G__36657 = cljs.core.cons(chromex_sample.content_script.core.xpath_ele_id(ele),segs);
ele = G__36656;
segs = G__36657;
continue;
}
} else {
if(cljs.core.truth_(ele.hasAttribute("class"))){
var G__36658 = next_ele;
var G__36659 = cljs.core.cons(chromex_sample.content_script.core.xpath_ele_class(ele),segs);
ele = G__36658;
segs = G__36659;
continue;
} else {
var index = (cljs.core.count(cljs.core.filter.cljs$core$IFn$_invoke$arity$2(((function (ele,segs,next_ele){
return (function (p1__36635_SHARP_){
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((function (){var target_obj_36652 = p1__36635_SHARP_;
var next_obj_36653 = (target_obj_36652["localName"]);
return next_obj_36653;
})(),(function (){var target_obj_36654 = ele;
var next_obj_36655 = (target_obj_36654["localName"]);
return next_obj_36655;
})());
});})(ele,segs,next_ele))
,chromex_sample.content_script.core.previous_sibling_elements(ele))) + (1));
var G__36660 = next_ele;
var G__36661 = cljs.core.cons([chromex_sample.content_script.core.ele_name(ele),"[",cljs.core.str.cljs$core$IFn$_invoke$arity$1(index),"]"].join(''),segs);
ele = G__36660;
segs = G__36661;
continue;

}
}
} else {
if(cljs.core.empty_QMARK_(segs)){
return null;
} else {
return ["/",clojure.string.join.cljs$core$IFn$_invoke$arity$2("/",segs)].join('');
}
}
break;
}
});
chromex_sample.content_script.core.lookup_element_by_xpath = (function chromex_sample$content_script$core$lookup_element_by_xpath(xpath){
var evaluator = (new XPathEvaluator());
var target_obj_36662 = evaluator.evaluate(xpath,(function (){var target_obj_36664 = document;
var next_obj_36665 = (target_obj_36664["documentElement"]);
return next_obj_36665;
})(),null,(function (){var target_obj_36666 = XPathResult;
var next_obj_36667 = (target_obj_36666["FIRST_ORDERED_NODE_TYPE"]);
return next_obj_36667;
})(),null);
var next_obj_36663 = (target_obj_36662["singleNodeValue"]);
return next_obj_36663;
});
chromex_sample.content_script.core.my_eval = (function chromex_sample$content_script$core$my_eval(code){
var head = document.head;
var script = dommy.core.create_element.cljs$core$IFn$_invoke$arity$1("script");
dommy.core.set_html_BANG_(script,["(",cljs.core.str.cljs$core$IFn$_invoke$arity$1(code),")()"].join(''));

return dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2(head,script);
});
chromex_sample.content_script.core.last_ele = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
chromex_sample.content_script.core.remove_mark = (function chromex_sample$content_script$core$remove_mark(ele){
if(cljs.core.truth_(ele)){
dommy.core.remove_style_BANG_.cljs$core$IFn$_invoke$arity$variadic(ele,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([cljs.core.cst$kw$box_DASH_shadow], 0));

return cljs.core.reset_BANG_(chromex_sample.content_script.core.last_ele,null);
} else {
return null;
}
});
chromex_sample.content_script.core.mark_element = (function chromex_sample$content_script$core$mark_element(ele){
if(cljs.core.truth_(ele)){
dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic(ele,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([cljs.core.cst$kw$box_DASH_shadow,"0px 0px 2px 2px blue"], 0));

return cljs.core.reset_BANG_(chromex_sample.content_script.core.last_ele,ele);
} else {
return null;
}
});
chromex_sample.content_script.core.handle_mouse_move = (function chromex_sample$content_script$core$handle_mouse_move(e){
var x = e.clientX;
var y = e.clientY;
console.log("x:",x," y:",y);


var temp__5733__auto__ = document.elementFromPoint(x,y);
if(cljs.core.truth_(temp__5733__auto__)){
var ele = temp__5733__auto__;
var temp__5735__auto___36668 = cljs.core.deref(chromex_sample.content_script.core.last_ele);
if(cljs.core.truth_(temp__5735__auto___36668)){
var prev_ele_36669 = temp__5735__auto___36668;
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(ele,prev_ele_36669)){
} else {
chromex_sample.content_script.core.remove_mark(prev_ele_36669);
}
} else {
}

chromex_sample.content_script.core.mark_element(ele);

chromex_sample.content_script.core.save_command("mouse-move",new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$x,x,cljs.core.cst$kw$y,y], null));

console.log("elements xpath:",(chromex_sample.robula.get_robust_xpath.cljs$core$IFn$_invoke$arity$2 ? chromex_sample.robula.get_robust_xpath.cljs$core$IFn$_invoke$arity$2(document,ele) : chromex_sample.robula.get_robust_xpath.call(null,document,ele)));

return null;
} else {
return chromex_sample.content_script.core.remove_mark(cljs.core.deref(chromex_sample.content_script.core.last_ele));
}
});
chromex_sample.content_script.core.bytes_len = (function chromex_sample$content_script$core$bytes_len(text){
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$2(cljs.core._PLUS_,cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p1__36670_SHARP_){
if((cljs.pprint.char_code(p1__36670_SHARP_) > (255))){
return (2);
} else {
return (1);
}
}),text));
});
chromex_sample.content_script.core.format_text = (function chromex_sample$content_script$core$format_text(text){
var trimed_text = clojure.string.trim(clojure.string.replace(text,/\s*\r?\n\s*/," "));
var pred__36671 = cljs.core._LT_;
var expr__36672 = chromex_sample.content_script.core.bytes_len(trimed_text);
if(cljs.core.truth_((pred__36671.cljs$core$IFn$_invoke$arity$2 ? pred__36671.cljs$core$IFn$_invoke$arity$2((60),expr__36672) : pred__36671.call(null,(60),expr__36672)))){
return "";
} else {
if(cljs.core.truth_((pred__36671.cljs$core$IFn$_invoke$arity$2 ? pred__36671.cljs$core$IFn$_invoke$arity$2((20),expr__36672) : pred__36671.call(null,(20),expr__36672)))){
return [cljs.core.subs.cljs$core$IFn$_invoke$arity$3(trimed_text,(0),(20)),"..."].join('');
} else {
return trimed_text;
}
}
});
chromex_sample.content_script.core.get_target_text = (function chromex_sample$content_script$core$get_target_text(element){
return chromex_sample.content_script.core.format_text((function (){var G__36674 = (function (){var target_obj_36675 = element;
var next_obj_36676 = (target_obj_36675["nodeName"]);
return next_obj_36676;
})();
switch (G__36674) {
case "INPUT":
if(cljs.core.truth_((function (){var G__36678 = dommy.core.attr(element,cljs.core.cst$kw$type);
var fexpr__36677 = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 3, ["reset",null,"submit",null,"button",null], null), null);
return (fexpr__36677.cljs$core$IFn$_invoke$arity$1 ? fexpr__36677.cljs$core$IFn$_invoke$arity$1(G__36678) : fexpr__36677.call(null,G__36678));
})())){
return dommy.core.attr(element,cljs.core.cst$kw$value);
} else {
var parent_node = dommy.core.parent(element);
var id = dommy.core.attr(element,cljs.core.cst$kw$id);
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2("LABEL",(function (){var target_obj_36679 = parent_node;
var next_obj_36680 = (target_obj_36679["nodeName"]);
return next_obj_36680;
})())){
return dommy.core.text(parent_node);
} else {
if(cljs.core.truth_(id)){
var temp__5733__auto__ = document.querySelector(dommy.core.selector(goog.string.format("label[for='%s']",id)));
if(cljs.core.truth_(temp__5733__auto__)){
var label_ele = temp__5733__auto__;
return dommy.core.text(label_ele);
} else {
return dommy.core.attr(element,cljs.core.cst$kw$name);
}
} else {
return dommy.core.attr(element,cljs.core.cst$kw$name);

}
}
}

break;
case "SELECT":
return dommy.core.attr(element,cljs.core.cst$kw$name);

break;
default:
return dommy.core.text(element);

}
})());
});
/**
 * 获取事件的目标
 */
chromex_sample.content_script.core.event_target = (function chromex_sample$content_script$core$event_target(event){
var target = event.target;
if(cljs.core.truth_(target.shadowRoot)){
return cljs.core.first(event.path);
} else {
return target;
}
});
/**
 * 获取label指向的目标,不含label指向则返回nil
 */
chromex_sample.content_script.core.get_label_target = (function chromex_sample$content_script$core$get_label_target(target){
if(((function (){var target_obj_36682 = target;
var next_obj_36683 = (target_obj_36682["nodeName"]);
return next_obj_36683;
})() === "INPUT")){
return null;
} else {
var temp__5735__auto__ = ((((function (){var target_obj_36684 = target;
var next_obj_36685 = (target_obj_36684["nodeName"]);
return next_obj_36685;
})() === "LABEL"))?target:((((function (){var target_obj_36686 = target;
var next_obj_36687 = (target_obj_36686["parentNode"]);
var next_obj_36688 = (next_obj_36687["nodeName"]);
return next_obj_36688;
})() === "LABEL"))?(function (){var target_obj_36689 = target;
var next_obj_36690 = (target_obj_36689["parentNode"]);
return next_obj_36690;
})():null));
if(cljs.core.truth_(temp__5735__auto__)){
var label = temp__5735__auto__;
var temp__5733__auto__ = dommy.core.attr(label,"for");
if(cljs.core.truth_(temp__5733__auto__)){
var for_value = temp__5733__auto__;
return document.querySelector(dommy.core.selector(["#",cljs.core.str.cljs$core$IFn$_invoke$arity$1(for_value)].join('')));
} else {
return (dommy.utils.__GT_Array(label.getElementsByTagName("input"))[(0)]);
}
} else {
return null;
}
}
});
chromex_sample.content_script.core.mouse_not_in_scroll_QMARK_ = (function chromex_sample$content_script$core$mouse_not_in_scroll_QMARK_(event){
var target = event.target;
return (((!((((target.clientWidth > (0))) && ((event.offsetX >= target.clientWidth)))))) && ((!((((target.clientHeight > (0))) && ((event.offsetY >= target.clientHeight)))))));
});
/**
 * 是否为鼠标可操作的目标
 */
chromex_sample.content_script.core.mouse_opable_target_QMARK_ = (function chromex_sample$content_script$core$mouse_opable_target_QMARK_(target){
return cljs.core.not(cljs.core.re_matches(/html|select|optgroup|option/i,(function (){var target_obj_36691 = target;
var next_obj_36692 = (target_obj_36691["tagName"]);
return next_obj_36692;
})()));
});
/**
 * 是否为文件输入
 */
chromex_sample.content_script.core.file_input_QMARK_ = (function chromex_sample$content_script$core$file_input_QMARK_(target){
return ((((function (){var target_obj_36695 = target;
var next_obj_36696 = (target_obj_36695["tagName"]);
return next_obj_36696;
})() === "INPUT")) && ((dommy.core.attr(target,cljs.core.cst$kw$type) === "file")));
});
/**
 * 是否为上传角色
 */
chromex_sample.content_script.core.upload_role_QMARK_ = (function chromex_sample$content_script$core$upload_role_QMARK_(target){
if(cljs.core.truth_(target)){
var role = (function (){var or__4185__auto__ = dommy.core.attr(target,cljs.core.cst$kw$role);
if(cljs.core.truth_(or__4185__auto__)){
return or__4185__auto__;
} else {
return dommy.core.attr(target,cljs.core.cst$kw$data_DASH_role);
}
})();
if(cljs.core.truth_(cljs.core.re_matches(/upload|file/i,role))){
return true;
} else {
var G__36697 = (function (){var target_obj_36698 = target;
var next_obj_36699 = (target_obj_36698["parentNode"]);
return next_obj_36699;
})();
return (chromex_sample.content_script.core.upload_role_QMARK_.cljs$core$IFn$_invoke$arity$1 ? chromex_sample.content_script.core.upload_role_QMARK_.cljs$core$IFn$_invoke$arity$1(G__36697) : chromex_sample.content_script.core.upload_role_QMARK_.call(null,G__36697));
}
} else {
return null;
}
});
/**
 * 是否为上传元素
 */
chromex_sample.content_script.core.upload_element_QMARK_ = (function chromex_sample$content_script$core$upload_element_QMARK_(target){
var or__4185__auto__ = chromex_sample.content_script.core.file_input_QMARK_(target);
if(or__4185__auto__){
return or__4185__auto__;
} else {
return chromex_sample.content_script.core.upload_role_QMARK_(target);
}
});
chromex_sample.content_script.core.handle_mouse_down = (function chromex_sample$content_script$core$handle_mouse_down(e){
return null;
});
if(chromex_sample.content_script.core.in_iframe){
console.log("CONTENT SCRIPT: in iframe");

} else {
}
chromex_sample.content_script.core.init_BANG_ = (function chromex_sample$content_script$core$init_BANG_(){
console.log("CONTENT SCRIPT: init");


return dommy.core.listen_BANG_.cljs$core$IFn$_invoke$arity$variadic(document,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([cljs.core.cst$kw$DOMContentLoaded,(function (){
console.log("dom content loaded!");


chromex_sample.content_script.core.hook_event.cljs$core$IFn$_invoke$arity$3(window,"message",chromex_sample.content_script.core.message_proc);

chromex_sample.content_script.core.hook_event.cljs$core$IFn$_invoke$arity$3(document,cljs.core.cst$kw$mousemove,chromex_sample.content_script.core.handle_mouse_move);

chromex_sample.content_script.core.connect_to_background_page_BANG_();

return chromex_sample.content_script.core.my_eval("// hook alert, confirm, prompt\nfunction hookAlertFunction(){\n    var rawAlert = window.alert;\n    function sendAlertCmd(cmd, data){\n        var cmdInfo = {\n            cmd: cmd,\n            data: data || {}\n        };\n        window.postMessage({\n            'type': 'ntr-alert-command',\n            'cmd-info': cmdInfo\n        }, '*');\n    }\n    window.alert = function(str){\n        var ret = rawAlert.call(this, str);\n        sendAlertCmd('acceptAlert');\n        return ret;\n    }\n    var rawConfirm = window.confirm;\n    window.confirm = function(str){\n        var ret = rawConfirm.call(this, str);\n        sendAlertCmd(ret?'acceptAlert':'dismissAlert');\n        return ret;\n    }\n    var rawPrompt = window.prompt;\n    window.prompt = function(str){\n        var ret = rawPrompt.call(this, str);\n        if(ret === null){\n            sendAlertCmd('dismissAlert');\n        }\n        else{\n            sendAlertCmd('setAlert', {\n                text: ret\n            });\n            sendAlertCmd('acceptAlert');\n        }\n        return ret;\n    }\n    function wrapBeforeUnloadListener(oldListener){\n        var newListener = function(e){\n            var returnValue = oldListener(e);\n            if(returnValue){\n                sendAlertCmd('acceptAlert');\n            }\n            return returnValue;\n        }\n        return newListener;\n    }\n    var rawAddEventListener = window.addEventListener;\n    window.addEventListener = function(type, listener, useCapture){\n        if(type === 'beforeunload'){\n            listener = wrapBeforeUnloadListener(listener);\n        }\n        return rawAddEventListener.call(window, type, listener, useCapture);\n    };\n    setTimeout(function(){\n        var oldBeforeunload = window.onbeforeunload;\n        if(oldBeforeunload){\n            window.onbeforeunload = wrapBeforeUnloadListener(oldBeforeunload)\n        }\n    }, 1000);\n}\n");
})], 0));
});
